# Changelog

Each version of `@cognitio/a11y` is a git tag of its repository,
`a11y-vX.Y.Z`, whose release publishes the archive a site vendors from
`https://tooling.cognitio.it/a11y/archives/a11y-X.Y.Z.tgz`;
`https://tooling.cognitio.it/a11y/index.json` lists every published version
with its archive's sha256. 1.0.0 holds every feature the package has at its
first release; a feature added after it is recorded under the next version,
above this one.

## 1.2.1

- The button's side follows the page's writing direction: `left` is the side where a line starts. On a page with `dir="rtl"` a button configured at the bottom right sits at the bottom left, and the panel opens from that corner. A side the visitor chose by moving the button is mirrored the same way, and the command that moves it names the side it moves to on the screen. On a left-to-right page nothing changes.
- The magnifier and the descriptions open beside the pointer toward where the text under it reads: to its left in a right-to-left text.
- Compatibility: the root's offset is written as `inset-inline-start` or `inset-inline-end` instead of `left` or `right`, and the panel is placed the same way. A site that places the button in its own stylesheet on a right-to-left page uses the same logical properties, so the panel opens on its side. No export, prop or file is removed or renamed.

## 1.2.0

- The panel speaks 42 languages: `locales/<tag>.json` ships its texts in `en`, `it`, `de`, `fr`, `es`, `pt-BR`, `pt`, `zh-Hans`, `zh-Hant`, `ja`, `ko`, `pl`, `tr`, `uk`, `id`, `vi`, `ru`, `hi`, `ar`, `bg`, `cs`, `da`, `nl`, `el`, `et`, `fi`, `ga`, `hr`, `hu`, `lt`, `lv`, `mt`, `ro`, `sk`, `sl`, `sv`, `nb`, `is`, `sr`, `bs`, `sq` and `mk`, and `SHIPPED_LANGUAGES` lists them. The `texts` prop of the panel takes a list of layers: the project's own texts first, then the shipped table, then the built-in English, then the key.
- The import: `import TEXTS from '@cognitio/a11y/project-locales'` gives the tables of exactly the declared languages, keyed by the project's tags, once the project declares them as `"projectLanguages"` in its `package.json` and registers `projectLanguagesPlugin()` from `@cognitio/languages/vite`; the panel takes `texts={[TEXTS[lang]]}`. Without the declaration, a site imports `@cognitio/a11y/locales/<lang>` by hand, one file per language it publishes.
- `texts` is optional: a panel given none shows the built-in English.
- On a page whose language is not English, when no layer answers any key, the panel's root carries `lang="en"`, so a screen reader reads its texts as English; the page's own text inside the panel keeps the page's language (the headings of the page-structure list, the magnifier's and the descriptions' copies of the page's text, a profile the site adds).
- Compatibility: a site passing its own complete texts sees no change; a key a site leaves unset reads English instead of the key's name. No export, prop or file is removed or renamed.
- `@cognitio/languages` is an optional peer; a project that reads its languages from the declaration adds it with `sh install.sh add @cognitio/languages`.
- The shipped translations are machine translations that a native speaker has not reviewed yet; a correction to any of them is welcome, as an issue or as a change to its `locales/<tag>.json`.

## 1.1.0

- The panel lays itself out in the page's writing direction: on a page with
  `dir="rtl"` the rows of the panel, the page-structure indent and the reading
  mode's lists and tables start on the right. On a left-to-right page nothing
  changes. The align options and the button's side stay physical.
- Under the letter-spacing preference, text whose language is Arabic
  (`:lang(ar)`) keeps its letters joined; its word spacing still follows the
  preference.

## 1.0.1

- The open panel lies inside the window, on a phone held sideways too: its
  height leaves room for the button's distance from the bottom, written on the
  root as `--a11y-bottom` from `position.bottom` (a site that places the button
  in its stylesheet declares it there), and follows the window shown now where
  the browser measures it, as a phone's toolbars come and go. In a short
  window, such as a phone held sideways, the panel's top was above the
  window's.
- On a screen up to 640px wide the panel opens 60px above the button's bottom,
  as the stylesheet intended; it opened 68px above it, the wide screen's gap.
- The README and the type declarations state the button's two corners,
  `position.side` `left` (the default) or `right`.

## 1.0.0

The package joins three copies of the same accessibility kit, each kept until
now inside a site: two of the current panel of tiles (one with every
identifier renamed), and one of the earlier, simpler panel of switches that the
current one replaced. Given the configuration, texts and variables its site
passes, the panel renders the DOM the current copies render through the same
interactions, its stylesheet yields their rules, its preferences are saved
under the same keys and applied as the same classes, and the command writes
the report their scripts write on the same pages, apart from the differences
listed below.

- `@cognitio/a11y/toolbar`: the panel `AccessibilityToolbar`, with its parts
  `AccessibilityTools`, `PageStructure`, `ReadingMode` and `useReadAloud`, and
  `TEXT_KEYS`; plain JavaScript through `React.createElement`, loadable by a
  server-side render as it is.
- `@cognitio/a11y/toolbar.css`: the panel's stylesheet and the rules of the
  preferences, with every colour, font and radius a `--a11y-*` variable.
- `@cognitio/a11y` (and `@cognitio/a11y/prefs`): the preferences with no
  framework — storage, normalization, profiles, the button's place, the
  shortcut, the classes and variables on `<html>`, the open and change events,
  reduced motion.
- The `cognitio-a11y-report` command and `@cognitio/a11y/report`: the axe-core
  check of the built site in Chromium, reported in English or Italian.
- Type declarations for every entry.

### How the three copies differed

Each difference is listed with what became of it: brought into the package as a
correction or a capability (a), a site's value moved into the site's
configuration, texts or stylesheet (b), or the site's own behaviour, which
stays in the site (c). A capability only one copy had is off unless the
configuration turns it on, so the other copies' output is unchanged.

The panel:

- (a) The panel of tiles replaces the earlier panel of switches (text size
  buttons, five switches). Preferences saved by the earlier panel are carried
  over to their counterparts, as the current copies already did: contrast to
  high contrast, underlined links to highlighted links, readable font, wide
  line spacing to the first line-height level, large cursor to the black one.
- (b) Every text came from the site's dictionary, under different keys in each
  copy: the panel reads them through `texts`, by the keys `TEXT_KEYS` lists.
  One copy added the site's host to the report's subject; the subject is a
  text, so a site that wants the host adds it in `texts`.
- (b) The configuration, the profiles' names and the stored preferences of one
  copy were written with other identifiers. The package keeps the current
  names; `migratePrefs` and `migrateButtonPrefs` let a site convert what its
  visitors saved in its own earlier shape, under the same storage keys.
- (b) The storage keys: `storageKey`, and `buttonStorageKey`, which one copy
  named on its own and the other derived as `<storageKey>-button`, still the
  default.
- (b) The statement's route was built in each copy from its own locale rules:
  the site passes `statementHref`, and `linkComponent` for its router. The
  read-aloud voice's language tag: `speechLang`.
- (a) The command that hides the button is shown only with the `hideButton`
  feature, as one copy did, since a hidden button needs the site's own link to
  open the panel again; a button hidden while the command was on shows again
  when it is turned off.
- (a) The report link is shown only with a `feedbackEmail`, as one copy did.
- (b) The button's symbol size (`buttonIconSize`) and its inline position: one
  copy placed the button in its stylesheet, with offsets of its own beside
  other fixed controls (c: those rules stay in that site); `position.offset`
  set to `""` and no `bottom` leave the place to the stylesheet.
- (a) The tools' layers are positioned in their event handlers rather than in
  render, and a pointer event with no coordinates places them at 0, as one copy
  did; the other placed them nowhere.
- (a) Reading mode looks up its portal's node after mount, as one copy did, so
  a server-side render never touches `document`.
- (a) The tools' layers render inside the panel's root, as one copy did; in
  another they sat beside it, so dark contrast inverted them with the page.
  They now keep their real colours, like the panel.
- (a) The change event is `a11y:change` and the open event `a11y:open`; one copy
  named both after its site and another the change event. A site's own
  listeners import `A11Y_CHANGE_EVENT`.
- (a) `prefersReducedMotion`, which each copy kept in its own code.
- (c) The panel's mount in the layout, the footer link that opens it, the skip
  link, the accessibility statement page and the site's dictionary stay in the
  sites.

The stylesheet:

- (b) Each copy wrote its theme's colours into its rules, some as fallbacks,
  some outside the panel, where the theme's variables did not reach: every
  colour, font and radius is now a `--a11y-*` variable with a neutral fallback,
  and the variables the rules outside the panel read are declared by the site
  on `:root`. Added for that: `--a11y-focus`, `--a11y-on-accent`,
  `--a11y-control-radius`, `--a11y-button-shadow`,
  `--a11y-reading-button-background`, `--a11y-reading-z-index`,
  `--a11y-readable-font` and `--a11y-dyslexic-font`.
- (b) The reading fonts' `@font-face` imports move to the site, which installs
  the fonts it offers.
- (b) The class of the site's content wrapper is `site-shell` in every rule;
  one copy named it otherwise, and the earlier panel's rules targeted the
  page's `main`, `header` and `footer` directly.
- (a) The tiles' icons no longer shrink in a narrow wide tile, as one copy did.
- (c) One copy clips the overflow of its header while the text is scaled (its
  desktop menu's hidden submenus), and two style the skip link in this
  stylesheet: those rules stay in the sites. One copy keeps the reduced-motion
  duration of its own stylesheet.

The check:

- (a) The paths of the routes get a trailing slash, the form a static host
  answers with the pre-rendered page, as one copy did; the query appended per
  language, another copy's rule, is `--query`.
- (a) The command serves the built directory itself when no `--base` is given,
  as one copy did.
- (a) The consent banner is answered from the site's consent configuration
  (`--consent`), as one copy did; the other wrote the same values inline.
- (a) A page answered with an HTTP error is reported as not loaded rather than
  checked, as one copy did; the browser is closed and the server stopped even
  when a run fails.
- (a) The details list the rules in the table's order, and a rule with no
  reference has no reference line, as one copy did; the other listed them in
  the order they were found.
- (a) `--out` creates its directory, as one copy did.
- (b) The note after the number of URLs (one copy named its languages):
  `--pages-note`. The report's language: `--lang`, Italian being what both
  copies wrote.
- (c) The npm script, the routes file and the consent configuration are the
  site's. The tests that read a site's real data — its dictionary, its consent
  inventory, its pages — stay in the sites; the package's tests run on a
  neutral example site.
