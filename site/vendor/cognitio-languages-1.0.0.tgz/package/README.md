# `@cognitio/languages` — a project's languages, declared once

A project writes its languages once, in its own `package.json`, and a module
that needs them reads them from there, through this package: which of its
shipped texts to bundle, which languages a command works on. No module knows how
the project is laid out; the declaration is found as many tools find theirs, by
walking up from the working directory to the nearest `package.json`.

This package is that one reader, and gives a project three ways in:

- **in Node**, `projectLanguages()`, which returns the project's source language
  and languages, and `matchLanguage()`, which picks the file a module ships for
  one of the project's tags;
- **through Vite** (and Astro, which builds with Vite), the plugin
  `projectLanguagesPlugin()`, which answers an import of
  `<package>/project-locales` with the package's tables for exactly the
  project's languages;
- **for another bundler**, the command `cognitio-languages write`, which writes
  the same module to a file the project names.

It also keeps, beside the same `package.json`, the record of the texts a project
copies from a module (a legal draft, a banner's texts), and reports each shipped
text that changed since: see [Copied texts](#copied-texts).

It is plain JavaScript (ES modules) with type declarations, and needs Node.js 20
or later; its tests run on Node.js 24. The plugin needs Vite 5 or later and takes
nothing from Vite at run time but what the build hands it; its tests run Vite
5.4. Vite is an optional peer dependency: a project that uses only the reader,
the command or the record of copied texts needs no Vite.
[`CHANGELOG.md`](CHANGELOG.md) lists what each version holds.

## Adding it to a project

At the project's root, with the command the project already has:

```sh
sh install.sh add @cognitio/languages
```

A module that reads the project's languages names `@cognitio/languages` as a
peer dependency, so a project holds one copy of it, shared by all its modules:
one reader of the declaration, one plugin, one matching of tags.

## The declaration

A top-level key of the project's `package.json`, `projectLanguages`, holds either
the list itself, the first tag the project's source language:

```json
{
  "projectLanguages": ["en", "it", "de"]
}
```

or the path of the project's own list file, relative to that `package.json`'s
directory, so a project that already keeps its list in a file keeps it there:

```json
{
  "projectLanguages": "src/i18n/languages.json"
}
```

The file holds one of three shapes:

| Shape | Example | The languages |
|---|---|---|
| A list of tags | `["en", "it", "de"]` | in order, the first the source |
| A list of objects with `lang` | `[{ "lang": "en" }, { "lang": "it" }]` | in order, the first the source |
| A source and the published languages | `{ "source": { "lang": "en" }, "published": [{ "lang": "it" }] }` | the source, then the published ones in order |

Any other field in those objects (a label, a writing direction) and at the top
of the third shape is read past, so a list a project's language selector already
reads serves as it is:

```json
{
  "source": { "lang": "en", "label": "English" },
  "published": [
    { "lang": "it", "label": "Italiano" },
    { "lang": "zh-CN", "label": "简体中文" }
  ]
}
```

Each language is a language tag: a language of two or three letters, then
optionally a script of four letters, a region of two letters or three digits,
variants and extensions (`en`, `pt-BR`, `zh-Hans`, `sr-Latn-RS`), each listed once,
whatever its case. The project's own spelling is what every module keys its
texts by.

**The nearest `package.json`.** The walk starts at the working directory (or,
for the plugin, Vite's `root`) and stops at the first `package.json` it finds, the
project's own; a `package.json` further up, a parent repository's, is never read,
even when it declares languages and the project's does not.

**`cognitio-modules.json` is not read.** It is the lockfile `cognitio-modules`
writes, rewritten in a fixed key order, so a key kept there by hand would be
undone by its writer. A project with no `package.json` passes its languages as an
option: `projectLanguages({ languages: ['en', 'it'] })`,
`projectLanguagesPlugin({ languages: ['en', 'it'] })`.

## In Node

```js
import { matchLanguage, projectLanguages } from '@cognitio/languages';

const { source, languages, declaredIn } = projectLanguages();
// source: 'en', languages: ['en', 'it', 'zh-CN'], declaredIn: '/…/package.json'

matchLanguage('zh-CN', ['de', 'en', 'it', 'zh-Hans']); // 'zh-Hans'
```

- `projectLanguages({ cwd, languages })` returns `{ source, languages,
  declaredIn }`: the source first, every language in the declaration's order,
  and the `package.json` the declaration was read from. With `languages`, those
  languages, checked as a declaration is, and `declaredIn` is `null`. `cwd` is
  where the walk starts, the working directory when absent. It throws an `Error`
  when the declaration is missing or malformed (see [The errors](#the-errors)).
- `parseDeclaration(value, baseDir)` reads one declaration's value as written in
  the `package.json` of `baseDir`, and returns `{ source, languages }`.
- `matchLanguage(projectTag, shippedTags)` returns the tag among `shippedTags`
  that serves `projectTag`, in its shipped spelling, or `null`. It tries, in
  order: the exact tag; the language and script (`zh-Hant-TW` → `zh-Hant`); for
  Chinese with no script, the region (`zh-CN`, `zh-SG`, `zh-MY` → `zh-Hans`;
  `zh-TW`, `zh-HK`, `zh-MO` → `zh-Hant`); the language alone (`pt-PT` → `pt`,
  `de-CH` → `de`). Case does not matter. A language alone is never widened to a
  region or a script: `pt` is not served by `pt-BR`, nor `zh` by `zh-Hans`.

## Through Vite: `<package>/project-locales`

Register the plugin in the project's Vite configuration:

```js
import { defineConfig } from 'vite';
import { projectLanguagesPlugin } from '@cognitio/languages/vite';

export default defineConfig({
  plugins: [projectLanguagesPlugin()],
});
```

or, in Astro, under `vite.plugins` in `astro.config.mjs`. Then the project imports
each module's texts with one line, never naming a language:

```js
import TEXTS from '@scope/module/project-locales';
```

`TEXTS` is keyed by the project's tags, so a component reads the page's table by
the page's own language, `TEXTS[lang]`.

For a package whose installed directory has a `locales/` directory, the plugin
answers that import, before Vite reads the package's own export of that name,
with a module that imports the package's file for each language the project
declares, matched with `matchLanguage` against the `<tag>.json` files in
`locales/`. For a project declaring `["en", "it", "zh-CN", "th"]` and a package
shipping `en`, `de`, `it` and `zh-Hans`:

```js
// The texts of @scope/module for the languages the project declares in "projectLanguages", written by @cognitio/languages.
import t0 from "@scope/module/locales/en";
import t1 from "@scope/module/locales/it";
import t2 from "@scope/module/locales/zh-Hans";

export default {
  "en": t0,
  "it": t1,
  "zh-CN": t2,
};
```

- **Exactly the project's languages.** The module imports nothing else, so the
  bundle holds the tables of the declared languages and no other.
- **A language the package does not ship is left out**, and the component falls
  back to English for it. The plugin says so once per package and language, as
  a warning of the build:

  ```text
  @scope/module: no texts for th; the component falls back to English
  ```

- **The declaration is read at the first such import of each build**, from the
  nearest `package.json` at or above Vite's `root`. A project that imports no
  `project-locales` is never asked for one, and imports of a module's files by
  hand (`import it from '@scope/module/locales/it'`) work with or without a
  declaration. The development server reads the declaration at the first
  `project-locales` import, and again at a later import if that read failed;
  after changing the declaration, restart the server.
- **The same in the development server**, for the browser and for a page the
  server renders: the plugin adds an alias that leaves each
  `<package>/project-locales` as written, so Vite resolves it through the plugins
  rather than loading the package's own export with Node.

`projectLanguagesPlugin({ languages })` takes the project's languages in place of
the declaration.

## For another bundler: the command

A bundle Vite does not build, such as a server function bundled by another tool,
gets the same module as a file, written before that bundle is built:

```sh
npx cognitio-languages write @scope/module src/generated/module-texts.mjs
```

```js
import TEXTS from './generated/module-texts.mjs';
```

| Command | What it does |
|---|---|
| `cognitio-languages list` | Prints the source language, the languages and the `package.json` they were read from. |
| `cognitio-languages write <package> <file>` | Writes to `<file>` (relative to the working directory, its directories created) the module the plugin answers for `<package>/project-locales`, byte for byte: the same project gives the same bytes. It prints the line above for each language the package lacks. |

```text
$ npx cognitio-languages list
source: en
languages: en it zh-CN th
declared in: /home/me/site/package.json
```

Both read the declaration from the working directory. The command exits 0 on
success; 1 on a declaration error, or when `write`'s package is not installed at
or above the working directory or has no `locales/` directory (nothing is
written); 2 on a wrong use, printing the usage. Its `copy` and `copies` are
described under [Copied texts](#copied-texts).

## The errors

A declaration that is missing when something asks for it, or malformed, stops
`projectLanguages()`, the plugin's build and the command with an error that
names the `package.json`, the value found, the accepted shapes and a line to
write. Each error is one of:

| The declaration | The error says |
|---|---|
| absent | `<package.json> declares no "projectLanguages"` |
| neither a list nor a string | `"projectLanguages" is <value>, neither a list of language tags nor the path of a list file` |
| a path to no file | `"projectLanguages" names "<path>", but there is no file at <absolute path>` |
| a file that is not JSON | `"projectLanguages" names "<path>", which is not JSON (<the parser's message>)` |
| a file in no accepted shape | `"projectLanguages" names "<path>", whose content <content> is in no accepted shape` |
| an empty list | `"projectLanguages" lists no language` |
| a tag that is not a language tag | `"projectLanguages" lists <value>, which is not a language tag such as en, pt-BR or zh-Hans` |
| a tag listed twice | `"projectLanguages" lists <value> twice` |

A problem found in the list file also names the file. Every error ends with the
accepted shapes and the example, so the message alone says what to write:

```text
/home/me/site/package.json declares no "projectLanguages": add the project's languages there. "projectLanguages" takes a list of language tags, the first the source language, or the path, relative to the package.json, of a JSON file holding a list of tags, a list of { "lang" } objects, or { "source": { "lang" }, "published": [{ "lang" }] }; for example "projectLanguages": ["en", "it"] or "projectLanguages": "src/languages.json".
```

With no `package.json` at or above the working directory at all, the error says
so and names the `languages` option.

## Copied texts

Some texts a module ships are copied into the project rather than imported: a
legal draft becomes the project's own page, a banner's texts are written into the
project's configuration. A copy is the project's to edit. When a later version of
the module changes a shipped text, the project needs to know whether its copy is
still the text as shipped, and can take the new one, or was customised, and a
person decides.

`copied-texts.json`, beside the project's `package.json` (found as the
declaration is, by walking up from the working directory), records per copied
file and per text the fingerprint of the shipped text the copy came from. The
project commits it.

```json
{
  "copies": {
    "src/content/de/privacy-policy.json": {
      "file": "drafts/de/privacy-policy.json",
      "package": "@scope/drafts",
      "texts": {
        "blocks[0].data.sections[2].html": "<the SHA-256 of the shipped text>"
      },
      "version": "1.1.0"
    }
  },
  "format": 1
}
```

- **A target**, a key of `copies`, is the project's file, relative to the
  directory of its `package.json`; `package` and `version` name what it was
  copied from, and `file` the package's file its texts were copied from.
- **A text** is a string of the JSON file, named by its key path: `.key` for a
  key of letters, digits, `_`, `$` and `-` that begins with a letter, `_` or
  `$`; `["key"]`, the key as a JSON string, for any other key; `[n]` for an item
  of a list. So `blocks[0].data.sections[2].html`, `texts.it.bannerTitle`, or
  `["categories.necessary.title"]` for a flat key holding dots.
- **The fingerprint** is the SHA-256, in hex, of the text's UTF-8 bytes. The
  fingerprint decides; the version is for the person reading the report.

A text takes one of two forms. When the shipped text sits in the target's
`file` at the same key path, as in a copied draft, the text is its fingerprint
alone, as above. When it sits in another file, or at another path, the text
names its shipped location: a banner's Italian title, nested in the project's
configuration, copied from a flat key of the module's Italian file:

```json
{
  "copies": {
    "consent.config.json": {
      "package": "@scope/banner",
      "texts": {
        "texts.it.bannerTitle": {
          "file": "locales/it.json",
          "path": "bannerTitle",
          "sha256": "<the SHA-256 of the shipped text>"
        },
        "texts.it.categories.necessary.title": {
          "file": "locales/it.json",
          "path": "[\"categories.necessary.title\"]",
          "sha256": "<the SHA-256 of the shipped text>"
        }
      },
      "version": "1.1.0"
    }
  },
  "format": 1
}
```

A target names the `file` most of its texts sit in at their own path (the first
by code unit on a tie), and those texts are fingerprints alone; a target none
of whose texts sits at its own path names no `file`, every text carrying its
own. Two texts of a target may come from one shipped text, as a language the
module does not ship filled from its English file.
- **Keys are sorted** at every level, in two-space JSON with a final newline:
  the same copies give the same bytes, and a diff shows only what changed.

### Copying a file

```sh
npx cognitio-languages copy @scope/drafts drafts/de/privacy-policy.json src/content/de/privacy-policy.json
```

copies a JSON file the installed package ships to the target (relative to the
working directory), as two-space JSON with a final newline, and records every
string of it, in place of what the record held for that target. It never
overwrites a target that exists and differs from the shipped file: a recorded
copy takes the module's later changes through `copies --write`. It reads the
record first, so a record it cannot read stops it before it writes anything.

The record, and every project file `copy` and `copies --write` write, are
written whole: to a temporary file in the same directory, then renamed over the
old one, so an interrupted run never leaves half a file.

### The statuses

For each recorded text, the check compares the recorded fingerprint `H` with the
shipped text in the package installed now, `S`, and with the project's text now,
`P`:

| Status | When | What `--write` does |
|---|---|---|
| `in sync` | `S` and `P` both have the fingerprint `H` | nothing |
| `module changed` | `S` changed and `P` has `H`: the project left the copy as it was | writes `S` into the project and records its fingerprint |
| `customised` | `S` has `H` and `P` changed | nothing; listed |
| `both` | `S` and `P` changed, and `P` differs from `S` | nothing; listed with the project's text and the new shipped text |
| `removed upstream` | the installed package's file holds the text neither by its fingerprint nor at a position the texts around it pin | nothing; listed |
| `removed by the project` | the project's file holds the text neither by its fingerprint nor at a position the texts around it pin | nothing; listed |

A project text already changed to the new shipped one reads `module changed`
until `--write` records the new fingerprint, leaving the text as it is; it then
reads `in sync`.

A text that moved, as when a section deleted before it shifts the ones after
it, is looked for by its fingerprint, in the project's file and in the shipped
one, before it is called changed or removed, and is reported where it is in the
project's file now. The record keeps the path each text was copied at. A moved
text is the same place at another position in a list (`sections[2].html` now at
`sections[1].html`), never a text under other keys: a translation filled from
the English file is never taken for the project's own English text that happens
to read the same.

A text found nowhere by its fingerprint is taken as changed only where the
texts found around it pin its place: another text of the same item was found,
or as many items lie between the nearest found items before and after it as
when it was copied. So a section revised in a draft that also gained or lost a
section before it reads `removed upstream` when its place is not pinned, never
`module changed` with another section's text: it is listed for a person and
never written. The same holds in the project's file, where such a text reads
`removed by the project`.

A line names a language when the shipped file's name, or its directory's name,
is a language tag: `locales/it.json`, `drafts/de/privacy-policy.json`.

### The command

| Command | What it does |
|---|---|
| `cognitio-languages copies`, or `copies --check` | Prints one line per text not `in sync`. Exits 1 when any text reads `module changed`, 0 otherwise: `customised`, `both` and the removed texts are printed for a person and do not fail. A project with no record prints nothing and exits 0. |
| `cognitio-languages copies --write` | Writes each `module changed` text into the project's file, where the text is now, and records its fingerprint; then lists the texts left for a person. A project file it writes is two-space JSON with a final newline, as `copy` writes it. |
| `cognitio-languages copies --accept <target>[#<path>]` | For a person who has read the text. A `both` text: records the new shipped fingerprint and keeps the project's text, which then reads `customised` until the module changes the text again. A `removed upstream` or `removed by the project` text: takes it out of the record, so it is no longer listed; a target left with no text leaves the record. Without `#<path>`, every such text of the target. `<target>` as the report prints it; `<path>` where the text is now, or the path it was recorded at. |

```text
$ npx cognitio-languages copies
src/content/de/privacy-policy.json blocks[0].data.sections[2].html (de): module changed, @scope/drafts 1.1.0 → 1.2.0
src/content/en/privacy-policy.json blocks[0].data.intro (en): both, @scope/drafts 1.1.0 → 1.2.0
  project: "<p>Who we are.</p>"
  shipped: "<p>Who decides what happens to your data.</p>"
src/content/en/privacy-policy.json blocks[0].data.title (en): customised, @scope/drafts 1.1.0 → 1.2.0
```

Each line names the target, the path, the language, the status, the package and
the version the record names, then the installed one when it differs. A `both`
line is followed by the project's text and the new shipped text, as JSON
strings. With `--write`, the line of each text it refreshed ends in
`; refreshed`; with `--accept`, the line of each text it accepted ends in
`; accepted` or `; removed from the record`. `--write` and `--accept` set a
target's version in the record to the installed one once every fingerprint the
record keeps for it is a text of the installed package's file.

A recorded package that is not installed stops the command with exit 1 and the
line to run, `sh install.sh add <package>`; so does `copy` for a package that is
not installed. A wrong use exits 2.

### In a build

The exit code is the integration: a project adds `cognitio-languages copies` to
its prebuild or its CI, and a shipped text that changed under a copy the project
left as it was stops the build until someone runs `cognitio-languages copies
--write`.

### From a module's command

```js
import { acceptCopies, checkCopies, recordCopies, refreshCopies } from '@cognitio/languages';
```

- `recordCopies(projectRoot, entries)` records texts a module's command copied
  into the project. Each entry is `{ target, package, version, file, path,
  shippedPath?, text }`: `text` the shipped text copied, `path` its key path in
  the project's `target`, `shippedPath` its key path in the shipped `file` when
  that differs (absent, the same as `path`), each in the form described above
  (`blocks[0].data.title`, `["categories.necessary.title"]`; a path in another
  form is refused). The record writes the form each text needs. Texts already
  recorded for the target are kept, and the target's version becomes the one
  given; a text of another package for a recorded target is refused.
- `checkCopies(projectRoot)` returns every recorded text as `{ target, path,
  language?, status, package, version, shipped?, project? }`: `path` where the
  text is in the project's file now, `version` the one recorded, `shipped` the
  shipped text when it changed, `project` the project's text when it differs
  from the one recorded. An empty list when the project has no record.
- `refreshCopies(projectRoot)` does what `copies --write` does and returns `{
  refreshed, listed }`, each a list as `checkCopies` returns it.
- `acceptCopies(projectRoot, target, path?)` does what `copies --accept` does
  and returns the number of texts accepted, the removed ones taken out of the
  record included.

`projectRoot` is any directory of the project: the record sits beside the
nearest `package.json` at or above it.

## Tests

```sh
npm install --no-save --no-audit --no-fund
npm test
```

The tests build fixture projects with Vite, run its development server in the
test process, and run the command as a child process, against a fixture package
that ships five languages and whose own `project-locales` export throws. The
tests of copied texts copy a fixture package's draft into a fixture project,
then install the package's next version, which changes one text, and edit the
project's copy or the installed files, once per status. They write only under
the system's temporary directory and reach no network.

## Licence

Apache License 2.0; see [`LICENSE`](LICENSE).
