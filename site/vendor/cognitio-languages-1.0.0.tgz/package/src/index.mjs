/**
 * @cognitio/languages — a project's languages, declared once.
 *
 * A project declares its languages in its nearest package.json, under the
 * top-level key `projectLanguages`: the list inline, the first tag its source
 * language, or the path, relative to that package.json, of a JSON file holding
 * the list. A module that needs the project's languages reads them here, so a
 * project writes its languages once and no module knows the project's layout.
 *
 * The declaration's reader READS the nearest package.json at or above the
 * working directory and the list file it names, and WRITES nothing. The record
 * of the texts a project copies from a module, which reads and writes
 * `copied-texts.json` beside the same package.json, lives in copies.mjs and is
 * exported from here. Node.js only.
 */

import fs from 'node:fs';
import path from 'node:path';

import { isLanguageTag, nearestPackageJson } from './shared.mjs';

export { acceptCopies, checkCopies, recordCopies, refreshCopies } from './copies.mjs';

const KEY = 'projectLanguages';
const EXAMPLE = '"projectLanguages": ["en", "it"] or "projectLanguages": "src/languages.json"';
const SHAPES =
  'a list of language tags, the first the source language, or the path, relative to the package.json, of a JSON file holding a list of tags, a list of { "lang" } objects, or { "source": { "lang" }, "published": [{ "lang" }] }';
const OPTION_HELP = "It takes a list of language tags, the first the source language; for example { languages: ['en', 'it'] }.";

// Chinese by region, when the tag names no script.
const CHINESE_SCRIPT_BY_REGION = new Map([
  ['cn', 'hans'],
  ['sg', 'hans'],
  ['my', 'hans'],
  ['tw', 'hant'],
  ['hk', 'hant'],
  ['mo', 'hant'],
]);

/** A value as an error message shows it: JSON, cut at 120 characters. */
function show(value) {
  let text;
  try {
    text = JSON.stringify(value);
  } catch {
    text = String(value);
  }
  if (text === undefined) text = String(value);
  return text.length > 120 ? `${text.slice(0, 117)}...` : text;
}

/** The error of a declaration in the package.json `pkgJson`. */
function declarationError(pkgJson, problem) {
  return new Error(`${pkgJson}: ${problem}. "${KEY}" takes ${SHAPES}; for example ${EXAMPLE}.`);
}

/**
 * Checks a list of tags: not empty, each a language tag, none twice whatever its
 * case. Returns `{ source, languages }`. `fail` makes the error from a problem;
 * `lists` opens each problem, `file` names the list file the tags came from.
 */
function checkTags(list, fail, { lists, file }) {
  const inFile = file ? ` in ${file}` : '';
  if (list.length === 0) throw fail(`${lists} no language${inFile}`);
  const seen = new Set();
  for (const tag of list) {
    if (!isLanguageTag(tag)) throw fail(`${lists} ${show(tag)}${inFile}, which is not a language tag such as en, pt-BR or zh-Hans`);
    const key = tag.toLowerCase();
    if (seen.has(key)) throw fail(`${lists} ${show(tag)} twice${inFile}`);
    seen.add(key);
  }
  return { source: list[0], languages: [...list] };
}

const isRecord = (value) => value !== null && typeof value === 'object' && !Array.isArray(value);

/** The tags of a list file's content, or null when it is in no accepted shape. */
function tagsOfFile(content) {
  if (Array.isArray(content)) {
    if (content.length > 0 && content.every(isRecord)) {
      return content.every((entry) => 'lang' in entry) ? content.map((entry) => entry.lang) : null;
    }
    return content;
  }
  if (isRecord(content) && isRecord(content.source) && 'lang' in content.source && Array.isArray(content.published)) {
    if (!content.published.every((entry) => isRecord(entry) && 'lang' in entry)) return null;
    return [content.source.lang, ...content.published.map((entry) => entry.lang)];
  }
  return null;
}

/**
 * Reads the value of a `projectLanguages` declaration, `value`, written in the
 * package.json of the directory `baseDir`: a list of tags, or the path,
 * relative to `baseDir`, of a JSON file holding a list of tags, a list of
 * `{ lang }` objects, or `{ source: { lang }, published: [{ lang }] }` (the
 * source then the published languages; any other field is read past).
 * Returns `{ source, languages }`, the source first. Throws an `Error` naming
 * the package.json, the value, the accepted shapes and an example line.
 */
export function parseDeclaration(value, baseDir) {
  const pkgJson = path.join(path.resolve(baseDir), 'package.json');
  const fail = (problem) => declarationError(pkgJson, problem);
  const lists = `"${KEY}" lists`;
  if (Array.isArray(value)) return checkTags(value, fail, { lists });
  if (typeof value !== 'string' || value === '') {
    throw fail(`"${KEY}" is ${show(value)}, neither a list of language tags nor the path of a list file`);
  }
  const file = path.resolve(baseDir, value);
  const names = `"${KEY}" names ${show(value)}`;
  if (!fs.statSync(file, { throwIfNoEntry: false })?.isFile()) throw fail(`${names}, but there is no file at ${file}`);
  let content;
  try {
    content = JSON.parse(fs.readFileSync(file, 'utf8'));
  } catch (error) {
    throw fail(`${names}, which is not JSON (${error.message})`);
  }
  const tags = tagsOfFile(content);
  if (!tags) throw fail(`${names}, whose content ${show(content)} is in no accepted shape`);
  return checkTags(tags, fail, { lists, file });
}

/**
 * The project's languages: `{ source, languages, declaredIn }`, the source
 * first and the languages in the declaration's order.
 *
 * With `languages`, those (checked as a declaration is), `declaredIn` null.
 * Otherwise the `projectLanguages` of the nearest package.json at or above
 * `cwd`: the walk stops at the first package.json found, the project's own, so
 * a parent's is never read; `declaredIn` is its path. Throws an `Error` naming
 * the package.json and the line to write when it declares nothing or something
 * malformed.
 *
 * @param {{ cwd?: string, languages?: readonly string[] }} [options]
 */
export function projectLanguages({ cwd = process.cwd(), languages } = {}) {
  if (languages !== undefined) {
    const fail = (problem) => new Error(`the languages option ${problem}. ${OPTION_HELP}`);
    if (!Array.isArray(languages)) throw fail(`is ${show(languages)}, not a list of language tags`);
    return { ...checkTags(languages, fail, { lists: 'lists' }), declaredIn: null };
  }
  const pkgJson = nearestPackageJson(cwd);
  if (!pkgJson) {
    throw new Error(
      `no package.json at or above ${path.resolve(cwd)}: add the project's package.json with its languages, for example ${EXAMPLE}, or pass the languages as an option`,
    );
  }
  let pkg;
  try {
    pkg = JSON.parse(fs.readFileSync(pkgJson, 'utf8'));
  } catch (error) {
    throw new Error(`${pkgJson} is not JSON (${error.message}): fix it, then declare the project's languages in it, for example ${EXAMPLE}`);
  }
  if (!isRecord(pkg) || !Object.hasOwn(pkg, KEY)) {
    throw new Error(
      `${pkgJson} declares no "${KEY}": add the project's languages there. "${KEY}" takes ${SHAPES}; for example ${EXAMPLE}.`,
    );
  }
  return { ...parseDeclaration(pkg[KEY], path.dirname(pkgJson)), declaredIn: pkgJson };
}

/**
 * The tag among `shippedTags` (the files a module ships) that serves the
 * project's tag `projectTag`, in its shipped spelling, or null: the exact tag;
 * then the language and script (`zh-Hant-TW` → `zh-Hant`); then, for Chinese
 * with no script, by region (`zh-CN`, `zh-SG`, `zh-MY` → `zh-Hans`; `zh-TW`,
 * `zh-HK`, `zh-MO` → `zh-Hant`); then the language alone (`pt-PT` → `pt`,
 * `de-CH` → `de`). Case-insensitive. A language alone is never widened to a
 * shipped region or script.
 *
 * @param {string} projectTag
 * @param {readonly string[]} shippedTags
 * @returns {string | null}
 */
export function matchLanguage(projectTag, shippedTags) {
  const shipped = [...shippedTags];
  const find = (tag) => shipped.find((s) => String(s).toLowerCase() === tag) ?? null;
  const wanted = String(projectTag).toLowerCase();
  const exact = find(wanted);
  if (exact) return exact;
  const [language, second] = wanted.split('-');
  const script = second && /^[a-z]{4}$/.test(second) ? second : null;
  if (script) {
    const withScript = find(`${language}-${script}`);
    if (withScript) return withScript;
  } else if (language === 'zh' && CHINESE_SCRIPT_BY_REGION.has(second)) {
    const byRegion = find(`zh-${CHINESE_SCRIPT_BY_REGION.get(second)}`);
    if (byRegion) return byRegion;
  }
  return language === wanted ? null : find(language);
}
