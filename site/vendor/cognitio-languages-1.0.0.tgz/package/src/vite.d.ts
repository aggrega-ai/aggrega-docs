/**
 * `@cognitio/languages/vite` — the Vite plugin that answers
 * `<package>/project-locales` with the package's tables for the project's
 * declared languages, keyed by the project's tags.
 */

import type { Plugin } from 'vite';

export declare function projectLanguagesPlugin(options?: {
  /** The project's languages, the source first, in place of its declaration. */
  languages?: readonly string[];
}): Plugin;
export default projectLanguagesPlugin;
