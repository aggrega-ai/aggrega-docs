/**
 * The record of the texts a project copies from a module, `copied-texts.json`
 * beside the project's package.json, and the check of each text against the
 * module installed now. Exported from `@cognitio/languages`.
 */

/**
 * Records texts a project copied from a module, in `copied-texts.json` beside
 * the nearest package.json at or above `projectRoot`: per entry, the
 * fingerprint (SHA-256 of the UTF-8 text) of `text`, the shipped text copied,
 * and where it came from. Texts already recorded for a target are kept; the
 * target's version becomes the one given. Throws when a target is recorded as
 * a copy of another package, lies outside the project, or a path is not a key
 * path such as `blocks[0].data.title`.
 */
export declare function recordCopies(
  projectRoot: string,
  entries: ReadonlyArray<{
    /** The project's file the text was copied into, relative to the project's root. */
    target: string;
    /** The package the text was copied from. */
    package: string;
    /** The installed version of that package. */
    version: string;
    /** The package's file the text was copied from, relative to the package. */
    file: string;
    /** The text's key path in `target`, such as `texts.it.bannerTitle`. */
    path: string;
    /**
     * The text's key path in `file`, when it differs from `path`: a flat key
     * holding dots is a quoted key, such as `["categories.necessary.title"]`.
     * Absent, the text sits at `path` in `file` too.
     */
    shippedPath?: string;
    /** The shipped text copied. */
    text: string;
  }>,
): void;

/**
 * Every recorded text of the project at or above `projectRoot`, with its
 * status from its fingerprint, the shipped text of the package installed now
 * and the project's text now. An empty list when the project has no record.
 * Throws, naming `sh install.sh add <package>`, when a recorded package is not
 * installed.
 */
export declare function checkCopies(projectRoot: string): Array<{
  /** The project's file, relative to its root, as the record names it. */
  target: string;
  /** The text's key path in the project's file now (where it was recorded, when the project removed it). */
  path: string;
  /** The language, when the shipped file's name or its directory's name is a language tag. */
  language?: string;
  status: 'in sync' | 'module changed' | 'customised' | 'both' | 'removed upstream' | 'removed by the project';
  package: string;
  /** The version the record names. */
  version: string;
  /** The shipped text, when it differs from the one recorded. */
  shipped?: string;
  /** The project's text, when it differs from the one recorded. */
  project?: string;
}>;

/**
 * Writes the new shipped text of every `module changed` text into the
 * project's file, where the text is now, and records its fingerprint.
 * `refreshed`: the texts written; `listed`: the texts not in sync left for a
 * person (`customised`, `both`, the removed ones); both as checkCopies
 * reports them before the refresh.
 */
export declare function refreshCopies(projectRoot: string): {
  refreshed: ReturnType<typeof checkCopies>;
  listed: ReturnType<typeof checkCopies>;
};

/**
 * Accepts what a person has read, for each text of `target`, or the one at
 * `path` (its key path in the project's file now, or the one it is recorded
 * at): a `both` text's new shipped fingerprint is recorded and the project's
 * text kept, so it reads `customised` until the module changes the text again;
 * a `removed upstream` or `removed by the project` text is taken out of the
 * record, and a target left with no text leaves it. Returns the number of
 * texts accepted. Throws when the record holds no such target or path.
 */
export declare function acceptCopies(projectRoot: string, target: string, path?: string): number;
