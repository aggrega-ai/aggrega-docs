/**
 * @cognitio/languages/vite — the Vite plugin that answers
 * `<package>/project-locales` with the package's tables for the project's
 * declared languages.
 *
 * For an import of `<package>/project-locales` where the installed package has
 * a `locales/` directory, the plugin answers, before Vite reads the package's
 * own export of that name, a module importing the package's table for each
 * language the project declares and the package ships, keyed by the project's
 * tags. A declared language the package lacks is left out and logged once per
 * package and language. The declaration is read once per build, at the first
 * such import, from the nearest package.json at or above Vite's `root`; a
 * project that imports no `project-locales` is never asked for one.
 *
 * READS the declaration and the installed packages' `locales/` directories;
 * WRITES nothing. It takes nothing from Vite but the configuration and the
 * logger the build hands it.
 */

import path from 'node:path';

import { projectLanguages } from './index.mjs';
import { findPackage } from './shared.mjs';
import { PACKAGE_NAME, missingLine, projectLocalesModule, shippedLanguages } from './write.mjs';

const SPECIFIER = new RegExp(`^(${PACKAGE_NAME})/project-locales$`);
const PREFIX = '\0cognitio-languages:';
const SUFFIX = '/project-locales';

/**
 * The plugin. Register it in the project's Vite configuration (or Astro's
 * `vite.plugins`):
 *
 *   import { projectLanguagesPlugin } from '@cognitio/languages/vite';
 *   export default defineConfig({ plugins: [projectLanguagesPlugin()] });
 *
 * @param {object} [options]
 * @param {readonly string[]} [options.languages] the project's languages, in
 *   place of its declaration
 * @returns {import('vite').Plugin}
 */
export function projectLanguagesPlugin({ languages } = {}) {
  let root = process.cwd();
  let logger = null;
  let declaration = null;
  const modules = new Map();
  const logged = new Set();

  function log(line) {
    if (logged.has(line)) return;
    logged.add(line);
    if (logger) logger.warn(line);
    else console.warn(line);
  }

  /**
   * The id answering `name`'s project-locales from `fromDir`, its module made
   * once per build; null when the package is not installed or ships no locales/.
   */
  function answer(name, fromDir) {
    const id = `${PREFIX}${name}${SUFFIX}`;
    if (modules.has(id)) return id;
    const dir = findPackage(name, fromDir);
    const shipped = dir && shippedLanguages(dir);
    if (!shipped) return null;
    declaration ??= projectLanguages({ cwd: root, languages });
    const { text, missing } = projectLocalesModule(name, shipped, declaration.languages);
    for (const tag of missing) log(missingLine(name, tag));
    modules.set(id, text);
    return id;
  }

  return {
    name: 'cognitio-languages',
    enforce: 'pre',
    config() {
      // Vite's development server loads a server-rendered page's imports of an
      // installed package with Node, before any plugin resolves them, unless
      // the import matches an alias. This alias leaves every
      // `<package>/project-locales` as written and makes Vite resolve it through
      // the plugins, so the plugin answers it there as in a build.
      return { resolve: { alias: [{ find: SPECIFIER, replacement: '$1' + SUFFIX }] } };
    },
    configResolved(config) {
      root = config.root;
      logger = config.logger;
    },
    buildStart() {
      declaration = null;
      modules.clear();
    },
    resolveId(source, importer) {
      if (source.startsWith(PREFIX)) return source;
      const match = SPECIFIER.exec(source);
      if (!match) return null;
      const file = importer ? importer.split('?')[0] : '';
      return answer(match[1], path.isAbsolute(file) ? path.dirname(file) : root);
    },
    load(id) {
      if (!id.startsWith(PREFIX)) return null;
      if (!modules.has(id)) answer(id.slice(PREFIX.length, -SUFFIX.length), root);
      return modules.get(id) ?? null;
    },
  };
}

export default projectLanguagesPlugin;
