/**
 * `@cognitio/languages` — a project's languages, declared once in its nearest
 * package.json under `projectLanguages`, the matching of a project's tags to
 * the files a module ships, and the record of the texts a project copies from
 * a module.
 */

export { acceptCopies, checkCopies, recordCopies, refreshCopies } from './copies.js';

/**
 * The project's languages: the `languages` option when given, otherwise the
 * `projectLanguages` of the nearest package.json at or above `cwd` (the walk
 * stops at the first package.json found). Throws an `Error` naming the
 * package.json, the value, the accepted shapes and a line to write when the
 * declaration is missing or malformed.
 */
export declare function projectLanguages(options?: {
  /** Where the walk up to the nearest package.json starts; the working directory when absent. */
  cwd?: string;
  /** The project's languages, the source first, in place of its declaration. */
  languages?: readonly string[];
}): {
  /** The project's source language: the first tag of its declaration. */
  source: string;
  /** Every language of the project, the source first, in the declaration's order and spelling. */
  languages: string[];
  /** The package.json the declaration was read from; null when the languages were passed as an option. */
  declaredIn: string | null;
};

/**
 * Reads the value of a `projectLanguages` declaration written in the
 * package.json of `baseDir`: a list of tags, or the path, relative to
 * `baseDir`, of a JSON file holding a list of tags, a list of `{ lang }`
 * objects, or `{ source: { lang }, published: [{ lang }] }`.
 */
export declare function parseDeclaration(value: unknown, baseDir: string): { source: string; languages: string[] };

/**
 * The tag among `shippedTags` that serves `projectTag`, in its shipped
 * spelling, or null: the exact tag, then language and script, then Chinese by
 * region (`zh-CN`, `zh-SG`, `zh-MY` → `zh-Hans`; `zh-TW`, `zh-HK`, `zh-MO` →
 * `zh-Hant`), then the language alone. Case-insensitive.
 */
export declare function matchLanguage(projectTag: string, shippedTags: readonly string[]): string | null;
