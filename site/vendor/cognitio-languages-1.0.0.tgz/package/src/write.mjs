/**
 * write.mjs — the module that answers `<package>/project-locales`: an import
 * of the package's table for each of the project's languages the package
 * ships, keyed by the project's own tags. The Vite plugin answers the import
 * with it and `cognitio-languages write` writes it to a file; both take its
 * text from here, so the two never differ.
 *
 * READS the installed package's `locales/` directory; WRITES nothing.
 */

import fs from 'node:fs';
import path from 'node:path';

import { matchLanguage } from './index.mjs';

const byCodeUnit = (a, b) => (a < b ? -1 : a > b ? 1 : 0);

/** The source of the pattern of an installed package's name: `name` or `@scope/name`. */
export const PACKAGE_NAME = String.raw`(?:@[^/@.\0][^/]*\/)?[^/@.\0][^/]*`;

/**
 * The tags a package ships: the names of the `<tag>.json` files in its
 * `locales/` directory, in code-unit order; null when it has no `locales/`
 * directory.
 */
export function shippedLanguages(packageDir) {
  const dir = path.join(packageDir, 'locales');
  if (!fs.statSync(dir, { throwIfNoEntry: false })?.isDirectory()) return null;
  return fs
    .readdirSync(dir)
    .filter((file) => file.endsWith('.json'))
    .map((file) => file.slice(0, -'.json'.length))
    .sort(byCodeUnit);
}

/**
 * The text of the module answering `<name>/project-locales` for the project's
 * `languages`, given the tags the package ships, and the project's languages
 * it leaves out: `{ text, missing }`.
 *
 * Each language is matched with `matchLanguage`; the module imports each
 * matched table once, as `t0`, `t1`, … in the order of the languages, and
 * exports `{ [projectTag]: table }` in that order. A language the package does
 * not ship is left out (the component falls back to English) and listed in
 * `missing`. The same input gives the same bytes.
 *
 * @param {string} name the package's name
 * @param {readonly string[]} shipped the tags the package ships
 * @param {readonly string[]} languages the project's languages
 * @returns {{ text: string, missing: string[] }}
 */
export function projectLocalesModule(name, shipped, languages) {
  const imports = new Map();
  const entries = [];
  const missing = [];
  for (const tag of languages) {
    const file = matchLanguage(tag, shipped);
    if (file === null) {
      missing.push(tag);
      continue;
    }
    if (!imports.has(file)) imports.set(file, `t${imports.size}`);
    entries.push(`  ${JSON.stringify(tag)}: ${imports.get(file)},`);
  }
  const lines = [
    `// The texts of ${name} for the languages the project declares in "projectLanguages", written by @cognitio/languages.`,
  ];
  for (const [file, local] of imports) lines.push(`import ${local} from ${JSON.stringify(`${name}/locales/${file}`)};`);
  lines.push('');
  if (entries.length === 0) lines.push('export default {};');
  else lines.push('export default {', ...entries, '};');
  return { text: `${lines.join('\n')}\n`, missing };
}

/** The line that says a package ships no texts for a project's language. */
export function missingLine(name, tag) {
  return `${name}: no texts for ${tag}; the component falls back to English`;
}
