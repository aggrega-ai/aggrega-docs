/**
 * shared.mjs — what the package's parts share: the walk up to the project's
 * package.json, the walk up to an installed package, and the test of a
 * language tag. The declaration's reader, the Vite plugin, the command and the
 * record of copied texts take them from here, so each lookup has one home.
 *
 * READS the file system; WRITES nothing.
 */

import fs from 'node:fs';
import path from 'node:path';

// A language tag: a language of two or three letters, then optionally a script
// of four letters, a region of two letters or three digits, variants,
// extensions and a private use part, case-insensitive.
const LANGUAGE_TAG =
  /^[a-z]{2,3}(?:-[a-z]{4})?(?:-(?:[a-z]{2}|\d{3}))?(?:-(?:[a-z\d]{5,8}|\d[a-z\d]{3}))*(?:-[a-wyz\d](?:-[a-z\d]{2,8})+)*(?:-x(?:-[a-z\d]{1,8})+)?$/i;

/** Whether `tag` is a well-formed language tag. */
export function isLanguageTag(tag) {
  return typeof tag === 'string' && LANGUAGE_TAG.test(tag);
}

/** The nearest package.json at or above `dir`, or null. */
export function nearestPackageJson(dir) {
  for (let current = path.resolve(dir); ; current = path.dirname(current)) {
    const candidate = path.join(current, 'package.json');
    if (fs.existsSync(candidate)) return candidate;
    if (path.dirname(current) === current) return null;
  }
}

/**
 * The directory of the package `name` installed in a node_modules at or above
 * `fromDir`, the first found walking up, or null.
 */
export function findPackage(name, fromDir) {
  for (let dir = path.resolve(fromDir); ; dir = path.dirname(dir)) {
    const candidate = path.join(dir, 'node_modules', ...name.split('/'));
    if (fs.existsSync(path.join(candidate, 'package.json'))) return candidate;
    if (path.dirname(dir) === dir) return null;
  }
}
