/**
 * copies.mjs — the record of the texts a project copies from a module, and
 * the check of each text against the module installed now.
 *
 * A project that copies texts a module ships (a consent banner's texts, a
 * legal draft) records them in `copied-texts.json`, beside its package.json:
 * per copied file (the target, relative to the project's root) the package
 * and its version, and per key path the fingerprint of the shipped text, the
 * SHA-256 in hex of its UTF-8 bytes. A text that sits at the same path of the
 * shipped file the copy names (`file`) is its fingerprint alone; a text from
 * another file or another path is `{ file, path, sha256 }`, its shipped
 * location.
 * Comparing that fingerprint with the shipped text in the installed package
 * now and with the project's text now gives each text one status: in sync,
 * module changed, customised, both, removed upstream or removed by the project.
 *
 * A key path names a string of a JSON file as `blocks[0].data.sections[2].html`
 * does: `.key` for a key of letters, digits, `_`, `$` and `-` that starts with
 * a letter, `_` or `$`; `["key"]`, the key as a JSON string, for any other key;
 * `[n]` for an array's item. A recorded text missing at its path is looked for
 * by its fingerprint at the same place in the same file, at another position in
 * a list, so a text that moved (a section deleted before it) is found where it
 * is now; a text is never looked for under other keys. A text found nowhere by
 * its fingerprint is taken as changed only at the position the texts found
 * around it pin; where they do not, it reads as removed, for a person to read,
 * and is never written.
 *
 * READS the record, the project's copied files and the installed packages'
 * files. WRITES the record, its keys sorted at every level, and the project's
 * copied files (a copy, a refresh), each as two-space JSON with a final
 * newline, each whole: to a temporary file in the same directory, renamed over
 * the old one.
 */

import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';

import { findPackage, isLanguageTag, nearestPackageJson } from './shared.mjs';

/** The record's file name, beside the project's package.json. */
export const RECORD = 'copied-texts.json';
const FORMAT = 1;

const IN_SYNC = 'in sync';
const MODULE_CHANGED = 'module changed';
const CUSTOMISED = 'customised';
const BOTH = 'both';
const REMOVED_UPSTREAM = 'removed upstream';
const REMOVED_BY_PROJECT = 'removed by the project';

const FINGERPRINT = /^[0-9a-f]{64}$/;
const PLAIN_KEY = /^[A-Za-z_$][\w$-]*$/;

const isObject = (value) => value !== null && typeof value === 'object' && !Array.isArray(value);
const byCodeUnit = (a, b) => (a < b ? -1 : a > b ? 1 : 0);

/** The fingerprint of a text: the SHA-256, in hex, of its UTF-8 bytes. */
const fingerprint = (text) => crypto.createHash('sha256').update(text, 'utf8').digest('hex');

/** Key paths in reading order: runs of digits (array items) by number, the rest by code unit. */
function byPath(a, b) {
  const pa = a.split(/(\d+)/);
  const pb = b.split(/(\d+)/);
  for (let i = 0; i < Math.min(pa.length, pb.length); i += 1) {
    if (pa[i] === pb[i]) continue;
    const difference = i % 2 === 1 ? Number(pa[i]) - Number(pb[i]) : 0;
    return difference || byCodeUnit(pa[i], pb[i]);
  }
  return pa.length - pb.length;
}

/** The key path of `key` (a string, or an array's index) under `parent`. */
function keyPath(parent, key) {
  if (typeof key === 'number') return `${parent}[${key}]`;
  if (PLAIN_KEY.test(key)) return parent === '' ? key : `${parent}.${key}`;
  return `${parent}[${JSON.stringify(key)}]`;
}

/** The key path of a list of keys and array indexes. */
const pathOf = (segments) => segments.reduce(keyPath, '');

/**
 * The keys and array indexes a key path names, or null when it is not a key
 * path as `pathOf` writes it.
 */
function parsePath(at) {
  const segments = [];
  const plain = /[A-Za-z_$][\w$-]*/y;
  const index = /\[(0|[1-9]\d*)\]/y;
  let i = 0;
  while (i < at.length) {
    if (at.startsWith('["', i)) {
      let end = i + 2;
      while (end < at.length && at[end] !== '"') end += at[end] === '\\' ? 2 : 1;
      if (at[end + 1] !== ']') return null;
      try {
        segments.push(JSON.parse(at.slice(i + 1, end + 1)));
      } catch {
        return null;
      }
      i = end + 2;
    } else if (at[i] === '[') {
      index.lastIndex = i;
      const match = index.exec(at);
      if (!match) return null;
      segments.push(Number(match[1]));
      i = index.lastIndex;
    } else {
      if (segments.length > 0) {
        if (at[i] !== '.') return null;
        i += 1;
      }
      plain.lastIndex = i;
      const match = plain.exec(at);
      if (!match) return null;
      segments.push(match[0]);
      i = plain.lastIndex;
    }
  }
  return pathOf(segments) === at ? segments : null;
}

/**
 * Every string of a parsed JSON value, in document order: its key path and
 * the keys and indexes it names, its text, its fingerprint, and the object or
 * array holding it with its key (null for a value that is one string).
 */
function stringsOf(value) {
  const strings = [];
  const walk = (node, segments, holder, key) => {
    if (typeof node === 'string') strings.push({ path: pathOf(segments), segments, text: node, hash: fingerprint(node), holder, key });
    else if (Array.isArray(node)) node.forEach((item, i) => walk(item, [...segments, i], node, i));
    else if (isObject(node)) for (const k of Object.keys(node)) walk(node[k], [...segments, k], node, k);
  };
  walk(value, [], null, null);
  return strings;
}

/**
 * Whether two key paths name the same place, perhaps at another position in a
 * list: the same keys at every level, array indexes wherever the other has
 * one (`sections[2].html` and `sections[1].html`, never `texts.th.x` and
 * `texts.en.x`).
 */
const samePlace = (a, b) => a.length === b.length && a.every((s, i) => (typeof s === 'number' ? typeof b[i] === 'number' : s === b[i]));

/** Whether `segments` lies under `prefix`, one level or more below it. */
const under = (segments, prefix) => segments.length > prefix.length && prefix.every((s, i) => segments[i] === s);

/** The value at `segments` in a parsed JSON value, or undefined. */
const valueAt = (tree, segments) => segments.reduce((node, s) => (node !== null && typeof node === 'object' ? node[s] : undefined), tree);

/**
 * Where the item `index` of the array the record knows at `recorded` is now,
 * in the array at `now`, as the texts found by their fingerprint pin it: the
 * index a text of the same item was found at; otherwise the item's offset from
 * the nearest item before it whose text was found, when as many items lie
 * between that item and the nearest one after it whose text was found (or the
 * end of the array) as when the texts were recorded. Null when the found texts
 * do not pin it: items were inserted or deleted around it, so its position
 * there is a guess.
 */
function itemNow(recorded, now, index, recordedPaths, found, tree) {
  const depth = recorded.length;
  const pins = new Map();
  for (const { from, to } of found) {
    if (!under(from, recorded) || typeof from[depth] !== 'number' || !under(to, now) || typeof to[depth] !== 'number') continue;
    const at = pins.get(from[depth]);
    pins.set(from[depth], at === undefined || at === to[depth] ? to[depth] : NaN);
  }
  if (pins.has(index)) return Number.isNaN(pins.get(index)) ? null : pins.get(index);
  let before = [-1, -1];
  let after = null;
  for (const [from, to] of pins) {
    if (from < index && from > before[0]) before = [from, to];
    if (from > index && (after === null || from < after[0])) after = [from, to];
  }
  if (after === null) {
    const array = valueAt(tree, now);
    if (!Array.isArray(array)) return null;
    const lengths = recordedPaths.filter((s) => under(s, recorded) && typeof s[depth] === 'number').map((s) => s[depth] + 1);
    after = [Math.max(...lengths), array.length];
  }
  if (Number.isNaN(before[1]) || Number.isNaN(after[1]) || after[0] - before[0] !== after[1] - before[1]) return null;
  return before[1] + (index - before[0]);
}

/**
 * The key path a recorded text's path names now, each array index on it moved
 * as `itemNow` pins it, or null when an index is not pinned.
 */
function pathNow(segments, recordedPaths, found, tree) {
  const now = [];
  for (let depth = 0; depth < segments.length; depth += 1) {
    const segment = segments[depth];
    if (typeof segment !== 'number') {
      now.push(segment);
      continue;
    }
    const index = itemNow(segments.slice(0, depth), now, segment, recordedPaths, found, tree);
    if (index === null) return null;
    now.push(index);
  }
  return pathOf(now);
}

/**
 * Where each recorded text, `{ at, hash }` (its path in this file and its
 * fingerprint), is in a file (`{ tree, strings }`). A text is found unchanged
 * at its recorded path when the string there has its fingerprint; otherwise
 * unchanged at the first other string with its fingerprint, at the same place
 * but another position in a list (`samePlace`), that no other text was found
 * at (a text that moved); otherwise changed at the path its recorded
 * one names now, as the texts found by their fingerprint pin it (`pathNow`),
 * when no other text was found there; otherwise nowhere. Texts recorded at the
 * same path (two project texts copied from one shipped text) may be found at
 * the same string. Returns, for each text in order, `{ same, string }` or
 * null.
 */
function locate(texts, { tree, strings }) {
  const atPath = new Map(strings.map((s) => [s.path, s]));
  const withHash = new Map();
  for (const s of strings) {
    if (!withHash.has(s.hash)) withHash.set(s.hash, []);
    withHash.get(s.hash).push(s);
  }
  const takenBy = new Map();
  const free = (string, at) => !takenBy.has(string) || takenBy.get(string) === at;
  const found = texts.map(() => undefined);
  const take = (i, same, string) => {
    found[i] = { same, string };
    takenBy.set(string, texts[i].at);
  };
  texts.forEach(({ at, hash }, i) => {
    const string = atPath.get(at);
    if (string?.hash === hash && free(string, at)) take(i, true, string);
  });
  const recordedPaths = texts.map(({ at }) => parsePath(at));
  texts.forEach(({ at, hash }, i) => {
    if (found[i]) return;
    const string = withHash.get(hash)?.find((s) => free(s, at) && samePlace(recordedPaths[i], s.segments));
    if (string) take(i, true, string);
  });
  const pins = texts.flatMap((text, i) => (found[i] ? [{ from: recordedPaths[i], to: found[i].string.segments }] : []));
  texts.forEach(({ at }, i) => {
    if (found[i]) return;
    const now = pathNow(recordedPaths[i], recordedPaths, pins, tree);
    const string = now === null ? undefined : atPath.get(now);
    if (string && free(string, at)) take(i, false, string);
    else found[i] = null;
  });
  return found;
}

/** The status of a text from where it was found in the shipped file and in the project's file. */
function statusOf(shipped, project) {
  if (!shipped) return REMOVED_UPSTREAM;
  if (!project) return REMOVED_BY_PROJECT;
  if (shipped.same) return project.same ? IN_SYNC : CUSTOMISED;
  // A project text that already equals the new shipped one only needs the new fingerprint recorded.
  if (project.same || project.string.text === shipped.string.text) return MODULE_CHANGED;
  return BOTH;
}

/**
 * The language of a shipped file, when its name or the name of its directory
 * is a language tag (`locales/it.json`, `drafts/de/privacy-policy.json`).
 */
function languageOf(file) {
  const parts = file.split('/');
  const name = parts[parts.length - 1].replace(/\.json$/i, '');
  if (isLanguageTag(name)) return name;
  const dir = parts[parts.length - 2];
  return dir !== undefined && isLanguageTag(dir) ? dir : undefined;
}

/** `file` relative to `base`, `/`-separated, or null when it is `base` itself or outside it. */
function inside(base, file) {
  const relative = path.relative(base, path.resolve(base, file));
  if (relative === '' || relative === '..' || relative.startsWith(`..${path.sep}`) || path.isAbsolute(relative)) return null;
  return relative.split(path.sep).join('/');
}

/** A file a package ships as the record names it: relative and inside the package, or null. */
function packageFile(file) {
  const normal = path.posix.normalize(file);
  if (normal === '.' || normal === '..' || normal.startsWith('../') || path.posix.isAbsolute(normal)) return null;
  return normal;
}

/** The project's root: the directory of the nearest package.json at or above `dir`. */
function projectRootOf(dir) {
  const pkgJson = nearestPackageJson(dir);
  if (!pkgJson) throw new Error(`no package.json at or above ${path.resolve(dir)}: ${RECORD} sits beside the project's package.json`);
  return path.dirname(pkgJson);
}

/** The directory and version of the package `name` installed for the project at `root`. */
function installedPackage(name, root) {
  const dir = findPackage(name, root);
  if (!dir) throw new Error(`${name} is not installed at or above ${root}: add it with sh install.sh add ${name}`);
  const pkgJson = path.join(dir, 'package.json');
  let version;
  try {
    ({ version } = JSON.parse(fs.readFileSync(pkgJson, 'utf8')));
  } catch (error) {
    throw new Error(`${pkgJson} is not JSON (${error.message})`);
  }
  if (typeof version !== 'string' || version === '') throw new Error(`${pkgJson} names no version`);
  return { dir, version };
}

/** A JSON file's parsed value and strings, or null when there is no such file. `name` names it in an error. */
function readStrings(file, name) {
  if (!fs.statSync(file, { throwIfNoEntry: false })?.isFile()) return null;
  let tree;
  try {
    tree = JSON.parse(fs.readFileSync(file, 'utf8'));
  } catch (error) {
    throw new Error(`${name} is not JSON (${error.message}): ${file}`);
  }
  return { file, tree, strings: stringsOf(tree) };
}

/**
 * The project's record, checked, or null when the project has none. In
 * memory, each text holds its shipped location whichever form the file gives
 * it: `{ file, path, sha256 }`. A copy keeps its own `file` only for a copy
 * with no text; `recordForm` writes the file's form back.
 */
function readRecord(root) {
  const file = path.join(root, RECORD);
  if (!fs.existsSync(file)) return null;
  let record;
  try {
    record = JSON.parse(fs.readFileSync(file, 'utf8'));
  } catch (error) {
    throw new Error(`${file} is not JSON (${error.message})`);
  }
  const bad = (problem) => new Error(`${file} is not a record of copied texts: ${problem}`);
  if (!isObject(record)) throw bad('it is not an object');
  if (record.format !== FORMAT) {
    throw new Error(`${file} has format ${JSON.stringify(record.format)}, and this version of @cognitio/languages reads format ${FORMAT}`);
  }
  if (!isObject(record.copies)) throw bad('"copies" is not an object');
  const copies = {};
  for (const [target, copy] of Object.entries(record.copies)) {
    if (inside(root, target) !== target) throw bad(`the copy ${target} is not a path inside the project`);
    if (!isObject(copy)) throw bad(`the copy ${target} is not an object`);
    for (const field of ['package', 'version']) {
      if (typeof copy[field] !== 'string' || copy[field] === '') throw bad(`the copy ${target} has no "${field}"`);
    }
    if (copy.file !== undefined && (typeof copy.file !== 'string' || packageFile(copy.file) !== copy.file)) {
      throw bad(`the copy ${target} names ${JSON.stringify(copy.file)}, not a file inside ${copy.package}`);
    }
    if (!isObject(copy.texts)) throw bad(`the copy ${target} has no "texts"`);
    const texts = {};
    for (const [at, value] of Object.entries(copy.texts)) {
      const text = `the text ${at} of ${target}`;
      if (parsePath(at) === null) throw bad(`${text} is not named by a key path such as blocks[0].data.title`);
      if (typeof value === 'string') {
        if (copy.file === undefined) throw bad(`${text} is a fingerprint, but the copy names no "file"`);
        if (!FINGERPRINT.test(value)) throw bad(`${text} has no SHA-256 fingerprint`);
        texts[at] = { file: copy.file, path: at, sha256: value };
        continue;
      }
      if (!isObject(value)) throw bad(`${text} is neither a fingerprint nor { "file", "path", "sha256" }`);
      const extra = Object.keys(value).find((key) => !['file', 'path', 'sha256'].includes(key));
      if (extra !== undefined) throw bad(`${text} has a field ${JSON.stringify(extra)}, beside "file", "path" and "sha256"`);
      if (typeof value.file !== 'string' || value.file === '') throw bad(`${text} has no "file"`);
      if (packageFile(value.file) !== value.file) throw bad(`${text} names ${value.file}, not a file inside ${copy.package}`);
      if (typeof value.path !== 'string' || parsePath(value.path) === null) throw bad(`${text} names ${value.path}, not a key path such as blocks[0].data.title`);
      if (typeof value.sha256 !== 'string' || !FINGERPRINT.test(value.sha256)) throw bad(`${text} has no SHA-256 fingerprint`);
      texts[at] = { file: value.file, path: value.path, sha256: value.sha256 };
    }
    copies[target] = { package: copy.package, version: copy.version, file: copy.file, texts };
  }
  return { format: FORMAT, copies };
}

/**
 * The record as its file holds it. A copy names the file most of its texts
 * sit in at their own path (the first by code unit on a tie), and each such
 * text is its fingerprint alone; every other text is `{ file, path, sha256 }`,
 * its shipped location. A copy with no such text names no file, unless it
 * holds no text at all.
 */
function recordForm(record) {
  const copies = {};
  for (const [target, copy] of Object.entries(record.copies)) {
    const keys = Object.keys(copy.texts);
    let file = keys.length === 0 ? copy.file : undefined;
    const counts = new Map();
    for (const at of keys) {
      const { file: from, path: there } = copy.texts[at];
      if (there === at) counts.set(from, (counts.get(from) ?? 0) + 1);
    }
    for (const [from, count] of counts) {
      const best = file === undefined ? 0 : counts.get(file);
      if (count > best || (count === best && from < file)) file = from;
    }
    const texts = {};
    for (const at of keys) {
      const location = copy.texts[at];
      texts[at] = location.file === file && location.path === at ? location.sha256 : { ...location };
    }
    copies[target] = { package: copy.package, version: copy.version, ...(file !== undefined && { file }), texts };
  }
  return { format: FORMAT, copies };
}

/** A value as two-space JSON, the keys of every object sorted by code unit. */
function sortedJson(value, indent = '') {
  if (!isObject(value)) return JSON.stringify(value);
  const keys = Object.keys(value).sort(byCodeUnit);
  if (keys.length === 0) return '{}';
  const inner = `${indent}  `;
  return `{\n${keys.map((key) => `${inner}${JSON.stringify(key)}: ${sortedJson(value[key], inner)}`).join(',\n')}\n${indent}}`;
}

/**
 * Writes `text` to `file` whole: to a temporary file in the same directory,
 * renamed over `file`, so a reader never sees half of it. The file keeps its
 * permissions.
 */
function writeWhole(file, text) {
  const mode = fs.statSync(file, { throwIfNoEntry: false })?.mode;
  const temporary = path.join(path.dirname(file), `.${path.basename(file)}.${process.pid}.${crypto.randomBytes(6).toString('hex')}.tmp`);
  try {
    fs.writeFileSync(temporary, text, { flag: 'wx' });
    if (mode !== undefined) fs.chmodSync(temporary, mode & 0o7777);
    fs.renameSync(temporary, file);
  } catch (error) {
    fs.rmSync(temporary, { force: true });
    throw error;
  }
}

function writeRecord(root, record) {
  writeWhole(path.join(root, RECORD), `${sortedJson(recordForm(record))}\n`);
}

/**
 * Adds `entries` (`{ target, package, version, file, path, text, shippedPath? }`)
 * to `record`, each text at its shipped location: `file`, at `shippedPath`, or
 * at `path` when there is none.
 */
function addTexts(record, root, entries) {
  if (!Array.isArray(entries)) throw new Error('the copied texts are not a list of { target, package, version, file, path, text }');
  for (const entry of entries) {
    if (!isObject(entry)) throw new Error('a copied text is not an object { target, package, version, file, path, text }');
    for (const field of ['target', 'package', 'version', 'file', 'path', 'text']) {
      if (typeof entry[field] !== 'string') throw new Error(`a copied text's "${field}" is not a string`);
    }
    for (const field of ['package', 'version']) {
      if (entry[field] === '') throw new Error(`a copied text's "${field}" is empty`);
    }
    if (parsePath(entry.path) === null) throw new Error(`a copied text's "path" ${entry.path} is not a key path such as blocks[0].data.title`);
    if (entry.shippedPath !== undefined && (typeof entry.shippedPath !== 'string' || parsePath(entry.shippedPath) === null)) {
      throw new Error(`a copied text's "shippedPath" ${entry.shippedPath} is not a key path such as blocks[0].data.title`);
    }
    const target = inside(root, entry.target);
    if (!target) throw new Error(`${entry.target} is outside the project at ${root}`);
    const file = packageFile(entry.file);
    if (!file) throw new Error(`${entry.file} is not a file inside ${entry.package}`);
    const copy = record.copies[target];
    if (copy && copy.package !== entry.package) {
      throw new Error(`${target} is recorded as a copy of ${copy.package}, so a text of ${entry.package} cannot be recorded for it`);
    }
    record.copies[target] = {
      package: entry.package,
      version: entry.version,
      file: copy?.file ?? file,
      texts: { ...copy?.texts, [entry.path]: { file, path: entry.shippedPath ?? entry.path, sha256: fingerprint(entry.text) } },
    };
  }
}

/**
 * Every recorded text of the project at or above `projectRoot`, with its
 * status: `{ root, record, targets, texts }`. `record` is null when the
 * project has none. `targets` maps each copied file to its installed version
 * and its parsed content; each of `texts` holds `result` (what checkCopies
 * returns for it), `at` (its recorded path), `installed` (the installed
 * version), `current` (whether the installed package's file holds its
 * recorded fingerprint) and `string` (where it is in the project's file, or
 * null).
 */
export function inspect(projectRoot) {
  const root = projectRootOf(projectRoot);
  const record = readRecord(root);
  const targets = new Map();
  const texts = [];
  if (!record) return { root, record, targets, texts };
  for (const target of Object.keys(record.copies).sort(byCodeUnit)) {
    const copy = record.copies[target];
    const installed = installedPackage(copy.package, root);
    const project = readStrings(path.join(root, target), target);
    targets.set(target, { installed: installed.version, project });
    const keys = Object.keys(copy.texts).sort(byPath);
    const inProject = project ? locate(keys.map((at) => ({ at, hash: copy.texts[at].sha256 })), project) : [];
    // Each text is looked for in its own shipped file, among the texts recorded from that file.
    const inShipped = [];
    const byFile = new Map();
    keys.forEach((at, i) => byFile.set(copy.texts[at].file, [...(byFile.get(copy.texts[at].file) ?? []), i]));
    for (const [file, indexes] of byFile) {
      const shipped = readStrings(path.join(installed.dir, file), `${copy.package} ${file}`);
      if (!shipped) continue;
      const found = locate(indexes.map((i) => ({ at: copy.texts[keys[i]].path, hash: copy.texts[keys[i]].sha256 })), shipped);
      indexes.forEach((i, j) => {
        inShipped[i] = found[j];
      });
    }
    keys.forEach((at, i) => {
      const s = inShipped[i] ?? null;
      const p = inProject[i] ?? null;
      const language = languageOf(copy.texts[at].file);
      const result = { target, path: p ? p.string.path : at };
      if (language) result.language = language;
      Object.assign(result, { status: statusOf(s, p), package: copy.package, version: copy.version });
      if (s && !s.same) result.shipped = s.string.text;
      if (p && !p.same) result.project = p.string.text;
      texts.push({ result, at, installed: installed.version, current: Boolean(s?.same), string: p?.string ?? null });
    });
  }
  return { root, record, targets, texts };
}

/**
 * Sets the version of each of `names` (copied files) to the installed one when
 * none of `stale`, the texts left in the record whose fingerprint the
 * installed package's file does not hold, is one of its texts: the record then
 * names the version every fingerprint it holds for the file came from.
 */
function advanceVersions(record, targets, names, stale) {
  for (const name of names) {
    if (record.copies[name] && !stale.some((t) => t.result.target === name)) record.copies[name].version = targets.get(name).installed;
  }
}

/**
 * Writes each `module changed` text's new shipped text into the project's file,
 * where the text is now, and records its fingerprint. Returns `{ refreshed,
 * listed }`, the texts of `inspect` it refreshed and those not in sync it left
 * for a person.
 */
export function refresh(projectRoot) {
  const { root, record, targets, texts } = inspect(projectRoot);
  const refreshed = [];
  const listed = [];
  if (!record) return { refreshed, listed };
  const written = new Set();
  for (const t of texts) {
    const { status, target, shipped } = t.result;
    if (status === MODULE_CHANGED) {
      if (t.string.text !== shipped) {
        if (t.string.holder) t.string.holder[t.string.key] = shipped;
        else targets.get(target).project.tree = shipped;
        written.add(target);
      }
      record.copies[target].texts[t.at].sha256 = fingerprint(shipped);
      refreshed.push(t);
    } else if (status !== IN_SYNC) {
      listed.push(t);
    }
  }
  for (const target of written) {
    const { project } = targets.get(target);
    writeWhole(project.file, `${JSON.stringify(project.tree, null, 2)}\n`);
  }
  advanceVersions(record, targets, [...targets.keys()], texts.filter((t) => !t.current && !refreshed.includes(t)));
  writeRecord(root, record);
  return { refreshed, listed };
}

/**
 * Accepts, for `target` (as the record names it), each text, or the one at
 * `at` (its path in the project's file now, or the path it is recorded at),
 * that a person has read: a `both` text's new shipped fingerprint is recorded
 * and the project's text kept; a `removed upstream` or `removed by the project`
 * text is taken out of the record, and a target left with no text leaves it.
 * Returns the texts of `inspect` it accepted, in their order.
 */
export function accept(projectRoot, target, at) {
  const { root, record, targets, texts } = inspect(projectRoot);
  const name = inside(root, target);
  if (!record || !name || !record.copies[name]) throw new Error(`${target} is not in ${path.join(root, RECORD)}: no copy of it is recorded`);
  const ofTarget = texts.filter((t) => t.result.target === name);
  let chosen = ofTarget;
  if (at !== undefined) {
    chosen = ofTarget.filter((t) => t.result.path === at);
    if (chosen.length === 0) chosen = ofTarget.filter((t) => t.at === at);
    if (chosen.length === 0) throw new Error(`${name} has no recorded text at ${at}`);
  }
  const accepted = chosen.filter((t) => [BOTH, REMOVED_UPSTREAM, REMOVED_BY_PROJECT].includes(t.result.status));
  if (accepted.length === 0) return accepted;
  const copy = record.copies[name];
  for (const t of accepted) {
    if (t.result.status === BOTH) copy.texts[t.at].sha256 = fingerprint(t.result.shipped);
    else delete copy.texts[t.at];
  }
  if (Object.keys(copy.texts).length === 0 && accepted.some((t) => t.result.status !== BOTH)) delete record.copies[name];
  advanceVersions(record, targets, [name], ofTarget.filter((t) => !t.current && !accepted.includes(t)));
  writeRecord(root, record);
  return accepted;
}

/**
 * Copies the file `file` the installed package `name` ships to `target`
 * (relative to `cwd`), as two-space JSON with a final newline, and records
 * every string of it, replacing the target's earlier record. The record is
 * read first, so a record that cannot be read stops the copy before anything
 * is written. A target that exists and differs from the shipped file is never
 * overwritten. Returns `{ target, file, count }`: the target relative to the
 * project's root, the shipped file as recorded and the number of texts
 * recorded.
 */
export function copyShipped(cwd, name, file, target) {
  const root = projectRootOf(cwd);
  const installed = installedPackage(name, root);
  const shippedFile = packageFile(file);
  if (!shippedFile) throw new Error(`${file} is not a file inside ${name}`);
  const shipped = readStrings(path.join(installed.dir, shippedFile), `${name} ${shippedFile}`);
  if (!shipped) throw new Error(`${name} ships no file ${shippedFile} (${path.join(installed.dir, shippedFile)})`);
  const rel = inside(root, path.resolve(cwd, target));
  if (!rel) throw new Error(`${target} is outside the project at ${root}`);
  const record = readRecord(root) ?? { format: FORMAT, copies: {} };
  delete record.copies[rel];
  const entries = shipped.strings.map((s) => ({ target: rel, package: name, version: installed.version, file: shippedFile, path: s.path, text: s.text }));
  addTexts(record, root, entries);
  record.copies[rel] ??= { package: name, version: installed.version, file: shippedFile, texts: {} };
  const destination = path.join(root, rel);
  const text = `${JSON.stringify(shipped.tree, null, 2)}\n`;
  if (fs.existsSync(destination)) {
    if (fs.readFileSync(destination, 'utf8') !== text) {
      throw new Error(
        `${rel} exists and differs from ${name} ${shippedFile}: copy never overwrites a project's file; a recorded copy takes the module's changes with cognitio-languages copies --write`,
      );
    }
  } else {
    fs.mkdirSync(path.dirname(destination), { recursive: true });
    writeWhole(destination, text);
  }
  writeRecord(root, record);
  return { target: rel, file: shippedFile, count: entries.length };
}

/**
 * Records texts a project copied from a module in `copied-texts.json`, beside
 * the nearest package.json at or above `projectRoot`: per entry, the
 * fingerprint of `text` (the shipped text copied) at `path` of `target` (the
 * project's file, relative to the project's root), which came from `file` of
 * `package` at `version`, at `shippedPath` in it, or at `path` when there is
 * none. Texts already recorded for a target are kept, and the target's
 * version becomes the one given. Throws when a target is recorded as a copy of
 * another package, or a path is not a key path.
 *
 * @param {string} projectRoot
 * @param {ReadonlyArray<{ target: string, package: string, version: string, file: string, path: string, shippedPath?: string, text: string }>} entries
 */
export function recordCopies(projectRoot, entries) {
  const root = projectRootOf(projectRoot);
  const record = readRecord(root) ?? { format: FORMAT, copies: {} };
  addTexts(record, root, entries);
  if (entries.length > 0) writeRecord(root, record);
}

/**
 * Every recorded text of the project at or above `projectRoot`, with its
 * status, comparing its fingerprint with the shipped text of the package
 * installed now and with the project's text now: `in sync`, `module changed`,
 * `customised`, `both`, `removed upstream` or `removed by the project`. `path`
 * is where the text is in the project's file now; `version` the version
 * recorded; `shipped` the shipped text when it changed; `project` the
 * project's text when it differs from the one recorded. An empty list when
 * the project has no record. Throws, naming `sh install.sh add <package>`,
 * when a recorded package is not installed.
 */
export function checkCopies(projectRoot) {
  return inspect(projectRoot).texts.map((t) => t.result);
}

/**
 * Writes the new shipped text of every `module changed` text into the
 * project's file and records its fingerprint. Returns `{ refreshed, listed }`:
 * the texts refreshed, and the texts not in sync left for a person
 * (`customised`, `both`, the removed ones), as checkCopies reports them.
 */
export function refreshCopies(projectRoot) {
  const { refreshed, listed } = refresh(projectRoot);
  return { refreshed: refreshed.map((t) => t.result), listed: listed.map((t) => t.result) };
}

/**
 * Accepts what a person has read, for each text of `target` (as the record
 * names it), or the one at `at` (its path in the project's file now, or the
 * path it is recorded at): a `both` text's new shipped fingerprint is recorded
 * and the project's text kept, so it reads `customised` until the module
 * changes the text again; a `removed upstream` or `removed by the project`
 * text is taken out of the record, and a target left with no text leaves it.
 * Returns the number of texts accepted. Throws when the record holds no such
 * target or path.
 *
 * @param {string} projectRoot
 * @param {string} target
 * @param {string} [at]
 */
export function acceptCopies(projectRoot, target, at) {
  return accept(projectRoot, target, at).length;
}
