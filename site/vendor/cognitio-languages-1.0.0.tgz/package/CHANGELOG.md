# Changelog

Each version of `@cognitio/languages` is a git tag of its repository,
`languages-vX.Y.Z`, whose release publishes the archive a project vendors from
`https://tooling.cognitio.it/languages/archives/languages-X.Y.Z.tgz`;
`https://tooling.cognitio.it/languages/index.json` lists every published
version with its archive's sha256. 1.0.0 holds every feature the package has at
its first release; a feature added after it is recorded under the next version,
above this one.

## 1.0.0

A project's languages, declared once in its `package.json` and read for every
module.

- The declaration: the top-level key `projectLanguages` of the project's nearest
  `package.json`, a list of language tags, the first the source language, or the
  path, relative to that `package.json`, of a JSON file holding a list of tags, a
  list of `{ "lang" }` objects, or `{ "source": { "lang" }, "published": [{
  "lang" }] }`, any other field read past. The walk stops at the first
  `package.json` found; `cognitio-modules.json` is not read.
- `@cognitio/languages`: `projectLanguages({ cwd, languages })`, which returns
  `{ source, languages, declaredIn }`, an explicit `languages` winning over the
  declaration; `parseDeclaration(value, baseDir)`; and `matchLanguage(projectTag,
  shippedTags)`, the file a module ships for a project's tag: the exact tag, then
  language and script, then Chinese by region, then the language alone,
  case-insensitive.
- A missing or malformed declaration (not a list or a string, a path to no
  file, a file that is not JSON or in no accepted shape, an empty list, a tag
  that is not a language tag, a tag listed twice) stops with an error naming the
  `package.json`, the value, the accepted shapes and an example line.
- `@cognitio/languages/vite`: `projectLanguagesPlugin({ languages })`, which
  answers `<package>/project-locales`, for a package that ships `locales/`, with
  a module importing its table for exactly each declared language it ships,
  keyed by the project's tags, before Vite reads the package's own export of
  that name, in a build and in the development server, for the browser and for
  a server-side render; a declared language the package lacks is left out and
  logged once per package and language.
- The command `cognitio-languages`: `list` prints the source language, the
  languages and where they were declared; `write <package> <file>` writes the
  plugin's module to a file, byte for byte, for another bundler. Exit 1 on a
  declaration error, 2 on a wrong use.
- The record of copied texts, `copied-texts.json` beside the project's
  `package.json`: per copied file, the package and version it came from, and per
  key path the SHA-256 of the shipped text, its keys sorted, in two-space JSON.
  A text at the same path of the copy's shipped `file` is its fingerprint alone;
  a text from another file or path is `{ "file", "path", "sha256" }`, and a copy
  none of whose texts sits at its own path names no `file`.
- `cognitio-languages copy <package> <file> <target>` copies a JSON file a
  package ships into the project, never over a file that differs from it, and
  records every string of it; a record it cannot read stops it before it writes.
- `cognitio-languages copies [--check]` prints each copied text that is not in
  sync, as `module changed`, `customised`, `both`, `removed upstream` or
  `removed by the project`, a text that moved within a list being found by its
  fingerprint and a changed one only where the texts around it pin its place,
  and exits 1 when any reads `module changed`; `--write` writes those texts into
  the project and lists the rest; `--accept <target>[#<path>]` keeps the
  project's text over a changed shipped one, or takes a removed text out of the
  record. A recorded package that is not installed stops it, naming `sh
  install.sh add <package>`.
- The record and every project file the command writes are written whole,
  through a temporary file renamed over the old one.
- `recordCopies`, `checkCopies`, `refreshCopies` and `acceptCopies`, exported
  from `@cognitio/languages`, for a module's own command that copies texts;
  `recordCopies` takes, per text, an optional `shippedPath`, its key path in the
  shipped file when it differs from its path in the project's file.
- Type declarations for both entries.
- Vite is an optional peer dependency (`>=5`), needed by the plugin alone.
