/** Type declarations of `@cognitio/a11y/toolbar`. */

import type { ComponentType, ReactElement, ReactNode } from 'react';
import type { A11yPrefsConfig, ButtonSide } from './prefs.js';

/**
 * The texts of the panel: one layer, or a list of layers, first to last. A
 * layer is a function of the key (`undefined` passes to the next layer) or an
 * object of key → text; an absent layer is passed over. A key no layer answers
 * reads the built-in English, then the key itself.
 */
export type A11yTexts =
  | ((key: string) => string | undefined)
  | Readonly<Record<string, string>>
  | readonly (((key: string) => string | undefined) | Readonly<Record<string, string>> | null | undefined)[];

export interface A11yToolbarConfig extends A11yPrefsConfig {
  position?: {
    /** The button's corner, bottom left or bottom right, before the visitor moves it; `left` with no `position`. */
    side: ButtonSide;
    /** Inline `bottom` of the panel's root, also written as `--a11y-bottom`; none when absent. */
    bottom?: string;
    /** Inline offset from the side; `16px` when absent, none when empty. */
    offset?: string;
  };
  /** Keyboard shortcut that opens and closes the panel, e.g. "Alt+A"; none when empty. */
  shortcut?: string;
  /** Address of the "report a problem" link; no link when empty. */
  feedbackEmail?: string;
  /** Theme values written on the root as `--a11y-<kebab-key>` variables. */
  theme?: Record<string, string>;
  /** Width and height of the button's symbol, in px (30). */
  buttonIconSize?: number;
}

export interface StatementLinkProps {
  href: string;
  onClick: () => void;
  children: ReactNode;
}

export interface AccessibilityToolbarProps {
  config: A11yToolbarConfig;
  /** The panel's texts; the built-in English when absent. */
  texts?: A11yTexts;
  /**
   * Language of the page, written as `lang` on reading mode. On a page not in
   * English where no layer answers, the panel's root carries `lang="en"`, and
   * the page's own text inside it keeps the page's language.
   */
  lang?: string;
  /** BCP 47 tag of the speech synthesis; `lang` when absent. */
  speechLang?: string;
  /** Link of the site's accessibility statement; no link when absent. */
  statementHref?: string;
  /** Renders the statement link (for a router's link); a plain `<a>` when absent. */
  linkComponent?: ComponentType<StatementLinkProps>;
}

/** Keys of the texts the panel reads, besides `profile.<name>` and `profile.<name>.desc`. */
export const TEXT_KEYS: readonly string[];

export function AccessibilityToolbar(props: AccessibilityToolbarProps): ReactElement;
export default AccessibilityToolbar;

/** The layers of the reading guide, mask, magnifier and descriptions (rendered by the toolbar). */
export function AccessibilityTools(props: { config: A11yPrefsConfig }): ReactElement;
export function PageStructure(props: { t: (key: string) => string; onClose: () => void }): ReactElement;
export function ReadingMode(props: { t: (key: string) => string; lang?: string; onClose: () => void }): ReactElement | null;
export function useReadAloud(speechLang?: string): { supported: boolean; speaking: boolean; start: () => void; stop: () => void };
