# `@cognitio/a11y` — a site's accessibility kit

A site helps a visitor read it in the way that suits them: larger text, wider
spacing, a readable font, other contrasts, animations stopped, a reading guide.
This package gives a site three things for that:

- **the panel** (`@cognitio/a11y/toolbar`): a React component, a floating button
  that opens a panel of tiles — ready profiles, text adjustments, colours and
  navigation aids, read aloud, page structure and reading mode — with its
  stylesheet, `@cognitio/a11y/toolbar.css`;
- **the preferences** (`@cognitio/a11y` and `@cognitio/a11y/prefs`), with no
  framework: how the visitor's choices are saved in the browser and applied to
  the document as classes and CSS variables on `<html>`, and the check a
  script-driven animation makes for reduced motion;
- **the automatic check** (`cognitio-a11y-report`, and
  `@cognitio/a11y/report` for Node): every route of the built site opened in a
  real Chromium at a desktop and a mobile width, checked with axe-core against
  the WCAG 2.0/2.1 level A and AA rules, and written up as a Markdown report.

The panel helps a visitor; it does not make a site conformant. Conformance
depends on the site itself — a skip link, the page's language, visible focus,
contrast, the automatic check and a manual review — and the site's
accessibility statement is a page of the site.

The package holds no site's values: the features, the levels, the storage keys,
the colours and the statement's route come from the site. Its texts ship with
it, in English and translated, and a site's own texts win over them (see
[The texts](#the-texts)). The mount in the layout, the link that opens the panel
from the footer, the statement page, the reading fonts' import and the npm
script stay in the site.

It is plain JavaScript (ES modules, React through `React.createElement`, no
JSX) with type declarations, so a server-side render loads it as it is, with no
`ssr.noExternal`. It needs Node.js 20 or later; its tests run on Node.js 24.
[`CHANGELOG.md`](CHANGELOG.md) lists what each version holds.

## Adding it to a site

At the site's root, with the command the site already has:

```sh
sh install.sh add @cognitio/a11y
sh install.sh add @cognitio/languages
```

The command vendors the archives as `vendor/cognitio-a11y-<version>.tgz` and
`vendor/cognitio-languages-<version>.tgz` and writes the dependencies.
`@cognitio/a11y` is a runtime dependency, because the site's layout renders the
panel. `@cognitio/languages` reads the project's languages, declared once in its
`package.json`, for `@cognitio/a11y/project-locales` (see
[The texts](#the-texts)); it is a peer, so a project holds one copy of it,
shared by every module that reads the project's languages.

Its peers are the site's own: `react` and `react-dom` (18 or later) and
`lucide-react` (the panel's icons) for the panel; `@cognitio/languages` for
`@cognitio/a11y/project-locales`; `playwright` (or `@playwright/test`) and
`axe-core` for the check. All are marked optional, so that a site that uses
only the preferences or only the check installs only what that part imports,
and an install that cannot count a vendored archive as a required peer still
succeeds.

## Mounting the panel

The site renders the component once, in its layout, inside the element that
wraps its content, and gives that element the class `site-shell`
(`SHELL_CLASS`): the preferences act inside it, and reading mode makes it inert
while open.

```tsx
import { Link } from 'react-router-dom';
import AccessibilityToolbar, { type StatementLinkProps } from '@cognitio/a11y/toolbar';
import A11Y_TEXTS from '@cognitio/a11y/project-locales';
import '@cognitio/a11y/toolbar.css';
import a11yConfig from './a11y-config.json';

const RouterLink = ({ href, onClick, children }: StatementLinkProps) => <Link to={href} onClick={onClick}>{children}</Link>;

export function Layout({ lang }: { lang: 'en' | 'it' }) {
  return (
    <div className="site-shell">
      {/* header, main, footer */}
      <AccessibilityToolbar
        config={a11yConfig}
        texts={[A11Y_TEXTS[lang]]}
        lang={lang}
        speechLang={lang === 'en' ? 'en-GB' : 'it-IT'}
        statementHref={`/${lang}/accessibility-statement/`}
        linkComponent={RouterLink}
      />
    </div>
  );
}
```

| Prop | What it is |
|---|---|
| `config` | The panel's configuration, below. |
| `texts` | The panel's texts: one layer — a function of the key, or an object of key → text — or a list of layers, first to last (see [The texts](#the-texts)). The built-in English when absent. |
| `lang` | The page's language, written as `lang` on reading mode. On a page not in English where no layer answers, the panel's root carries `lang="en"`, and the page's own text inside it keeps the page's language. |
| `speechLang` | The BCP 47 tag of the read-aloud voice; `lang` when absent. |
| `statementHref` | The link of the site's accessibility statement, in the page's language; no link when absent. |
| `linkComponent` | Renders the statement link, for the site's router; it receives `href`, `onClick` and `children`. A plain `<a>` when absent. |

A link of the site that opens the panel — needed when the button can be hidden —
calls `openAccessibilityPanel()` from `@cognitio/a11y`. The panel also opens and
closes with the configured shortcut.

### The configuration

```json
{
  "storageKey": "example-a11y",
  "features": ["textSize", "lineHeight", "letterSpacing", "font", "align", "color", "highlightLinks", "highlightHeadings",
               "textMagnifier", "readAloud", "readingMode", "pageStructure", "stopAnimations", "hideImages", "muteSounds",
               "readingGuide", "readingMask", "cursor", "highlightFocus", "highlightHover", "tooltips", "hideButton"],
  "textSizes": [100, 110, 120, 135, 150],
  "lineHeights": [0, 1.7, 2, 2.3],
  "letterSpacings": [0, 0.06, 0.12],
  "profiles": {
    "vision": { "textSize": 2, "color": "high", "highlightLinks": true, "highlightHeadings": true, "cursor": "black" },
    "reading": { "font": "dyslexic", "lineHeight": 1, "letterSpacing": 1, "readingGuide": true },
    "seizure": { "stopAnimations": true, "color": "lowSaturation" },
    "focus": { "stopAnimations": true, "readingMask": true, "highlightFocus": true },
    "elderly": { "textSize": 2, "lineHeight": 1, "cursor": "black", "stopAnimations": true, "highlightHover": true }
  },
  "position": { "side": "left", "bottom": "96px" },
  "shortcut": "Alt+A",
  "feedbackEmail": "accessibility@example.com",
  "theme": { "accent": "#0050a0" }
}
```

| Field | What it is |
|---|---|
| `storageKey` | The localStorage key of the preferences. Keep the key a site already uses, or its visitors lose their choices. |
| `buttonStorageKey` | The key of the button's place (hidden, side); `<storageKey>-button` when absent. |
| `features` | The features shown. `hideButton` adds the command that hides the button: turn it on only when the site has its own link calling `openAccessibilityPanel()`. |
| `textSizes`, `lineHeights`, `letterSpacings` | The steppers' levels: percentages starting at 100; line heights and letter spacings (em) starting at 0, which leaves the site's own. |
| `profiles` | Named combinations of preferences, one row each. `vision`, `reading`, `seizure`, `focus` and `elderly` have their own icon; another name gets the accessibility symbol. The five above are the reference profiles: the shipped name and description of each (`profile.<name>`, `profile.<name>.desc`) describe exactly that combination, so a site that configures a profile differently, or adds one, passes its own two texts for it. |
| `position` | `side` of the button before the visitor moves it: `left` (the default, with no `position`) or `right`, the window's bottom-left or bottom-right corner, where the button floats over the page and takes no room of it; the panel opens above it, toward the page. `bottom` and `offset` (from the side, `16px` when absent, none when empty) as inline style; `bottom` is also written as `--a11y-bottom`. A site that places the button in its stylesheet leaves `bottom` out, sets `offset` to `""`, and declares `--a11y-bottom` there. |
| `shortcut` | The keyboard shortcut, e.g. `Alt+A`, matched on the physical key; none when empty. |
| `feedbackEmail` | The address of the "report a problem" link; no link when empty. |
| `theme` | Values written on the panel's root as `--a11y-*` variables (`buttonBackground` → `--a11y-button-background`). |
| `buttonIconSize` | The width and height of the button's symbol, in px (30). |
| `migratePrefs`, `migrateButtonPrefs` | Functions (in code, not JSON) that convert preferences a site stored in an earlier shape of its own before they are read. |

Preferences saved by the earlier, simpler panel (`contrast`, `underlineLinks`,
`readableFont`, `lineSpacing`, `bigCursor`) are converted by the package
itself.

### The texts

The panel's texts ship with the package in 42 languages: English, their source,
and 41 translations of it.

```text
en it de fr es pt-BR pt zh-Hans zh-Hant ja ko pl tr uk id vi ru hi ar bg cs da nl el
et fi ga hr hu lt lv mt ro sk sl sv nb is sr bs sq mk
```

Each language is a file `locales/<tag>.json` of key → text, and
`SHIPPED_LANGUAGES` (from `@cognitio/a11y`) lists the tags the installed version
holds, English first. The translations are machine translations that a native
speaker has not reviewed yet; a correction to any of them is welcome, as an
issue or as a change to its `locales/<tag>.json`.

**The project's languages, declared once.** A project that builds with Vite (or
Astro) declares its languages once, in its `package.json`, and registers the
plugin of `@cognitio/languages`:

```json
{
  "projectLanguages": ["en", "it", "de"]
}
```

```js
import { projectLanguagesPlugin } from '@cognitio/languages/vite';

export default defineConfig({ plugins: [projectLanguagesPlugin()] });
```

Then one import gives the tables of exactly the declared languages, keyed by
the project's own tags, and the page passes its own:

```tsx
import A11Y_TEXTS from '@cognitio/a11y/project-locales';

<AccessibilityToolbar config={config} lang={lang} texts={[A11Y_TEXTS[lang]]} />
```

The declaration can also name the project's own list file; a project tag is
matched to the file that serves it (`zh-CN` to `zh-Hans`, `pt-PT` to `pt`); and
`cognitio-languages write` writes the same module for another bundler: the
README of `@cognitio/languages` says how. Loaded without the plugin,
`@cognitio/a11y/project-locales` throws an error naming the plugin, the
declaration and the way without them.

**By hand, one import per language.** Without the declaration, or without a
Vite build, a project imports the file of each language it publishes and keys
it by its own tags:

```tsx
import en from '@cognitio/a11y/locales/en';
import it from '@cognitio/a11y/locales/it';

const A11Y_TEXTS = { en, it };
```

`@cognitio/a11y/locales/<tag>` is `locales/<tag>.mjs`, the texts of
`locales/<tag>.json` as a module that Node imports with no import attribute, as
a server-side render does; `@cognitio/a11y/locales/<tag>.json` is the JSON file
itself.

**The layers.** `texts` takes one layer or a list of layers, first to last, and
the panel reads each key from the first that answers:

1. a layer: an object of key → text answers a key it holds with a value other
   than `undefined`; a function of the key answers with anything but
   `undefined` (an empty string shows nothing); an absent layer (`undefined`,
   `null`) is passed over;
2. when no layer answers, the built-in English, `locales/en.json`;
3. when that has no text either, the key itself.

A site that words some keys its own way puts its texts before the table: an
object holding only those keys, or a function that returns `undefined` for every
key it leaves to the package.

```tsx
const OWN_TEXTS = { en: { title: 'Reading preferences' }, it: { title: 'Preferenze di lettura' } };

<AccessibilityToolbar config={config} lang={lang} texts={[OWN_TEXTS[lang], A11Y_TEXTS[lang]]} />
```

A function or an object that answers every key renders exactly its own texts.

**The project's own list.** The project chooses its languages: the package never
compares `SHIPPED_LANGUAGES` with them and asks for no language the project does
not publish, and the project's bundle holds only the tables it imports, besides
the English one. For a project language the package does not ship (`th`, say)
there is no table: the panel shows the project's own texts if it passes any, and
the built-in English for every other key, with no warning at run time; the
plugin says once, at build, which declared languages have no texts.

**English on a page in another language.** When no layer answers any key of
the built-in English on a page whose `lang` is not English, the panel's own
texts are all English, so its root carries `lang="en"` and a screen reader reads
them as English. What the panel shows of the site and the page keeps its own
language: a heading in the page-structure list whose language differs from the
list's carries its own `lang`, the magnifier's and the descriptions' copies of
the page's text carry the language of the element they copy, and a profile the
site adds, whose texts only the site gives, carries the page's `lang`.

**The keys.** `TEXT_KEYS` lists them, and each profile adds two,
`profile.<name>` and `profile.<name>.desc`:

| Keys | Where |
|---|---|
| `open`, `title`, `close` | the button's name, the panel's title, the close button |
| `profiles`, `text`, `colors`, `navigation` | the four sections |
| `textSize`, `lineHeight`, `letterSpacing`, `normal`, `increase`, `decrease` | the steppers: `<label>: <increase>` names the + button, `normal` is level 0 |
| `font.readable`, `font.dyslexic`, `align.left`, `align.center`, `align.right` | text tiles |
| `color.dark`, `color.light`, `color.high`, `color.monochrome`, `color.lowSaturation`, `color.highSaturation` | colour tiles |
| `highlightLinks`, `highlightHeadings`, `textMagnifier`, `stopAnimations`, `hideImages`, `muteSounds`, `readingGuide`, `readingMask`, `highlightFocus`, `highlightHover`, `tooltips`, `cursor.black`, `cursor.white` | on/off tiles |
| `readAloud`, `readAloudStop`, `pageStructure`, `landmark.header`, `landmark.nav`, `landmark.main`, `landmark.footer` | read aloud, page structure and its areas |
| `readingMode`, `readingModeClose`, `readingModeEmpty` | reading mode |
| `reset`, `hideButton`, `showButton`, `hideButtonHint`, `moveLeft`, `moveRight`, `shortcut` | the panel's foot |
| `statement`, `feedback`, `feedbackSubject` | the statement link, the report link and its email subject |
| `profile.vision`, `profile.reading`, `profile.seizure`, `profile.focus`, `profile.elderly` and each with `.desc` | the reference profiles' names and descriptions |

### The stylesheet and its variables

`@cognitio/a11y/toolbar.css` draws the panel and turns the preferences into
rules. It names the two reading fonts and loads neither: a site that offers
them imports their `@font-face`, e.g.
`@fontsource/atkinson-hyperlegible` and `@fontsource/opendyslexic`.

Every colour, font and radius is a variable with a neutral fallback. The
panel's variables come from `theme` or from the site's stylesheet; reading
mode and the rules applied to the page read only those the site declares on
`:root`:

| Variable | Fallback | Used by |
|---|---|---|
| `--a11y-font-family` | `sans-serif` | the panel, reading mode |
| `--a11y-button-background` | `#1f1f1f` | the button; reading mode's close button |
| `--a11y-button-icon` | `#fff` | the button's symbol and edge |
| `--a11y-button-shadow` | `0 4px 14px rgba(0, 0, 0, 0.25)` | the button |
| `--a11y-panel-background` | `#fff` | the panel, icons, reading mode |
| `--a11y-panel-text` | `#1f1f1f` (`#1a1a1a` in reading mode) | the panel's text, reading mode |
| `--a11y-muted-text` | `#555` | hints, profile descriptions |
| `--a11y-border` | `#ddd` (`#ccc` for reading mode's table cells) | borders |
| `--a11y-radius` | `8px` | the panel, tiles, page structure |
| `--a11y-control-radius` | `4px` | the foot's buttons, page structure's entries, reading mode's close button |
| `--a11y-tile-background` | `#f4f5f7` | tiles, reading mode's bar |
| `--a11y-tile-active-background` | `#ececec` | pressed tiles |
| `--a11y-accent` | `#1f1f1f` | pressed tiles, steppers, links, highlighted links, headings and hover |
| `--a11y-on-accent` | `#fff` | icons and steppers on the accent |
| `--a11y-focus` | `--a11y-accent` | focus outlines, the reading guide |
| `--a11y-reading-button-background` | `#fff` | reading mode's close button |
| `--a11y-reading-z-index` | `1000` | reading mode's layer |
| `--a11y-bottom` | `16px` | the button's distance from the window's bottom, which the open panel's height leaves room for, so the panel lies inside the window, on a phone held sideways too; written from `position.bottom` |
| `--a11y-readable-font` | `'Atkinson Hyperlegible', Verdana, sans-serif` | "More readable font" |
| `--a11y-dyslexic-font` | `'OpenDyslexic', 'Comic Sans MS', sans-serif` | "Dyslexia font" |

The preferences set `--a11y-font-scale`, `--a11y-line-height` and
`--a11y-letter-spacing` on `<html>` themselves.

### What a visitor's choices depend on

The saved preferences live under the site's `storageKey` (and the button's
place under its own key); they are applied as `a11y-*` classes on `<html>`
(`a11y-highlight-links`, `a11y-color-dark`, `a11y-text-scaled`, …). The panel
dispatches `a11y:change` (`A11Y_CHANGE_EVENT`) on `window` after every change,
and opens on `a11y:open` (`A11Y_OPEN_EVENT`). A component that animates from
script calls `prefersReducedMotion()`, true with "Stop animations" on or the
system's reduced-motion preference, and listens to `A11Y_CHANGE_EVENT`.

### Right-to-left pages

The panel follows the page's writing direction: on a page whose `<html>` has
`dir="rtl"` its rows, the page-structure indent and the reading mode's lists
and tables start on the right. The align options (left, centre, right) and the
button's `position.side` are physical by design: they name a side the visitor
or the site chooses, in any direction. Under the letter-spacing preference,
text whose language is Arabic (`:lang(ar)`) keeps its letters joined, because
spacing them breaks the word; its word spacing still takes the preference.

## The preferences, with no framework

`@cognitio/a11y` (the same as `@cognitio/a11y/prefs`) imports no framework and
no other package: only its generated list of the languages its texts ship in.
Each function takes the configuration:

| Export | What it does |
|---|---|
| `readPrefs(storage, cfg)`, `writePrefs(storage, prefs, cfg)` | The saved preferences, the defaults when none or unreadable. |
| `readButtonPrefs`, `writeButtonPrefs`, `buttonStorageKey` | The button's place. |
| `normalizePrefs(raw, cfg)` | Any object to the full, valid shape. |
| `applyProfile`, `profileActive` | A profile over the current preferences; whether it is on. |
| `prefsToDocument(prefs, cfg)`, `applyPrefs(prefs, cfg)` | The classes and variables for `<html>`; applying them. |
| `matchesShortcut(event, shortcut)` | Whether a key event is the shortcut. |
| `openAccessibilityPanel()`, `prefersReducedMotion()` | Open the panel; reduced motion. |
| `DEFAULT_PREFS`, `A11Y_OPEN_EVENT`, `A11Y_CHANGE_EVENT`, `STOP_ANIMATIONS_CLASS`, `SHELL_CLASS` | The constants. |
| `SHIPPED_LANGUAGES` | The tags of the languages whose texts the installed version ships, English first. |

`@cognitio/a11y/toolbar` also exports the panel's parts — `AccessibilityTools`
(the reading guide, mask, magnifier and descriptions), `PageStructure`,
`ReadingMode` and `useReadAloud` — which the panel renders itself.

## The command

```sh
cognitio-a11y-report --routes src/data/routes.json [--dist dist | --base <url>]
                     [--query <lang>=<query>]... [--consent <file>]
                     [--pages-note <text>] [--lang en|it] [--out <file>]
```

| Option | What it does |
|---|---|
| `--routes` | A JSON file of routes: an array, or an object with a `routes` array, each `{ "path", "lang"? }`. Every path is checked with a trailing slash, the form a static host answers with the route's pre-rendered page. |
| `--dist` | The built site, served by the command on a free port of 127.0.0.1 (`dist` by default). |
| `--base` | A server already running, instead of `--dist`. |
| `--query` | The query appended to the routes of a language, e.g. `--query en=?lang=en`; repeatable. |
| `--consent` | The site's consent configuration (`storageKey`, `version`, `durationDays`, `categories`): the banner is answered as a refusal before every page loads, so the check sees the page. |
| `--pages-note` | A note after the number of URLs, e.g. the languages. |
| `--lang` | The report's language, `en` (default) or `it`. |
| `--out` | The report's file, its directory created if needed; printed when absent. |

Paths are relative to the current directory. It checks every URL at 1366 and
390 px, lists the violated rules by number of pages with up to 15 pages each,
and reports a page that does not load (an HTTP error or a timeout) as a rule of
its own. It exits 0 once the report is written, whatever it finds, and 1 on an
error. A site runs it from an npm script after its build:

```json
"a11y:report": "cognitio-a11y-report --routes src/data/routes.json --consent src/data/consent.config.json"
```

`@cognitio/a11y/report` exports the same pieces for Node: `runAxeReport`,
`composeReport`, `reportUrls`, `readRoutes`, `checkablePath`,
`rejectedConsent`, `startStaticServer`, `fileToServe`, `contentType`,
`axeCore`, `messages`, `WIDTHS`, `WCAG_TAGS` and `MESSAGES`.

## Tests

```sh
npm install --no-save && npm test
```

The install copies `@cognitio/languages` from `../languages`, whose plugin the
tests run. The tests run with Vitest: the panel in jsdom (opening and closing,
every kind of tile and its effect on `<html>` and storage, steppers, profiles,
the button's place, the shortcut, the site's link, the tools, reading mode, the
server-side render), the shipped texts (each language's keys and placeholders,
the twins, `SHIPPED_LANGUAGES`) and the layers, the project's own languages both
ways (a project with two languages, a language the package does not ship, with
and without the project's texts, `project-locales` without the plugin and
answered by it), the preferences, the report (URLs, static server, consent,
both languages, a real run in Chromium on a small built site, through the
function and the command) and the package's shape (imports, exports, declared
exports, a consumer type-checked against the declarations). The real run needs
Playwright's Chromium (`npx playwright install chromium`); where Chromium
cannot start, it is skipped with a warning that gives the reason, and the
other tests still run.

## Licence

Apache License 2.0; see [`LICENSE`](LICENSE).
