/**
 * toolbar.mjs — The visitor's accessibility panel, as a React component.
 *
 * A floating button opens a panel of tiles with icons (lucide-react): ready
 * profiles, text adjustments (size, line height, letter spacing, readable or
 * dyslexia font, alignment, highlighted links and headings, magnifier),
 * colours (contrasts, black and white, saturation) and navigation (reading
 * mode, read aloud, page structure, stop animations, hide images, mute audio,
 * reading guide and mask, highlighted focus, highlight under the mouse,
 * descriptions on hover, large cursor).
 *
 * Accessible itself: the button has `aria-expanded`, `aria-controls` and
 * `aria-keyshortcuts`; the panel is a named `role="dialog"`; the tiles are
 * buttons with `aria-pressed`; Esc closes it and the focus goes back. The
 * visitor can move the button to the other side and, when the `hideButton`
 * feature is on, hide it: the panel then opens from the site's own link
 * (`openAccessibilityPanel`) and from the keyboard shortcut.
 *
 * Every text comes from the site, through `texts`. The features, levels,
 * profiles, position, shortcut and theme come from `config`. The route of the
 * accessibility statement is the site's: it passes the link's `statementHref`,
 * and `linkComponent` when its router should handle the link.
 *
 * A server-side render is the closed button with the default preferences; the
 * storage, the document and the keyboard are touched in effects and handlers
 * only. No network. Written with `React.createElement`: no build step.
 */

import React from 'react';
import {
  Accessibility,
  AlignCenter,
  AlignLeft,
  AlignRight,
  Armchair,
  ArrowLeftRight,
  Baseline,
  BookOpen,
  BookOpenText,
  Brain,
  CaseSensitive,
  Contrast,
  Droplet,
  Droplets,
  Eye,
  EyeOff,
  Focus,
  Glasses,
  Heading,
  ImageOff,
  Keyboard,
  Link2,
  ListTree,
  MessageSquareText,
  Minus,
  Moon,
  MousePointer2,
  MoveHorizontal,
  MoveVertical,
  Pause,
  Plus,
  RectangleHorizontal,
  RotateCcw,
  ScanLine,
  SquareMousePointer,
  Sun,
  SunDim,
  Type,
  Volume2,
  VolumeX,
  X,
  Zap,
  ZoomIn,
} from 'lucide-react';

import {
  A11Y_OPEN_EVENT,
  applyPrefs,
  applyProfile,
  DEFAULT_PREFS,
  matchesShortcut,
  profileActive,
  readButtonPrefs,
  readPrefs,
  writeButtonPrefs,
  writePrefs,
} from './prefs.mjs';
import { AccessibilityTools, PageStructure, ReadingMode, useReadAloud } from './tools.mjs';

export { AccessibilityTools, PageStructure, ReadingMode, useReadAloud };

const h = React.createElement;
const { useEffect, useRef, useState } = React;

/**
 * The keys of every text the panel reads through `texts`, besides the two of
 * each profile, `profile.<name>` and `profile.<name>.desc`.
 */
export const TEXT_KEYS = Object.freeze([
  'open',
  'title',
  'close',
  'profiles',
  'text',
  'colors',
  'navigation',
  'textSize',
  'lineHeight',
  'letterSpacing',
  'normal',
  'increase',
  'decrease',
  'font.readable',
  'font.dyslexic',
  'highlightLinks',
  'highlightHeadings',
  'textMagnifier',
  'align.left',
  'align.center',
  'align.right',
  'color.dark',
  'color.light',
  'color.high',
  'color.monochrome',
  'color.lowSaturation',
  'color.highSaturation',
  'readingMode',
  'readingModeClose',
  'readingModeEmpty',
  'readAloud',
  'readAloudStop',
  'pageStructure',
  'landmark.header',
  'landmark.nav',
  'landmark.main',
  'landmark.footer',
  'stopAnimations',
  'hideImages',
  'muteSounds',
  'readingGuide',
  'readingMask',
  'highlightFocus',
  'highlightHover',
  'tooltips',
  'cursor.black',
  'cursor.white',
  'reset',
  'hideButton',
  'showButton',
  'hideButtonHint',
  'moveLeft',
  'moveRight',
  'shortcut',
  'statement',
  'feedback',
  'feedbackSubject',
]);

const storage = () => (typeof window !== 'undefined' ? window.localStorage : undefined);

/** `texts` as a function: a function is used as is; in an object a missing key reads as the key. */
const textFunction = (texts) => (typeof texts === 'function' ? texts : (k) => texts?.[k] ?? k);

/**
 * The inline style of the panel's root: the theme as `--a11y-*` variables
 * (`buttonBackground` → `--a11y-button-background`), then the offset from the
 * button's side and the distance from the bottom.
 */
function rootStyle(cfg, side) {
  const v = {};
  for (const [k, val] of Object.entries(cfg.theme ?? {})) v[`--a11y-${k.replace(/[A-Z]/g, (c) => `-${c.toLowerCase()}`)}`] = val;
  const offset = cfg.position?.offset === undefined ? '16px' : cfg.position.offset;
  if (offset) v[side] = offset;
  if (cfg.position?.bottom) v.bottom = cfg.position.bottom;
  return v;
}

const PROFILE_ICONS = { vision: Glasses, reading: BookOpen, seizure: Zap, focus: Brain, elderly: Armchair };
const FONT_TILES = [
  ['readable', CaseSensitive],
  ['dyslexic', Type],
];
const ALIGN_TILES = [
  ['left', AlignLeft],
  ['center', AlignCenter],
  ['right', AlignRight],
];
const COLOR_TILES = [
  ['dark', Moon],
  ['light', Sun],
  ['high', Contrast],
  ['monochrome', Droplet],
  ['lowSaturation', SunDim],
  ['highSaturation', Droplets],
];
const TEXT_TOGGLES = [
  ['highlightLinks', Link2],
  ['highlightHeadings', Heading],
  ['textMagnifier', ZoomIn],
];
const NAV_TOGGLES = [
  ['stopAnimations', Pause],
  ['hideImages', ImageOff],
  ['muteSounds', VolumeX],
  ['readingGuide', ScanLine],
  ['readingMask', RectangleHorizontal],
  ['highlightFocus', Focus],
  ['highlightHover', SquareMousePointer],
  ['tooltips', MessageSquareText],
];
/** Icons of the large cursor: the fill shows the chosen colour. */
const CursorBlack = (p) => h(MousePointer2, { ...p, fill: 'currentColor' });
const CursorWhite = (p) => h(MousePointer2, { ...p, fill: '#fff' });
const CURSOR_TILES = [
  ['black', CursorBlack],
  ['white', CursorWhite],
];

/** The symbol of universal access (a figure with open arms), drawn by hand. */
function AccessSymbol({ size }) {
  return h(
    'svg',
    { viewBox: '0 0 24 24', width: String(size), height: String(size), 'aria-hidden': 'true', focusable: 'false' },
    h('circle', { cx: '12', cy: '4.2', r: '2.1', fill: 'currentColor' }),
    h('path', {
      d: 'M4.2 8.3c2.6.8 5.2 1.1 7.8 1.1s5.2-.3 7.8-1.1l.55 1.9c-2.1.65-4.3 1.05-6.55 1.2v3.1l2.35 7.3-1.95.62L12 16.1l-2.2 6.3-1.95-.62 2.35-7.3v-3.1c-2.25-.15-4.45-.55-6.55-1.2z',
      fill: 'currentColor',
    }),
  );
}

function ProfileRow({ icon, label, desc, pressed, onClick }) {
  return h(
    'button',
    { type: 'button', className: 'a11y-profile', 'aria-pressed': pressed, onClick },
    h('span', { className: 'a11y-tile-icon', 'aria-hidden': 'true' }, h(icon, { size: 22, strokeWidth: 1.8 })),
    h('span', { className: 'a11y-profile-text' }, h('span', { className: 'a11y-profile-name' }, label), h('span', { className: 'a11y-profile-desc' }, desc)),
    h('span', { className: 'a11y-profile-state', 'aria-hidden': 'true' }, pressed ? '✓' : ''),
  );
}

function Tile({ icon, label, pressed, onClick }) {
  return h(
    'button',
    { type: 'button', className: 'a11y-tile', 'aria-pressed': pressed, onClick },
    h('span', { className: 'a11y-tile-icon', 'aria-hidden': 'true' }, h(icon, { size: 22, strokeWidth: 1.8 })),
    h('span', { className: 'a11y-tile-label' }, label),
  );
}

function Stepper({ icon, label, value, max, valueLabel, onChange, t }) {
  return h(
    'div',
    { className: 'a11y-tile a11y-tile-wide', role: 'group', 'aria-label': label },
    h('span', { className: 'a11y-tile-icon', 'aria-hidden': 'true' }, h(icon, { size: 22, strokeWidth: 1.8 })),
    h('span', { className: 'a11y-tile-label' }, label),
    h(
      'span',
      { className: 'a11y-stepper' },
      h('button', { type: 'button', 'aria-label': `${label}: ${t('decrease')}`, disabled: value <= 0, onClick: () => onChange(value - 1) }, h(Minus, { size: 16, 'aria-hidden': 'true' })),
      h('span', { className: 'a11y-stepper-value', 'aria-live': 'polite' }, valueLabel),
      h('button', { type: 'button', 'aria-label': `${label}: ${t('increase')}`, disabled: value >= max, onClick: () => onChange(value + 1) }, h(Plus, { size: 16, 'aria-hidden': 'true' })),
    ),
  );
}

function Section({ title, children }) {
  return h('section', { className: 'a11y-section', 'aria-label': title }, h('h3', null, title), h('div', { className: 'a11y-grid' }, children));
}

/** The statement link when the site passes no `linkComponent`: a plain anchor. */
function PlainLink({ href, onClick, children }) {
  return h('a', { href, onClick }, children);
}

export function AccessibilityToolbar({ config, texts, lang, speechLang, statementHref, linkComponent }) {
  const cfg = config;
  const t = textFunction(texts);
  const [open, setOpen] = useState(false);
  const [structure, setStructure] = useState(false);
  const [reading, setReading] = useState(false);
  const [prefs, setPrefs] = useState(DEFAULT_PREFS);
  const [btn, setBtn] = useState({ hidden: false });
  const button = useRef(null);
  const panel = useRef(null);
  /** The element the panel was opened from (the site's link, the shortcut). */
  const returnFocus = useRef(null);
  const reader = useReadAloud(speechLang ?? lang);

  // The saved preferences are read after hydration: the server render is the
  // default one, the same for every visitor.
  useEffect(() => {
    const p = readPrefs(storage(), cfg);
    setPrefs(p);
    applyPrefs(p, cfg);
    setBtn(readButtonPrefs(storage(), cfg));
    // The configuration is read once, at mount.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Opening from the site's link, and the keyboard shortcut.
  useEffect(() => {
    const remember = () => {
      const el = document.activeElement;
      returnFocus.current = el && el !== document.body && !el.closest('.a11y-root') ? el : null;
    };
    const openFromLink = () => {
      remember();
      setOpen(true);
    };
    const onKey = (e) => {
      if (e.defaultPrevented || !cfg.shortcut || !matchesShortcut(e, cfg.shortcut)) return;
      e.preventDefault();
      setOpen((o) => {
        if (!o) remember();
        return !o;
      });
    };
    window.addEventListener(A11Y_OPEN_EVENT, openFromLink);
    document.addEventListener('keydown', onKey);
    return () => {
      window.removeEventListener(A11Y_OPEN_EVENT, openFromLink);
      document.removeEventListener('keydown', onKey);
    };
  }, [cfg.shortcut]);

  const restoreFocus = () => {
    const target = button.current ?? returnFocus.current;
    returnFocus.current = null;
    target?.focus();
  };
  const close = () => {
    setOpen(false);
    restoreFocus();
  };

  // Reading mode closed: the focus goes back once the site is no longer inert.
  const wasReading = useRef(false);
  useEffect(() => {
    if (wasReading.current && !reading) restoreFocus();
    wasReading.current = reading;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [reading]);

  useEffect(() => {
    if (!open) return;
    panel.current?.querySelector('button')?.focus();
    const onKey = (e) => {
      if (e.key === 'Escape') close();
    };
    document.addEventListener('keydown', onKey);
    return () => document.removeEventListener('keydown', onKey);
    // `close` reads refs only.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open]);

  const update = (next) => {
    setPrefs(next);
    writePrefs(storage(), next, cfg);
    applyPrefs(next, cfg);
  };
  const updateButton = (next) => {
    setBtn(next);
    writeButtonPrefs(storage(), next, cfg);
  };
  const has = (f) => (cfg.features ?? []).includes(f);
  const level = (i) => (i === 0 ? t('normal') : `+${i}`);
  const side = btn.side ?? cfg.position?.side ?? 'left';
  // A button hidden while the command to show it again was on stays visible
  // once the site turns the command off.
  const hidden = has('hideButton') && btn.hidden;
  const profiles = Object.keys(cfg.profiles ?? {});
  const textSizes = cfg.textSizes ?? [];
  const lineHeights = cfg.lineHeights ?? [];
  const letterSpacings = cfg.letterSpacings ?? [];
  const StatementLink = linkComponent ?? PlainLink;

  const toggle = ([f, icon]) => h(Tile, { key: f, icon, label: t(f), pressed: prefs[f], onClick: () => update({ ...prefs, [f]: !prefs[f] }) });
  const choice = (group, field) => ([mode, icon]) =>
    h(Tile, {
      key: mode,
      icon,
      label: t(`${group}.${mode}`),
      pressed: prefs[field] === mode,
      onClick: () => update({ ...prefs, [field]: prefs[field] === mode ? 'default' : mode }),
    });

  const panelNode =
    open &&
    h(
      'div',
      { ref: panel, id: 'a11y-panel', className: 'a11y-panel', role: 'dialog', 'aria-modal': 'false', 'aria-labelledby': 'a11y-title' },
      h(
        'div',
        { className: 'a11y-head' },
        h('h2', { id: 'a11y-title' }, t('title')),
        h('button', { type: 'button', className: 'a11y-close', 'aria-label': t('close'), onClick: close }, h(X, { size: 20, 'aria-hidden': 'true' })),
      ),
      profiles.length > 0 &&
        h(
          Section,
          { title: t('profiles') },
          profiles.map((name) =>
            h(ProfileRow, {
              key: name,
              icon: PROFILE_ICONS[name] ?? Accessibility,
              label: t(`profile.${name}`),
              desc: t(`profile.${name}.desc`),
              pressed: profileActive(prefs, name, cfg),
              onClick: () => update(profileActive(prefs, name, cfg) ? { ...DEFAULT_PREFS } : applyProfile(prefs, name, cfg)),
            }),
          ),
        ),
      h(
        Section,
        { title: t('text') },
        has('textSize') &&
          h(Stepper, {
            icon: Baseline,
            label: t('textSize'),
            value: prefs.textSize,
            max: textSizes.length - 1,
            valueLabel: `${textSizes[prefs.textSize]}%`,
            onChange: (n) => update({ ...prefs, textSize: n }),
            t,
          }),
        has('lineHeight') &&
          h(Stepper, {
            icon: MoveVertical,
            label: t('lineHeight'),
            value: prefs.lineHeight,
            max: lineHeights.length - 1,
            valueLabel: level(prefs.lineHeight),
            onChange: (n) => update({ ...prefs, lineHeight: n }),
            t,
          }),
        has('letterSpacing') &&
          h(Stepper, {
            icon: MoveHorizontal,
            label: t('letterSpacing'),
            value: prefs.letterSpacing,
            max: letterSpacings.length - 1,
            valueLabel: level(prefs.letterSpacing),
            onChange: (n) => update({ ...prefs, letterSpacing: n }),
            t,
          }),
        has('font') && FONT_TILES.map(choice('font', 'font')),
        TEXT_TOGGLES.filter(([f]) => has(f)).map(toggle),
        has('align') && ALIGN_TILES.map(choice('align', 'align')),
      ),
      has('color') && h(Section, { title: t('colors') }, COLOR_TILES.map(choice('color', 'color'))),
      h(
        Section,
        { title: t('navigation') },
        has('readingMode') &&
          h(Tile, {
            icon: BookOpenText,
            label: t('readingMode'),
            onClick: () => {
              setOpen(false);
              setReading(true);
            },
          }),
        has('readAloud') &&
          reader.supported &&
          h(Tile, {
            icon: Volume2,
            label: reader.speaking ? t('readAloudStop') : t('readAloud'),
            pressed: reader.speaking,
            onClick: () => (reader.speaking ? reader.stop() : reader.start()),
          }),
        has('pageStructure') && h(Tile, { icon: ListTree, label: t('pageStructure'), pressed: structure, onClick: () => setStructure((s) => !s) }),
        NAV_TOGGLES.filter(([f]) => has(f)).map(toggle),
        has('cursor') && CURSOR_TILES.map(choice('cursor', 'cursor')),
      ),
      structure && h(PageStructure, { t, onClose: () => setStructure(false) }),
      h(
        'div',
        { className: 'a11y-foot' },
        h('button', { type: 'button', className: 'a11y-reset', onClick: () => update({ ...DEFAULT_PREFS }) }, h(RotateCcw, { size: 16, 'aria-hidden': 'true' }), ' ', t('reset')),
        h(
          'div',
          { className: 'a11y-button-actions' },
          has('hideButton') &&
            h(
              'button',
              { type: 'button', className: 'a11y-reset', onClick: () => updateButton({ ...btn, hidden: !btn.hidden }) },
              btn.hidden ? h(Eye, { size: 16, 'aria-hidden': 'true' }) : h(EyeOff, { size: 16, 'aria-hidden': 'true' }),
              ' ',
              t(btn.hidden ? 'showButton' : 'hideButton'),
            ),
          h(
            'button',
            { type: 'button', className: 'a11y-reset', onClick: () => updateButton({ ...btn, side: side === 'left' ? 'right' : 'left' }) },
            h(ArrowLeftRight, { size: 16, 'aria-hidden': 'true' }),
            ' ',
            t(side === 'left' ? 'moveRight' : 'moveLeft'),
          ),
        ),
        has('hideButton') && h('p', { className: 'a11y-hint' }, t('hideButtonHint')),
        cfg.shortcut && h('p', { className: 'a11y-hint' }, h(Keyboard, { size: 16, 'aria-hidden': 'true' }), ' ', t('shortcut'), ': ', h('kbd', null, cfg.shortcut)),
        statementHref && h(StatementLink, { href: statementHref, onClick: () => setOpen(false) }, t('statement')),
        cfg.feedbackEmail && h('a', { href: `mailto:${cfg.feedbackEmail}?subject=${encodeURIComponent(t('feedbackSubject'))}` }, t('feedback')),
      ),
    );

  return h(
    'div',
    { className: 'a11y-root', 'data-side': side, style: rootStyle(cfg, side) },
    h(AccessibilityTools, { config: cfg }),
    !hidden &&
      h(
        'button',
        {
          ref: button,
          type: 'button',
          className: 'a11y-fab',
          'aria-expanded': open,
          'aria-controls': 'a11y-panel',
          'aria-label': t('open'),
          'aria-keyshortcuts': cfg.shortcut || undefined,
          onClick: () => setOpen((o) => !o),
        },
        h(AccessSymbol, { size: cfg.buttonIconSize ?? 30 }),
      ),
    panelNode,
    reading && h(ReadingMode, { t, lang, onClose: () => setReading(false) }),
  );
}

export default AccessibilityToolbar;
