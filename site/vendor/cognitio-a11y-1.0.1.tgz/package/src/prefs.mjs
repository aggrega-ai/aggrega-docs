/**
 * prefs.mjs — A visitor's accessibility preferences, with no framework.
 *
 * The preferences chosen in the panel are saved in the browser's storage, under
 * the site's own key, and applied to `<html>` as classes and CSS variables,
 * which the package's stylesheet (`toolbar.css`) turns into rules. Pure
 * functions, plus the two that touch the document (`applyPrefs`,
 * `prefersReducedMotion`) and the one that dispatches the open event; every
 * one of them returns at once outside a browser, and every storage read and
 * write tolerates a missing or broken storage.
 *
 * The configuration is the site's: which features are on, the levels of the
 * three steppers, the profiles, the storage keys. Nothing here names a site.
 */

/** The preferences when nothing is chosen. */
export const DEFAULT_PREFS = Object.freeze({
  textSize: 0,
  lineHeight: 0,
  letterSpacing: 0,
  font: 'default',
  align: 'default',
  color: 'default',
  cursor: 'default',
  highlightLinks: false,
  highlightHeadings: false,
  textMagnifier: false,
  stopAnimations: false,
  hideImages: false,
  muteSounds: false,
  readingGuide: false,
  readingMask: false,
  highlightFocus: false,
  highlightHover: false,
  tooltips: false,
});

/** Event that opens the panel from outside it (a footer link), even with its button hidden. */
export const A11Y_OPEN_EVENT = 'a11y:open';

/** Event dispatched on `window` after every change of the preferences. */
export const A11Y_CHANGE_EVENT = 'a11y:change';

/** Class on `<html>` while "Stop animations" is on. */
export const STOP_ANIMATIONS_CLASS = 'a11y-stop-animations';

/**
 * Class of the element wrapping the site's content. The rules of the
 * preferences act inside it, and reading mode makes it inert while open.
 */
export const SHELL_CLASS = 'site-shell';

/** Classes on `<html>` of the on/off preferences that CSS alone renders. */
const TOGGLE_CLASS = {
  highlightLinks: 'a11y-highlight-links',
  highlightHeadings: 'a11y-highlight-headings',
  stopAnimations: STOP_ANIMATIONS_CLASS,
  hideImages: 'a11y-hide-images',
  highlightFocus: 'a11y-highlight-focus',
  highlightHover: 'a11y-highlight-hover',
  textMagnifier: 'a11y-text-magnifier',
};

const COLOR_MODES = ['dark', 'light', 'high', 'monochrome', 'lowSaturation', 'highSaturation'];
const MANAGED_VARS = ['--a11y-font-scale', '--a11y-line-height', '--a11y-letter-spacing'];

const clampIndex = (n, len) => Math.min(Math.max(0, Math.trunc(Number(n) || 0)), Math.max(0, len - 1));
const levels = (list) => (Array.isArray(list) ? list : []);
const features = (cfg) => (Array.isArray(cfg?.features) ? cfg.features : []);
const isObject = (v) => v !== null && typeof v === 'object' && !Array.isArray(v);

/** The storage key of the panel's button: `buttonStorageKey`, or `<storageKey>-button`. */
export function buttonStorageKey(cfg) {
  return cfg.buttonStorageKey ?? `${cfg.storageKey}-button`;
}

/**
 * Any object — read from storage, or a profile laid over the current
 * preferences — brought to the full, valid shape: unknown keys dropped,
 * out-of-range values back to the default, indexes limited to the configured
 * levels. Preferences saved by the earlier, simpler panel (`contrast`,
 * `underlineLinks`, `readableFont`, `lineSpacing`, `bigCursor`) are carried
 * over to their counterparts.
 */
export function normalizePrefs(raw, cfg) {
  const r = isObject(raw) ? raw : {};
  const p = { ...DEFAULT_PREFS };
  for (const k of Object.keys(DEFAULT_PREFS)) {
    if (typeof DEFAULT_PREFS[k] === 'boolean' && typeof r[k] === 'boolean') p[k] = r[k];
  }
  if (r.contrast === true && !r.color) p.color = 'high';
  if (r.underlineLinks === true && r.highlightLinks === undefined) p.highlightLinks = true;
  if (r.readableFont === true && !r.font) p.font = 'readable';
  if (r.lineSpacing === true && r.lineHeight === undefined) p.lineHeight = 1;
  if (r.bigCursor === true && !r.cursor) p.cursor = 'black';
  p.textSize = clampIndex(r.textSize, levels(cfg.textSizes).length);
  if (r.lineHeight !== undefined) p.lineHeight = clampIndex(r.lineHeight, levels(cfg.lineHeights).length);
  p.letterSpacing = clampIndex(r.letterSpacing, levels(cfg.letterSpacings).length);
  if (r.font === 'readable' || r.font === 'dyslexic') p.font = r.font;
  if (r.align === 'left' || r.align === 'center' || r.align === 'right') p.align = r.align;
  if (typeof r.color === 'string' && COLOR_MODES.includes(r.color)) p.color = r.color;
  if (r.cursor === 'black' || r.cursor === 'white') p.cursor = r.cursor;
  return p;
}

/** The saved preferences, or the defaults when there are none or they cannot be read. */
export function readPrefs(storage, cfg) {
  try {
    const raw = storage?.getItem(cfg.storageKey);
    if (!raw) return { ...DEFAULT_PREFS };
    const parsed = JSON.parse(raw);
    return normalizePrefs(cfg.migratePrefs ? cfg.migratePrefs(parsed) : parsed, cfg);
  } catch {
    return { ...DEFAULT_PREFS };
  }
}

export function writePrefs(storage, prefs, cfg) {
  try {
    storage?.setItem(cfg.storageKey, JSON.stringify(prefs));
  } catch {
    /* storage unavailable: the choice holds for the current page only */
  }
}

/** A profile (a predefined combination) laid over the current preferences. */
export function applyProfile(prefs, name, cfg) {
  return normalizePrefs({ ...prefs, ...(cfg.profiles?.[name] ?? {}) }, cfg);
}

/** True when every setting of the profile is already on. */
export function profileActive(prefs, name, cfg) {
  const pr = cfg.profiles?.[name];
  return !!pr && Object.entries(pr).every(([k, v]) => prefs[k] === v);
}

/**
 * The panel's button, hidden or moved by the visitor. It has a key of its own,
 * so resetting the preferences leaves it where the visitor put it.
 */
export function readButtonPrefs(storage, cfg) {
  try {
    let raw = JSON.parse(storage?.getItem(buttonStorageKey(cfg)) ?? '{}');
    if (cfg.migrateButtonPrefs) raw = cfg.migrateButtonPrefs(raw);
    if (!isObject(raw)) return { hidden: false };
    return { hidden: raw.hidden === true, side: raw.side === 'left' || raw.side === 'right' ? raw.side : undefined };
  } catch {
    return { hidden: false };
  }
}

export function writeButtonPrefs(storage, b, cfg) {
  try {
    storage?.setItem(buttonStorageKey(cfg), JSON.stringify(b));
  } catch {
    /* storage unavailable: the button is back in its place on the next page */
  }
}

/** Opens the panel from outside it. Outside a browser it does nothing. */
export function openAccessibilityPanel() {
  if (typeof window !== 'undefined') window.dispatchEvent(new Event(A11Y_OPEN_EVENT));
}

/**
 * True when the keyboard event is the shortcut, e.g. "Alt+A", with exactly its
 * modifiers. A letter is matched on the physical key (`code`): with Option on a
 * Mac, `key` is "å", not "a".
 */
export function matchesShortcut(e, shortcut) {
  const parts = String(shortcut ?? '').split('+').map((x) => x.trim().toLowerCase());
  const key = parts.pop() ?? '';
  if (!key) return false;
  const mods = { alt: parts.includes('alt'), ctrl: parts.includes('ctrl'), meta: parts.includes('meta'), shift: parts.includes('shift') };
  if (e.altKey !== mods.alt || e.ctrlKey !== mods.ctrl || e.metaKey !== mods.meta || e.shiftKey !== mods.shift) return false;
  return /^[a-z]$/.test(key) ? e.code === `Key${key.toUpperCase()}` : String(e.key).toLowerCase() === key;
}

/** The classes and CSS variables a set of preferences puts on `<html>` (pure). */
export function prefsToDocument(prefs, cfg) {
  const list = features(cfg);
  const on = (f) => list.includes(f);
  const classes = [];
  for (const [k, cls] of Object.entries(TOGGLE_CLASS)) {
    if (on(k) && prefs[k]) classes.push(cls);
  }
  if (on('font') && prefs.font !== 'default') classes.push(`a11y-font-${prefs.font}`);
  if (on('align') && prefs.align !== 'default') classes.push(`a11y-align-${prefs.align}`);
  if (on('cursor') && prefs.cursor !== 'default') classes.push('a11y-big-cursor', `a11y-cursor-${prefs.cursor}`);
  if (on('color') && prefs.color !== 'default') classes.push(`a11y-color-${prefs.color.replace(/[A-Z]/g, (c) => `-${c.toLowerCase()}`)}`);
  const vars = {};
  const size = on('textSize') ? levels(cfg.textSizes)[prefs.textSize] ?? 100 : 100;
  if (size !== 100) {
    classes.push('a11y-text-scaled');
    vars['--a11y-font-scale'] = String(size / 100);
  }
  const lh = on('lineHeight') ? levels(cfg.lineHeights)[prefs.lineHeight] ?? 0 : 0;
  if (lh) {
    classes.push('a11y-line-height');
    vars['--a11y-line-height'] = String(lh);
  }
  const ls = on('letterSpacing') ? levels(cfg.letterSpacings)[prefs.letterSpacing] ?? 0 : 0;
  if (ls) {
    classes.push('a11y-letter-spacing');
    vars['--a11y-letter-spacing'] = `${ls}em`;
  }
  return { classes, vars };
}

/**
 * Applies the preferences to the current document: every other `a11y-*` class
 * on `<html>` is removed. Then dispatches `A11Y_CHANGE_EVENT`, which the
 * package's tools and a site's script-driven animations listen to.
 */
export function applyPrefs(prefs, cfg) {
  if (typeof document === 'undefined') return;
  const root = document.documentElement;
  const { classes, vars } = prefsToDocument(prefs, cfg);
  for (const c of Array.from(root.classList)) if (c.startsWith('a11y-') && !classes.includes(c)) root.classList.remove(c);
  for (const c of classes) root.classList.add(c);
  for (const v of MANAGED_VARS) {
    if (vars[v]) root.style.setProperty(v, vars[v]);
    else root.style.removeProperty(v);
  }
  if (typeof window !== 'undefined') window.dispatchEvent(new Event(A11Y_CHANGE_EVENT));
}

/**
 * Reduced motion: the operating system's preference, or "Stop animations" in
 * the panel. A component that animates from script checks this instead of the
 * media query alone, which does not see the panel's choice. False outside a
 * browser.
 */
export function prefersReducedMotion() {
  if (typeof window === 'undefined' || typeof document === 'undefined') return false;
  if (document.documentElement.classList.contains(STOP_ANIMATIONS_CLASS)) return true;
  return typeof window.matchMedia === 'function' && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
}
