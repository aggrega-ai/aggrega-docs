/** Type declarations of `@cognitio/a11y/report`. */

export type ReportLang = 'en' | 'it';

export interface ReportNode {
  target: string;
  summary: string;
}

export interface RuleEntry {
  id: string;
  impact: string;
  help: string;
  helpUrl?: string;
  tags: string[];
  /** `"<url> @<width>"` → nodes. */
  pages: Map<string, ReportNode[]>;
}

export interface Route {
  path: string;
  lang?: string;
}

export interface StorageEntry {
  key: string;
  value: string;
}

export interface ConsentConfig {
  storageKey: string;
  version: string | number;
  durationDays: number;
  categories: Array<{ key: string; required?: boolean }>;
}

export const WIDTHS: readonly number[];
export const WCAG_TAGS: readonly string[];
export const MESSAGES: Readonly<Record<ReportLang, Record<string, unknown>>>;

export function messages(lang?: ReportLang): Record<string, any>;
export function checkablePath(p: string): string;
export function reportUrls(routes: Route[], options?: { query?: Record<string, string> }): string[];
export function readRoutes(file: string): Route[];
export function contentType(file: string): string;
export function fileToServe(dir: string, requested: string, isFile: (absolute: string) => boolean): string | null;
export function startStaticServer(dir: string): Promise<{ base: string; close: () => Promise<void> }>;
export function rejectedConsent(config: ConsentConfig, now: Date, uuid?: () => string): StorageEntry;
export function composeReport(input: {
  date: string;
  axeVersion: string;
  urls: string[];
  widths: readonly number[];
  checks: number;
  base: string;
  byRule: Map<string, RuleEntry>;
  pagesNote?: string;
  lang?: ReportLang;
}): string;
export function axeCore(): { version: string; source: string };
export function runAxeReport(options: {
  urls: string[];
  base?: string;
  dist?: string;
  widths?: readonly number[];
  storage?: StorageEntry[];
  pagesNote?: string;
  lang?: ReportLang;
  date?: string;
  chromium?: unknown;
  axe?: { version: string; source: string };
}): Promise<{ report: string; byRule: Map<string, RuleEntry>; checks: number; base: string }>;
