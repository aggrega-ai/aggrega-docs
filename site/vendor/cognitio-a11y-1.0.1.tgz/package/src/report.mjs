/**
 * report.mjs — The automatic accessibility check of a built site, for Node.
 *
 * Opens every route of the site in a real Chromium (Playwright), at a desktop
 * and a mobile width, and runs axe-core with the WCAG 2.0/2.1 level A and AA
 * rules, colour contrast included. It is not part of a build or of the tests:
 * it writes a Markdown report, which the `cognitio-a11y-report` command prints
 * or saves.
 *
 * The pages come either from a server already running (`base`) or from the
 * built directory (`dist`), which a minimal static server serves on a free
 * port of 127.0.0.1, resolving each path as a static host does: the exact file,
 * then the directory's `index.html`. A consent banner can be resolved
 * beforehand as a refusal, so the check sees the page and not the banner.
 *
 * No request leaves for anything but the server named or started.
 */

import fs from 'node:fs';
import http from 'node:http';
import path from 'node:path';
import { randomUUID } from 'node:crypto';
import { createRequire } from 'node:module';

const require = createRequire(import.meta.url);

/** The widths checked: desktop and mobile. */
export const WIDTHS = Object.freeze([1366, 390]);
/** The axe-core rule tags the check applies. */
export const WCAG_TAGS = Object.freeze(['wcag2a', 'wcag2aa', 'wcag21a', 'wcag21aa']);

const DAY_MS = 86_400_000;

/** The report's sentences, in the two languages it is written in. */
export const MESSAGES = Object.freeze({
  it: {
    title: (date) => `# Verifica di accessibilità automatica — ${date}`,
    tool: (version) => `Strumento: axe-core ${version}, regole WCAG 2.0/2.1 livelli A e AA (contrasto incluso), Chromium reale.`,
    pages: ({ urls, note, widths, checks, base }) =>
      `Pagine: ${urls} URL${note ? ` (${note})` : ''} × ${widths.length} larghezze (${widths.join(' e ')} px) = ${checks} verifiche. Server: ${base}.`,
    manual: 'I controlli automatici coprono solo una parte dei criteri WCAG: la conformità richiede anche una verifica manuale (tastiera, lettori di schermo, contenuti).',
    clean: '**Esito: nessuna violazione rilevata.**',
    violations: '## Violazioni',
    header: '| Regola | Gravità | Criteri WCAG | Pagine | Elementi |',
    reference: (url) => `Riferimento: ${url}`,
    more: (n) => `- … altre ${n} pagine`,
    loadErrorId: 'errore-di-caricamento',
    loadErrorHelp: 'Pagina non verificabile',
    noResponse: 'nessuna risposta',
    written: (out, rules, checks) => `report scritto: ${out} (${rules} regole violate, ${checks} verifiche)`,
  },
  en: {
    title: (date) => `# Automatic accessibility check — ${date}`,
    tool: (version) => `Tool: axe-core ${version}, WCAG 2.0/2.1 level A and AA rules (contrast included), real Chromium.`,
    pages: ({ urls, note, widths, checks, base }) =>
      `Pages: ${urls} URLs${note ? ` (${note})` : ''} × ${widths.length} widths (${widths.join(' and ')} px) = ${checks} checks. Server: ${base}.`,
    manual: 'Automatic checks cover only part of the WCAG criteria: conformance also needs a manual review (keyboard, screen readers, content).',
    clean: '**Result: no violation found.**',
    violations: '## Violations',
    header: '| Rule | Impact | WCAG criteria | Pages | Elements |',
    reference: (url) => `Reference: ${url}`,
    more: (n) => `- … ${n} more pages`,
    loadErrorId: 'load-error',
    loadErrorHelp: 'Page could not be checked',
    noResponse: 'no response',
    written: (out, rules, checks) => `report written: ${out} (${rules} rules violated, ${checks} checks)`,
  },
});

export function messages(lang = 'en') {
  const m = MESSAGES[lang];
  if (!m) throw new Error(`unknown report language "${lang}": ${Object.keys(MESSAGES).join(', ')}`);
  return m;
}

const CONTENT_TYPES = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.mjs': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.webp': 'image/webp',
  '.avif': 'image/avif',
  '.gif': 'image/gif',
  '.ico': 'image/x-icon',
  '.woff': 'font/woff',
  '.woff2': 'font/woff2',
  '.txt': 'text/plain; charset=utf-8',
  '.xml': 'application/xml; charset=utf-8',
  '.mp4': 'video/mp4',
  '.webm': 'video/webm',
};

/**
 * A route's path in the form a static server resolves to the route's
 * pre-rendered HTML: with a leading and a trailing slash.
 */
export function checkablePath(p) {
  const clean = `/${String(p).replace(/^\/+/, '')}`.replace(/\/+$/, '');
  return `${clean}/`;
}

/**
 * The URLs to check, one per route, without duplicates and sorted. A route is
 * `{ path, lang? }`; `query` maps a route's `lang` to the query appended to
 * its path (`{ en: '?lang=en' }`).
 */
export function reportUrls(routes, { query = {} } = {}) {
  return [...new Set(routes.map((r) => checkablePath(r.path) + (r.lang && query[r.lang] ? query[r.lang] : '')))].sort();
}

/** The routes of a JSON file: an array of routes, or an object with a `routes` array. */
export function readRoutes(file) {
  const data = JSON.parse(fs.readFileSync(file, 'utf8'));
  const routes = Array.isArray(data) ? data : data?.routes;
  if (!Array.isArray(routes)) throw new Error(`${file}: no routes (an array, or an object with a "routes" array)`);
  return routes;
}

export function contentType(file) {
  return CONTENT_TYPES[path.extname(file).toLowerCase()] ?? 'application/octet-stream';
}

/**
 * The file of `dir` that answers a requested path, or `null`: the exact file
 * first, then the directory's index. A path leading out of `dir` never
 * answers. `isFile` receives an absolute path and tells whether it is a file.
 */
export function fileToServe(dir, requested, isFile) {
  let decoded;
  try {
    decoded = decodeURIComponent(String(requested).split(/[?#]/)[0]);
  } catch {
    return null;
  }
  const root = path.resolve(dir);
  const abs = path.resolve(root, `.${path.posix.normalize(`/${decoded}`)}`);
  if (abs !== root && !abs.startsWith(root + path.sep)) return null;
  for (const candidate of [abs, path.join(abs, 'index.html')]) {
    if (candidate !== root && isFile(candidate)) return candidate;
  }
  return null;
}

/** A minimal static server on `dir`, on a free port of 127.0.0.1. */
export function startStaticServer(dir) {
  const isFile = (file) => {
    try {
      return fs.statSync(file).isFile();
    } catch {
      return false;
    }
  };
  const server = http.createServer((req, res) => {
    const file = req.method === 'GET' || req.method === 'HEAD' ? fileToServe(dir, req.url ?? '/', isFile) : null;
    if (!file) {
      res.writeHead(404, { 'content-type': 'text/plain; charset=utf-8' }).end('404');
      return;
    }
    res.writeHead(200, { 'content-type': contentType(file) });
    if (req.method === 'HEAD') res.end();
    else fs.createReadStream(file).pipe(res);
  });
  return new Promise((resolve) => {
    server.listen(0, '127.0.0.1', () => {
      const { port } = server.address();
      resolve({ base: `http://127.0.0.1:${port}`, close: () => new Promise((done) => server.close(done)) });
    });
  });
}

/**
 * The consent already given as a refusal, in the stored format of the consent
 * SDK, from the site's consent configuration: required categories on, the
 * others off, the configuration's version and duration.
 */
export function rejectedConsent(config, now, uuid = randomUUID) {
  const categories = Object.fromEntries(config.categories.map((c) => [c.key, c.required === true]));
  return {
    key: config.storageKey,
    value: JSON.stringify({
      v: 1,
      deviceId: uuid(),
      consentId: uuid(),
      configVersion: config.version,
      categories,
      action: 'reject_all',
      decidedAt: now.toISOString(),
      expiresAt: new Date(now.getTime() + config.durationDays * DAY_MS).toISOString(),
    }),
  };
}

/**
 * The Markdown report from the violations collected per rule. `byRule` maps a
 * rule's id to `{ id, impact, help, helpUrl, tags, pages }`, where `pages` maps
 * `"<url> @<width>"` to the nodes, `{ target, summary }`. Rules are listed by
 * the number of pages, in the table and in the details alike.
 */
export function composeReport({ date, axeVersion, urls, widths, checks, base, byRule, pagesNote = '', lang = 'en' }) {
  const m = messages(lang);
  const lines = [m.title(date), '', m.tool(axeVersion), m.pages({ urls: urls.length, note: pagesNote, widths, checks, base }), '', m.manual, ''];
  if (byRule.size === 0) {
    lines.push(m.clean, '');
    return lines.join('\n');
  }
  lines.push(m.violations, '', m.header, '|---|---|---|---|---|');
  const sorted = [...byRule.values()].sort((a, b) => b.pages.size - a.pages.size);
  for (const e of sorted) {
    const n = [...e.pages.values()].reduce((s, x) => s + x.length, 0);
    lines.push(`| \`${e.id}\` — ${e.help} | ${e.impact} | ${e.tags.join(', ')} | ${e.pages.size} | ${n} |`);
  }
  lines.push('');
  for (const e of sorted) {
    lines.push(`### \`${e.id}\``, '');
    if (e.helpUrl) lines.push(m.reference(e.helpUrl), '');
    for (const [p, nodes] of [...e.pages].slice(0, 15)) {
      lines.push(`- ${p}: ${nodes.slice(0, 3).map((x) => `\`${x.target}\` — ${x.summary}`).join('; ')}`);
    }
    if (e.pages.size > 15) lines.push(m.more(e.pages.size - 15));
    lines.push('');
  }
  return lines.join('\n');
}

async function loadChromium() {
  for (const name of ['playwright', '@playwright/test']) {
    try {
      const mod = await import(name);
      if (mod.chromium) return mod.chromium;
    } catch {
      /* try the next package */
    }
  }
  throw new Error('Playwright is not installed: add "playwright" (or "@playwright/test") to the site\'s dependencies.');
}

/** The version and the source of the axe-core the project installs. */
export function axeCore() {
  return {
    version: JSON.parse(fs.readFileSync(require.resolve('axe-core/package.json'), 'utf8')).version,
    source: fs.readFileSync(require.resolve('axe-core/axe.min.js'), 'utf8'),
  };
}

/**
 * Runs the check and returns `{ report, byRule, checks, base }`.
 *
 * Options: `urls` (paths, as `reportUrls` returns them); `base` (a running
 * server) or `dist` (the built directory, served here); `widths`;
 * `storage` (entries `{ key, value }` written to localStorage before every
 * page loads, e.g. `rejectedConsent(...)`); `pagesNote`; `lang` (`en` or
 * `it`); `date` (YYYY-MM-DD, today by default). `chromium` and `axe`
 * (`{ version, source }`) replace the installed Playwright and axe-core.
 */
export async function runAxeReport(options) {
  const { urls, widths = WIDTHS, storage = [], pagesNote = '', lang = 'en' } = options;
  const m = messages(lang);
  const chromium = options.chromium ?? (await loadChromium());
  const axe = options.axe ?? axeCore();
  let base = options.base;
  let closeServer = async () => {};
  if (!base) {
    const server = await startStaticServer(options.dist);
    base = server.base;
    closeServer = server.close;
  }
  base = base.replace(/\/+$/, '');

  const browser = await chromium.launch();
  const byRule = new Map();
  let checks = 0;
  try {
    for (const width of widths) {
      const ctx = await browser.newContext({ viewport: { width, height: 900 } });
      await ctx.addInitScript((entries) => {
        for (const { key, value } of entries) window.localStorage.setItem(key, value);
      }, storage);
      for (const u of urls) {
        const page = await ctx.newPage();
        try {
          const res = await page.goto(base + u, { waitUntil: 'load', timeout: 30_000 });
          if (!res || !res.ok()) throw new Error(`HTTP ${res ? res.status() : m.noResponse}`);
          await page.waitForTimeout(700);
          // Down to the bottom and back: elements that appear on scroll and lazy
          // images reach their final state.
          await page.evaluate(() => window.scrollTo(0, document.body.scrollHeight));
          await page.waitForTimeout(500);
          await page.evaluate(() => window.scrollTo(0, 0));
          await page.addScriptTag({ content: axe.source });
          const violations = await page.evaluate(async (tags) => {
            const result = await window.axe.run(document, { runOnly: { type: 'tag', values: tags } });
            return result.violations.map((v) => ({
              id: v.id,
              impact: v.impact,
              help: v.help,
              helpUrl: v.helpUrl,
              tags: v.tags.filter((t) => /^wcag\d/.test(t)),
              nodes: v.nodes.map((n) => ({ target: n.target.join(' '), summary: (n.any[0]?.message || n.failureSummary || '').split('\n')[0] })),
            }));
          }, [...WCAG_TAGS]);
          for (const v of violations) {
            const e = byRule.get(v.id) ?? { id: v.id, impact: v.impact, help: v.help, helpUrl: v.helpUrl, tags: v.tags, pages: new Map() };
            e.pages.set(`${u} @${width}`, v.nodes);
            byRule.set(v.id, e);
          }
          checks++;
        } catch (err) {
          const e = byRule.get(m.loadErrorId) ?? { id: m.loadErrorId, impact: 'n/a', help: m.loadErrorHelp, helpUrl: '', tags: [], pages: new Map() };
          e.pages.set(`${u} @${width}`, [{ target: '-', summary: String(err.message).slice(0, 160) }]);
          byRule.set(e.id, e);
        }
        await page.close();
      }
      await ctx.close();
    }
  } finally {
    await browser.close();
    await closeServer();
  }

  const report = composeReport({
    date: options.date ?? new Date().toISOString().slice(0, 10),
    axeVersion: axe.version,
    urls,
    widths,
    checks,
    base,
    byRule,
    pagesNote,
    lang,
  });
  return { report, byRule, checks, base };
}
