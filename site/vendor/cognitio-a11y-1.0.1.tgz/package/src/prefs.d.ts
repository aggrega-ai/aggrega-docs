/** Type declarations of `@cognitio/a11y/prefs` (also the package's main entry). */

export type ColorMode = 'default' | 'dark' | 'light' | 'high' | 'monochrome' | 'lowSaturation' | 'highSaturation';
export type FontMode = 'default' | 'readable' | 'dyslexic';
export type AlignMode = 'default' | 'left' | 'center' | 'right';
/** Large cursor: black (white edge) or white (black edge). The magnifier follows its colour and size. */
export type CursorMode = 'default' | 'black' | 'white';
export type ButtonSide = 'left' | 'right';

/** On/off preferences. */
export type A11yToggle =
  | 'highlightLinks'
  | 'highlightHeadings'
  | 'textMagnifier'
  | 'stopAnimations'
  | 'hideImages'
  | 'muteSounds'
  | 'readingGuide'
  | 'readingMask'
  | 'highlightFocus'
  | 'highlightHover'
  | 'tooltips';

/**
 * Features a site turns on in its configuration: the preferences, the actions
 * (read aloud, reading mode, page structure) and `hideButton`, the command
 * that hides the floating button — on only when the site has its own link
 * that opens the panel (`openAccessibilityPanel`).
 */
export type A11yFeature =
  | 'textSize'
  | 'lineHeight'
  | 'letterSpacing'
  | 'font'
  | 'align'
  | 'color'
  | 'cursor'
  | 'readAloud'
  | 'readingMode'
  | 'pageStructure'
  | 'hideButton'
  | A11yToggle;

export interface A11yPrefs {
  /** Index in `textSizes` (0 = normal). */
  textSize: number;
  /** Index in `lineHeights` (0 = normal). */
  lineHeight: number;
  /** Index in `letterSpacings` (0 = normal). */
  letterSpacing: number;
  font: FontMode;
  align: AlignMode;
  color: ColorMode;
  cursor: CursorMode;
  highlightLinks: boolean;
  highlightHeadings: boolean;
  textMagnifier: boolean;
  stopAnimations: boolean;
  hideImages: boolean;
  muteSounds: boolean;
  readingGuide: boolean;
  readingMask: boolean;
  highlightFocus: boolean;
  highlightHover: boolean;
  tooltips: boolean;
}

/** The panel's button, hidden or moved by the visitor. */
export interface ButtonPrefs {
  hidden: boolean;
  side?: ButtonSide;
}

/** The site's configuration of the preferences. */
export interface A11yPrefsConfig {
  /** localStorage key of the preferences. */
  storageKey: string;
  /** localStorage key of the button's place; `<storageKey>-button` when absent. */
  buttonStorageKey?: string;
  features: A11yFeature[];
  /** Text sizes in percent, the first being 100. */
  textSizes: number[];
  /** Line heights, the first being 0 (unchanged). */
  lineHeights: number[];
  /** Letter spacings in em, the first being 0 (unchanged). */
  letterSpacings: number[];
  /** Named combinations of preferences; their texts are `profile.<name>` and `profile.<name>.desc`. */
  profiles?: Record<string, Partial<A11yPrefs>>;
  /** Converts preferences a site stored in an earlier shape of its own, before they are normalized. */
  migratePrefs?: (raw: unknown) => unknown;
  /** The same for the button's stored place. */
  migrateButtonPrefs?: (raw: unknown) => unknown;
}

export interface DocumentState {
  classes: string[];
  vars: Record<string, string>;
}

type ReadStorage = Pick<Storage, 'getItem'> | undefined;
type WriteStorage = Pick<Storage, 'setItem'> | undefined;
type ShortcutEvent = Pick<KeyboardEvent, 'key' | 'code' | 'altKey' | 'ctrlKey' | 'metaKey' | 'shiftKey'>;

export const DEFAULT_PREFS: Readonly<A11yPrefs>;
export const A11Y_OPEN_EVENT: 'a11y:open';
export const A11Y_CHANGE_EVENT: 'a11y:change';
export const STOP_ANIMATIONS_CLASS: 'a11y-stop-animations';
export const SHELL_CLASS: 'site-shell';

export function buttonStorageKey(cfg: A11yPrefsConfig): string;
export function normalizePrefs(raw: unknown, cfg: A11yPrefsConfig): A11yPrefs;
export function readPrefs(storage: ReadStorage, cfg: A11yPrefsConfig): A11yPrefs;
export function writePrefs(storage: WriteStorage, prefs: A11yPrefs, cfg: A11yPrefsConfig): void;
export function applyProfile(prefs: A11yPrefs, name: string, cfg: A11yPrefsConfig): A11yPrefs;
export function profileActive(prefs: A11yPrefs, name: string, cfg: A11yPrefsConfig): boolean;
export function readButtonPrefs(storage: ReadStorage, cfg: A11yPrefsConfig): ButtonPrefs;
export function writeButtonPrefs(storage: WriteStorage, b: ButtonPrefs, cfg: A11yPrefsConfig): void;
export function openAccessibilityPanel(): void;
export function matchesShortcut(e: ShortcutEvent, shortcut: string): boolean;
export function prefsToDocument(prefs: A11yPrefs, cfg: A11yPrefsConfig): DocumentState;
export function applyPrefs(prefs: A11yPrefs, cfg: A11yPrefsConfig): void;
export function prefersReducedMotion(): boolean;
