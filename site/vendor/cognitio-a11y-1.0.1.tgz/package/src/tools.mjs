/**
 * tools.mjs — The panel's tools that need script.
 *
 * - Reading guide: a horizontal line that follows the pointer.
 * - Reading mask: darkens the page, leaving a band around the pointer.
 * - Text magnifier: shows enlarged the text under the pointer or under the
 *   focus (the cursor becomes a magnifier, see the stylesheet).
 * - Descriptions on hover: the alternative text of images and the name of
 *   buttons and links that only have an icon.
 * - Mute audio: mutes the page's audio and video, those added later too.
 * - Read aloud (`useReadAloud`): the browser's speech synthesis (Web Speech
 *   API) on the main content, or on the selected text.
 * - Page structure (`PageStructure`): the page's areas and headings, to jump
 *   straight to a section.
 * - Reading mode (`ReadingMode`): the text alone of the main content
 *   (headings, paragraphs, lists, tables, links) in a plain column above the
 *   page; the rest of the site is inert while it stays open.
 *
 * Everything runs in the browser, with no network. `window` and `document` are
 * touched only in effects and event handlers, and the layers' positions are
 * computed in the handlers, so a server-side render is the closed state.
 * Written with `React.createElement`: no build step, no JSX transform.
 */

import React from 'react';
import ReactDOM from 'react-dom';

import { A11Y_CHANGE_EVENT, DEFAULT_PREFS, readPrefs, SHELL_CLASS } from './prefs.mjs';

const h = React.createElement;
const { Fragment, useEffect, useRef, useState } = React;

const MAGNIFY_SELECTOR = 'p, li, a, h1, h2, h3, h4, h5, h6, td, th, label, button, dt, dd, figcaption, blockquote';
const TIP_SELECTOR = 'img[alt], [aria-label], [title]';
/** Half the height of the band the reading mask leaves uncovered. */
const BAND = 70;

/** Pointer coordinates; zero when the event carries none (synthetic events). */
const coords = (e) => [Number(e.clientX) || 0, Number(e.clientY) || 0];
/** True for an element of the panel itself: the tools never describe it. */
const insidePanel = (el) => el.closest('.a11y-root') !== null;

function usePrefs(config) {
  const [prefs, setPrefs] = useState(DEFAULT_PREFS);
  useEffect(() => {
    const read = () => setPrefs(readPrefs(window.localStorage, config));
    read();
    window.addEventListener(A11Y_CHANGE_EVENT, read);
    return () => window.removeEventListener(A11Y_CHANGE_EVENT, read);
    // The configuration is read once, at mount.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
  return prefs;
}

/** The layers of the reading guide, reading mask, magnifier and descriptions. */
export function AccessibilityTools({ config }) {
  const prefs = usePrefs(config);
  const [y, setY] = useState(null);
  const [lens, setLens] = useState(null);
  const [tip, setTip] = useState(null);
  const needPointer = prefs.readingGuide || prefs.readingMask;

  // Guide and mask: the pointer's vertical position.
  useEffect(() => {
    if (!needPointer) return;
    const move = (e) => setY(e.clientY);
    window.addEventListener('pointermove', move, { passive: true });
    return () => window.removeEventListener('pointermove', move);
  }, [needPointer]);

  // Magnifier: the text of the element under the pointer or under the focus.
  useEffect(() => {
    if (!prefs.textMagnifier) {
      setLens(null);
      return;
    }
    const pick = (el, x, yy) => {
      const target = el?.closest?.(MAGNIFY_SELECTOR);
      if (!target || insidePanel(target)) return setLens(null);
      const text = (target.innerText ?? target.textContent ?? '').trim();
      setLens(text ? { text: text.slice(0, 300), left: Math.min(x + 16, window.innerWidth - 420), top: Math.min(yy + 20, window.innerHeight - 160) } : null);
    };
    const over = (e) => pick(e.target, ...coords(e));
    const focus = (e) => {
      const r = e.target.getBoundingClientRect?.();
      if (r) pick(e.target, r.left, r.bottom);
    };
    document.addEventListener('pointerover', over);
    document.addEventListener('focusin', focus);
    return () => {
      document.removeEventListener('pointerover', over);
      document.removeEventListener('focusin', focus);
    };
  }, [prefs.textMagnifier]);

  // Descriptions: the alternative text of images, the name of buttons and links.
  useEffect(() => {
    if (!prefs.tooltips) {
      setTip(null);
      return;
    }
    const pick = (el, x, yy) => {
      // Links and buttons made of an image alone: the image may not receive the pointer.
      const target = el?.closest?.(TIP_SELECTOR) ?? el?.closest?.('a, button')?.querySelector('img[alt]');
      if (!target || insidePanel(target)) return setTip(null);
      const text = (target.tagName === 'IMG' ? target.getAttribute('alt') : target.getAttribute('aria-label') || target.getAttribute('title'))?.trim();
      setTip(text ? { text: text.slice(0, 200), left: Math.min(x + 12, window.innerWidth - 320), top: Math.max(8, yy - 44) } : null);
    };
    const over = (e) => pick(e.target, ...coords(e));
    const focus = (e) => {
      const r = e.target.getBoundingClientRect?.();
      if (r) pick(e.target, r.left, r.top);
    };
    document.addEventListener('pointerover', over);
    document.addEventListener('focusin', focus);
    return () => {
      document.removeEventListener('pointerover', over);
      document.removeEventListener('focusin', focus);
    };
  }, [prefs.tooltips]);

  // Mute audio: the media on the page and those added later.
  useEffect(() => {
    if (!prefs.muteSounds) return;
    const muteAll = () =>
      document.querySelectorAll('audio, video').forEach((m) => {
        m.muted = true;
      });
    muteAll();
    const obs = new MutationObserver(muteAll);
    obs.observe(document.body, { childList: true, subtree: true });
    return () => obs.disconnect();
  }, [prefs.muteSounds]);

  // Stop animations: playing videos stop too.
  useEffect(() => {
    if (!prefs.stopAnimations) return;
    document.querySelectorAll('video').forEach((v) => {
      if (!v.paused) v.pause();
    });
  }, [prefs.stopAnimations]);

  return h(
    Fragment,
    null,
    prefs.readingGuide && y !== null && h('div', { className: 'a11y-reading-guide', style: { top: y - 3 }, 'aria-hidden': 'true' }),
    prefs.readingMask &&
      y !== null &&
      h(
        Fragment,
        null,
        h('div', { className: 'a11y-reading-mask', style: { top: 0, height: Math.max(0, y - BAND) }, 'aria-hidden': 'true' }),
        h('div', { className: 'a11y-reading-mask', style: { top: y + BAND, bottom: 0 }, 'aria-hidden': 'true' }),
      ),
    lens && h('div', { className: 'a11y-lens', style: { left: lens.left, top: lens.top }, 'aria-hidden': 'true' }, lens.text),
    tip && h('div', { className: 'a11y-tip', style: { left: tip.left, top: tip.top }, 'aria-hidden': 'true' }, tip.text),
  );
}

/**
 * Reading aloud of the main content (or of the selected text) with the
 * browser's speech synthesis, in the language `speechLang` names (a BCP 47
 * tag such as "en-GB").
 */
export function useReadAloud(speechLang) {
  const [speaking, setSpeaking] = useState(false);
  const [supported, setSupported] = useState(false);
  useEffect(() => {
    setSupported(typeof window !== 'undefined' && 'speechSynthesis' in window && typeof SpeechSynthesisUtterance !== 'undefined');
    return () => {
      if (typeof window !== 'undefined' && 'speechSynthesis' in window) window.speechSynthesis.cancel();
    };
  }, []);
  const stop = () => {
    window.speechSynthesis.cancel();
    setSpeaking(false);
  };
  const start = () => {
    const main = document.querySelector('main');
    const text = (window.getSelection()?.toString().trim() || main?.innerText || main?.textContent || '').replace(/\s+/g, ' ').trim();
    if (!text) return;
    window.speechSynthesis.cancel();
    // Short sentences: some browsers cut long readings off.
    const parts = text.match(/[^.!?;:]+[.!?;:]?/g) ?? [text];
    parts.forEach((part, i) => {
      const u = new SpeechSynthesisUtterance(part);
      if (speechLang) u.lang = speechLang;
      if (i === parts.length - 1) u.onend = () => setSpeaking(false);
      window.speechSynthesis.speak(u);
    });
    setSpeaking(true);
  };
  return { supported, speaking, start, stop };
}

const LANDMARKS = [
  ['header', 'landmark.header'],
  ['nav', 'landmark.nav'],
  ['main', 'landmark.main'],
  ['footer', 'landmark.footer'],
];

/** The page's areas and headings, each a button that moves the focus there. */
export function PageStructure({ t, onClose }) {
  const [items, setItems] = useState([]);
  useEffect(() => {
    const out = [];
    for (const [sel, key] of LANDMARKS) {
      const el = document.querySelector(sel);
      if (el) out.push({ label: t(key), level: 0, el });
    }
    document.querySelectorAll('main h1, main h2, main h3').forEach((hd) => {
      const label = (hd.innerText ?? hd.textContent ?? '').trim();
      if (label) out.push({ label, level: Number(hd.tagName[1]), el: hd });
    });
    setItems(out);
    // One reading, when it opens.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
  const go = (el) => {
    if (!el.hasAttribute('tabindex')) el.setAttribute('tabindex', '-1');
    el.scrollIntoView?.({ block: 'start' });
    el.focus({ preventScroll: true });
    onClose();
  };
  return h(
    'div',
    { className: 'a11y-structure', role: 'region', 'aria-label': t('pageStructure') },
    h(
      'ul',
      null,
      items.map((v, i) =>
        h(
          'li',
          { key: i, style: { paddingLeft: v.level > 1 ? (v.level - 1) * 12 : 0 } },
          h('button', { type: 'button', onClick: () => go(v.el) }, v.level === 0 ? h('strong', null, v.label) : v.label),
        ),
      ),
    ),
  );
}

const READING_BLOCKS = 'h1, h2, h3, h4, h5, h6, p, ul, ol, dl, blockquote, table';
const READING_STRIP = 'img, picture, video, audio, iframe, svg, canvas, button, input, select, textarea, form, script, style, noscript, template';
const READING_ATTRS = ['href', 'colspan', 'rowspan', 'scope', 'lang'];

/** Cleaned copies (text and links alone) of the visible top-level text blocks. */
function readingContent(root) {
  const out = [];
  root.querySelectorAll(READING_BLOCKS).forEach((el) => {
    if (el.parentElement?.closest(READING_BLOCKS)) return;
    if (el.closest('[hidden], [aria-hidden="true"], nav, form, .a11y-root')) return;
    if (typeof el.checkVisibility === 'function' && !el.checkVisibility()) return;
    const c = el.cloneNode(true);
    c.querySelectorAll(READING_STRIP).forEach((n) => n.remove());
    for (const n of [c, ...Array.from(c.querySelectorAll('*'))]) {
      for (const a of Array.from(n.attributes)) if (!READING_ATTRS.includes(a.name)) n.removeAttribute(a.name);
    }
    if ((c.textContent ?? '').trim()) out.push(c);
  });
  return out;
}

/**
 * Reading mode: the page's text in a plain column, above the site. It carries
 * the shell's class, so the reading preferences (font, spacing) apply in it.
 */
export function ReadingMode({ t, lang, onClose }) {
  const body = useRef(null);
  const closeBtn = useRef(null);
  const [target, setTarget] = useState(null);
  const [empty, setEmpty] = useState(false);

  // The portal's node is looked up after mount, never in render.
  useEffect(() => setTarget(document.body), []);

  useEffect(() => {
    if (!target) return;
    const main = document.querySelector('main');
    const blocks = main ? readingContent(main) : [];
    body.current?.replaceChildren(...blocks);
    setEmpty(blocks.length === 0);
    const shell = document.querySelector(`.${SHELL_CLASS}:not(.a11y-reading)`);
    shell?.setAttribute('inert', '');
    const overflow = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    closeBtn.current?.focus();
    const onKey = (e) => {
      if (e.key === 'Escape') onClose();
    };
    document.addEventListener('keydown', onKey);
    return () => {
      shell?.removeAttribute('inert');
      document.body.style.overflow = overflow;
      document.removeEventListener('keydown', onKey);
    };
    // One reading, when it opens.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [target]);

  if (!target) return null;
  return ReactDOM.createPortal(
    h(
      'div',
      { className: `${SHELL_CLASS} a11y-reading`, role: 'dialog', 'aria-modal': 'true', 'aria-labelledby': 'a11y-reading-title', lang },
      h(
        'div',
        { className: 'a11y-reading-bar' },
        h('h2', { id: 'a11y-reading-title' }, t('readingMode')),
        h('button', { ref: closeBtn, type: 'button', onClick: onClose }, t('readingModeClose')),
      ),
      h('article', { className: 'a11y-reading-body', ref: body, onClick: (e) => e.target.closest('a') && onClose() }),
      empty && h('p', { className: 'a11y-reading-body' }, t('readingModeEmpty')),
    ),
    target,
  );
}
