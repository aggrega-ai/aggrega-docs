#!/usr/bin/env node
/**
 * config-reference.mjs — The package script that writes the README's generated
 * sections (`npm run reference`): the configuration reference, from the schema,
 * and the table of the models' reasoning settings, from `src/models.mjs`.
 *
 * READS `README.md` beside `package.json`, and each section's source through
 * `src/config-reference.mjs`. WRITES `README.md`: the body of each section
 * `GENERATED_SECTIONS` names, and nothing outside them. With `--check` it WRITES
 * nothing and exits 1 when a committed section differs from a fresh generation.
 */

import fs from 'node:fs';
import { fileURLToPath } from 'node:url';

import { GENERATED_SECTIONS, readReference, spliceReference } from '../src/config-reference.mjs';

const README = fileURLToPath(new URL('../README.md', import.meta.url));

const text = fs.readFileSync(README, 'utf8');

if (process.argv.includes('--check')) {
  const stale = GENERATED_SECTIONS.filter(({ name, render }) => readReference(text, name) !== render()).map(({ name }) => name);
  if (stale.length === 0) {
    console.log('reference: README.md holds every generated section as its source generates it.');
    process.exit(0);
  }
  console.error(`reference: README.md differs from a fresh generation in ${stale.join(', ')}; run \`npm run reference\`.`);
  process.exit(1);
}

const next = GENERATED_SECTIONS.reduce((current, { name, render }) => spliceReference(current, render(), name), text);
if (next !== text) fs.writeFileSync(README, next, 'utf8');
console.log(next === text ? 'reference: README.md already up to date.' : 'reference: README.md rewritten.');
