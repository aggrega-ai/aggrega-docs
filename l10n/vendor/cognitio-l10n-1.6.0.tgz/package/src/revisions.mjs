/**
 * revisions.mjs — The earlier translation a changed segment starts from.
 *
 * READS nothing and WRITES nothing: a pure function over the gate's worklist,
 * the memory's lookup view and the recorded sources its caller supplies.
 *
 * A segment's key is the hash of its source, so editing a segment gives it a
 * new key: the new key is missing from every locale, and the old one is left an
 * orphan — a memory key no unit of the catalogue holds — with its translation
 * still in the memory and its source still recorded (`store.readRecordedSources`).
 * Nothing in the key links the two. This module links them by their text: a
 * missing segment and an orphan whose recorded source is similar to the
 * segment's, at a similarity of at least `REVISION_SIMILARITY`, are paired one
 * to one, as an edit replaces one segment with one segment — the most similar
 * pairs first, each segment and each orphan in one pair at most — so a sentence
 * merely resembling an orphan does not borrow it once the orphan's own edited
 * version has. The orphan is the segment's REVISION in each locale that
 * translates it. A request then gives the translator
 * that orphan's source and translation to start from (`requests.mjs`), so an
 * edited paragraph keeps the wording the change did not touch, and the entry
 * written for it records where it came from.
 *
 * A REVIEWED revision is one whose orphan the memory holds in its human layer —
 * a translation a person wrote or corrected. The request marks it, so the
 * translator keeps that person's wording where the new source allows, and the
 * entry written for the new segment records it, so the people who review
 * translations can find the machine translations that revise their work
 * (`engine.review`).
 *
 * THE SIMILARITY of two sources is the Dice coefficient of their words: twice the
 * number of words they share, each counted as often as both hold it, over the
 * words of both, a word being a run of letters and digits compared in lower
 * case. It reads what a change to a sentence leaves in place, so a paragraph
 * with a word changed, a clause added or a term renamed stays well above the
 * threshold, while two different paragraphs on one subject stay below it.
 *
 * DETERMINISM: the pairs are taken by similarity, then by the segment's key,
 * then by the orphan's, so the same worklist and memory give the same revisions
 * every time.
 */

import { STATUS } from './types.mjs';

/** The least similarity at which an orphan counts as the earlier version of a missing segment. */
export const REVISION_SIMILARITY = 0.5;

const WORD = /[\p{L}\p{N}]+/gu;

/** A text's words in lower case, as a multiset: word → count, and the total. */
function wordBag(text) {
  const counts = new Map();
  let size = 0;
  for (const word of String(text).toLowerCase().match(WORD) || []) {
    counts.set(word, (counts.get(word) || 0) + 1);
    size += 1;
  }
  return { counts, size };
}

/** The Dice coefficient of two word multisets. */
function dice(a, b) {
  if (a.size === 0 || b.size === 0) return 0;
  const [small, large] = a.counts.size <= b.counts.size ? [a, b] : [b, a];
  let shared = 0;
  for (const [word, n] of small.counts) shared += Math.min(n, large.counts.get(word) || 0);
  return (2 * shared) / (a.size + b.size);
}

/**
 * The similarity of two sources: the Dice coefficient of their words, from 0 to 1.
 *
 * @param {string} a
 * @param {string} b
 * @returns {number}
 */
export function similarity(a, b) {
  return dice(wordBag(a), wordBag(b));
}

/**
 * The revision of every missing segment that has one, per locale.
 *
 * @param {Object} args
 * @param {import('./types.mjs').Worklist} args.worklist  the gate's worklist, its `orphans` included.
 * @param {Object.<string, import('./types.mjs').TM>} args.tmByLang  the lookup view of the memory, per locale.
 * @param {Object.<string,string>} args.sources  key → source, for every key whose source is recorded.
 * @param {string[]} args.targets
 * @param {number} [args.threshold]
 * @returns {Object.<string, Object.<string, import('./types.mjs').Revision>>}  locale → missing key → its revision.
 */
export function findRevisions({ worklist, tmByLang = {}, sources = {}, targets = [], threshold = REVISION_SIMILARITY }) {
  if (!worklist || worklist.status !== 'work' || !(worklist.orphans || []).length) return {};
  const wanted = targets.filter((lang) => tmByLang[lang]);
  const translated = (key) => wanted.some((lang) => tmByLang[lang][key] && typeof tmByLang[lang][key].text === 'string');
  // An orphan qualifies when its source is recorded and some target locale translates it.
  const candidates = [...worklist.orphans]
    .filter((key) => typeof sources[key] === 'string' && translated(key))
    .sort()
    .map((key) => ({ key, bag: wordBag(sources[key]) }))
    .filter((c) => c.bag.size > 0);
  if (candidates.length === 0) return {};

  const pairs = [];
  const missingIn = new Map();
  for (const item of worklist.items || []) {
    const langs = item.missing.filter((lang) => wanted.includes(lang));
    if (langs.length === 0) continue;
    const bag = wordBag(item.source);
    if (bag.size === 0) continue;
    missingIn.set(item.srcHash, langs);
    for (const c of candidates) {
      // Dice can reach at most 2·min/(a+b), so a pair this unequal in length cannot qualify.
      if ((2 * Math.min(bag.size, c.bag.size)) / (bag.size + c.bag.size) < threshold) continue;
      const score = dice(bag, c.bag);
      if (score >= threshold) pairs.push({ id: item.srcHash, key: c.key, score });
    }
  }
  pairs.sort((x, y) => y.score - x.score || (x.id < y.id ? -1 : x.id > y.id ? 1 : x.key < y.key ? -1 : 1));

  const pairedIds = new Set();
  const pairedOrphans = new Set();
  const out = {};
  for (const pair of pairs) {
    if (pairedIds.has(pair.id) || pairedOrphans.has(pair.key)) continue;
    pairedIds.add(pair.id);
    pairedOrphans.add(pair.key);
    for (const lang of missingIn.get(pair.id)) {
      const entry = tmByLang[lang][pair.key];
      if (!entry || typeof entry.text !== 'string') continue;
      if (!out[lang]) out[lang] = {};
      out[lang][pair.id] = { from: pair.key, source: sources[pair.key], translation: entry.text, reviewed: entry.status !== STATUS.MACHINE };
    }
  }
  return out;
}

export default { REVISION_SIMILARITY, similarity, findRevisions };
