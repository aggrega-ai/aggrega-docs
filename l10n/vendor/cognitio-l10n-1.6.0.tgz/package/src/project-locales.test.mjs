import '../test/no-network.mjs';
import { describe, it, expect, beforeEach, afterEach } from 'vitest';
import { spawnSync } from 'node:child_process';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

import { ConfigError, loadConfig, parseConfig } from './config.mjs';
import { runCli } from './cli.mjs';
import { runDoctor } from './doctor.mjs';
import { fixtureConfig, writeJson } from '../test/helpers.mjs';

const BIN = fileURLToPath(new URL('../bin/l10n.mjs', import.meta.url));

let dir;
let configPath;

beforeEach(() => {
  dir = fs.mkdtempSync(path.join(os.tmpdir(), 'l10n-project-locales-'));
  configPath = path.join(dir, 'l10n.config.json');
});

afterEach(() => {
  fs.rmSync(dir, { recursive: true, force: true });
});

/** Writes the project's package.json and a configuration whose `locales` is `locales`. */
function project({ declaration, locales = 'project' }) {
  writeJson(path.join(dir, 'package.json'), declaration === undefined ? { name: 'site' } : { name: 'site', projectLanguages: declaration });
  writeJson(configPath, { ...fixtureConfig(), locales });
}

describe('"locales": "project"', () => {
  it('"project" with an inline list: source the first, targets the rest', () => {
    project({ declaration: ['en', 'it', 'pt-BR', 'zh-Hans'] });
    expect(loadConfig({ configPath }).locales).toMatchObject({ source: 'en', targets: ['it', 'pt-BR', 'zh-Hans'] });
  });

  it('"project" with a path to {source, published}', () => {
    project({ declaration: 'languages.json' });
    writeJson(path.join(dir, 'languages.json'), { source: { lang: 'it' }, published: [{ lang: 'en' }, { lang: 'de' }] });
    expect(loadConfig({ configPath }).locales).toMatchObject({ source: 'it', targets: ['en', 'de'] });
  });

  it('"project" finds the declaration from the configuration file, not the working directory', () => {
    project({ declaration: ['fr', 'es'] });
    const cwd = process.cwd();
    process.chdir(os.tmpdir());
    try {
      expect(loadConfig({ configPath }).locales).toMatchObject({ source: 'fr', targets: ['es'] });
    } finally {
      process.chdir(cwd);
    }
  });

  it('"project" with no declaration stops with exit 2 naming the package.json and the line to add', async () => {
    project({ declaration: undefined });
    expect(() => loadConfig({ configPath })).toThrow(ConfigError);
    const out = [];
    const code = await runCli(['status'], { cwd: dir, env: {}, log: (m) => out.push(m), errlog: (m) => out.push(m) });
    expect(code).toBe(2);
    const text = out.join('\n');
    expect(text).toContain(path.join(dir, 'package.json'));
    expect(text).toContain('"projectLanguages"');
    expect(text).toContain("add the project's languages there");
  });

  it('"project" without @cognitio/languages stops naming sh install.sh add @cognitio/languages', () => {
    project({ declaration: ['en', 'it'] });
    const missing = () => {
      throw Object.assign(new Error('Cannot find package'), { code: 'MODULE_NOT_FOUND' });
    };
    expect(() => loadConfig({ configPath, loadLanguages: missing })).toThrow(/sh install\.sh add @cognitio\/languages/);
  });

  it('an explicit { source, targets } or a path to one reads as today', () => {
    // No package.json and no @cognitio/languages are consulted.
    const never = () => {
      throw new Error('the declaration reader must not load');
    };
    writeJson(configPath, { ...fixtureConfig(), locales: { source: 'it', targets: ['en', 'de'] } });
    expect(loadConfig({ configPath, loadLanguages: never }).locales).toEqual({ source: 'it', targets: ['en', 'de'] });
    writeJson(path.join(dir, 'set.json'), { source: 'en', targets: ['fr'] });
    writeJson(configPath, { ...fixtureConfig(), locales: 'set.json' });
    expect(loadConfig({ configPath, loadLanguages: never }).locales).toEqual({ source: 'en', targets: ['fr'] });
    expect(parseConfig({ ...fixtureConfig(), locales: 'project' }).locales).toBe('project');
  });

  it('on a Node.js that cannot require() an ES module, "project" and seed --layer machine stop with exit 2 naming the version they need', () => {
    // `--no-experimental-require-module` gives this Node.js the behaviour of 20.0–20.18 and 22.0–22.11.
    const l10n = (argv) => spawnSync(process.execPath, ['--no-experimental-require-module', BIN, ...argv], { cwd: dir, env: { PATH: process.env.PATH }, encoding: 'utf8' });
    project({ declaration: ['en', 'it'] });
    const status = l10n(['status']);
    expect(status.status, status.stderr).toBe(2);
    expect(status.stderr).toContain('Node.js 20.19, 22.12 or later');
    expect(status.stderr).not.toContain('Fatal error');
    project({ declaration: ['en', 'it'], locales: { source: 'it', targets: ['en'] } });
    const seed = l10n(['seed', '--layer', 'machine', '--targets', 'en']);
    expect(seed.status, seed.stderr).toBe(2);
    expect(seed.stderr).toContain('Node.js 20.19, 22.12 or later');
  });

  it('doctor reports the declaration it read', () => {
    project({ declaration: ['en', 'it', 'de'] });
    const { results } = runDoctor({ cwd: dir, env: {}, log: () => {} });
    const row = results.find((r) => r.check === 'configuration');
    expect(row.detail).toContain('source en, targets it, de');
    expect(row.detail).toContain(`projectLanguages in ${path.join(dir, 'package.json')}`);
  });
});
