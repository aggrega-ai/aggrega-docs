/**
 * budget-env.test.mjs — The spending budget stated in the environment
 * (`L10N_BUDGET_USD`, `L10N_BUDGET_SINCE`, `L10N_BUDGET_BILLED_BEFORE`) in place
 * of `backend.budget`, run through the command line against the fixture project
 * with a fake Batch API client.
 *
 * READS the fixture project's copy. WRITES only that copy, in a temporary
 * directory each test removes. No request leaves the process.
 */

import '../test/no-network.mjs';
import { describe, it, expect, beforeEach, afterEach } from 'vitest';
import fs from 'node:fs';
import path from 'node:path';

import { runCli } from './cli.mjs';
import { BUDGET_ENV, budgetFromEnv, ConfigError, translationSettings } from './config.mjs';
import { capture, copyFixtureProject, fakeAnthropic, writeJson } from '../test/helpers.mjs';

let project;
let configPath;

beforeEach(() => {
  project = copyFixtureProject();
  configPath = path.join(project, 'l10n.config.json');
});

afterEach(() => {
  fs.rmSync(project, { recursive: true, force: true });
});

const memory = (...p) => path.join(project, 'memory', ...p);
const readJson = (file) => JSON.parse(fs.readFileSync(file, 'utf8'));

async function run(argv, env = {}, deps = {}) {
  const io = capture();
  const code = await runCli(argv, { cwd: project, env: { ANTHROPIC_API_KEY: 'test-key', ...env }, log: io.log, errlog: io.errlog, ...deps });
  return { code, out: io.text(), err: io.errors() };
}

function editConfig(mutate) {
  const cfg = readJson(configPath);
  mutate(cfg);
  writeJson(configPath, cfg);
}

describe('budgetFromEnv and translationSettings', () => {
  it('reads the three variables, and says where the budget came from', () => {
    expect(budgetFromEnv({ L10N_BUDGET_USD: '120', L10N_BUDGET_SINCE: '2026-09-01', L10N_BUDGET_BILLED_BEFORE: '12.5' })).toEqual({
      usd: 120,
      since: '2026-09-01',
      billedBefore: 12.5,
      source: 'environment',
    });
    expect(budgetFromEnv({})).toBeNull();
    expect(budgetFromEnv({ L10N_BUDGET_USD: '' })).toBeNull();
    expect(translationSettings({ kind: 'anthropic', budget: { usd: 50 } }).budget).toEqual({ usd: 50, since: null, billedBefore: 0, source: 'configuration' });
  });

  it('the environment states the budget in place of backend.budget, the configuration’s since and billedBefore included', () => {
    const settings = translationSettings({ kind: 'anthropic', budget: { usd: 50, since: '2026-01-01', billedBefore: 9 } }, {}, { L10N_BUDGET_USD: '20' });
    expect(settings.budget).toEqual({ usd: 20, since: null, billedBefore: 0, source: 'environment' });
  });

  const MALFORMED = [
    { env: { L10N_BUDGET_USD: 'twenty' }, names: BUDGET_ENV.usd },
    { env: { L10N_BUDGET_USD: '0' }, names: BUDGET_ENV.usd },
    { env: { L10N_BUDGET_USD: '-5' }, names: BUDGET_ENV.usd },
    { env: { L10N_BUDGET_USD: '20', L10N_BUDGET_SINCE: 'last week' }, names: BUDGET_ENV.since },
    { env: { L10N_BUDGET_USD: '20', L10N_BUDGET_BILLED_BEFORE: '-1' }, names: BUDGET_ENV.billedBefore },
    { env: { L10N_BUDGET_SINCE: '2026-09-01' }, names: `${BUDGET_ENV.since} is set without ${BUDGET_ENV.usd}` },
    { env: { L10N_BUDGET_BILLED_BEFORE: '3' }, names: `${BUDGET_ENV.billedBefore} is set without ${BUDGET_ENV.usd}` },
  ];
  for (const row of MALFORMED) {
    it(`refuses ${JSON.stringify(row.env)}, naming ${row.names}, with exit 2 before any file is read`, async () => {
      expect(() => budgetFromEnv(row.env)).toThrow(ConfigError);
      const r = await run(['status'], row.env);
      expect(r.code).toBe(2);
      expect(r.err).toContain(row.names);
      expect(fs.existsSync(memory('source.json'))).toBe(false);
    });
  }
});

describe('the commands under a budget from the environment', () => {
  it('status prints the environment’s budget, naming L10N_BUDGET_BILLED_BEFORE for the spend before the job logs', async () => {
    const r = await run(['status'], { L10N_BUDGET_USD: '10', L10N_BUDGET_BILLED_BEFORE: '3' });
    expect(r.code).toBe(0);
    expect(r.out).toContain('status: budget USD 10.00: billed USD 3.00 (USD 0.00 recorded by the collected batches, USD 3.00 before them (L10N_BUDGET_BILLED_BEFORE))');
    expect(r.out).not.toContain('backend.budget');
  });

  it('submit is refused by the environment’s budget even where backend.budget would admit the batch, and names the variable to raise', async () => {
    editConfig((c) => (c.backend.budget = { usd: 1000 }));
    expect((await run(['extract'])).code).toBe(0);
    const fake = fakeAnthropic({ status: 'in_progress' });
    const refused = await run(['submit'], { L10N_BUDGET_USD: '0.0001' }, { ClientClass: fake.FakeAnthropic });
    expect(refused.code).toBe(1);
    expect(refused.err).toContain('submit: refused by L10N_BUDGET_USD: no batch created. Raise L10N_BUDGET_USD,');
    expect(fake.calls.batchCreate).toHaveLength(0);

    // Without the variable, the configuration's budget applies again.
    const admitted = await run(['submit'], {}, { ClientClass: fake.FakeAnthropic });
    expect(admitted.code).toBe(0);
    expect(fake.calls.batchCreate).toHaveLength(1);
  });
});
