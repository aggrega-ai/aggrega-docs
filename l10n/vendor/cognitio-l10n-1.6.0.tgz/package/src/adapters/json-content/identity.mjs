/**
 * identity.mjs — What a JSON-content segment's key is a hash of
 * (`adapter.identity`).
 *
 * READS nothing and WRITES nothing: pure functions over a leaf's source text
 * and its usage.
 *
 *   - `text` (the default): the hash of the source text alone (`keyOf`). One
 *     text has one key, so one translation per locale, wherever it is used:
 *     identical strings collapse onto one unit with several usages.
 *   - `text+path`: the hash of the source text and its usage (`usageKeyOf`) —
 *     the usage's file label (`<content usageLabel>/<file name>`, or the UI
 *     dictionary's label) and the leaf's path in it (`blocks[2].data.status`,
 *     `filters.active`). The same text under two keys is two units, each with
 *     its own translation and revisions, for a language that inflects one
 *     source word by gender or number.
 *
 * Extraction, the page view, generation, seeding, the drift guard and
 * `materialize` all key a leaf through the one identity the adapter builds
 * here, so they agree key for key.
 */

import { DEFAULT_IDENTITY, IDENTITIES } from '../../config.mjs';
import { keyOf, usageKeyOf } from '../../normalize.mjs';

export { DEFAULT_IDENTITY, IDENTITIES };

/**
 * @typedef {Object} Identity
 * @property {'text'|'text+path'} kind
 * @property {boolean} byPath  whether a key depends on the usage.
 * @property {(name:string, leafPath:string, value:string) => string} content
 *           the key of a content leaf: its file's name in the source directory, its path, its value.
 * @property {(dictKey:string, value:string) => string} ui
 *           the key of a UI dictionary entry: its dictionary key (its path, when nested), its value.
 */

/** The text identity, every leaf keyed by its source text alone. */
export const TEXT_IDENTITY = Object.freeze({
  kind: 'text',
  byPath: false,
  content: (_name, _leafPath, value) => keyOf(value),
  ui: (_dictKey, value) => keyOf(value),
});

/**
 * Builds the identity the configuration names.
 *
 * @param {Object} [args]
 * @param {'text'|'text+path'} [args.identity]  `adapter.identity`.
 * @param {string} [args.contentLabel]  the content usage label (`adapter.content.usageLabel`, resolved).
 * @param {string|null} [args.uiLabel]  the UI dictionary's usage label, or null without one.
 * @returns {Identity}
 */
export function createIdentity({ identity = DEFAULT_IDENTITY, contentLabel = '', uiLabel = null } = {}) {
  if (identity === 'text') return TEXT_IDENTITY;
  if (identity !== 'text+path') {
    throw new Error(`adapter.identity "${identity}" is not supported; supported: ${IDENTITIES.join(', ')}.`);
  }
  return Object.freeze({
    kind: 'text+path',
    byPath: true,
    content: (name, leafPath, value) => usageKeyOf(value, `${contentLabel}/${name}`, leafPath),
    ui: (dictKey, value) => usageKeyOf(value, uiLabel ?? '', dictKey),
  });
}

export default { IDENTITIES, DEFAULT_IDENTITY, TEXT_IDENTITY, createIdentity };
