import '../test/no-network.mjs';
import { describe, it, expect, beforeEach, afterEach, vi } from 'vitest';
import fs from 'node:fs';
import path from 'node:path';

import { runCli } from './cli.mjs';
import { capture, copyMarkdownFixture, echoReply, fakeAnthropic, replyMessage } from '../test/helpers.mjs';

/** A translation holding this mark makes the Markdown reading fail, as the package's own fault would. */
const CRASH = '⟦crash⟧';

vi.mock('./adapters/markdown/segment.mjs', async (importOriginal) => {
  const actual = await importOriginal();
  return {
    ...actual,
    standaloneProtectedSpans: (text) => {
      if (text.includes(CRASH)) throw new TypeError("Cannot read properties of undefined (reading 'end')");
      return actual.standaloneProtectedSpans(text);
    },
  };
});

let project;
beforeEach(() => {
  project = copyMarkdownFixture('l10n-internal-');
});
afterEach(() => {
  fs.rmSync(project, { recursive: true, force: true });
});

const memory = (...p) => path.join(project, 'memory', ...p);
const work = (...p) => memory('session', ...p);
const readJson = (file) => JSON.parse(fs.readFileSync(file, 'utf8'));
const jobs = () => fs.readdirSync(memory('jobs')).sort().map((f) => readJson(memory('jobs', f)));

async function run(argv, deps = {}) {
  const io = capture();
  const code = await runCli(argv, { cwd: project, env: { ANTHROPIC_API_KEY: 'test-key' }, log: io.log, errlog: io.errlog, ...deps });
  return { code, out: io.text(), err: io.errors() };
}

const PARAGRAPH = 'Text with a footnote[^note].';

describe('a check that fails itself is the package’s fault, never the translation’s', () => {
  it('session import: the segment is neither written nor queued, returns to the pool, and its next batch is its first attempt', async () => {
    const [batch] = [...(await run(['session', 'export', '--batches', '50'])).out.matchAll(/^session export: batch (\d{4}):/gm)].map((m) => m[1]);
    const task = readJson(work('batches', batch, 'task.json'));
    const target = task.chunks.flatMap((c) => c.segments).find((s) => s.source === PARAGRAPH);
    for (const lang of task.locales) {
      const lines = [];
      for (const s of task.chunks.flatMap((c) => c.segments)) {
        if (!s.translate) continue;
        lines.push(`@@@ ${s.id}`, s.id === target.id && lang === 'it' ? `${s.source} ${CRASH}` : `${s.source} ⟨${lang}⟩`);
      }
      fs.writeFileSync(task.output[lang], lines.join('\n') + '\n');
    }
    fs.writeFileSync(task.done, 'ok\n');

    const r = await run(['session', 'import']);
    expect(r.code).toBe(0);
    expect(r.out).toContain('1 returned to the pool after an internal error');
    expect(r.out).toContain(`internal error, not a defect of the translation and not counted as an attempt: it ${target.id}: reading the translation as Markdown failed (Cannot read properties of undefined (reading 'end'))`);
    const queue = fs.existsSync(work('queue.json')) ? readJson(work('queue.json')) : {};
    expect(queue.it && queue.it[target.id]).toBeUndefined();
    expect(readJson(memory('machine', 'it.json'))[target.id]).toBeUndefined();
    const job = jobs().find((j) => j.trigger === 'session');
    expect(job.internal).toEqual([expect.objectContaining({ srcHash: target.id, lang: 'it', attempt: 1 })]);
    expect(job.failures).toEqual([]);
    expect(readJson(work('batches', batch, 'result.json')).internal).toEqual({ it: 1 });

    const [next] = [...(await run(['session', 'export'])).out.matchAll(/^session export: batch (\d{4}):/gm)].map((m) => m[1]);
    const plan = readJson(work('batches', next, 'plan.json'));
    expect(plan.requested.it).toContain(target.id);
    expect(plan.attempts.it[target.id]).toBe(1);
    const again = readJson(work('batches', next, 'task.json')).chunks.flatMap((c) => c.segments).find((s) => s.id === target.id);
    expect(again.corrections).toBeUndefined();
  });

  it('collect: the segment is neither written nor queued, and the next submission requests it as its first attempt', async () => {
    let crashed = null;
    const reply = (params) => {
      const echoed = JSON.parse(echoReply(params).content[0].text).translations;
      const body = JSON.parse(params.messages[0].content[0].text);
      return replyMessage(
        echoed.map((e) => {
          const source = body.segments.find((s) => s.id === e.id).source;
          if (source !== PARAGRAPH || crashed) return e;
          crashed = e.id;
          return { id: e.id, text: `${e.text} ${CRASH}` };
        })
      );
    };
    const fake = fakeAnthropic({ reply });
    expect((await run(['extract'])).code).toBe(0);
    expect((await run(['submit', '--targets', 'it'], { ClientClass: fake.FakeAnthropic })).code).toBe(0);
    const r = await run(['collect'], { ClientClass: fake.FakeAnthropic });
    expect(r.code).toBe(0);
    expect(r.out).toContain('1 left for the next submission after an internal error');
    expect(r.out).toContain(`internal error, not a defect of the translation and not counted as an attempt: it ${crashed}:`);
    expect((readJson(memory('pending.json')).queue.it || {})[crashed]).toBeUndefined();
    expect(jobs().find((j) => j.trigger === 'collect').internal).toEqual([expect.objectContaining({ srcHash: crashed, lang: 'it', attempt: 1 })]);

    expect((await run(['submit', '--targets', 'it'], { ClientClass: fake.FakeAnthropic })).code).toBe(0);
    const resent = Object.values(readJson(memory('pending.json')).batches[0].requests).find((q) => q.ids.includes(crashed));
    expect(resent.attempt).toBe(1);
  });
});
