/**
 * batches-in-flight.test.mjs — Several Message Batches in flight, the spending
 * budget and the attempt rule, each run through the command line against the
 * fixture project with a fake Batch API client; and the budget's arithmetic and
 * the attempt rule as pure functions.
 *
 * READS the fixture project's copy. WRITES only that copy, in a temporary
 * directory each test removes. No request leaves the process.
 */

import '../test/no-network.mjs';
import { describe, it, expect, beforeEach, afterEach } from 'vitest';
import fs from 'node:fs';
import path from 'node:path';
import { InternalServerError } from '@anthropic-ai/sdk';

import { runCli } from './cli.mjs';
import { keyOf } from './normalize.mjs';
import { DEFAULT_MODEL, translationSettings } from './config.mjs';
import { formatUsd } from './cost.mjs';
import { resultFailure } from './pending.mjs';
import { batchVerdict, committedSpend, estimateBound, observedShare } from './budget.mjs';
import { capture, copyFixtureProject, echoReply, fakeAnthropic, replyMessage, requestBody, writeJson } from '../test/helpers.mjs';

let project;
let configPath;

beforeEach(() => {
  project = copyFixtureProject();
  configPath = path.join(project, 'l10n.config.json');
});

afterEach(() => {
  fs.rmSync(project, { recursive: true, force: true });
});

const memory = (...p) => path.join(project, 'memory', ...p);
const readJson = (file) => JSON.parse(fs.readFileSync(file, 'utf8'));

async function run(argv, deps = {}) {
  const io = capture();
  const code = await runCli(argv, { cwd: project, env: { ANTHROPIC_API_KEY: 'test-key' }, log: io.log, errlog: io.errlog, ...deps });
  return { code, out: io.text(), err: io.errors() };
}

function editConfig(mutate) {
  const cfg = readJson(configPath);
  mutate(cfg);
  writeJson(configPath, cfg);
}

/** The fixture's missing units after extract: the home page's four and the UI dictionary's two. */
const HOME_MISSING = ['Benvenuti', 'Una pagina di prova', 'Scopri', 'Primo paragrafo.'].map(keyOf);
const UI_MISSING = ['Torna su', 'Menu'].map(keyOf);
const ALL_MISSING = [...HOME_MISSING, ...UI_MISSING];

/** Sets the per-submission budgets to the home page's request, so each batch holds one request. */
async function oneRequestPerBatch() {
  const dry = await run(['submit', '--dry-run']);
  const [, input, output] = dry.out.match(/request 1: content\/it\/home\.json \(en\): estimated input (\d+) \(\d+ cached, \d+ uncached\), output (\d+)/);
  editConfig((c) => (c.backend.submission = { inputTokens: Number(input), outputTokens: Number(output) }));
}

/** Every (locale, segment) pair a recorded batch holds, as `lang:key`. */
const heldBy = (batch) => Object.values(batch.requests).flatMap((r) => r.ids.map((id) => `${r.lang}:${id}`));

/** An errored batch result. */
const errored = (type, message) => ({ type: 'errored', error: { type: 'error', error: { type, message } } });

/** A job log `collect` wrote for a batch billed `cost` US dollars against an upper bound of `bound`. */
const collectedJob = ({ id, at = '2026-10-01T00:00:00.000Z', cost, bound }) => ({
  id,
  at,
  trigger: 'collect',
  items: [],
  failures: [],
  exhausted: [],
  usage: {
    requests: [{ customId: '000000-en', lang: 'en', page: 'p', section: null, model: DEFAULT_MODEL, input: 1, output: 1, cacheRead: 0, cacheWrite: 0, cacheWrite5m: 0 }],
    total: { input: 1, output: 1, cacheRead: 0, cacheWrite: 0, cacheWrite5m: 0 },
    cost,
    estimate: { input: 1, cached: 0, output: 1, bound },
  },
  result: 'ok',
});
const jobFile = (id, at = '2026-10-01T00:00:00.000Z') => memory('jobs', `${at.replace(/[:.]/g, '-')}-${id}.json`);

describe('several batches in flight (backend.batches.maxInFlight)', () => {
  it('two batches in flight hold no pair in common: the second submission leaves out, and names, the pairs the first holds; at the limit a third is refused', async () => {
    editConfig((c) => (c.backend.batches = { maxInFlight: 2 }));
    expect((await run(['extract'])).code).toBe(0);
    await oneRequestPerBatch();
    const fake = fakeAnthropic({ status: 'in_progress' });
    expect((await run(['submit'], { ClientClass: fake.FakeAnthropic })).code).toBe(0);

    const second = await run(['submit'], { ClientClass: fake.FakeAnthropic });
    expect(second.code).toBe(0);
    expect(second.out).toContain('submit: 4 segment-locale pair(s) are held by the batch msgbatch_fake1 in flight and are left to it.');
    const batches = readJson(memory('pending.json')).batches;
    expect(batches.map((b) => b.id)).toEqual(['msgbatch_fake1', 'msgbatch_fake2']);
    const [first, next] = batches.map(heldBy);
    expect(first.filter((pair) => next.includes(pair))).toEqual([]);
    expect([...first, ...next].sort()).toEqual(ALL_MISSING.map((id) => `en:${id}`).sort());

    const third = await run(['submit'], { ClientClass: fake.FakeAnthropic });
    expect(third.code).toBe(1);
    expect(third.err).toContain(
      'submit: batches msgbatch_fake1, msgbatch_fake2 are recorded and not yet collected; run `l10n collect` first. ' +
        '2 batch(es) in flight is the most backend.batches.maxInFlight allows (2).'
    );
    expect(fake.calls.batchCreate).toHaveLength(2);
  });

  it('submit --batches creates as many batches as the free slots and the work allow, each within the per-submission budget, holding distinct pairs', async () => {
    editConfig((c) => (c.backend.batches = { maxInFlight: 3 }));
    expect((await run(['extract'])).code).toBe(0);
    await oneRequestPerBatch();
    const fake = fakeAnthropic({ status: 'in_progress' });

    const dry = await run(['submit', '--dry-run', '--batches', '3'], { ClientClass: fake.FakeAnthropic });
    expect(dry.code).toBe(0);
    expect(dry.out).toMatch(/^submit --dry-run: batch 1 of 2: 1 request\(s\), estimated input \d+ tokens/m);
    expect(dry.out).toMatch(/^submit --dry-run: batch 2 of 2: 1 request\(s\), estimated input \d+ tokens/m);
    expect(dry.out).toContain('submit --dry-run: 0 request(s) left for the next submission.');
    expect(dry.out).toMatch(/^ {2}batch 2, request 1: ui\/it\.json \(en\): estimated input/m);
    expect(fake.constructed).toHaveLength(0);

    const r = await run(['submit', '--batches', '3'], { ClientClass: fake.FakeAnthropic });
    expect(r.code).toBe(0);
    expect(fake.calls.batchCreate.map((b) => b.requests.map((q) => requestBody(q.params).page))).toEqual([['content/it/home.json'], ['ui/it.json']]);
    const batches = readJson(memory('pending.json')).batches;
    expect(batches.map((b) => b.id)).toEqual(['msgbatch_fake1', 'msgbatch_fake2']);
    expect(batches.map(heldBy)).toEqual([HOME_MISSING.map((id) => `en:${id}`), UI_MISSING.map((id) => `en:${id}`)]);
    // Each batch records its estimate's bound in US dollars beside its tokens.
    for (const b of batches) expect(b.estimate.bound).toBeGreaterThan(0);
  });

  it('submit --max-in-flight lowers the ceiling for one run: with one batch in flight of three allowed, --max-in-flight 1 creates nothing and says why', async () => {
    editConfig((c) => (c.backend.batches = { maxInFlight: 3 }));
    expect((await run(['extract'])).code).toBe(0);
    await oneRequestPerBatch();
    const fake = fakeAnthropic({ status: 'in_progress' });
    expect((await run(['submit'], { ClientClass: fake.FakeAnthropic })).code).toBe(0);

    const capped = await run(['submit', '--max-in-flight', '1'], { ClientClass: fake.FakeAnthropic });
    expect(capped.code).toBe(1);
    expect(capped.err).toContain(
      'submit: batch msgbatch_fake1 is recorded and not yet collected; run `l10n collect` first. ' +
        '1 batch(es) in flight is the most --max-in-flight allows (1). No batch created.'
    );
    expect(fake.calls.batchCreate).toHaveLength(1);
    expect(readJson(memory('pending.json')).batches).toHaveLength(1);

    // At two it has one free slot, and --batches 3 still creates one batch.
    expect((await run(['submit', '--max-in-flight', '2', '--batches', '3'], { ClientClass: fake.FakeAnthropic })).code).toBe(0);
    expect(fake.calls.batchCreate).toHaveLength(2);

    for (const bad of ['4', '0', 'two']) {
      const refused = await run(['submit', '--max-in-flight', bad], { ClientClass: fake.FakeAnthropic });
      expect(refused.code).toBe(2);
      expect(refused.err).toContain('submit: --max-in-flight takes a positive integer no greater than backend.batches.maxInFlight (3).');
    }
    expect(fake.calls.batchCreate).toHaveLength(2);
  });

  it('submit --batches takes no more than the free slots, and refuses a value that is not a positive integer', async () => {
    expect((await run(['extract'])).code).toBe(0);
    await oneRequestPerBatch();
    const fake = fakeAnthropic({ status: 'in_progress' });
    expect((await run(['submit', '--batches', '3'], { ClientClass: fake.FakeAnthropic })).code).toBe(0);
    expect(fake.calls.batchCreate).toHaveLength(1);
    const bad = await run(['submit', '--batches', '0'], { ClientClass: fake.FakeAnthropic });
    expect(bad.code).toBe(2);
    expect(bad.err).toContain('submit: --batches takes a positive integer.');
  });

  it('collect applies the batch that has ended and leaves the one still processing recorded, with its last known request counts', async () => {
    editConfig((c) => (c.backend.batches = { maxInFlight: 2 }));
    expect((await run(['extract'])).code).toBe(0);
    await oneRequestPerBatch();
    const ended = new Set();
    const fake = fakeAnthropic({ status: (id) => (ended.has(id) ? 'ended' : 'in_progress') });
    expect((await run(['submit'], { ClientClass: fake.FakeAnthropic })).code).toBe(0);
    expect((await run(['submit'], { ClientClass: fake.FakeAnthropic })).code).toBe(0);

    ended.add('msgbatch_fake1');
    const r = await run(['collect'], { ClientClass: fake.FakeAnthropic, now: () => '2026-10-16T02:30:01Z' });
    expect(r.code).toBe(0);
    expect(r.out).toContain(
      'collect: batch msgbatch_fake1 has ended, 2 h 30 min after it was created (processing 0, succeeded 1, errored 0, canceled 0, expired 0).'
    );
    expect(r.out).toContain(
      'collect: batch msgbatch_fake2 is in_progress, in flight for 2 h 29 min (processing 1, succeeded 0, errored 0, canceled 0, expired 0); left recorded.'
    );
    expect(Object.keys(readJson(memory('machine', 'en.json'))).sort()).toEqual([...HOME_MISSING].sort());
    expect(fake.calls.results).toEqual(['msgbatch_fake1']);
    const pending = readJson(memory('pending.json'));
    expect(pending.batches.map((b) => b.id)).toEqual(['msgbatch_fake2']);
    expect(pending.batches[0].counts).toEqual({ processing: 1, succeeded: 0, errored: 0, canceled: 0, expired: 0 });
    expect(pending.batches[0].checkedAt).toBe('2026-10-16T02:30:01Z');
    expect(fs.readdirSync(memory('jobs'))).toHaveLength(1);

    ended.add('msgbatch_fake2');
    expect((await run(['collect'], { ClientClass: fake.FakeAnthropic })).code).toBe(0);
    expect(Object.keys(readJson(memory('machine', 'en.json'))).sort()).toEqual([...ALL_MISSING].sort());
    expect(readJson(memory('pending.json')).batches).toEqual([]);
  });

  it('collect applies the batches in creation order and writes the pending file after each, so a failure reading a later one loses nothing an earlier one applied and applies nothing twice', async () => {
    editConfig((c) => (c.backend.batches = { maxInFlight: 2 }));
    expect((await run(['extract'])).code).toBe(0);
    await oneRequestPerBatch();
    let failing = true;
    const fake = fakeAnthropic({
      status: (id) => {
        if (id === 'msgbatch_fake2' && failing) throw new InternalServerError(500, { type: 'error', error: { type: 'api_error', message: 'boom' } }, undefined, new Headers());
        return 'ended';
      },
    });
    expect((await run(['submit'], { ClientClass: fake.FakeAnthropic })).code).toBe(0);
    expect((await run(['submit'], { ClientClass: fake.FakeAnthropic })).code).toBe(0);
    // The file lists the later batch first: creation order, not the file's, decides.
    const recorded = readJson(memory('pending.json'));
    recorded.batches.reverse();
    writeJson(memory('pending.json'), recorded);

    await expect(run(['collect'], { ClientClass: fake.FakeAnthropic })).rejects.toThrow();
    expect(fake.calls.retrieve).toEqual(['msgbatch_fake1', 'msgbatch_fake2']);
    expect(readJson(memory('pending.json')).batches.map((b) => b.id)).toEqual(['msgbatch_fake2']);
    expect(Object.keys(readJson(memory('machine', 'en.json'))).sort()).toEqual([...HOME_MISSING].sort());

    failing = false;
    expect((await run(['collect'], { ClientClass: fake.FakeAnthropic })).code).toBe(0);
    expect(fake.calls.results).toEqual(['msgbatch_fake1', 'msgbatch_fake2']);
    expect(Object.keys(readJson(memory('machine', 'en.json'))).sort()).toEqual([...ALL_MISSING].sort());
    expect(readJson(memory('pending.json')).batches).toEqual([]);
  });

  it('status lists each batch in flight with its age and last known request counts, and flags one in flight past backend.batches.staleAfterHours as stale, as collect does', async () => {
    expect((await run(['extract'])).code).toBe(0);
    const fake = fakeAnthropic({ status: 'in_progress' });
    expect((await run(['submit'], { ClientClass: fake.FakeAnthropic })).code).toBe(0);
    expect((await run(['collect'], { ClientClass: fake.FakeAnthropic, now: () => '2026-10-16T05:00:01Z' })).code).toBe(0);

    const counts = '(processing 2, succeeded 0, errored 0, canceled 0, expired 0)';
    const fresh = await run(['status'], { now: () => '2026-10-16T05:00:01Z', env: {} });
    expect(fresh.out).toContain(
      `status: batch msgbatch_fake1, created 2026-10-16T00:00:01Z: 2 request(s) (en); in flight for 5 h 0 min; last read at 2026-10-16T05:00:01Z ${counts}; ` +
        'run `l10n collect` to apply it once it has ended.'
    );
    expect(fresh.out).not.toContain('stale');

    const stale = 'stale: in flight for more than backend.batches.staleAfterHours (6 h); `l10n cancel msgbatch_fake1` cancels it';
    const old = await run(['status'], { now: () => '2026-10-16T07:00:01Z', env: {} });
    expect(old.out).toContain(`in flight for 7 h 0 min; last read at 2026-10-16T05:00:01Z ${counts}; ${stale}; run \`l10n collect\``);
    const collected = await run(['collect'], { ClientClass: fake.FakeAnthropic, now: () => '2026-10-16T07:00:01Z' });
    expect(collected.out).toContain(`in flight for 7 h 0 min ${counts}; left recorded; ${stale}.`);

    editConfig((c) => (c.backend.batches = { staleAfterHours: 2 }));
    const shorter = await run(['status'], { now: () => '2026-10-16T05:00:01Z', env: {} });
    expect(shorter.out).toContain('stale: in flight for more than backend.batches.staleAfterHours (2 h)');
  });

  it('l10n cancel asks the API to cancel the batch and records it; the next collect leaves its canceled pairs to the next submission, counting no attempt', async () => {
    expect((await run(['extract'])).code).toBe(0);
    let processing = 'in_progress';
    const fake = fakeAnthropic({ status: () => processing, result: () => ({ type: 'canceled' }) });
    expect((await run(['submit'], { ClientClass: fake.FakeAnthropic })).code).toBe(0);

    const r = await run(['cancel', 'msgbatch_fake1'], { ClientClass: fake.FakeAnthropic, now: () => '2026-10-16T03:00:01Z' });
    expect(r.code).toBe(0);
    expect(fake.calls.cancel).toEqual(['msgbatch_fake1']);
    expect(r.out).toContain(
      'cancel: batch msgbatch_fake1, created 2026-10-16T00:00:01Z, in flight for 3 h 0 min: the API accepted the cancellation (processing status: canceling).'
    );
    expect(readJson(memory('pending.json')).batches[0].canceledAt).toBe('2026-10-16T03:00:01Z');

    processing = 'ended';
    const collected = await run(['collect'], { ClientClass: fake.FakeAnthropic });
    expect(collected.code).toBe(0);
    expect(collected.out).toContain('6 left for the next submission after a transport failure');
    expect(collected.out).toContain('  2 request(s) failed for the transport, not counted as attempts: the request was canceled (2)');
    const pending = readJson(memory('pending.json'));
    expect(pending.batches).toEqual([]);
    expect(pending.queue).toEqual({});
    const [job] = fs.readdirSync(memory('jobs')).map((f) => readJson(memory('jobs', f)));
    expect(job.failures).toEqual([]);
    expect(job.transport.map((t) => t.srcHash).sort()).toEqual([...ALL_MISSING].sort());
    expect(job.transport[0]).toMatchObject({ lang: 'en', error: 'the request was canceled', attempt: 1 });

    // The next submission requests them again, still as the first attempt.
    processing = 'in_progress';
    expect((await run(['submit'], { ClientClass: fake.FakeAnthropic })).code).toBe(0);
    expect(Object.values(readJson(memory('pending.json')).batches[0].requests).map((q) => q.attempt)).toEqual([1, 1]);
  });

  it('l10n cancel --stale cancels only the stale batches, --dry-run names them and sends nothing, and a batch the pending file does not record is refused', async () => {
    editConfig((c) => (c.backend.batches = { maxInFlight: 2 }));
    expect((await run(['extract'])).code).toBe(0);
    await oneRequestPerBatch();
    const fake = fakeAnthropic({ status: 'in_progress' });
    expect((await run(['submit'], { ClientClass: fake.FakeAnthropic })).code).toBe(0);
    expect((await run(['submit'], { ClientClass: fake.FakeAnthropic })).code).toBe(0);
    // The second batch was created five hours after the first.
    const recorded = readJson(memory('pending.json'));
    recorded.batches[1].createdAt = '2026-10-16T05:00:02Z';
    writeJson(memory('pending.json'), recorded);
    const now = () => '2026-10-16T07:00:01Z';
    const constructed = fake.constructed.length;

    const dry = await run(['cancel', '--stale', '--dry-run'], { ClientClass: fake.FakeAnthropic, now });
    expect(dry.code).toBe(0);
    expect(dry.out).toContain('cancel --dry-run: would cancel batch msgbatch_fake1, created 2026-10-16T00:00:01Z, in flight for 7 h 0 min.');
    expect(dry.out).not.toContain('msgbatch_fake2');
    expect(dry.out).toContain('cancel --dry-run: no request sent, no file written.');
    expect(fake.constructed).toHaveLength(constructed);

    const r = await run(['cancel', '--stale'], { ClientClass: fake.FakeAnthropic, now });
    expect(r.code).toBe(0);
    expect(fake.calls.cancel).toEqual(['msgbatch_fake1']);
    expect(readJson(memory('pending.json')).batches.map((b) => b.canceledAt)).toEqual([now(), undefined]);

    const unknown = await run(['cancel', 'msgbatch_other'], { ClientClass: fake.FakeAnthropic });
    expect(unknown.code).toBe(2);
    expect(unknown.err).toContain(`cancel: batch msgbatch_other is not recorded in ${memory('pending.json')}: nothing was canceled.`);
    expect((await run(['cancel'], { ClientClass: fake.FakeAnthropic })).code).toBe(2);
    expect((await run(['cancel', 'msgbatch_fake2', '--stale'], { ClientClass: fake.FakeAnthropic })).code).toBe(2);
    expect(fake.calls.cancel).toEqual(['msgbatch_fake1']);
  });

  it('session export leaves out the pairs every batch in flight holds', async () => {
    editConfig((c) => (c.backend.batches = { maxInFlight: 2 }));
    expect((await run(['extract'])).code).toBe(0);
    await oneRequestPerBatch();
    const fake = fakeAnthropic({ status: 'in_progress' });
    expect((await run(['submit'], { ClientClass: fake.FakeAnthropic })).code).toBe(0);
    expect((await run(['submit'], { ClientClass: fake.FakeAnthropic })).code).toBe(0);
    const r = await run(['session', 'export']);
    expect(r.out).toContain(
      `session export: ${ALL_MISSING.length} segment-locale pair(s) are held by a recorded Message Batch (${memory('pending.json')}) and are left to \`l10n collect\`.`
    );
  });
});

describe('the spending budget (backend.budget)', () => {
  it('the arithmetic: billed since the date plus the spend before it, the batches in flight at the observed share, and the verdict on a new batch', () => {
    const jobs = [
      // Billed 4 against a recorded bound of 10.
      { id: 'b1', at: '2026-10-20T00:00:00.000Z', usage: { requests: [{ model: 'claude-opus-5-5' }], cost: 4, estimate: { input: 1e6, output: 1e5, bound: 10 } } },
      // Billed 2 against an estimate recorded with no bound: its tokens at the model's rates, 0.5 × 4 + 0.05 × 10 = 2.5.
      { id: 'b0', at: '2026-10-10T00:00:00.000Z', usage: { requests: [{ model: 'claude-opus-5-5' }], cost: 2, estimate: { input: 500000, output: 50000 } } },
    ];
    expect(estimateBound(jobs[1].usage.estimate, ['claude-opus-5-5'])).toBeCloseTo(2.5, 10);
    expect(observedShare(jobs)).toEqual({ share: 6 / 12.5, batches: 2 });
    const pending = { batches: [{ id: 'b2', estimate: { input: 1, output: 1, bound: 5 }, requests: {} }] };
    const spend = committedSpend({ budget: { usd: 20, since: '2026-10-15', billedBefore: 7 }, jobs, pending });
    expect(spend.recorded).toBe(4);
    expect(spend.billed).toBe(11);
    expect(spend.expectedInFlight).toBeCloseTo(5 * 0.48, 10);
    expect(spend.committed).toBeCloseTo(13.4, 10);
    expect(spend.unpriced).toBeNull();
    const fits = batchVerdict(spend, 10);
    expect(fits.fits).toBe(true);
    expect(fits.expected).toBeCloseTo(4.8, 10);
    expect(fits.after).toBeCloseTo(18.2, 10);
    // A batch planned before it in the same submission counts too.
    expect(batchVerdict(spend, 10, 2).fits).toBe(false);
    // With no history, a batch is expected to cost its bound.
    const fresh = committedSpend({ budget: { usd: 20, since: null, billedBefore: 0 }, jobs: [], pending });
    expect(fresh.share).toBe(1);
    expect(fresh.committed).toBe(5);
    // A collected batch with no price makes the budget uncheckable.
    const unpriced = committedSpend({ budget: { usd: 20, since: null, billedBefore: 0 }, jobs: [{ id: 'x', at: '2026-10-21T00:00:00Z', usage: { requests: [] } }], pending });
    expect(unpriced.unpriced).toContain('batch x');
    expect(batchVerdict(unpriced, 1).fits).toBe(false);
    expect(batchVerdict(spend, null).unpriced).toContain('rate table');
  });

  it('submit refuses a batch whose expected cost — its bound at the observed billed share — would take the committed spend over backend.budget, stating the figures; --dry-run states the same', async () => {
    expect((await run(['extract'])).code).toBe(0);
    const fake = fakeAnthropic({ status: 'in_progress' });
    // The bound a batch of this work records.
    expect((await run(['submit'], { ClientClass: fake.FakeAnthropic })).code).toBe(0);
    const bound = readJson(memory('pending.json')).batches[0].estimate.bound;
    expect(bound).toBeGreaterThan(0);
    fs.rmSync(memory('pending.json'));
    // One collected batch was billed half its bound: the observed share is 0.5.
    writeJson(jobFile('msgbatch_old'), collectedJob({ id: 'msgbatch_old', cost: 1, bound: 2 }));
    const figures = (usd) =>
      `billed so far USD 1.00, expected in flight USD 0.00, this batch ${formatUsd(bound * 0.5)} expected (upper bound ${formatUsd(bound)}), budget ${formatUsd(usd)}`;

    // Room for the batch at the observed share, though not at its bound.
    editConfig((c) => (c.backend.budget = { usd: 1 + bound * 0.75 }));
    const fits = await run(['submit'], { ClientClass: fake.FakeAnthropic });
    expect(fits.code).toBe(0);
    expect(fits.out).toContain(`submit: within the budget: ${figures(1 + bound * 0.75)}; committed after it ${formatUsd(1 + bound * 0.5)}.`);
    expect(fake.calls.batchCreate).toHaveLength(2);
    fs.rmSync(memory('pending.json'));

    // Room for less than its expected cost: refused, with the figures, and no batch created.
    editConfig((c) => (c.backend.budget = { usd: 1 + bound * 0.25 }));
    const refused = await run(['submit'], { ClientClass: fake.FakeAnthropic });
    expect(refused.code).toBe(1);
    expect(refused.err).toContain(`submit: over the budget: ${figures(1 + bound * 0.25)}; it would take the committed spend to ${formatUsd(1 + bound * 0.5)}.`);
    expect(refused.err).toContain('submit: refused by backend.budget: no batch created.');
    expect(fake.calls.batchCreate).toHaveLength(2);
    expect(fs.existsSync(memory('pending.json'))).toBe(false);

    const dry = await run(['submit', '--dry-run']);
    expect(dry.code).toBe(0);
    expect(dry.out).toContain(`submit --dry-run: over the budget: ${figures(1 + bound * 0.25)}`);
    expect(dry.out).toContain('submit --dry-run: a submission now would be refused by backend.budget; no batch created, no file written.');

    // With no history a batch is expected to cost its bound: the room that took it at the observed share refuses it.
    fs.rmSync(jobFile('msgbatch_old'));
    editConfig((c) => (c.backend.budget = { usd: 1 + bound * 0.75, billedBefore: 1 }));
    const unseen = await run(['submit', '--dry-run']);
    expect(unseen.out).toContain(
      `over the budget: billed so far USD 1.00, expected in flight USD 0.00, this batch ${formatUsd(bound)} expected (upper bound ${formatUsd(bound)})`
    );
  });

  it('a batch in flight counts its expected cost against the budget before the next one is admitted', async () => {
    editConfig((c) => (c.backend.batches = { maxInFlight: 2 }));
    expect((await run(['extract'])).code).toBe(0);
    await oneRequestPerBatch();
    const fake = fakeAnthropic({ status: 'in_progress' });
    expect((await run(['submit'], { ClientClass: fake.FakeAnthropic })).code).toBe(0);
    const inFlight = readJson(memory('pending.json')).batches[0].estimate.bound;
    // Room for the batch in flight and nothing more.
    editConfig((c) => (c.backend.budget = { usd: inFlight * 1.01 }));
    const r = await run(['submit'], { ClientClass: fake.FakeAnthropic });
    expect(r.code).toBe(1);
    expect(r.err).toContain(`submit: over the budget: billed so far USD 0.00, expected in flight ${formatUsd(inFlight)}, this batch`);
    expect(fake.calls.batchCreate).toHaveLength(1);
  });

  it('status prints the budget: billed since the date with the spend before it, the expected cost in flight, and what remains', async () => {
    expect((await run(['extract'])).code).toBe(0);
    const fake = fakeAnthropic({ status: 'in_progress' });
    expect((await run(['submit'], { ClientClass: fake.FakeAnthropic })).code).toBe(0);
    const bound = readJson(memory('pending.json')).batches[0].estimate.bound;
    writeJson(jobFile('msgbatch_old'), collectedJob({ id: 'msgbatch_old', cost: 1, bound: 2 }));

    editConfig((c) => (c.backend.budget = { usd: 10, since: '2026-09-01', billedBefore: 3 }));
    const r = await run(['status'], { env: {} });
    expect(r.out).toContain(
      'status: budget USD 10.00: billed USD 4.00 (USD 1.00 recorded by the collected batches created since 2026-09-01, ' +
        `USD 3.00 before them (backend.budget.billedBefore)), in flight ${formatUsd(bound * 0.5)} expected (1 batch(es)), ` +
        `remaining ${formatUsd(10 - 4 - bound * 0.5)}.`
    );
    expect(r.out).toContain("status: a batch's expected cost is its upper bound times the billed share of the bound observed over 1 collected batch(es), 0.500.");

    // A date after the collected batch: its spend no longer counts, though its share still does.
    editConfig((c) => (c.backend.budget = { usd: 10, since: '2026-10-02', billedBefore: 3 }));
    const later = await run(['status'], { env: {} });
    expect(later.out).toContain('status: budget USD 10.00: billed USD 3.00 (USD 0.00 recorded by the collected batches created since 2026-10-02,');
    expect(later.out).toContain('observed over 1 collected batch(es), 0.500.');
  });
});

describe('fair attempts (the attempt rule)', () => {
  const ROWS = [
    { result: errored('billing_error', 'spend limit reached'), counts: false, account: true },
    { result: errored('permission_error', 'not allowed'), counts: false, account: true },
    { result: errored('authentication_error', 'invalid x-api-key'), counts: false, account: true },
    { result: errored('invalid_request_error', 'Your credit balance is too low to access the Anthropic API.'), counts: false, account: true },
    { result: errored('invalid_request_error', 'You have reached your specified API usage limits.'), counts: false, account: true },
    { result: errored('rate_limit_error', 'Number of requests has exceeded your rate limit'), counts: false, account: false },
    { result: errored('overloaded_error', 'Overloaded'), counts: false, account: false },
    { result: errored('api_error', 'Internal server error'), counts: false, account: false },
    { result: errored('timeout_error', 'Request timed out'), counts: false, account: false },
    { result: { type: 'expired' }, counts: false, account: false },
    { result: { type: 'canceled' }, counts: false, account: false },
    { result: null, counts: false, account: false },
    { result: errored('invalid_request_error', 'prompt is too long'), counts: true, account: false },
    { result: errored('not_found_error', 'model: claude-x'), counts: true, account: false },
    { result: errored('some_new_error', 'unheard of'), counts: true, account: false },
  ];
  for (const row of ROWS) {
    const name = row.result ? (row.result.type === 'errored' ? `${row.result.error.error.type}: ${row.result.error.error.message}` : row.result.type) : 'no result';
    it(`${name} ${row.counts ? 'counts an attempt' : 'counts no attempt'}${row.account ? ' and is the account’s own' : ''}`, () => {
      const failure = resultFailure(row.result);
      expect(failure.counts).toBe(row.counts);
      expect(failure.account).toBe(row.account);
    });
  }

  it('overloaded, rate-limited, timed-out, server-errored, expired, canceled and missing results keep their attempt count, while a validation failure and an invalid_request_error count one', async () => {
    editConfig((c) => (c.backend.attempts = 5));
    expect((await run(['extract'])).code).toBe(0);
    const OUTCOMES = {
      empty: (params) => ({ type: 'succeeded', message: replyMessage(requestBody(params).translate.map((id) => ({ id, text: '' }))) }),
      overloaded: () => errored('overloaded_error', 'Overloaded'),
      rate: () => errored('rate_limit_error', 'Number of requests has exceeded your rate limit'),
      timeout: () => errored('timeout_error', 'Request timed out'),
      api: () => errored('api_error', 'Internal server error'),
      expired: () => ({ type: 'expired' }),
      canceled: () => ({ type: 'canceled' }),
      invalid: () => errored('invalid_request_error', 'messages: text content blocks must be non-empty'),
    };
    let outcome = 'empty';
    let missing = false;
    const fake = fakeAnthropic({ result: (params) => OUTCOMES[outcome](params), order: (lines) => (missing ? [] : lines) });
    const queue = () => readJson(memory('pending.json')).queue;
    const attempts = () => Object.values(queue().en || {}).map((e) => e.attempts);
    const round = async (name, { noResults = false } = {}) => {
      outcome = name;
      missing = noResults;
      expect((await run(['submit'], { ClientClass: fake.FakeAnthropic })).code).toBe(0);
      const sent = Object.values(readJson(memory('pending.json')).batches[0].requests).map((q) => q.attempt);
      expect((await run(['collect'], { ClientClass: fake.FakeAnthropic })).code).toBe(0);
      return sent;
    };

    await round('empty');
    expect(attempts()).toEqual(ALL_MISSING.map(() => 1));
    for (const name of ['overloaded', 'rate', 'timeout', 'api', 'expired', 'canceled']) {
      const before = queue();
      expect(await round(name)).toEqual([2, 2]);
      expect(queue()).toEqual(before);
    }
    const beforeMissing = queue();
    expect(await round('empty', { noResults: true })).toEqual([2, 2]);
    expect(queue()).toEqual(beforeMissing);

    expect(await round('invalid')).toEqual([2, 2]);
    expect(attempts()).toEqual(ALL_MISSING.map(() => 2));
    expect(await round('empty')).toEqual([3, 3]);
    expect(attempts()).toEqual(ALL_MISSING.map(() => 3));
  });

  it('a failure of the account counts no attempt and halts submission until submit --resume; status names the halt', async () => {
    expect((await run(['extract'])).code).toBe(0);
    const CREDIT = 'Your credit balance is too low to access the Anthropic API. Please go to Plans & Billing to upgrade or purchase credits.';
    let broke = true;
    const fake = fakeAnthropic({ result: (params) => (broke ? errored('invalid_request_error', CREDIT) : { type: 'succeeded', message: echoReply(params) }) });
    expect((await run(['submit'], { ClientClass: fake.FakeAnthropic })).code).toBe(0);
    const at = '2026-10-16T01:00:00Z';
    const collected = await run(['collect'], { ClientClass: fake.FakeAnthropic, now: () => at });
    expect(collected.code).toBe(0);
    const reason = `the request errored (invalid_request_error: ${CREDIT})`;
    const halt = `submission is halted since ${at}: batch msgbatch_fake1 failed for the account (${reason}), and submitting more would fail the same way`;
    expect(collected.err).toContain(`collect: ${halt}`);
    const pending = readJson(memory('pending.json'));
    expect(pending.queue).toEqual({});
    expect(pending.halt).toEqual({ at, batch: 'msgbatch_fake1', reason });

    const refused = await run(['submit'], { ClientClass: fake.FakeAnthropic });
    expect(refused.code).toBe(1);
    expect(refused.err).toContain(`submit: ${halt}.`);
    expect(refused.err).toContain('then run `l10n submit --resume`');
    expect(fake.calls.batchCreate).toHaveLength(1);
    expect((await run(['status'], { env: {} })).out).toContain(`status: ${halt}; \`l10n submit --resume\` submits again once the account is fixed.`);
    const dry = await run(['submit', '--dry-run']);
    expect(dry.out).toContain(`submit --dry-run: ${halt}, so a submission now would be refused.`);

    broke = false;
    const resumed = await run(['submit', '--resume'], { ClientClass: fake.FakeAnthropic });
    expect(resumed.code).toBe(0);
    expect(resumed.out).toContain('submit: --resume: the halt is cleared');
    const after = readJson(memory('pending.json'));
    expect(after.halt).toBeUndefined();
    expect(Object.values(after.batches[0].requests).map((q) => q.attempt)).toEqual([1, 1]);
    expect((await run(['collect'], { ClientClass: fake.FakeAnthropic })).code).toBe(0);
    expect(Object.keys(readJson(memory('machine', 'en.json'))).sort()).toEqual([...ALL_MISSING].sort());
  });
});

describe('compatibility with what 1.3.3 wrote, and the configuration', () => {
  it('a batch a 1.3.3 submit recorded — no bound, no request counts — collects under 1.3.4, and counts toward the budget at its tokens’ bound', async () => {
    expect((await run(['extract'])).code).toBe(0);
    let processing = 'in_progress';
    const fake = fakeAnthropic({ status: () => processing });
    expect((await run(['submit'], { ClientClass: fake.FakeAnthropic })).code).toBe(0);
    const recorded = readJson(memory('pending.json'));
    const bound = recorded.batches[0].estimate.bound;
    delete recorded.batches[0].estimate.bound;
    writeJson(memory('pending.json'), recorded);

    editConfig((c) => (c.backend.budget = { usd: 100 }));
    expect((await run(['status'], { env: {} })).out).toContain(`in flight ${formatUsd(bound)} expected (1 batch(es))`);

    processing = 'ended';
    expect((await run(['collect'], { ClientClass: fake.FakeAnthropic })).code).toBe(0);
    expect(Object.keys(readJson(memory('machine', 'en.json'))).sort()).toEqual([...ALL_MISSING].sort());
    expect(readJson(memory('pending.json'))).toEqual({ batches: [], queue: {} });
  });

  it('the defaults keep one batch in flight, a six-hour stale mark and no budget', () => {
    expect(translationSettings({ kind: 'anthropic' })).toMatchObject({ batches: { maxInFlight: 1, staleAfterHours: 6 }, budget: null });
    expect(translationSettings({ kind: 'anthropic', batches: { maxInFlight: 3 }, budget: { usd: 200, billedBefore: 25 } })).toMatchObject({
      batches: { maxInFlight: 3, staleAfterHours: 6 },
      budget: { usd: 200, since: null, billedBefore: 25 },
    });
  });

  const MALFORMED = [
    { backend: { batches: { maxInFlight: 0 } }, names: 'backend.batches.maxInFlight' },
    { backend: { batches: { maxInFlight: 1.5 } }, names: 'backend.batches.maxInFlight' },
    { backend: { batches: { staleAfterHours: 0 } }, names: 'backend.batches.staleAfterHours' },
    { backend: { batches: { inFlight: 2 } }, names: 'backend.batches' },
    { backend: { budget: { billedBefore: 25 } }, names: 'backend.budget.usd' },
    { backend: { budget: { usd: -1 } }, names: 'backend.budget.usd' },
    { backend: { budget: { usd: 200, since: 'last week' } }, names: 'backend.budget.since' },
    { backend: { budget: { usd: 200, billedBefore: -1 } }, names: 'backend.budget.billedBefore' },
  ];
  for (const row of MALFORMED) {
    it(`refuses ${JSON.stringify(row.backend)}, naming ${row.names}, before any file is read`, async () => {
      editConfig((c) => Object.assign(c.backend, row.backend));
      const r = await run(['status']);
      expect(r.code).toBe(2);
      expect(r.err).toContain(row.names);
    });
  }
});
