import '../test/no-network.mjs';
import { describe, it, expect, beforeEach, afterEach } from 'vitest';
import fs from 'node:fs';
import path from 'node:path';

import { runCli } from './cli.mjs';
import { requeueLeftOut } from './requeue.mjs';
import { keyOf } from './normalize.mjs';
import { capture, copyMarkdownFixture, fakeAnthropic, requestBody, writeJson } from '../test/helpers.mjs';

let project;
beforeEach(() => {
  project = copyMarkdownFixture('l10n-requeue-');
});
afterEach(() => {
  fs.rmSync(project, { recursive: true, force: true });
});

const memory = (...p) => path.join(project, 'memory', ...p);
const work = (...p) => memory('session', ...p);
const readJson = (file) => JSON.parse(fs.readFileSync(file, 'utf8'));

async function run(argv, deps = {}) {
  const io = capture();
  const code = await runCli(argv, { cwd: project, env: { ANTHROPIC_API_KEY: 'test-key' }, log: io.log, errlog: io.errlog, ...deps });
  return { code, out: io.text(), err: io.errors() };
}

const LEFT = keyOf('Text with a footnote[^note].');
const OTHER = keyOf('Lists');
const DEFECT = 'inline code, a link or image destination, HTML or a reference differs from the source: added "`x`"';

/** A pending file and a session queue as 1.3.0 leaves them: segments at the attempt limit (3 by default) and below it. */
function leaveOut() {
  writeJson(memory('pending.json'), {
    batches: [],
    queue: {
      it: { [LEFT]: { attempts: 3, defect: DEFECT }, [OTHER]: { attempts: 1, defect: 'the translation is empty' } },
      de: { [LEFT]: { attempts: 3, defect: DEFECT, usedFallback: true } },
    },
  });
  writeJson(work('queue.json'), { it: { [OTHER]: { attempts: 3, defect: 'the translation is empty' } } });
}

describe('l10n requeue: the segments left out after backend.attempts rejections', () => {
  it('--dry-run names them and writes nothing', async () => {
    leaveOut();
    const before = [fs.readFileSync(memory('pending.json'), 'utf8'), fs.readFileSync(work('queue.json'), 'utf8')];
    const r = await run(['requeue', '--dry-run']);
    expect(r.code).toBe(0);
    expect(r.out).toContain(`requeue: ${memory('pending.json')}: would give 2 left-out segment(s) their attempts again (de: 1, it: 1).`);
    expect(r.out).toContain(`requeue: ${work('queue.json')}: would give 1 left-out segment(s) their attempts again (it: 1).`);
    expect(r.out).toContain(`  it ${LEFT}, rejected 3 times: ${DEFECT}`);
    expect(r.out).toContain('requeue --dry-run: nothing was written.');
    expect([fs.readFileSync(memory('pending.json'), 'utf8'), fs.readFileSync(work('queue.json'), 'utf8')]).toEqual(before);
  });

  it('gives each its attempts again and keeps its defect and fallback state, in both queues; a segment below the limit is untouched', async () => {
    leaveOut();
    expect((await run(['requeue'])).code).toBe(0);
    const queue = readJson(memory('pending.json')).queue;
    expect(queue.it[LEFT]).toEqual({ attempts: 0, defect: DEFECT });
    expect(queue.de[LEFT]).toEqual({ attempts: 0, defect: DEFECT, usedFallback: true });
    expect(queue.it[OTHER]).toEqual({ attempts: 1, defect: 'the translation is empty' });
    expect(readJson(work('queue.json')).it[OTHER]).toEqual({ attempts: 0, defect: 'the translation is empty' });
  });

  it('narrows to --targets, --keys, --api or --session', async () => {
    leaveOut();
    await run(['requeue', '--targets', 'de', '--api']);
    expect(readJson(memory('pending.json')).queue.it[LEFT].attempts).toBe(3);
    expect(readJson(memory('pending.json')).queue.de[LEFT].attempts).toBe(0);
    expect(readJson(work('queue.json')).it[OTHER].attempts).toBe(3);

    await run(['requeue', '--session', '--keys', 'nothing-like-it']);
    expect(readJson(work('queue.json')).it[OTHER].attempts).toBe(3);
    await run(['requeue', '--session', '--keys', OTHER]);
    expect(readJson(work('queue.json')).it[OTHER].attempts).toBe(0);
    expect(readJson(memory('pending.json')).queue.it[LEFT].attempts).toBe(3);
  });

  it('leaves a pair a recorded batch still requests, naming it', async () => {
    leaveOut();
    const pending = readJson(memory('pending.json'));
    pending.batches.push({ id: 'msgbatch_recorded', createdAt: 'then', requests: { '000000-it': { page: 'README.md', section: null, lang: 'it', ids: [LEFT], attempt: 3, model: 'm', fallback: false } } });
    writeJson(memory('pending.json'), pending);
    const r = await run(['requeue', '--api']);
    expect(r.out).toContain(`  it ${LEFT}: a recorded batch still requests it, so it is left as it is; requeue it after \`l10n collect\`.`);
    const after = readJson(memory('pending.json'));
    expect(after.queue.it[LEFT].attempts).toBe(3);
    expect(after.batches).toEqual(pending.batches);
  });

  it('submit then requests a requeued segment as a first attempt, stating its last defect', async () => {
    expect((await run(['extract'])).code).toBe(0);
    leaveOut();
    // Alone in the queue: a request's attempt is the highest of its segments', so a neighbour at attempt 1 would make it 2.
    const pending = readJson(memory('pending.json'));
    delete pending.queue.it[OTHER];
    writeJson(memory('pending.json'), pending);
    const dry = await run(['submit', '--targets', 'it', '--dry-run']);
    expect(dry.out).toContain('submit: it: 1 segment(s) reached the attempt limit and stay untranslated');
    await run(['requeue', '--api', '--targets', 'it']);
    const fake = fakeAnthropic({ status: 'in_progress' });
    expect((await run(['submit', '--targets', 'it'], { ClientClass: fake.FakeAnthropic })).code).toBe(0);
    const request = fake.calls.batchCreate[0].requests.map((q) => q.params).find((p) => requestBody(p).translate.includes(LEFT));
    expect(requestBody(request).corrections[LEFT]).toBe(DEFECT);
    const record = Object.values(readJson(memory('pending.json')).batches[0].requests).find((q) => q.ids.includes(LEFT));
    expect(record.attempt).toBe(1);
  });

  it('says when there is no session queue, and requeues nothing it does not find', async () => {
    const r = await run(['requeue']);
    expect(r.code).toBe(0);
    expect(r.out).toContain(`requeue: ${memory('pending.json')}: no left-out segment matches.`);
    expect(r.out).toContain(`requeue: ${work('queue.json')}: there is no session queue.`);
  });
});

describe('requeueLeftOut', () => {
  it('resets only entries at the limit, in the locales named', () => {
    const queue = { it: { a: { attempts: 3, defect: 'd' }, b: { attempts: 2, defect: 'e' } }, de: { a: { attempts: 4, defect: 'd' } } };
    const { reset } = requeueLeftOut(queue, { attemptLimit: 3, targets: ['it'], keys: null });
    expect(reset).toEqual([{ lang: 'it', id: 'a', attempts: 3, defect: 'd' }]);
    expect(queue).toEqual({ it: { a: { attempts: 0, defect: 'd' }, b: { attempts: 2, defect: 'e' } }, de: { a: { attempts: 4, defect: 'd' } } });
  });
});
