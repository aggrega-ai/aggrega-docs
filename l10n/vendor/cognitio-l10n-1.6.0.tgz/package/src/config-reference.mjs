/**
 * config-reference.mjs — The configuration reference, generated from the
 * configuration's schema.
 *
 * READS nothing from disk: it walks `ConfigSchema` (`config.mjs`) and the key
 * documentation every key carries there — its sentence, the commands that read
 * it, any default applied outside the schema — and renders one table row per
 * key: its type, its default and the commands that read it. `spliceReference`
 * places the result between the README's markers; the package script
 * `scripts/config-reference.mjs` writes it, or with `--check` compares it, and
 * does the same for every section `GENERATED_SECTIONS` names — the table of the
 * models' reasoning settings among them (`models.mjs`). WRITES nothing.
 *
 * A key with no documentation, a reader that is not a command and a schema
 * shape the renderer has no notation for each throw, naming the key, so the
 * reference cannot silently omit what the schema accepts.
 */

import { COMMANDS } from './cli.mjs';
import { ConfigSchema, EVERY_COMMAND, isIntegerSchema, keyDoc, typeName } from './config.mjs';
import { renderModelTable } from './models.mjs';

/** The name of the README's generated configuration reference. */
export const REFERENCE_SECTION = 'config-reference';

/** The name of the README's generated table of the models' reasoning settings. */
export const MODEL_SECTION = 'model-settings';

/** The marker lines that open and close a generated section. */
export const sectionMarkers = (name) => [`<!-- BEGIN GENERATED: ${name} -->`, `<!-- END GENERATED: ${name} -->`];

/** A schema node's Zod definition. */
const defOf = (schema) => schema && schema._zod && schema._zod.def;

/** A schema node's Zod kind, a union with a discriminator told apart as `discriminated-union`. */
function kindOf(schema) {
  const def = defOf(schema);
  if (!def) return undefined;
  return def.type === 'union' && def.discriminator !== undefined ? 'discriminated-union' : def.type;
}

/** The value of a literal schema, as a discriminator's is. */
const literalOf = (schema) => defOf(schema).values[0];

/** A key path's components, joined for display. */
const keyPath = (parts) => parts.join('.');

/**
 * The schema with its optional and default wrappers removed, and what the
 * wrappers said; a refinement is part of the schema it refines, so it leaves
 * nothing to remove. A default is either kind Zod has: one returned as written
 * (`default`) or one validated as the value would be (`prefault`); the reference
 * prints the value as written. A schema `named` gave a type name stops the walk,
 * since the name is what the reference prints.
 */
function unwrap(schema) {
  let node = schema;
  let optional = false;
  let defaultValue;
  let hasDefault = false;
  for (;;) {
    if (typeName(node)) break;
    const kind = kindOf(node);
    if (kind === 'optional') {
      optional = true;
      node = defOf(node).innerType;
    } else if (kind === 'default' || kind === 'prefault') {
      if (!hasDefault) {
        hasDefault = true;
        defaultValue = defOf(node).defaultValue;
      }
      node = defOf(node).innerType;
    } else {
      break;
    }
  }
  return { node, optional, hasDefault, defaultValue };
}

/**
 * The TypeScript-like notation of a value schema. Named types are recorded in
 * `used`, so the reference can define each one it prints.
 */
function typeOf(schema, used, where) {
  const named = typeName(schema);
  if (named) {
    used.set(named.name, named.text);
    return named.name;
  }
  const kind = kindOf(schema);
  const def = defOf(schema);
  switch (kind) {
    case 'optional':
    case 'default':
    case 'prefault':
      return typeOf(def.innerType, used, where);
    case 'string':
      return 'string';
    case 'number':
      return isIntegerSchema(schema) ? 'integer' : 'number';
    case 'boolean':
      return 'boolean';
    case 'literal':
      return def.values.map((v) => JSON.stringify(v)).join(' | ');
    case 'enum':
      return Object.values(def.entries)
        .map((v) => JSON.stringify(v))
        .join(' | ');
    case 'array': {
      const item = typeOf(def.element, used, where);
      return item.includes(' | ') ? `(${item})[]` : `${item}[]`;
    }
    case 'record':
      return `Record<${typeOf(def.keyType, used, where)}, ${typeOf(def.valueType, used, where)}>`;
    case 'object': {
      const keys = Object.entries(def.shape).map(([key, value]) => (unwrap(value).optional || unwrap(value).hasDefault ? `${key}?` : key));
      return `{ ${keys.join(', ')} }`;
    }
    case 'union':
    case 'discriminated-union':
      return def.options.map((option) => typeOf(option, used, where)).join(' | ');
    default:
      throw new Error(`config-reference: ${where}: no notation for a ${kind}`);
  }
}

/** The commands a key's documentation names, checked against the command line's, in its order. */
function readersOf(meta, where, commands) {
  if (meta.readBy === EVERY_COMMAND) return 'every command';
  if (!Array.isArray(meta.readBy) || meta.readBy.length === 0) throw new Error(`config-reference: ${where}: names no command that reads it`);
  const unknown = meta.readBy.filter((name) => !commands.includes(name));
  if (unknown.length) throw new Error(`config-reference: ${where}: ${unknown.join(', ')} is not a command`);
  return commands.filter((name) => meta.readBy.includes(name)).map((name) => `\`${name}\``).join(', ');
}

/** Escapes a table cell's pipes and line breaks. */
const cell = (text) => String(text).replace(/\|/g, '\\|').replace(/\n/g, ' ');

/**
 * Walks one schema node at `parts`, adding a row per documented key to
 * `tables[table]`, and descending into an undocumented object.
 *
 * @param {Object} state
 * @param {string|null} state.within     the nearest optional ancestor's key path, or null.
 * @param {Object|undefined} state.parentDefault  the default value the parent object supplies.
 * @param {string} state.table           the table rows go to.
 */
function walk(schema, parts, state, ctx) {
  const where = keyPath(parts);
  const meta = keyDoc(schema);
  const { node, optional, hasDefault, defaultValue } = unwrap(schema);
  const kind = kindOf(node);
  const own = hasDefault ? defaultValue : state.parentDefault;

  if (kind === 'discriminated-union' && !typeName(node)) {
    if (!meta) throw new Error(`config-reference: ${where}: no documentation`);
    const { discriminator } = defOf(node);
    const options = [...defOf(node).options];
    const kindParts = [...parts, discriminator];
    addRow(ctx, state.table, {
      key: keyPath(kindParts),
      type: options.map((option) => JSON.stringify(literalOf(option.shape[discriminator]))).join(' | '),
      default: own !== undefined && own[discriminator] !== undefined ? `\`${JSON.stringify(own[discriminator])}\`` : requiredText(state.within, optional),
      readBy: readersOf(meta, where, ctx.commands),
      text: meta.text,
    });
    for (const option of options) {
      const value = literalOf(option.shape[discriminator]);
      const table = options.length > 1 ? `${keyPath(kindParts)}: ${JSON.stringify(value)}` : state.table;
      for (const [key, child] of Object.entries(option.shape)) {
        if (key === discriminator) continue;
        walk(child, [...parts, key], { within: optional && !hasDefault ? where : state.within, parentDefault: own && own[key], table }, ctx);
      }
    }
    return;
  }

  if (kind === 'object' && !meta) {
    const within = optional && !hasDefault ? where : state.within;
    for (const [key, child] of Object.entries(node.shape)) {
      walk(child, [...parts, key], { within, parentDefault: own && own[key], table: state.table }, ctx);
    }
    return;
  }

  if (!meta) throw new Error(`config-reference: ${where}: no documentation`);
  let defaultText;
  if (meta.default !== undefined) defaultText = meta.default;
  else if (own !== undefined) defaultText = `\`${JSON.stringify(own)}\``;
  else if (optional) defaultText = 'none';
  else defaultText = requiredText(state.within, false);
  addRow(ctx, state.table, {
    key: where,
    type: typeOf(schema, ctx.used, where),
    default: defaultText,
    readBy: readersOf(meta, where, ctx.commands),
    text: meta.text,
  });
}

/** The default cell of a key with no default. */
function requiredText(within, optional) {
  if (optional) return 'none';
  return within ? `required in \`${within}\`` : 'required';
}

function addRow(ctx, table, row) {
  if (!ctx.tables.has(table)) ctx.tables.set(table, []);
  ctx.tables.get(table).push(row);
}

/** Renders one table. */
function renderTable(rows) {
  const lines = ['| Key | Type | Default | Read by | What it holds |', '|---|---|---|---|---|'];
  for (const row of rows) {
    lines.push(`| \`${row.key}\` | \`${cell(row.type)}\` | ${cell(row.default)} | ${cell(row.readBy)} | ${cell(row.text)} |`);
  }
  return lines.join('\n');
}

/**
 * The configuration reference, as Markdown: one table of the keys every
 * configuration may hold, one table per adapter kind, and the definition of
 * every named type the tables print.
 *
 * @param {Object} [args]
 * @param {Object} [args.schema]      the schema (default: `ConfigSchema`).
 * @param {readonly string[]} [args.commands]  the command names a reader must be one of (default: the command line's).
 * @returns {string}
 */
export function renderConfigReference({ schema = ConfigSchema, commands = COMMANDS } = {}) {
  const ctx = { tables: new Map(), used: new Map(), commands };
  const main = 'main';
  ctx.tables.set(main, []);
  const { node } = unwrap(schema);
  if (kindOf(node) !== 'object') throw new Error('config-reference: the schema is not an object');
  for (const [key, child] of Object.entries(node.shape)) {
    walk(child, [key], { within: null, parentDefault: undefined, table: main }, ctx);
  }
  const parts = [
    'Generated from the schema in `src/config.mjs` by `npm run reference`: change a key there, then regenerate.',
    renderTable(ctx.tables.get(main)),
  ];
  for (const [table, rows] of ctx.tables) {
    if (table === main) continue;
    parts.push(`With \`${table}\`:`, renderTable(rows));
  }
  if (ctx.used.size) {
    parts.push(
      'The named types:',
      [...ctx.used.entries()]
        .sort(([a], [b]) => (a < b ? -1 : a > b ? 1 : 0))
        .map(([name, text]) => `- \`${name}\` — ${text}`)
        .join('\n')
    );
  }
  return parts.join('\n\n');
}

/**
 * Replaces the body of the generated section `name` in `text` with `body`,
 * the markers kept on lines of their own with a blank line on each side of the
 * body. Throws when the section's markers are missing, repeated or out of
 * order.
 */
export function spliceReference(text, body, name = REFERENCE_SECTION) {
  const [begin, end] = sectionMarkers(name);
  const start = text.indexOf(begin);
  const stop = text.indexOf(end);
  if (start === -1 || stop === -1 || stop < start || text.indexOf(begin, start + 1) !== -1 || text.indexOf(end, stop + 1) !== -1) {
    throw new Error(`config-reference: the text holds no single "${begin}" … "${end}" section`);
  }
  return `${text.slice(0, start)}${begin}\n\n${body}\n\n${text.slice(stop)}`;
}

/** The body of the generated section `name` in `text`, as `spliceReference` writes it, or null without one. */
export function readReference(text, name = REFERENCE_SECTION) {
  const [begin, end] = sectionMarkers(name);
  const start = text.indexOf(begin);
  const stop = text.indexOf(end);
  if (start === -1 || stop === -1 || stop < start) return null;
  return text.slice(start + begin.length, stop).replace(/^\n\n/, '').replace(/\n\n$/, '');
}

/** Every generated section of the README, each with what renders its body. */
export const GENERATED_SECTIONS = Object.freeze([
  Object.freeze({ name: REFERENCE_SECTION, render: () => renderConfigReference() }),
  Object.freeze({ name: MODEL_SECTION, render: () => renderModelTable() }),
]);

export default { REFERENCE_SECTION, MODEL_SECTION, GENERATED_SECTIONS, sectionMarkers, renderConfigReference, spliceReference, readReference };
