/**
 * progress.mjs — How far the translation has come, per locale and in total, and
 * the resubmission-queue entries that no longer stand for work.
 *
 * READS, through the store, the catalogue, both memory layers and the
 * re-translation marks; the queues and the held pairs are handed in by the
 * caller. WRITES nothing.
 *
 * PROGRESS is counted against the catalogue as the last extract wrote it: a
 * locale's segments are the catalogue's units, its words theirs, and a segment is
 * translated in a locale when the memory's lookup view holds its key there, as
 * the gate decides. Among the missing ones, a segment a resubmission queue holds
 * at `backend.attempts` or more is left out, and one a queue holds below it is
 * queued. Percentages are of words, since a long segment is more work than a
 * short one.
 *
 * A STALE QUEUE ENTRY is one a transport would never act on: its segment is
 * already translated in its locale, and not marked for re-translation; or the
 * other transport holds the pair — a session batch not yet imported, for an
 * entry of the pending file's queue, or a recorded Message Batch, for an entry of
 * the session's — so the pair's next translation, accepted or queued, is that
 * transport's. `l10n requeue --prune` removes them.
 */

import { markedFromStore } from './retranslate.mjs';

const WORD = /[\p{L}\p{N}]+/gu;

/** The words of a text: its runs of letters and digits. The one word count of a batch, a status and a progress line. */
export const wordsOf = (text) => (String(text).match(WORD) || []).length;

const own = (object, key) => Boolean(object) && Object.prototype.hasOwnProperty.call(object, key);

/**
 * Per target locale, the translation's progress against the catalogue.
 *
 * @param {Object} args
 * @param {Object.<string, {source:string}>} args.units   the catalogue's units.
 * @param {Object.<string, Object>} args.tmByLang         locale → the memory's lookup view.
 * @param {string[]} args.targets
 * @param {Array<import('./types.mjs').Queue>} [args.queues]  the resubmission queues to count left-out and queued segments in.
 * @param {number} args.attemptLimit
 * @returns {Array<{lang:string, segments:number, words:number, translated:number, translatedWords:number,
 *                  missing:number, missingWords:number, leftOut:number, queued:number}>}
 */
export function progressRows({ units, tmByLang, targets, queues = [], attemptLimit }) {
  const all = Object.entries(units || {}).map(([key, unit]) => ({ key, words: wordsOf(unit && unit.source) }));
  const words = all.reduce((n, u) => n + u.words, 0);
  return targets.map((lang) => {
    const tm = (tmByLang && tmByLang[lang]) || {};
    const row = { lang, segments: all.length, words, translated: 0, translatedWords: 0, missing: 0, missingWords: 0, leftOut: 0, queued: 0 };
    for (const { key, words: w } of all) {
      if (own(tm, key)) {
        row.translated += 1;
        row.translatedWords += w;
        continue;
      }
      row.missing += 1;
      row.missingWords += w;
      const entries = queues.map((q) => q && q[lang] && q[lang][key]).filter(Boolean);
      if (entries.some((e) => e.attempts >= attemptLimit)) row.leftOut += 1;
      else if (entries.length) row.queued += 1;
    }
    return row;
  });
}

const done = (part, whole) => (whole > 0 ? `${((part / whole) * 100).toFixed(1)}%` : '100.0%');

/**
 * One line per locale and a total line, each prefixed with `prefix`.
 *
 * @param {ReturnType<typeof progressRows>} rows
 * @param {string} prefix
 * @returns {string[]}
 */
export function progressLines(rows, prefix) {
  const line = (name, r) =>
    `  ${name}: ${done(r.translatedWords, r.words)} done by words; translated ${r.translated} of ${r.segments} segments, ` +
    `${r.translatedWords} of ${r.words} words; missing ${r.missing} segments, ${r.missingWords} words; ${r.leftOut} left out, ${r.queued} queued`;
  const total = rows.reduce(
    (t, r) => {
      for (const k of ['segments', 'words', 'translated', 'translatedWords', 'missing', 'missingWords', 'leftOut', 'queued']) t[k] += r[k];
      return t;
    },
    { segments: 0, words: 0, translated: 0, translatedWords: 0, missing: 0, missingWords: 0, leftOut: 0, queued: 0 }
  );
  return [
    `${prefix}: progress against the catalogue of the last extract, per locale:`,
    ...rows.map((r) => line(r.lang, r)),
    line(`total over ${rows.length} locale${rows.length === 1 ? '' : 's'}`, total),
  ];
}

/**
 * The translation's progress read through a store: the catalogue and the
 * lookup view of every target.
 *
 * @param {ReturnType<import('./store.mjs').createStore>} store
 * @param {Object} args
 * @param {string[]} args.targets
 * @param {Array<import('./types.mjs').Queue>} [args.queues]
 * @param {number} args.attemptLimit
 */
export function progressFromStore(store, { targets, queues = [], attemptLimit }) {
  return progressRows({ units: store.readSourceCatalog().units || {}, tmByLang: store.readAllTM(targets), targets, queues, attemptLimit });
}

/**
 * The stale entries of one queue, in locale then key order.
 *
 * @param {import('./types.mjs').Queue} queue
 * @param {Object} args
 * @param {string[]} args.targets
 * @param {Object.<string, Object>} args.tmByLang       locale → the memory's lookup view.
 * @param {Map<string, Set<string>>} args.marked        the pairs marked for re-translation.
 * @param {Map<string, Set<string>>} args.heldElsewhere the pairs the other transport holds.
 * @param {string} args.elsewhere                       what the other transport is, as the reason names it.
 * @returns {Array<{lang:string, id:string, why:string}>}
 */
export function staleEntries(queue, { targets, tmByLang, marked, heldElsewhere, elsewhere }) {
  const stale = [];
  for (const lang of Object.keys(queue || {}).sort()) {
    if (!targets.includes(lang)) continue;
    for (const id of Object.keys(queue[lang] || {}).sort()) {
      if (own(tmByLang[lang], id) && !(marked.has(lang) && marked.get(lang).has(id))) {
        stale.push({ lang, id, why: 'already translated' });
      } else if (heldElsewhere.has(lang) && heldElsewhere.get(lang).has(id)) {
        stale.push({ lang, id, why: `held by ${elsewhere}` });
      }
    }
  }
  return stale;
}

/**
 * The stale entries of both queues, read through a store.
 *
 * @param {ReturnType<import('./store.mjs').createStore>} store
 * @param {Object} args
 * @param {string[]} args.targets
 * @param {import('./types.mjs').Queue} args.apiQueue      the pending file's queue.
 * @param {import('./types.mjs').Queue} args.sessionQueue  the session's queue.
 * @param {Map<string, Set<string>>} args.batchHeld        the pairs the recorded Message Batches hold.
 * @param {Map<string, Set<string>>} args.sessionHeld      the pairs the session's batches not yet imported hold.
 * @returns {{api: Array<{lang:string, id:string, why:string}>, session: Array<{lang:string, id:string, why:string}>}}
 */
export function staleFromStore(store, { targets, apiQueue, sessionQueue, batchHeld, sessionHeld }) {
  const tmByLang = store.readAllTM(targets);
  const marked = markedFromStore(store, targets).pairs;
  return {
    api: staleEntries(apiQueue, { targets, tmByLang, marked, heldElsewhere: sessionHeld, elsewhere: 'a session batch not yet imported' }),
    session: staleEntries(sessionQueue, { targets, tmByLang, marked, heldElsewhere: batchHeld, elsewhere: 'a recorded Message Batch' }),
  };
}

/**
 * The lines naming a queue's stale entries: a count per reason, then each entry.
 *
 * @param {Array<{lang:string, id:string, why:string}>} stale
 * @param {Object} args
 * @param {string} args.prefix
 * @param {string} args.queue   the queue, as the line names it.
 * @returns {string[]}
 */
export function staleLines(stale, { prefix, queue }) {
  if (!stale.length) return [];
  return [
    `${prefix}: ${stale.length} entr${stale.length === 1 ? 'y' : 'ies'} of ${queue} no longer stand for work; \`l10n requeue --prune\` removes them:`,
    ...stale.map((s) => `  ${s.lang} ${s.id}: ${s.why}`),
  ];
}

export default { wordsOf, progressRows, progressLines, progressFromStore, staleEntries, staleFromStore, staleLines };
