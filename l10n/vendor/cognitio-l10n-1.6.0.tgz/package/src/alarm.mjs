/**
 * alarm.mjs — The rejection alarm: a batch whose translations were rejected far
 * more often than the recent batches of its transport is named, with what was
 * wrong with them, before the next batch repeats the cause.
 *
 * READS the job logs, through the store, for the history. WRITES nothing: the
 * caller records the alarm in the batch's job log and, under
 * `backend.alarm.stopSubmissions`, the halt that stops its transport.
 *
 * THE RATE of a batch is the share of its judged (segment, locale) pairs that
 * were rejected: a job log's `failures` over its `items` and `failures`. A pair
 * the transport failed (`transport`), one a check could not judge (`internal`)
 * and a locale with no output file count in neither, since no translation of
 * them was judged.
 *
 * THE HISTORY is the latest `history` other job logs of the same transport —
 * `collect` for the Message Batches API, `session` for a translating session —
 * that judged at least `minPairs` pairs, in the order their file names sort,
 * which is the order of their times. A job log of any version is read as it is:
 * every one records `items` and `failures`.
 *
 * A BATCH WARNS when it judged at least `minPairs` pairs, its history holds at
 * least `ALARM_MIN_HISTORY` batches, and its rate is above both `factor` times
 * the history's median rate and `minRate`. The warning names the defect kinds
 * that account for most of its rejections, each with its count and one example:
 * a kind is a defect's sentence up to its first detail, with quoted text and
 * numbers left out (`defectKind`), so the same slip on different segments counts
 * once.
 */

import { TRANSLATION_DEFAULTS } from './config.mjs';

/** The fewest earlier batches a median is taken over: below it, a batch is not compared. */
export const ALARM_MIN_HISTORY = 3;

/** How many defect kinds a warning names. */
export const ALARM_KINDS = 3;

/** The pairs a job log judged, and how many of them it rejected. */
export function judgedPairs(job) {
  const rejected = Array.isArray(job && job.failures) ? job.failures.length : 0;
  const accepted = Array.isArray(job && job.items) ? job.items.length : 0;
  return { judged: accepted + rejected, rejected };
}

/**
 * The kind of a defect: its sentence up to its first detail (`: `, `; `, ` (`),
 * quoted text written `…` and every number standing alone `N` — a line number, a
 * count — while one inside a name, as in `UTF-8`, is kept.
 *
 * @param {string} defect
 * @returns {string}
 */
export function defectKind(defect) {
  const kind = String(defect ?? '')
    .replace(/"(?:[^"\\]|\\.)*"/g, '…')
    .split(/: |; | \(/)[0]
    .replace(/(?<![\p{L}\p{N}-])\d+(?![\p{L}\p{N}])/gu, 'N')
    .trim();
  return kind || 'no defect recorded';
}

/**
 * The most frequent defect kinds among rejections, most frequent first, each
 * with its count and its first rejection as the example.
 *
 * @param {Array<{srcHash:string, lang:string, error:string}>} failures
 * @param {number} [limit]
 * @returns {Array<{kind:string, count:number, example:{lang:string, srcHash:string, defect:string}}>}
 */
export function defectKinds(failures, limit = ALARM_KINDS) {
  const kinds = new Map();
  for (const f of failures || []) {
    const kind = defectKind(f.error);
    if (!kinds.has(kind)) kinds.set(kind, { kind, count: 0, example: { lang: f.lang, srcHash: f.srcHash, defect: f.error } });
    kinds.get(kind).count += 1;
  }
  return [...kinds.values()].sort((a, b) => b.count - a.count || (a.kind < b.kind ? -1 : a.kind > b.kind ? 1 : 0)).slice(0, limit);
}

/** The median of a list of numbers, or null for an empty list. */
export function median(values) {
  if (!values.length) return null;
  const sorted = [...values].sort((a, b) => a - b);
  const mid = Math.floor(sorted.length / 2);
  return sorted.length % 2 ? sorted[mid] : (sorted[mid - 1] + sorted[mid]) / 2;
}

/**
 * The rates of the latest job logs of a transport, latest first: at most
 * `history` of them, each of a job other than `exclude` that judged at least
 * `minPairs` pairs. Reads the job logs from the latest back, and no further than
 * it needs.
 *
 * @param {ReturnType<import('./store.mjs').createStore>} store
 * @param {Object} args
 * @param {string} args.trigger   `collect` or `session`.
 * @param {string} [args.exclude] the job being judged, when its log is already written.
 * @param {number} args.history
 * @param {number} args.minPairs
 * @returns {Array<{id:string, rate:number}>}
 */
export function recentRates(store, { trigger, exclude = null, history, minPairs }) {
  const rates = [];
  if (typeof store.listJobs !== 'function' || typeof store.readJobLog !== 'function') return rates;
  const names = store.listJobs();
  for (let i = names.length - 1; i >= 0 && rates.length < history; i--) {
    const job = store.readJobLog(names[i]);
    if (!job || job.trigger !== trigger || job.id === exclude) continue;
    const { judged, rejected } = judgedPairs(job);
    if (judged >= minPairs) rates.push({ id: job.id, rate: rejected / judged });
  }
  return rates;
}

const rounded = (x) => Math.round(x * 10000) / 10000;

/**
 * Judges a batch's job log against the recent batches of its transport: the
 * alarm to record in it, or null when it does not warn.
 *
 * @param {Object} args
 * @param {ReturnType<import('./store.mjs').createStore>} args.store
 * @param {import('./types.mjs').JobLog} args.job  the batch's job log, before or after it is written.
 * @param {import('./config.mjs').TranslationSettings['alarm']} [args.settings]
 * @returns {{rate:number, rejected:number, judged:number, median:number, history:number, factor:number, minRate:number,
 *            kinds:Array<{kind:string, count:number, example:{lang:string, srcHash:string, defect:string}}>}|null}
 */
export function judgeBatch({ store, job, settings = TRANSLATION_DEFAULTS.alarm }) {
  const { judged, rejected } = judgedPairs(job);
  if (judged < settings.minPairs) return null;
  const history = recentRates(store, { trigger: job.trigger, exclude: job.id, history: settings.history, minPairs: settings.minPairs });
  if (history.length < ALARM_MIN_HISTORY) return null;
  const rate = rejected / judged;
  const typical = median(history.map((h) => h.rate));
  if (!(rate > settings.factor * typical && rate > settings.minRate)) return null;
  return {
    rate: rounded(rate),
    rejected,
    judged,
    median: rounded(typical),
    history: history.length,
    factor: settings.factor,
    minRate: settings.minRate,
    kinds: defectKinds(job.failures),
  };
}

const percent = (x) => `${(x * 100).toFixed(1)}%`;

/** The alarm in one clause, as a halt records its reason. */
export function alarmReason(alarm) {
  return `${alarm.rejected} of ${alarm.judged} judged pairs rejected, ${percent(alarm.rate)} against a median of ${percent(alarm.median)}`;
}

/** The warning's lines: the rates, then each defect kind with its count and example. */
export function alarmLines(alarm) {
  return [
    `rejection alarm: ${alarm.rejected} of ${alarm.judged} judged pairs were rejected (${percent(alarm.rate)}), above ${alarm.factor} times the ` +
      `median of the last ${alarm.history} batches (${percent(alarm.median)}) and above ${percent(alarm.minRate)}. The most frequent defects:`,
    ...alarm.kinds.map((k) => `  ${k.count} × ${k.kind}; for example ${k.example.lang} ${k.example.srcHash}: ${k.example.defect}`),
  ];
}

export default { ALARM_MIN_HISTORY, ALARM_KINDS, judgedPairs, defectKind, defectKinds, median, recentRates, judgeBatch, alarmReason, alarmLines };
