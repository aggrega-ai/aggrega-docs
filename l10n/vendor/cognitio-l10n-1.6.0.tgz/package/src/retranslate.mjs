/**
 * retranslate.mjs — Re-translating chosen segments whose source is unchanged:
 * `l10n retranslate`, the marks it records, and the work every transport plans
 * from them.
 *
 *   l10n retranslate [--targets a,b] [--keys k1,k2] [--keys-file f.json] [--match <regex>]
 *                    [--context <prefix>] [--file <glob>] [--reason "<text>"] [--include-human] [--dry-run]
 *
 * A segment is translated again when its source changes (`revisions.mjs`) or when
 * a locale lacks it. A translation can also need to change while its source does
 * not: a form of address or a variety decided after the fact, a glossary term
 * added later, a bad translation found in review. Marking the pair is the way to
 * ask for that without editing the machine layer by hand, which has one writer.
 *
 * THE MARKS, `<memory.dir>/retranslate.json`, are committed with the rest of the
 * memory, so a mark made on one machine is seen in review and by whoever
 * translates next:
 *   { "<locale>": { "<key>": { "reason": string, "markedAt": string, "human"?: true } } }
 * `human` marks a pair whose current translation is a person's (`--include-human`).
 *
 * SELECTION is the intersection of the selectors given, at least one of them:
 * `--keys` (in every target locale) and `--keys-file` (`{ "<locale>": [keys] }`)
 * name pairs, their union; `--match` keeps a pair whose translation now served
 * matches the regular expression; `--context` one whose unit's context starts with
 * the prefix — advisory, and only the first context the catalogue met is kept;
 * `--file` one any of whose usages sits in a file the glob matches, the reliable
 * selector. A pair is marked only where the locale translates it already: one with
 * no translation is translated by the next run anyway. A pair whose translation is
 * a person's (the human layer) is skipped and named, unless `--include-human`.
 * Marking a pair again replaces its reason. `--dry-run` prints exactly the pairs
 * it would mark and writes nothing.
 *
 * THE MARKED WORK (`markedWork`) is planned by every transport — `submit`,
 * `session export`, `translate`, `pipeline`, `local` — beside what is missing: a
 * marked pair is requested as a REVISION of itself, its current translation the
 * starting point and its mark's reason stated (`reason` in `revise`), under the
 * locale's guide and glossary as they stand. Until a new translation is accepted
 * the current one stays and serves; accepting it replaces it, clears the mark
 * (`settleAccepted`) and, for a `human` mark, moves the person's entry to the
 * human layer's archive so the new one is served. A rejected one follows the
 * attempts and `l10n requeue` like any other, the mark staying until a
 * translation is accepted. A mark is not planned, and is dropped at the next
 * marking, when its key has left the catalogue (the source changed, and the
 * change is translated as a revision), when the locale no longer translates the
 * key, or when a person's entry has come to stand for a pair marked without
 * `human`.
 *
 * READS the catalogue, both memory layers and the marks; the command WRITES the
 * marks alone, and nothing under `--dry-run`. It makes no network call.
 */

import path from 'node:path';

import { LAYER, STATUS } from './types.mjs';

/**
 * The reason a mark carries when `--reason` gives none: the translation is made
 * again under the locale's instructions as they now stand.
 */
export const DEFAULT_REASON =
  "the language guide, the glossary or the project's instructions changed after this translation was made: follow them as they now stand";

const own = (object, key) => Boolean(object) && Object.prototype.hasOwnProperty.call(object, key);

/**
 * The pairs a selection names, with what was left out and why. Pure.
 *
 * @param {Object} args
 * @param {Object.<string, Object>} args.units          the catalogue's units.
 * @param {Object.<string, Object>} args.lookup         locale → the lookup view of the memory.
 * @param {Object.<string, Object>} args.human          locale → the human layer.
 * @param {string[]} args.targets
 * @param {string[]|null} [args.keys]                   keys, in every target locale.
 * @param {Object.<string,string[]>|null} [args.keysFile]  locale → keys.
 * @param {RegExp|null} [args.match]                    on the translation now served.
 * @param {string|null} [args.context]                  a prefix of the unit's context.
 * @param {string|null} [args.file]                     a glob over the usages' files.
 * @param {boolean} [args.includeHuman]
 * @returns {{pairs: Array<{lang:string, key:string, translation:string, human:boolean}>,
 *            skipped: {human: Array<{lang:string, key:string}>, untranslated: Array<{lang:string, key:string}>,
 *                      unknown: string[], otherLocales: string[]}}}
 */
export function selectPairs({ units, lookup, human, targets, keys = null, keysFile = null, match = null, context = null, file = null, includeHuman = false }) {
  const skipped = { human: [], untranslated: [], unknown: [], otherLocales: [] };
  const named = keys || keysFile ? new Map() : null;
  const name = (lang, key) => {
    if (!named.has(lang)) named.set(lang, new Set());
    named.get(lang).add(key);
  };
  if (keys) for (const lang of targets) for (const key of keys) name(lang, key);
  if (keysFile) {
    for (const [lang, list] of Object.entries(keysFile)) {
      if (!targets.includes(lang)) skipped.otherLocales.push(lang);
      else for (const key of list) name(lang, key);
    }
  }
  const candidates = [];
  for (const lang of targets) {
    const keysOf = named ? [...(named.get(lang) || [])] : Object.keys(units);
    for (const key of keysOf.sort()) candidates.push({ lang, key });
  }

  const unknown = new Set();
  const pairs = [];
  for (const { lang, key } of candidates) {
    const unit = units[key];
    if (!unit) {
      unknown.add(key);
      continue;
    }
    if (context !== null && !(typeof unit.context === 'string' && unit.context.startsWith(context))) continue;
    if (file !== null && !(unit.usages || []).some((usage) => path.matchesGlob(usage.file, file))) continue;
    const entry = lookup[lang] && lookup[lang][key];
    if (!entry || typeof entry.text !== 'string') {
      // Named, it is reported; found by a filter, it is simply not a translation to redo.
      if (named) skipped.untranslated.push({ lang, key });
      continue;
    }
    if (match !== null && !match.test(entry.text)) continue;
    const isHuman = own(human[lang], key);
    if (isHuman && !includeHuman) {
      skipped.human.push({ lang, key });
      continue;
    }
    pairs.push({ lang, key, translation: entry.text, human: isHuman });
  }
  skipped.unknown = [...unknown].sort();
  return { pairs, skipped };
}

/**
 * The work the marks ask for: a worklist item per marked key, missing in each
 * locale it is marked in, and per locale the revision each marked key is
 * requested as — itself, its current translation the starting point, its reason
 * stated. A mark is left out, and named in `stale`, when its key has left the
 * catalogue, when the locale no longer translates it, or when a person's entry
 * stands for a pair marked without `human`. Pure.
 *
 * @param {Object} args
 * @param {Object.<string, Object>} args.units
 * @param {Object} args.marks         the marks (`store.readRetranslate`).
 * @param {Object.<string, Object>} args.lookup   locale → the lookup view.
 * @param {Object.<string, Object>} args.human    locale → the human layer.
 * @param {string[]} args.targets
 * @returns {{items: import('./types.mjs').WorklistItem[], revisions: Object.<string, Object.<string, import('./types.mjs').Revision>>,
 *            pairs: Map<string, Set<string>>, count: number, stale: Array<{lang:string, key:string, why:string}>}}
 */
export function markedWork({ units, marks, lookup, human, targets }) {
  const items = new Map();
  const revisions = {};
  const pairs = new Map();
  const stale = [];
  let count = 0;
  for (const lang of targets) {
    for (const key of Object.keys((marks && marks[lang]) || {}).sort()) {
      const mark = marks[lang][key] || {};
      const unit = units[key];
      if (!unit) {
        stale.push({ lang, key, why: 'its source changed, and the change is translated as a revision' });
        continue;
      }
      const entry = lookup[lang] && lookup[lang][key];
      if (!entry || typeof entry.text !== 'string') {
        stale.push({ lang, key, why: 'the locale no longer translates it, so the next run translates it anyway' });
        continue;
      }
      if (own(human[lang], key) && !mark.human) {
        stale.push({ lang, key, why: 'a person has since written its translation' });
        continue;
      }
      if (!items.has(key)) {
        const item = { srcHash: key, source: unit.source, format: unit.format || 'text', missing: [] };
        if (unit.context !== undefined) item.context = unit.context;
        if (unit.protected !== undefined) item.protected = unit.protected;
        items.set(key, item);
      }
      items.get(key).missing.push(lang);
      if (!revisions[lang]) revisions[lang] = {};
      revisions[lang][key] = {
        from: key,
        source: unit.source,
        translation: entry.text,
        reviewed: entry.status !== STATUS.MACHINE,
        forced: true,
        reason: typeof mark.reason === 'string' && mark.reason.trim() ? mark.reason : DEFAULT_REASON,
        ...(mark.human ? { human: true } : {}),
      };
      if (!pairs.has(lang)) pairs.set(lang, new Set());
      pairs.get(lang).add(key);
      count += 1;
    }
  }
  return { items: [...items.values()].sort((a, b) => (a.srcHash < b.srcHash ? -1 : 1)), revisions, pairs, count, stale };
}

/**
 * The marked work, read through a store: the catalogue, the marks, both layers.
 *
 * @param {ReturnType<import('./store.mjs').createStore>} store
 * @param {string[]} targets
 */
export function markedFromStore(store, targets) {
  const marks = typeof store.readRetranslate === 'function' ? store.readRetranslate() : {};
  if (!targets.some((lang) => marks[lang] && Object.keys(marks[lang]).length)) {
    return { items: [], revisions: {}, pairs: new Map(), count: 0, stale: [] };
  }
  return markedWork({
    units: store.readSourceCatalog().units || {},
    marks,
    lookup: store.readAllTM(targets),
    human: Object.fromEntries(targets.map((lang) => [lang, store.readLayer(LAYER.HUMAN, lang)])),
    targets,
  });
}

/**
 * A worklist with the marked work added: each marked pair missing in its
 * locale, beside what the gate found missing. With no marked work it is the
 * worklist as it was.
 *
 * @param {import('./types.mjs').Worklist} worklist
 * @param {ReturnType<typeof markedWork>} marked
 * @param {string[]} targets
 * @returns {import('./types.mjs').Worklist}
 */
export function withMarked(worklist, marked, targets) {
  if (!marked || marked.count === 0) return worklist;
  const byKey = new Map(((worklist && worklist.status === 'work' && worklist.items) || []).map((item) => [item.srcHash, { ...item, missing: [...item.missing] }]));
  for (const item of marked.items) {
    const existing = byKey.get(item.srcHash);
    if (!existing) {
      byKey.set(item.srcHash, { ...item, missing: [...item.missing] });
      continue;
    }
    for (const lang of item.missing) if (!existing.missing.includes(lang)) existing.missing.push(lang);
  }
  const items = [...byKey.values()].sort((a, b) => (a.srcHash < b.srcHash ? -1 : 1));
  return { status: 'work', targets: (worklist && worklist.targets) || targets, items, orphans: (worklist && worklist.orphans) || [] };
}

/**
 * Per locale, the revisions found for changed segments with the marked ones laid
 * over them: a marked pair is a revision of itself.
 */
export function withMarkedRevisions(revisions, marked) {
  const out = { ...(revisions || {}) };
  for (const [lang, byKey] of Object.entries((marked && marked.revisions) || {})) out[lang] = { ...(out[lang] || {}), ...byKey };
  return out;
}

/**
 * What a transport does once translations of a locale are accepted and written:
 * every mark on an accepted pair is cleared, and a re-translation that replaces a
 * person's entry moves that entry to the human layer's archive, so the new
 * translation is served. Reads and writes the marks and, for those, the human
 * layer; nothing when no accepted pair is marked.
 *
 * @param {Object} args
 * @param {ReturnType<import('./store.mjs').createStore>} args.store
 * @param {string} args.lang
 * @param {string[]} args.ids  the accepted keys.
 * @param {Object.<string, {forced?:boolean, human?:boolean}>} [args.revisions]  key → the revision it was requested as.
 * @returns {{cleared: string[], archived: string[]}}
 */
export function settleAccepted({ store, lang, ids, revisions = {} }) {
  if (typeof store.readRetranslate !== 'function') return { cleared: [], archived: [] };
  const marks = store.readRetranslate();
  const cleared = ids.filter((id) => own(marks[lang], id));
  const replacing = ids.filter((id) => revisions && revisions[id] && revisions[id].forced && revisions[id].human);
  const archived = replacing.length ? store.archiveLayerKeys(LAYER.HUMAN, lang, replacing) : [];
  if (cleared.length) {
    for (const id of cleared) delete marks[lang][id];
    store.writeRetranslate(marks);
  }
  return { cleared, archived };
}

/** A revision as a pending file, a session plan or a machine entry records it: its origin and, when forced, its reason. */
export function recordedRevision(revision) {
  return {
    from: revision.from,
    reviewed: Boolean(revision.reviewed),
    ...(revision.forced ? { forced: true, reason: revision.reason, ...(revision.human ? { human: true } : {}) } : {}),
  };
}

/**
 * The lines `gate`, `status` and `session status` print about the marks: how many
 * pairs wait for their re-translation, per locale; those at the attempt limit,
 * whose current translation still serves; the marks no longer planned. None when
 * nothing is marked.
 *
 * @param {ReturnType<typeof markedWork>} marked
 * @param {Object} [args]
 * @param {Object} [args.queue]         the queue whose attempts apply.
 * @param {number} [args.attemptLimit]
 * @param {string} [args.prefix]
 * @returns {string[]}
 */
export function markLines(marked, { queue = {}, attemptLimit = Infinity, prefix = 'retranslate' } = {}) {
  const lines = [];
  if (marked.count) {
    const perLang = [...marked.pairs].map(([lang, keys]) => `${lang}: ${keys.size}`).join(', ');
    lines.push(`${prefix}: ${marked.count} pair(s) marked for re-translation (${perLang}); the current translation serves until a new one is accepted.`);
    for (const [lang, keys] of marked.pairs) {
      for (const key of keys) {
        const entry = queue[lang] && queue[lang][key];
        if (entry && entry.attempts >= attemptLimit) {
          lines.push(`  left out after ${entry.attempts} attempts, the current translation still serving: ${lang} ${key}: ${entry.defect}`);
        }
      }
    }
  }
  if (marked.stale.length) lines.push(`${prefix}: ${marked.stale.length} mark(s) no longer planned, dropped at the next \`l10n retranslate\`.`);
  return lines;
}

/** The pairs of a list, per locale, as a summary line reads them. */
const perLocale = (pairs) => {
  const counts = new Map();
  for (const p of pairs) counts.set(p.lang, (counts.get(p.lang) || 0) + 1);
  return [...counts].map(([lang, n]) => `${lang}: ${n}`).join(', ');
};

/**
 * Runs `l10n retranslate`. See the module comment.
 *
 * @param {Object} args
 * @param {ReturnType<import('./store.mjs').createStore>} args.store
 * @param {string[]} args.targets
 * @param {Object} args.select  `{ keys, keysFile, match, context, file, includeHuman }`, as `selectPairs` takes them.
 * @param {string|null} [args.reason]
 * @param {boolean} [args.dryRun]
 * @param {() => string} [args.now]
 * @param {(...a:any[])=>void} [args.log]
 * @param {(...a:any[])=>void} [args.errlog]
 * @returns {{code:number, marked:number}}
 */
export function runRetranslate({ store, targets, select, reason = null, dryRun = false, now = () => new Date().toISOString(), log = (...a) => console.log(...a), errlog = (...a) => console.error(...a) }) {
  const catalog = store.readSourceCatalog();
  if (!catalog.units) {
    errlog('retranslate: there is no source catalogue yet; run `l10n extract` first. Nothing was marked.');
    return { code: 2, marked: 0 };
  }
  const lookup = store.readAllTM(targets);
  const human = Object.fromEntries(targets.map((lang) => [lang, store.readLayer(LAYER.HUMAN, lang)]));
  const { pairs, skipped } = selectPairs({ units: catalog.units, lookup, human, targets, ...select });
  const why = typeof reason === 'string' && reason.trim() ? reason.trim() : DEFAULT_REASON;
  const heading = dryRun ? 'retranslate --dry-run' : 'retranslate';

  if (skipped.otherLocales.length) log(`${heading}: the keys file names locales outside the targets, left out: ${skipped.otherLocales.join(', ')}.`);
  if (skipped.unknown.length) log(`${heading}: ${skipped.unknown.length} key(s) the catalogue does not hold, left out: ${skipped.unknown.join(', ')}.`);
  if (skipped.untranslated.length) {
    log(`${heading}: ${skipped.untranslated.length} pair(s) with no translation yet, left out: the next translation run translates them anyway (${perLocale(skipped.untranslated)}).`);
  }
  if (skipped.human.length) {
    log(`${heading}: ${skipped.human.length} pair(s) whose translation a person wrote, left out; --include-human replaces them:`);
    for (const p of skipped.human) log(`  ${p.lang} ${p.key}`);
  }
  if (pairs.length === 0) {
    log(`${heading}: no pair matches; nothing was marked.`);
    return { code: 0, marked: 0 };
  }

  log(`${heading}: ${dryRun ? 'would mark' : 'marked'} ${pairs.length} pair(s) for re-translation (${perLocale(pairs)}), reason: ${JSON.stringify(why)}.`);
  for (const p of pairs) log(`  ${p.lang} ${p.key}${p.human ? ' (a person’s translation, archived once the new one is accepted)' : ''}: ${JSON.stringify(p.translation.length > 80 ? `${p.translation.slice(0, 80)}…` : p.translation)}`);
  if (dryRun) {
    log('retranslate --dry-run: nothing was written.');
    return { code: 0, marked: pairs.length };
  }

  // The marks that still stand, those of keys that left the catalogue dropped, then the new ones laid over them.
  const marks = store.readRetranslate();
  for (const lang of Object.keys(marks)) for (const key of Object.keys(marks[lang])) if (!catalog.units[key]) delete marks[lang][key];
  const at = now();
  for (const p of pairs) {
    if (!marks[p.lang]) marks[p.lang] = {};
    marks[p.lang][p.key] = { reason: why, markedAt: at, ...(p.human ? { human: true } : {}) };
  }
  store.writeRetranslate(marks);
  log(`retranslate: recorded in ${store.paths.retranslate}; commit it with the memory. The next \`l10n session export\`, \`l10n submit\`, \`l10n local\` or \`l10n translate\` requests them, each starting from its current translation.`);
  return { code: 0, marked: pairs.length };
}

export default {
  DEFAULT_REASON,
  selectPairs,
  markedWork,
  markedFromStore,
  withMarked,
  withMarkedRevisions,
  settleAccepted,
  recordedRevision,
  markLines,
  runRetranslate,
};
