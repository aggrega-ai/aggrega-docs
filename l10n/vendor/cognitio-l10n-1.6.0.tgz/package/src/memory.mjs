/**
 * memory.mjs — `l10n memory commit`: commits the project's machine layer, and its
 * re-translation marks when it has any, to the CI branch, in a worktree of that
 * branch the caller has checked out.
 *
 *   l10n memory commit --worktree <dir> [--message <text>] [--author "<name> <email>"] [--trailer "<line>"]
 *
 * It is how a project that translates outside CI — in a translating session, or
 * by hand — puts what it translated where CI and the deploy-time overlay read
 * the machine layer, without copying files and staging them by hand.
 *
 * READS the configuration's `ci.branch`, the project's machine layer and
 * `retranslate.json`, and, through git, the repository top of the project and of
 * the worktree and the worktree's branch. WRITES those files into the worktree at
 * the paths the CI branch holds them at — the project's path in its own
 * repository — replacing each file of the same name and leaving any other file
 * there as it is; then, through git, the index entries of exactly those paths and
 * ONE commit of them on the worktree's branch. Nothing else in the worktree is
 * staged or committed, and nothing is pushed.
 *
 * It holds the package lock (`lock.mjs`) while it copies, so it never copies a
 * layer that `collect`, `session import` or `requeue` is rewriting, and refuses
 * while one of them runs.
 *
 * REFUSED, with exit 2 and nothing written: a configuration without `ci.branch`;
 * a worktree that is not the top of a git worktree; one whose checked-out branch
 * is not `ci.branch`; a memory directory outside the project's repository; an
 * `--author` not written `Name <email>`. With exit 1: a held lock, or a git
 * command that fails — a hook refusing the commit, an identity git lacks.
 */

import fs from 'node:fs';
import path from 'node:path';

import { branchPaths, machineLayerFiles, memoryPathInRepo } from './ci.mjs';
import { createGit, GitError, redactCredentials } from './git.mjs';
import { withLock } from './lock.mjs';

/** The subject of a commit `memory commit` makes when `--message` names none. */
export const MEMORY_COMMIT_MESSAGE = 'Update the machine translation layer';

/** An author as `--author` takes it: a name, then an email address in angle brackets. */
const AUTHOR_RE = /^\s*([^<>]*?)\s*<([^<>\s]+@[^<>\s]+)>\s*$/;

/** The name and email of an `--author` value, or null when it is not `Name <email>`. */
export function parseAuthor(value) {
  const match = AUTHOR_RE.exec(String(value));
  return match && match[1] ? { name: match[1], email: match[2] } : null;
}

/**
 * Runs `l10n memory commit`.
 *
 * @param {Object} args
 * @param {import('./config.mjs').Project} args.project
 * @param {string} args.worktree            the worktree, absolute.
 * @param {string|null} [args.message]
 * @param {string|null} [args.author]       `Name <email>`: the commit's author and committer.
 * @param {string|null} [args.trailer]      a line closing the message, after a blank line.
 * @param {NodeJS.ProcessEnv} [args.env]
 * @param {(...a:any[])=>void} [args.log]
 * @param {(...a:any[])=>void} [args.errlog]
 * @returns {Promise<{code:number, action:string, commit?:string, files?:string[]}>}
 */
export async function runMemoryCommit({ project, worktree, message = null, author = null, trailer = null, env = process.env, log = (...a) => console.log(...a), errlog = (...a) => console.error(...a) }) {
  const fail = (code, action, text) => {
    errlog(`memory commit: ${text} Nothing was copied or committed.`);
    return { code, action };
  };
  const ci = project.config.ci;
  if (!ci || !ci.branch) return fail(2, 'no-ci-branch', 'the configuration names no ci.branch, the branch the machine layer is committed to.');
  const identity = author === null ? null : parseAuthor(author);
  if (author !== null && !identity) return fail(2, 'bad-author', `--author ${JSON.stringify(author)} is not "Name <email>".`);
  if (!fs.existsSync(worktree)) return fail(2, 'no-worktree', `${worktree} does not exist.`);

  let wtTop;
  let projectTop;
  const wtGit = createGit({ cwd: worktree, env });
  try {
    wtTop = fs.realpathSync(wtGit.toplevel());
    projectTop = fs.realpathSync(createGit({ cwd: project.root, env }).toplevel());
  } catch (err) {
    if (!(err instanceof GitError)) throw err;
    return fail(2, 'not-a-repository', `${err.message}: the worktree and the project must each be in a git repository.`);
  }
  if (wtTop !== fs.realpathSync(worktree)) return fail(2, 'not-a-worktree', `${worktree} is not the top of a git worktree (its top is ${wtTop}).`);
  const branch = wtGit.currentBranch();
  if (branch !== ci.branch) {
    return fail(2, 'wrong-branch', `${worktree} has ${branch ? `the branch ${branch}` : 'a detached HEAD'} checked out, not the CI branch ${ci.branch}.`);
  }
  const memRel = fs.existsSync(project.memoryDir) ? memoryPathInRepo(projectTop, fs.realpathSync(project.memoryDir)) : null;
  if (memRel === null) return fail(2, 'outside-repository', `the memory directory ${project.memoryDir} is not inside the project's repository ${projectTop}.`);

  return withLock({ memoryDir: project.memoryDir, command: 'memory commit', log, errlog }, () => {
    const { machineDir } = branchPaths(memRel);
    const marks = `${memRel}/retranslate.json`;
    const files = machineLayerFiles(projectTop, memRel);
    if (fs.existsSync(path.join(projectTop, ...marks.split('/')))) files.push(marks);
    if (files.length === 0) return fail(1, 'no-machine-layer', `the project holds no machine layer at ${machineDir}/.`);
    for (const rel of files) {
      const to = path.join(wtTop, ...rel.split('/'));
      fs.mkdirSync(path.dirname(to), { recursive: true });
      fs.copyFileSync(path.join(projectTop, ...rel.split('/')), to);
    }
    const paths = [machineDir, ...(files.includes(marks) ? [marks] : [])];
    log(`memory commit: copied ${files.length} file(s) into ${wtTop}: ${machineDir}/${files.includes(marks) ? ` and ${marks}` : ''}.`);

    const identityEnv = identity
      ? { GIT_AUTHOR_NAME: identity.name, GIT_AUTHOR_EMAIL: identity.email, GIT_COMMITTER_NAME: identity.name, GIT_COMMITTER_EMAIL: identity.email }
      : {};
    const git = (args, extraEnv = {}) => {
      const res = wtGit.run(args, { extraEnv });
      if (res.status !== 0) {
        const last = String(res.stderr || res.stdout).trim().split('\n').filter(Boolean).pop() || `exit ${res.status}`;
        throw new GitError(`git ${args[0]} failed: ${redactCredentials(last.trim())}`);
      }
      return String(res.stdout).trim();
    };
    try {
      git(['add', '--', ...paths]);
      const staged = git(['diff', '--cached', '--name-only', '--', ...paths]);
      if (!staged) {
        log(`memory commit: the worktree's ${machineDir}/ already holds the project's: nothing to commit.`);
        return { code: 0, action: 'unchanged', files: [] };
      }
      const subject = message || MEMORY_COMMIT_MESSAGE;
      git(['commit', '--quiet', '-m', subject, ...(trailer ? ['-m', trailer] : []), '--', ...paths], identityEnv);
      const commit = git(['rev-parse', 'HEAD']);
      const changed = git(['show', '--name-only', '--format=', commit]).split('\n').filter(Boolean);
      log(`memory commit: ${commit} on ${branch}: ${subject} (${changed.length} file(s) changed). Nothing was pushed.`);
      return { code: 0, action: 'committed', commit, files: changed };
    } catch (err) {
      if (!(err instanceof GitError)) throw err;
      errlog(`memory commit: ${err.message}. The files are copied into the worktree; nothing was committed.`);
      return { code: 1, action: 'git-failed' };
    }
  });
}

export default { MEMORY_COMMIT_MESSAGE, parseAuthor, runMemoryCommit };
