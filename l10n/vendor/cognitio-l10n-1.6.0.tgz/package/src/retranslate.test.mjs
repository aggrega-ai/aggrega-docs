import '../test/no-network.mjs';
import { describe, it, expect, beforeEach, afterEach } from 'vitest';
import fs from 'node:fs';
import path from 'node:path';

import { runCli } from './cli.mjs';
import { keyOf } from './normalize.mjs';
import { DEFAULT_REASON, markedWork, selectPairs, withMarked } from './retranslate.mjs';
import { FORCED_REVISE_SENTENCE, generalRules } from './translator-prompt.mjs';
import { capture, copyFixtureProject, copyMarkdownFixture, echoReply, fakeAnthropic, replyMessage, requestBody, writeJson } from '../test/helpers.mjs';

const TARGETS = ['pt-BR', 'zh-Hans', 'zh-Hant'];
const NOTE = 'Text with a footnote[^note].';
const LISTS = 'Lists';
const REASON = 'address the reader formally';

let project;
const memory = (...p) => path.join(project, 'memory', ...p);
const work = (...p) => memory('session', ...p);
const readJson = (file) => JSON.parse(fs.readFileSync(file, 'utf8'));
const machine = (lang) => readJson(memory('machine', `${lang}.json`));
const marks = () => (fs.existsSync(memory('retranslate.json')) ? readJson(memory('retranslate.json')) : {});
const jobs = (trigger) => fs.readdirSync(memory('jobs')).sort().map((f) => readJson(memory('jobs', f))).filter((j) => j.trigger === trigger);

async function run(argv, deps = {}) {
  const io = capture();
  const code = await runCli(argv, { cwd: project, env: { ANTHROPIC_API_KEY: 'test-key' }, log: io.log, errlog: io.errlog, ...deps });
  return { code, out: io.text(), err: io.errors() };
}

/** The current translation every target locale holds of a source: the source tagged with the locale. */
const current = (source, lang) => `${source} ⟨${lang}⟩`;
/** The translation a re-translation writes. */
const revised = (source) => `${source} ⟪revised⟫`;

/**
 * The Markdown fixture in the local mode, translated into three BCP 47 locales: the catalogue extracted and every
 * unit in the machine layer of every target.
 */
async function translatedProject() {
  project = copyMarkdownFixture('l10n-retranslate-');
  const configPath = path.join(project, 'l10n.config.json');
  const config = readJson(configPath);
  config.mode = 'local';
  config.locales.targets = TARGETS;
  writeJson(configPath, config);
  for (const lang of TARGETS) fs.writeFileSync(memory('prompts', `${lang}.md`), `Translate into ${lang}.\n`);
  expect((await run(['extract'])).code).toBe(0);
  const units = readJson(memory('source.json')).units;
  for (const lang of TARGETS) {
    writeJson(
      memory('machine', `${lang}.json`),
      Object.fromEntries(Object.entries(units).map(([key, u]) => [key, { text: current(u.source, lang), status: 'machine', srcHash: key, job: 'seed', at: 'then' }]))
    );
  }
  return units;
}

afterEach(() => {
  if (project) fs.rmSync(project, { recursive: true, force: true });
  project = null;
});

describe('l10n retranslate: marking chosen pairs', () => {
  beforeEach(async () => {
    await translatedProject();
  });

  it('--dry-run prints exactly the pairs it would mark and writes nothing', async () => {
    const r = await run(['retranslate', '--targets', 'zh-Hans,zh-Hant', '--keys', keyOf(NOTE), '--dry-run']);
    expect(r.code).toBe(0);
    expect(r.out).toContain('retranslate --dry-run: would mark 2 pair(s) for re-translation (zh-Hans: 1, zh-Hant: 1)');
    expect(r.out).toContain(`  zh-Hans ${keyOf(NOTE)}: ${JSON.stringify(current(NOTE, 'zh-Hans'))}`);
    expect(r.out).toContain(`  zh-Hant ${keyOf(NOTE)}: `);
    expect(r.out).not.toContain(`  pt-BR ${keyOf(NOTE)}`);
    expect(fs.existsSync(memory('retranslate.json'))).toBe(false);
  });

  it('records the marks with their reason, and marking again replaces the reason', async () => {
    expect((await run(['retranslate', '--targets', 'zh-Hans', '--keys', keyOf(NOTE), '--reason', REASON])).code).toBe(0);
    expect(marks()).toEqual({ 'zh-Hans': { [keyOf(NOTE)]: { reason: REASON, markedAt: expect.any(String) } } });
    await run(['retranslate', '--targets', 'zh-Hans', '--keys', keyOf(NOTE), '--reason', 'use the Taiwan vocabulary']);
    expect(marks()['zh-Hans'][keyOf(NOTE)].reason).toBe('use the Taiwan vocabulary');
    await run(['retranslate', '--targets', 'pt-BR', '--keys', keyOf(LISTS)]);
    expect(marks()['pt-BR'][keyOf(LISTS)].reason).toBe(DEFAULT_REASON);
  });

  it('a keys file names pairs per locale, a locale outside the targets named and left out', async () => {
    const file = path.join(project, 'review.json');
    writeJson(file, { 'pt-BR': [keyOf(NOTE)], 'zh-Hant': [keyOf(LISTS)], fr: [keyOf(NOTE)] });
    const r = await run(['retranslate', '--keys-file', file]);
    expect(r.code).toBe(0);
    expect(r.out).toContain('the keys file names locales outside the targets, left out: fr.');
    expect(Object.fromEntries(Object.entries(marks()).map(([lang, byKey]) => [lang, Object.keys(byKey)]))).toEqual({ 'pt-BR': [keyOf(NOTE)], 'zh-Hant': [keyOf(LISTS)] });
  });

  it('--match on the translation now served, --file on the usages, intersected with each other', async () => {
    const zhHans = machine('zh-Hans');
    zhHans[keyOf(NOTE)].text = '您好 text with a footnote[^note].';
    writeJson(memory('machine', 'zh-Hans.json'), zhHans);
    expect((await run(['retranslate', '--match', '您'])).out).toContain(`marked 1 pair(s) for re-translation (zh-Hans: 1)`);
    expect(Object.keys(marks()['zh-Hans'])).toEqual([keyOf(NOTE)]);

    fs.rmSync(memory('retranslate.json'));
    const units = readJson(memory('source.json')).units;
    const inGuide = Object.keys(units).filter((k) => units[k].usages.some((u) => u.file.startsWith('guide/')));
    await run(['retranslate', '--targets', 'pt-BR', '--file', 'guide/**']);
    expect(Object.keys(marks()['pt-BR']).sort()).toEqual(inGuide.sort());

    fs.rmSync(memory('retranslate.json'));
    const r = await run(['retranslate', '--targets', 'pt-BR', '--file', 'guide/**', '--keys', keyOf(NOTE)]);
    expect(r.out).toContain('no pair matches; nothing was marked.');
  });

  it('skips and names a pair a person translated, and marks it with --include-human', async () => {
    writeJson(memory('messages', 'zh-Hant.json'), { [keyOf(NOTE)]: { text: '人工翻譯 footnote[^note].', status: 'human', srcHash: keyOf(NOTE) } });
    const skipped = await run(['retranslate', '--targets', 'zh-Hant', '--keys', keyOf(NOTE)]);
    expect(skipped.out).toContain('1 pair(s) whose translation a person wrote, left out; --include-human replaces them:');
    expect(skipped.out).toContain(`  zh-Hant ${keyOf(NOTE)}`);
    expect(marks()).toEqual({});
    await run(['retranslate', '--targets', 'zh-Hant', '--keys', keyOf(NOTE), '--include-human']);
    expect(marks()['zh-Hant'][keyOf(NOTE)]).toMatchObject({ human: true });
  });

  it('refuses with no selector, and names a key the catalogue does not hold', async () => {
    expect((await run(['retranslate'])).code).toBe(2);
    expect((await run(['retranslate', '--keys', 'ffffffffffffffff'])).out).toContain('1 key(s) the catalogue does not hold, left out: ffffffffffffffff.');
  });

  it('gate reports the marks and does not fail --check over them', async () => {
    await run(['retranslate', '--targets', 'zh-Hans', '--keys', keyOf(NOTE)]);
    const gate = await run(['gate', '--check']);
    expect(gate.code).toBe(0);
    expect(gate.out).toContain('  retranslate: 1 pair(s) marked for re-translation (zh-Hans: 1); the current translation serves until a new one is accepted.');
  });
});

describe('the CI mode', () => {
  it('refuses to mark, naming the modes that support it', async () => {
    project = copyMarkdownFixture('l10n-retranslate-ci-');
    const r = await run(['retranslate', '--keys', 'x']);
    expect(r.code).toBe(2);
    expect(r.err).toContain('marking is supported in the local and session modes; this project runs in the CI mode');
  });
});

describe('a session re-translates a marked pair from its current translation', () => {
  beforeEach(async () => {
    await translatedProject();
    await run(['retranslate', '--targets', 'zh-Hans', '--keys', keyOf(NOTE), '--reason', REASON]);
  });

  /** Writes a batch's output files, each requested segment answered by `answer`, and its done file. */
  function agent(batch, answer) {
    const task = readJson(work('batches', batch, 'task.json'));
    for (const lang of task.locales) {
      const lines = task.chunks.flatMap((c) => c.segments).filter((s) => s.translate).flatMap((s) => [`@@@ ${s.id}`, answer(s.source, lang)]);
      fs.writeFileSync(task.output[lang], lines.join('\n') + '\n');
    }
    fs.writeFileSync(task.done, 'ok\n');
    return task;
  }
  const exportOne = async () => [...(await run(['session', 'export', '--batches', '50'])).out.matchAll(/^session export: batch (\d{4}):/gm)].map((m) => m[1]);

  it('exports it with the current translation and the reason, keeps serving it, and replaces it on import', async () => {
    const [batch] = await exportOne();
    const task = readJson(work('batches', batch, 'task.json'));
    expect(task.locales).toEqual(['zh-Hans']);
    const segment = task.chunks.flatMap((c) => c.segments).find((s) => s.id === keyOf(NOTE));
    expect(segment.translate).toBe('all');
    // A forced revision revises the current source, which the segment carries: the entry does not repeat it.
    expect(segment.revise).toEqual({ 'zh-Hans': { translation: current(NOTE, 'zh-Hans'), reason: REASON } });
    expect(segment.earlier).toBeUndefined();
    expect(readJson(work('batches', batch, 'plan.json')).revisions['zh-Hans'][keyOf(NOTE)]).toEqual({ from: keyOf(NOTE), reviewed: false, forced: true, reason: REASON });
    expect(fs.readFileSync(task.instructions, 'utf8')).toContain(FORCED_REVISE_SENTENCE);

    // Until the import, the current translation stays and is what generate writes.
    expect((await run(['generate'])).code).toBe(0);
    expect(fs.readFileSync(path.join(project, 'out', 'zh-Hans', 'README.md'), 'utf8')).toContain(current(NOTE, 'zh-Hans'));

    agent(batch, (source) => revised(source));
    expect((await run(['session', 'import'])).code).toBe(0);
    expect(machine('zh-Hans')[keyOf(NOTE)]).toMatchObject({ text: revised(NOTE), revision: { from: keyOf(NOTE), reviewed: false, forced: true, reason: REASON } });
    expect(machine('pt-BR')[keyOf(NOTE)].text).toBe(current(NOTE, 'pt-BR'));
    expect(jobs('session')[0].items).toEqual([expect.objectContaining({ srcHash: keyOf(NOTE), lang: 'zh-Hans', forced: true, reason: REASON })]);
    expect(marks()).toEqual({});
    await run(['generate']);
    expect(fs.readFileSync(path.join(project, 'out', 'zh-Hans', 'README.md'), 'utf8')).toContain(revised(NOTE));
  });

  it('a rejected re-translation keeps the current one, is retried, and is named once left out', async () => {
    const lossy = (source) => source.replace('[^note]', '');
    for (let attempt = 1; attempt <= 3; attempt++) {
      const [batch] = await exportOne();
      agent(batch, lossy);
      await run(['session', 'import']);
      expect(machine('zh-Hans')[keyOf(NOTE)].text).toBe(current(NOTE, 'zh-Hans'));
    }
    expect(await exportOne()).toEqual([]);
    expect(marks()['zh-Hans'][keyOf(NOTE)]).toBeDefined();
    const status = await run(['session', 'status']);
    expect(status.out).toContain('session status: 1 pair(s) marked for re-translation (zh-Hans: 1)');
    expect(status.out).toContain(`  left out after 3 attempts, the current translation still serving: zh-Hans ${keyOf(NOTE)}:`);
    // requeue gives it its attempts again.
    await run(['requeue', '--session']);
    expect(await exportOne()).toHaveLength(1);
  });

  it('a pair marked over a person’s translation starts from it and archives it once the new one is accepted', async () => {
    const humanText = '人工翻譯 footnote[^note].';
    writeJson(memory('messages', 'zh-Hant.json'), { [keyOf(NOTE)]: { text: humanText, status: 'human', srcHash: keyOf(NOTE) } });
    await run(['retranslate', '--targets', 'zh-Hant', '--keys', keyOf(NOTE), '--include-human', '--reason', 'use the Taiwan vocabulary']);
    const [batch] = await exportOne();
    const segment = readJson(work('batches', batch, 'task.json')).chunks.flatMap((c) => c.segments).find((s) => s.id === keyOf(NOTE));
    expect(segment.revise['zh-Hant']).toEqual({ translation: humanText, reviewed: true, reason: 'use the Taiwan vocabulary' });
    agent(batch, (source) => revised(source));
    await run(['session', 'import']);
    expect(readJson(memory('messages', 'zh-Hant.json'))[keyOf(NOTE)]).toBeUndefined();
    expect(readJson(memory('messages', '_archive', 'zh-Hant.json'))[keyOf(NOTE)].text).toBe(humanText);
    expect(machine('zh-Hant')[keyOf(NOTE)].text).toBe(revised(NOTE));
  });

  it('a mark whose source changed is not planned, and the next marking drops it', async () => {
    const page = path.join(project, 'docs', 'README.md');
    fs.writeFileSync(page, fs.readFileSync(page, 'utf8').replace(NOTE, 'Text with a footnote[^note], edited.'));
    await run(['extract']);
    const status = await run(['session', 'status']);
    expect(status.out).toContain('session status: 1 mark(s) no longer planned');
    await run(['retranslate', '--targets', 'pt-BR', '--keys', keyOf(LISTS)]);
    expect(marks()['zh-Hans']).toBeUndefined();
  });
});

describe('Message Batches: submit and collect re-translate a marked pair', () => {
  beforeEach(async () => {
    await translatedProject();
    await run(['retranslate', '--targets', 'pt-BR', '--keys', keyOf(NOTE), '--reason', REASON]);
  });

  it('sends the current translation and the reason, records the forced revision, and replaces it on collect', async () => {
    const fake = fakeAnthropic({
      reply: (params) => replyMessage(requestBody(params).translate.map((id) => ({ id, text: revised(requestBody(params).segments.find((s) => s.id === id).source) }))),
    });
    const submitted = await run(['submit'], { ClientClass: fake.FakeAnthropic });
    expect(submitted.out).toContain('submit: 1 pair(s) marked for re-translation are requested beside what is missing.');
    const [params] = fake.calls.batchCreate[0].requests.map((q) => q.params);
    expect(requestBody(params).translate).toEqual([keyOf(NOTE)]);
    expect(requestBody(params).revise).toEqual({ [keyOf(NOTE)]: { source: NOTE, translation: current(NOTE, 'pt-BR'), reason: REASON } });
    const [record] = readJson(memory('pending.json')).batches;
    expect(Object.values(record.requests)[0].revisions).toEqual({ [keyOf(NOTE)]: { from: keyOf(NOTE), reviewed: false, forced: true, reason: REASON } });
    expect(machine('pt-BR')[keyOf(NOTE)].text).toBe(current(NOTE, 'pt-BR'));

    expect((await run(['collect'], { ClientClass: fake.FakeAnthropic })).code).toBe(0);
    expect(machine('pt-BR')[keyOf(NOTE)]).toMatchObject({ text: revised(NOTE), revision: { forced: true, reason: REASON } });
    expect(jobs('collect')[0].items[0]).toMatchObject({ forced: true, reason: REASON });
    expect(marks()).toEqual({});
  });

  it('a rejected one is queued and keeps the current translation, and status names the mark', async () => {
    const fake = fakeAnthropic({ reply: (params) => replyMessage(requestBody(params).translate.map((id) => ({ id, text: 'dropped the footnote.' }))) });
    await run(['submit'], { ClientClass: fake.FakeAnthropic });
    await run(['collect'], { ClientClass: fake.FakeAnthropic });
    expect(machine('pt-BR')[keyOf(NOTE)].text).toBe(current(NOTE, 'pt-BR'));
    expect(readJson(memory('pending.json')).queue['pt-BR'][keyOf(NOTE)]).toMatchObject({ attempts: 1 });
    expect((await run(['status'])).out).toContain('status: 1 pair(s) marked for re-translation (pt-BR: 1)');
  });

  it('l10n local submits and collects a marked pair when nothing is missing', async () => {
    const fake = fakeAnthropic({ reply: (params) => replyMessage(requestBody(params).translate.map((id) => ({ id, text: revised(NOTE) }))) });
    const r = await run(['local'], { ClientClass: fake.FakeAnthropic, sleep: async () => {} });
    expect(r.code).toBe(0);
    expect(fake.calls.batchCreate).toHaveLength(1);
    expect(machine('pt-BR')[keyOf(NOTE)].text).toBe(revised(NOTE));
  });
});

describe('the synchronous transport re-translates a marked pair', () => {
  it('translate sends the revision and replaces the translation', async () => {
    await translatedProject();
    await run(['retranslate', '--targets', 'zh-Hant', '--keys', keyOf(LISTS), '--reason', REASON]);
    const fake = fakeAnthropic({ reply: (params) => replyMessage(requestBody(params).translate.map((id) => ({ id, text: '清單' }))) });
    const r = await run(['translate', '--targets', 'zh-Hant'], { ClientClass: fake.FakeAnthropic });
    expect(r.code).toBe(0);
    expect(fake.calls.create).toHaveLength(1);
    expect(requestBody(fake.calls.create[0]).revise).toEqual({ [keyOf(LISTS)]: { source: LISTS, translation: current(LISTS, 'zh-Hant'), reason: REASON } });
    expect(machine('zh-Hant')[keyOf(LISTS)]).toMatchObject({ text: '清單', revision: { forced: true, reason: REASON } });
    expect(marks()).toEqual({});
  });

  it('a rejected one keeps the current translation and is named as not re-translated', async () => {
    await translatedProject();
    await run(['retranslate', '--targets', 'zh-Hant', '--keys', keyOf(NOTE)]);
    const fake = fakeAnthropic({ reply: (params) => replyMessage(requestBody(params).translate.map((id) => ({ id, text: '沒有腳註。' }))) });
    const r = await run(['translate', '--targets', 'zh-Hant'], { ClientClass: fake.FakeAnthropic });
    expect(r.code).toBe(1);
    expect(machine('zh-Hant')[keyOf(NOTE)].text).toBe(current(NOTE, 'zh-Hant'));
    const [job] = jobs('dispatch');
    expect(job.failures).toEqual([expect.objectContaining({ srcHash: keyOf(NOTE), lang: 'zh-Hant' })]);
    expect(marks()['zh-Hant'][keyOf(NOTE)]).toBeDefined();
  });
});

describe('--context on a unit’s context', () => {
  it('marks the units whose context starts with the prefix, a person’s translation among them skipped', async () => {
    project = copyFixtureProject('l10n-retranslate-ctx-');
    const configPath = path.join(project, 'l10n.config.json');
    const config = readJson(configPath);
    config.mode = 'local';
    writeJson(configPath, config);
    expect((await run(['extract'])).code).toBe(0);
    const units = readJson(memory('source.json')).units;
    writeJson(memory('machine', 'en.json'), Object.fromEntries(Object.entries(units).map(([k, u]) => [k, { text: `EN ${u.source}`, status: 'machine', srcHash: k }])));
    const r = await run(['retranslate', '--context', 'Hero:', '--dry-run']);
    const hero = Object.keys(units).filter((k) => String(units[k].context).startsWith('Hero:')).sort();
    expect(hero).toHaveLength(2);
    // The fixture's human layer holds the heading, so the label alone is marked and the heading is named.
    expect(r.out).toContain(`  en ${keyOf('Scopri')}: `);
    expect(r.out).toContain('would mark 1 pair(s)');
    expect(r.out).toContain(`1 pair(s) whose translation a person wrote, left out; --include-human replaces them:\n  en ${keyOf('Ciao mondo')}`);
  });
});

describe('the marked work, pure', () => {
  const units = { a: { source: 'A.', format: 'text', usages: [{ file: 'x/one.md' }] }, b: { source: 'B.', format: 'text', usages: [{ file: 'y/two.md' }] } };
  const lookup = { 'zh-Hans': { a: { text: 'A 你', status: 'machine' }, b: { text: 'B 您', status: 'machine' } }, 'pt-BR': { a: { text: 'A tu', status: 'machine' } } };

  it('selectPairs intersects its selectors', () => {
    const { pairs } = selectPairs({ units, lookup, human: {}, targets: ['zh-Hans', 'pt-BR'], match: /你|tu/u, file: 'x/**' });
    expect(pairs.map((p) => `${p.lang} ${p.key}`)).toEqual(['zh-Hans a', 'pt-BR a']);
  });

  it('markedWork makes each mark a revision of itself, and withMarked adds it to the worklist', () => {
    const marked = markedWork({ units, marks: { 'zh-Hans': { a: { reason: 'r', markedAt: 't' } } }, lookup, human: {}, targets: ['zh-Hans'] });
    expect(marked.revisions['zh-Hans'].a).toEqual({ from: 'a', source: 'A.', translation: 'A 你', reviewed: false, forced: true, reason: 'r' });
    expect(withMarked({ status: 'up-to-date' }, marked, ['zh-Hans'])).toEqual({ status: 'work', targets: ['zh-Hans'], items: [{ srcHash: 'a', source: 'A.', format: 'text', missing: ['zh-Hans'] }], orphans: [] });
  });

  it('the general rules say what a reason asks', () => {
    expect(generalRules({ lang: 'zh-Hans', sourceLang: 'en' })).toContain('the source is unchanged: change only what the reason asks for');
  });
});
