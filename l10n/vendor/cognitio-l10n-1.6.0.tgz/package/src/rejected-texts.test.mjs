import '../test/no-network.mjs';
import { describe, it, expect, beforeEach, afterEach } from 'vitest';
import fs from 'node:fs';
import path from 'node:path';

import { runCli } from './cli.mjs';
import { RECORDED_TEXT_LIMIT, recordedText, validateTranslations } from './validate.mjs';
import { literalAutolinks, standaloneProtectedTexts } from './adapters/markdown/segment.mjs';
import { capture, copyMarkdownFixture, echoReply, fakeAnthropic, replyMessage } from '../test/helpers.mjs';

describe('the plain word WWW is not a link', () => {
  // "a web server" is "serwer WWW" in Polish: ending a sentence, "WWW." has no domain after its dot.
  it('is no protected span, at the end of a sentence or anywhere else', () => {
    for (const text of ['podłączyć serwera WWW.', 'serwer WWW. Dalej', 'serwer WWW obsługuje', 'WWW', '„WWW.”', 'the www. prefix']) {
      expect(standaloneProtectedTexts(text), text).toEqual([]);
      expect(literalAutolinks(text), text).toEqual([]);
    }
  });

  it('while a web address after www. still is', () => {
    expect(standaloneProtectedTexts('zob. „www.example.com”')).toEqual(['www.example.com”']);
    expect(standaloneProtectedTexts('see www.example.com.')).toEqual(['www.example.com']);
  });

  it('so a translation writing it is accepted', () => {
    const item = { srcHash: 'w', source: 'If a socket requires a database, the developer cannot plug in a web server.', format: 'markdown', protected: [] };
    const text = 'Jeśli gniazdo wymaga bazy danych, programista nie może podłączyć serwera WWW.';
    expect(validateTranslations({ items: [item], entries: [{ id: 'w', text }] }).accepted).toEqual({ w: text });
  });
});

describe('recordedText', () => {
  it('records a text whole up to the limit, and cuts a longer one, giving its length', () => {
    expect(recordedText('Tekst.')).toEqual({ text: 'Tekst.' });
    const long = 'ą'.repeat(RECORDED_TEXT_LIMIT + 5);
    expect(recordedText(long)).toEqual({ text: 'ą'.repeat(RECORDED_TEXT_LIMIT), textLength: RECORDED_TEXT_LIMIT + 5 });
    expect(recordedText(undefined)).toEqual({});
  });
});

describe('a job log records the text of every rejected translation beside its defect', () => {
  let project;
  beforeEach(() => {
    project = copyMarkdownFixture('l10n-rejected-');
  });
  afterEach(() => {
    fs.rmSync(project, { recursive: true, force: true });
  });
  const memory = (...p) => path.join(project, 'memory', ...p);
  const work = (...p) => memory('session', ...p);
  const readJson = (file) => JSON.parse(fs.readFileSync(file, 'utf8'));
  const jobs = (trigger) => fs.readdirSync(memory('jobs')).map((f) => readJson(memory('jobs', f))).filter((j) => j.trigger === trigger);
  async function run(argv, deps = {}) {
    const io = capture();
    const code = await runCli(argv, { cwd: project, env: { ANTHROPIC_API_KEY: 'test-key' }, log: io.log, errlog: io.errlog, ...deps });
    return { code, out: io.text(), err: io.errors() };
  }
  const LOSSY = (text) => text.replace('[^note]', '');

  it('collect', async () => {
    let lost = null;
    const reply = (params) => {
      const echoed = JSON.parse(echoReply(params).content[0].text).translations;
      return replyMessage(echoed.map((e) => (!lost && e.text.includes('[^note]') ? ((lost = { id: e.id, text: LOSSY(e.text) }), { id: e.id, text: lost.text }) : e)));
    };
    const fake = fakeAnthropic({ reply });
    expect((await run(['extract'])).code).toBe(0);
    await run(['submit', '--targets', 'it'], { ClientClass: fake.FakeAnthropic });
    await run(['collect'], { ClientClass: fake.FakeAnthropic });
    const [job] = jobs('collect');
    expect(job.failures).toEqual([expect.objectContaining({ srcHash: lost.id, lang: 'it', text: lost.text })]);
    // The queue stays as it was: the text lives in the job log alone.
    expect(Object.keys(readJson(memory('pending.json')).queue.it[lost.id])).toEqual(['attempts', 'defect']);
  });

  it('session import', async () => {
    const [batch] = [...(await run(['session', 'export', '--batches', '50'])).out.matchAll(/^session export: batch (\d{4}):/gm)].map((m) => m[1]);
    const task = readJson(work('batches', batch, 'task.json'));
    let lost = null;
    for (const lang of task.locales) {
      const lines = [];
      for (const s of task.chunks.flatMap((c) => c.segments).filter((s) => s.translate)) {
        const text = !lost && lang === 'it' && s.source.includes('[^note]') ? ((lost = { id: s.id, text: LOSSY(`${s.source} ⟨it⟩`) }), lost.text) : `${s.source} ⟨${lang}⟩`;
        lines.push(`@@@ ${s.id}`, text);
      }
      fs.writeFileSync(task.output[lang], lines.join('\n') + '\n');
    }
    fs.writeFileSync(task.done, 'ok\n');
    await run(['session', 'import']);
    const [job] = jobs('session');
    expect(job.failures).toEqual([expect.objectContaining({ srcHash: lost.id, lang: 'it', text: lost.text })]);
  });
});
