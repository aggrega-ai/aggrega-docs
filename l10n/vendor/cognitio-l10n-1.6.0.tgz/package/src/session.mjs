/**
 * session.mjs — Translating in a session: the translations are written by the
 * agents of an AI coding session, while the package plans the work, states the
 * rules and checks every translation before it reaches the memory.
 *
 *   l10n session export [--work <dir>] [--words <n>] [--output-words <n>] [--batches <n>] [--resume]
 *   l10n session check <batch> [--work <dir>]
 *   l10n session import [--work <dir>] [--batch <ids>] [--model <name>]
 *   l10n session status [--work <dir>]
 *
 * It is a third transport beside the Messages API and the Message Batches API,
 * for a project that translates with no API key and no command-line model: the
 * session that runs these commands starts one agent per batch, each agent reads
 * the instructions and its batch and writes its translations to files, and
 * `import` applies them as `collect` applies a batch.
 *
 * READS the configuration's adapter pages, the catalogue (which `export` extracts
 * first), both memory layers, the recorded sources, the glossary, the prompt files
 * (`export`) and the work directory. WRITES the work directory, and, in `import`
 * alone and through the store, the machine layer, its sources, the source map and
 * one job log per batch. It never writes the human layer, makes no network call
 * and starts no process: the agents are the session's.
 *
 * THE WORK DIRECTORY, `<memory.dir>/session/` unless `--work` names another,
 * belongs to the session and is never committed:
 *   INSTRUCTIONS.<locales>.md    what an agent reads first: the formats below, the
 *                                package's rules, the glossary, the project's general
 *                                prompt and the terminology and language guide of each
 *                                locale its batches are written in, one file per distinct
 *                                set of locales (`instructionsName`); `export` rewrites
 *                                one when its text changes. A batch's task names its file.
 *   INSTRUCTIONS.md              the instructions of every configured locale, as a
 *                                version before the per-locale files wrote them; still
 *                                read by the batches exported then, and never rewritten.
 *   queue.json                   the session's resubmission queue, in the pending
 *                                file's shape (`pending.mjs`): per locale, per segment,
 *                                the attempts made and the defect the next batch states.
 *   halt.json                    the halt a rejection alarm recorded under
 *                                `backend.alarm.stopSubmissions`; while it exists `export`
 *                                writes no batch, and `export --resume` removes it.
 *   batches/<NNNN>/task.json     the batch, as an agent reads it.
 *   batches/<NNNN>/plan.json     what `import` checks the batch against: each requested
 *                                unit as the catalogue held it, its attempt and revision.
 *   batches/<NNNN>/<locale>.txt  one output file per locale, written by the agent.
 *   batches/<NNNN>/done          written by the agent last, once every output file is.
 *   batches/<NNNN>/result.json   written by `import`: the batch is applied.
 *
 * A BATCH is whole pages, or runs of sections of a long page, in the adapter's
 * page order, up to `--words` source words to translate and, when it is given,
 * `--output-words` words to write — each requested segment's source words once
 * per locale it is requested in — with every locale of a segment in the same
 * batch: the agent reads the source once and writes it in each language. The
 * pages are cut into sections exactly as for a request
 * (`planRequests`, `backend.sectionTokens`), each section given the sections on
 * either side of it as context, and the sections of one page in one batch are
 * joined, each segment listed once. A segment in a batch not yet imported is
 * never planned again, so batches can be translated side by side; nor is one a
 * recorded Message Batch holds (`batchHeldPairs`), so a session and `submit` can
 * run side by side, and `export` says how many pairs each held back. A pair
 * marked for re-translation (`retranslate.mjs`) is planned beside the missing
 * ones, as a revision of itself, and its accepted translation clears its mark.
 *
 * THE OUTPUT FORMAT is plain text, so an agent escapes nothing: each segment is a
 * line `@@@ <id>` and its translation on the lines up to the next. The format
 * cannot carry a translation's leading or trailing whitespace, so `import` gives
 * each translation its source's (rule 4).
 *
 * IMPORT applies a batch whose `done` file exists, or one `--batch` names: every
 * locale's output file is validated with the one validation (`validate.mjs`), the
 * accepted translations are written to the machine layer (`machineEntry`), each
 * rejected one is queued with its defect, which the next batch states for it, up
 * to `backend.attempts` attempts, and a locale whose output file is absent
 * returns to the pool unqueued, since no translation of it was judged; so does a
 * segment the validation could not judge, a failure of the package rather than of
 * the translation, named in the output and the job log's `internal`. A batch
 * is applied once: its `result.json` marks it. Each batch's rejections are
 * judged against the session's recent batches (`alarm.mjs`), as `collect`
 * judges a Message Batch's.
 *
 * CHECK reads a batch's output files with the same parse and the same
 * validation as `import`, and writes nothing: what is missing, what was not
 * asked for, the lines the format cannot read as meant, and what the import
 * would reject and why — so a session can have an agent fix its files first.
 */

import { createHash } from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';

import { planRequests } from './requests.mjs';
import { findRevisions } from './revisions.mjs';
import { recordedText, returnedTexts, validateTranslations } from './validate.mjs';
import { batchHeldPairs, clearQueued, queueDefect } from './pending.mjs';
import { withoutHeld } from './gate.mjs';
import { markedFromStore, markLines, recordedRevision, settleAccepted, withMarked, withMarkedRevisions } from './retranslate.mjs';
import { machineEntry } from './engine.mjs';
import {
  doNotTranslateOf,
  FORCED_REVISE_SENTENCE,
  glossaryTerms,
  languageName,
  PATH_SENTENCE,
  REFERENCES_SENTENCE,
  REVISE_SENTENCE,
  terminologyRules,
  translationRules,
} from './translator-prompt.mjs';
import { alarmLines, alarmReason, judgeBatch } from './alarm.mjs';
import { progressFromStore, progressLines, staleFromStore, staleLines, wordsOf } from './progress.mjs';
import { TRANSLATION_DEFAULTS } from './config.mjs';
import { LAYER, RESULT, STATUS } from './types.mjs';

/** The default size of a batch: the source words it asks to translate. */
export const DEFAULT_BATCH_WORDS = 3000;

/** The line opening a segment in an output file. */
const HEADER_RE = /^@@@ (\S+)[ \t]*$/;

/** A line an agent meant as a segment's opening line, whether or not it is well formed. */
const HEADER_LIKE_RE = /^\s*@@@/;

const readJson = (file, fallback) => (fs.existsSync(file) ? JSON.parse(fs.readFileSync(file, 'utf8')) : fallback);

/** Writes a file whole: a temporary file, then a rename, so a reader never meets a half-written one. */
function writeWhole(file, text) {
  fs.mkdirSync(path.dirname(file), { recursive: true });
  const tmp = `${file}.tmp-${process.pid}-${Math.random().toString(36).slice(2)}`;
  fs.writeFileSync(tmp, text, 'utf8');
  fs.renameSync(tmp, file);
}
const writeJson = (file, value) => writeWhole(file, JSON.stringify(value, null, 2) + '\n');

/**
 * The work directory's layout.
 *
 * @param {string} root  the work directory, absolute.
 */
export function sessionPaths(root) {
  return {
    root,
    // The one instructions file versions before 1.3.1 wrote, kept for their batches; `instructionsName` names the rest.
    instructions: path.join(root, 'INSTRUCTIONS.md'),
    queue: path.join(root, 'queue.json'),
    halt: path.join(root, 'halt.json'),
    batches: path.join(root, 'batches'),
    batch: (id) => path.join(root, 'batches', id),
  };
}

/** The session's resubmission queue (`queue.json`), in the pending file's shape; empty when there is none. */
export function readSessionQueue(work) {
  return readJson(sessionPaths(work).queue, {});
}

/** Writes the session's resubmission queue whole. */
export function writeSessionQueue(work, queue) {
  writeJson(sessionPaths(work).queue, queue);
}

/** Every batch, in order, with its state: imported, done (waiting for import), or open. */
function listBatches(paths) {
  if (!fs.existsSync(paths.batches)) return [];
  return fs
    .readdirSync(paths.batches)
    .filter((name) => /^\d{4,}$/.test(name))
    .sort()
    .map((id) => {
      const dir = paths.batch(id);
      return { id, dir, imported: fs.existsSync(path.join(dir, 'result.json')), done: fs.existsSync(path.join(dir, 'done')) };
    });
}

/** Per locale, the segments some batch not yet imported asks for. */
function openPairs(paths) {
  const open = new Map();
  for (const batch of listBatches(paths)) {
    if (batch.imported) continue;
    const plan = readJson(path.join(batch.dir, 'plan.json'), { requested: {} });
    for (const [lang, ids] of Object.entries(plan.requested || {})) {
      if (!open.has(lang)) open.set(lang, new Set());
      for (const id of ids) open.get(lang).add(id);
    }
  }
  return open;
}

/**
 * The (segment, locale) pairs a session holds: those its batches not yet imported
 * ask for, which no other transport plans meanwhile. A work directory that does
 * not exist holds none.
 *
 * @param {string} work  the work directory, absolute.
 * @returns {Map<string, Set<string>>}  locale → the segments held in it.
 */
export function sessionHeldPairs(work) {
  return openPairs(sessionPaths(work));
}

/** The longest name `instructionsName` spells out; a longer locale set is named by a digest. */
const MAX_INSTRUCTIONS_NAME = 100;

/**
 * The file name of the instructions for a set of locales: `INSTRUCTIONS.<a>+<b>.md`,
 * or `INSTRUCTIONS.<digest>.md` when the locales spelled out would make it longer
 * than `MAX_INSTRUCTIONS_NAME`.
 *
 * @param {string[]} locales  in the order the batch lists them.
 */
export function instructionsName(locales) {
  const spelled = `INSTRUCTIONS.${locales.join('+')}.md`;
  if (spelled.length <= MAX_INSTRUCTIONS_NAME) return spelled;
  return `INSTRUCTIONS.${createHash('sha256').update(locales.join('+')).digest('hex').slice(0, 12)}.md`;
}

/**
 * The instructions an agent reads before its batch: the batch and output
 * formats, then the package's rules (`translationRules`), the glossary
 * (`glossaryTerms`, and `terminologyRules` per locale), the project's general
 * prompt and the language guide of each locale, each as the package or the
 * project writes it. `export` writes one per set of locales its batches are
 * written in, so an agent reads only the guides of the locales it writes.
 *
 * @param {Object} args
 * @param {string} args.sourceLang
 * @param {string[]} args.targets          the locales of the batches that read them.
 * @param {Object} [args.glossary]
 * @param {string|null} [args.generalPrompt]
 * @param {Object.<string,string>} args.prompts  locale → its language guide.
 * @param {'text'|'text+path'} [args.identity]  the adapter's identity: `text+path` describes a segment's `path` and
 *        `references`; `text` (the default) does not mention them.
 * @returns {string}
 */
export function sessionInstructions({ sourceLang, targets, glossary = {}, generalPrompt = null, prompts, identity = 'text' }) {
  const names = (glossary && glossary.target_lang_names) || {};
  const source = languageName(sourceLang, names);
  const byPath = identity === 'text+path';
  return [
    `# Translating a batch from ${source}`,
    '',
    `You translate segments of a site or a documentation corpus from ${source} into several languages at once. A batch is one file, \`task.json\`: read it once, then write one output file per locale.`,
    '',
    '## The batch',
    '',
    '`task.json` holds:',
    '',
    '- `instructions`: the file of these instructions.',
    '- `locales`: the target locales of the batch.',
    '- `output`: for each locale, the absolute path of the file you write its translations to.',
    '- `done`: the absolute path of the file you write last, holding `ok`, once every output file is written.',
    '- `chunks`: the parts of pages to translate, in reading order. A chunk is a whole page, or a run of sections of a long page, given with the sections around it as context:',
    '  - `page`: the page. `outline`, for a long page: every section of the page in order, with its headings, so you see where the chunk sits.',
    `  - \`segments\`: the source segments in reading order, each \`{ "id", "format", "context"?, ${byPath ? '"path"?, ' : ''}"source", "translate"?, "keep"?, "earlier"?, "revise"?, ${byPath ? '"references"?, ' : ''}"corrections"? }\`. A long segment is written over several lines.`,
    '    - A segment without `translate` is context: read it, and never translate it or write it to an output file. The import discards every identifier the batch does not ask for, so writing one is wasted work.',
    '    - `translate` is `"all"`, every locale of the batch, or the list of the locales to translate the segment into.',
    '    - `format` is `markdown`, `html` or `text`, and rule 3 below says what each keeps.',
    '    - `context` is advisory: it says what the segment is or where it sits. Never translate it.',
    ...(byPath ? [`    - \`path\`: ${PATH_SENTENCE}`] : []),
    '    - `keep`: the strings rule 3 keeps byte for byte in this segment.',
    '    - `earlier`: an earlier version of the segment\'s source, given once for every locale that revises it.',
    `    - \`revise\`: for a locale, \`{ "translation", "source"?, "reviewed"?, "reason"? }\`: the translation of \`earlier\` — or of the entry's own \`source\`, an earlier version of its own — or, with a \`reason\`, the segment's current translation. ${REVISE_SENTENCE} ${FORCED_REVISE_SENTENCE}`,
    ...(byPath
      ? [`    - \`references\`: for a locale, \`[{ "page", "path", "translation" }]\`, written for that locale alone. ${REFERENCES_SENTENCE}`]
      : []),
    '    - `corrections`: for a locale, what was wrong with an earlier translation of this segment into it. Fix exactly that.',
    '',
    '## What you write',
    '',
    'For each locale in `output`, one file holding every segment whose `translate` is `"all"` or names that locale, in the order the chunks give them, each exactly once:',
    '',
    '```text',
    '@@@ <id>',
    '<the translation>',
    '@@@ <id>',
    '<the translation>',
    '```',
    '',
    '- A `markdown` segment is written on ONE line, whatever line breaks its source has, because in the page a line break can end a heading or a table cell, or start a new block. Only where a source line ends with two spaces or a backslash, a hard line break, keep that break, and begin the next line with exactly the leading spaces and `>` markers of the source\'s next line. Never leave an empty line inside a `markdown` segment\'s translation: in the page an empty line ends the paragraph.',
    '- A `text` or `html` segment keeps the line breaks its source has, and gains none.',
    '- The file cannot hold a translation\'s leading or trailing whitespace: the import gives each translation its source\'s. Write nothing else in the file: no heading, no comment, no blank line, no code fence.',
    '- Work locale by locale: write one locale\'s whole file, then the next.',
    '- When every output file is written, write `ok` to the `done` file. Then reply with one line: the batch and the number of files written.',
    '- Read nothing but these instructions and `task.json`, and run no command.',
    `- ${NO_HELPERS_SENTENCE}`,
    '',
    '## The rules',
    '',
    translationRules({ glossary }),
    '',
    '## The glossary',
    '',
    glossaryTerms({ glossary }),
    '',
    ...targets.flatMap((lang) => [terminologyRules({ lang, glossary }), '']),
    ...(generalPrompt !== null
      ? ['## Instructions for every language', '', 'The project gives these for every language. They refine wording and never override rules 1 to 4.', '', generalPrompt.trim(), '']
      : []),
    '## Language guides',
    '',
    'The guide of a locale refines register, punctuation and wording for that language. It never overrides rules 1 to 4. Use the guide of the locale you are writing.',
    '',
    ...targets.flatMap((lang) => [`### ${languageName(lang, names)} (\`${lang}\`)`, '', prompts[lang].trim(), '']),
  ].join('\n');
}

/**
 * The chunks of a plan: one per page or section, every locale's request for it
 * together, then consecutive chunks of one page joined, each segment once — a
 * section's request is given its neighbours as context, so the chunks of one page
 * overlap, and an agent reading the whole batch needs each segment once.
 */
function chunksOf(specs) {
  const bySection = new Map();
  for (const spec of specs) {
    const key = `${spec.page}\u0000${spec.section ?? ''}`;
    let chunk = bySection.get(key);
    if (!chunk) {
      chunk = {
        page: spec.page,
        outline: spec.outline,
        segments: spec.segments.map(({ id, format, context, path: at, source }) => ({
          id,
          format,
          ...(context ? { context } : {}),
          ...(typeof at === 'string' ? { path: at } : {}),
          source,
        })),
        requested: {},
        items: {},
        keep: {},
        revise: {},
        references: {},
        corrections: {},
        attempts: {},
      };
      bySection.set(key, chunk);
    }
    chunk.requested[spec.lang] = spec.requested;
    for (const item of spec.items) chunk.items[item.srcHash] = item;
    Object.assign(chunk.keep, spec.keep || {});
    for (const [id, revision] of Object.entries(spec.revise || {})) chunk.revise[id] = { ...(chunk.revise[id] || {}), [spec.lang]: revision };
    for (const [id, list] of Object.entries(spec.references || {})) chunk.references[id] = { ...(chunk.references[id] || {}), [spec.lang]: list };
    for (const [id, defect] of Object.entries(spec.corrections || {})) chunk.corrections[id] = { ...(chunk.corrections[id] || {}), [spec.lang]: defect };
    chunk.attempts[spec.lang] = spec.attempt;
  }
  return [...bySection.values()];
}

/** Consecutive chunks of one page joined into one, in page order, each segment kept once. */
function joinByPage(chunks) {
  const joined = [];
  for (const chunk of chunks) {
    let last = joined[joined.length - 1];
    if (!last || last.page !== chunk.page) {
      last = { page: chunk.page, outline: chunk.outline, segments: [], seen: new Set(), requested: {}, items: {}, keep: {}, revise: {}, references: {}, corrections: {}, attempts: {} };
      joined.push(last);
    }
    for (const segment of chunk.segments) {
      if (last.seen.has(segment.id)) continue;
      last.seen.add(segment.id);
      last.segments.push(segment);
    }
    for (const [lang, ids] of Object.entries(chunk.requested)) {
      last.requested[lang] = [...(last.requested[lang] || []), ...ids];
      last.attempts[lang] = { ...(last.attempts[lang] || {}), ...Object.fromEntries(ids.map((id) => [id, chunk.attempts[lang]])) };
    }
    Object.assign(last.items, chunk.items);
    Object.assign(last.keep, chunk.keep);
    for (const [id, byLang] of Object.entries(chunk.revise)) last.revise[id] = { ...(last.revise[id] || {}), ...byLang };
    for (const [id, byLang] of Object.entries(chunk.references)) last.references[id] = { ...(last.references[id] || {}), ...byLang };
    for (const [id, byLang] of Object.entries(chunk.corrections)) last.corrections[id] = { ...(last.corrections[id] || {}), ...byLang };
  }
  return joined;
}

/**
 * A segment's revisions as a task carries them: the earlier version of its source
 * once, as `earlier`, and per locale the translation to revise, with `reviewed`
 * and `reason` as they apply. Every locale's revision of one changed segment
 * usually starts from the same earlier source, which the task would otherwise
 * repeat once per locale; an entry keeps its own `source` only when it revises
 * another earlier version than `earlier`. An entry with a `reason` revises the
 * current source, which the segment carries already.
 *
 * @param {string} source  the segment's current source.
 * @param {Object.<string, import('./types.mjs').Revision>} byLang  locale → its revision.
 * @returns {{earlier?:string, revise:Object.<string, {translation:string, source?:string, reviewed?:true, reason?:string}>}}
 */
export function taskRevisions(source, byLang) {
  let earlier = null;
  const revise = {};
  for (const [lang, r] of Object.entries(byLang)) {
    const entry = { translation: r.translation, ...(r.reviewed ? { reviewed: true } : {}), ...(r.forced ? { reason: r.reason } : {}) };
    if (!r.forced && r.source !== source) {
      if (earlier === null) earlier = r.source;
      if (r.source !== earlier) entry.source = r.source;
    }
    revise[lang] = entry;
  }
  return { ...(earlier !== null ? { earlier } : {}), revise };
}

/**
 * The bytes of a segment's one-line form above which a task writes it over
 * several lines, one field and one revision per line, so no line of a task holds
 * more than one text and an agent reading the file in parts never meets a line
 * too long to read.
 */
export const LONG_SEGMENT_BYTES = 4096;

/** A segment as a task's text writes it: one line, or one field per line when it is long. */
function segmentText(segment) {
  const line = JSON.stringify(segment);
  if (Buffer.byteLength(line, 'utf8') <= LONG_SEGMENT_BYTES) return `      ${line}`;
  return JSON.stringify(segment, null, 2)
    .split('\n')
    .map((l) => `      ${l}`)
    .join('\n');
}

/** A task's text: one segment per line, a long one over several, so it reads compactly and is still one JSON document. */
function taskText(task) {
  const { chunks, ...head } = task;
  const headText = JSON.stringify(head, null, 2).slice(0, -2);
  const chunkTexts = chunks.map((chunk) => {
    const { segments, ...meta } = chunk;
    const metaText = Object.entries(meta).map(([k, v]) => `${JSON.stringify(k)}: ${JSON.stringify(v)}, `).join('');
    return `    { ${metaText}"segments": [\n${segments.map(segmentText).join(',\n')}\n    ] }`;
  });
  return `${headText},\n  "chunks": [\n${chunkTexts.join(',\n')}\n  ]\n}\n`;
}

/**
 * What keeps a batch to the one agent the session started for it: a session that
 * runs one agent at a time does so to stay within its limits, and an agent that
 * starts others to share the work breaks that.
 */
export const NO_HELPERS_SENTENCE = 'Do all the work yourself: do not start other agents or subagents.';

/** What tells an agent its output is read by a program, which takes every header and identifier as written. */
export const CHECKED_SENTENCE = 'A command checks every output file afterwards, so write each `@@@ <id>` line exactly, once per segment asked for.';

/** The prompt that starts an agent on a batch. */
export function agentPrompt({ instructions, task }) {
  return `Translate the batch in ${task}. First read ${instructions} and follow it exactly; then read ${task}, write every output file it names, and last its done file. Only read and write files, and run no command. ${NO_HELPERS_SENTENCE} ${CHECKED_SENTENCE} Reply with one line.`;
}

/** The halt a rejection alarm recorded in the work directory, or null when there is none. */
export function readSessionHalt(work) {
  return readJson(sessionPaths(work).halt, null);
}

/**
 * Writes the next batches of the missing segments.
 *
 * @param {Object} args
 * @param {ReturnType<import('./engine.mjs').createEngine>} args.engine
 * @param {Object} args.adapter
 * @param {string} args.sourceLang
 * @param {string[]} [args.allTargets] every target locale of the configuration; unused, kept for callers that pass it.
 * @param {string[]} args.targets      the locales to plan.
 * @param {import('./config.mjs').TranslationSettings} args.settings  `sectionTokens` and `attempts`.
 * @param {Object} [args.glossary]
 * @param {Object.<string,string>} args.prompts  locale → its language guide, for every locale of `targets`.
 * @param {string|null} [args.generalPrompt]
 * @param {string} args.work           the work directory, absolute.
 * @param {number|null} [args.words]   the source words a batch asks to translate, at most, beyond a single chunk;
 *        null for no such bound.
 * @param {number|null} [args.outputWords]  the words a batch asks to write, at most, beyond a single chunk: each requested
 *        segment's source words once per locale it is requested in; null for no such bound.
 * @param {number} [args.batches]      how many batches to write.
 * @param {boolean} [args.resume]      clears the halt a rejection alarm recorded, after a person acted on it.
 * @param {() => string} [args.now]
 * @param {(...a:any[])=>void} [args.log]
 * @param {(...a:any[])=>void} [args.errlog]
 * @returns {Promise<{code:number, written:string[], action?:string}>}
 */
export async function sessionExport({
  engine,
  adapter,
  sourceLang,
  targets,
  settings,
  glossary = {},
  prompts,
  generalPrompt = null,
  work,
  words = DEFAULT_BATCH_WORDS,
  outputWords = null,
  batches = 1,
  resume = false,
  now = () => new Date().toISOString(),
  log = (...a) => console.log(...a),
  errlog = (...a) => console.error(...a),
}) {
  const paths = sessionPaths(work);
  const halt = readSessionHalt(work);
  if (halt && !resume) {
    errlog(
      `session export: ${sessionHaltText(halt)}. Find the cause in the defects \`session import\` named, which the batch's job log ` +
        'records — the instructions, the glossary, the agents — then run `l10n session export --resume`. No batch written.'
    );
    return { code: 1, written: [], action: 'halted' };
  }
  if (halt) {
    fs.rmSync(paths.halt, { force: true });
    log(`session export: --resume: the halt is cleared (${sessionHaltText(halt)}).`);
  }

  const { unitCount } = await engine.extract();
  const store = engine.store;
  // What is missing, and the pairs marked for re-translation beside it, each planned as a revision of itself.
  const marked = markedFromStore(store, targets);
  const worklist = withMarked(engine.gate({ targets }), marked, targets);
  if (worklist.status !== 'work') {
    log(`session export: ${unitCount} source units; nothing to translate into ${targets.join(', ')}.`);
    return { code: 0, written: [] };
  }
  if (marked.count > 0) log(`session export: ${marked.count} pair(s) marked for re-translation are planned beside what is missing.`);
  // A pair a batch of this session not yet imported holds, or a recorded Message Batch, is planned by neither again.
  const inSession = withoutHeld(worklist, openPairs(paths));
  const inBatches = withoutHeld(inSession.worklist, batchHeldPairs(store.readPending()));
  if (inSession.skipped > 0) {
    log(`session export: ${inSession.skipped} segment-locale pair(s) are in batches of this session not yet imported and are not planned again.`);
  }
  if (inBatches.skipped > 0) {
    log(`session export: ${inBatches.skipped} segment-locale pair(s) are held by a recorded Message Batch (${store.paths.pending}) and are left to \`l10n collect\`.`);
  }
  const items = inBatches.worklist.items;
  if (items.length === 0) {
    log(
      inSession.skipped > 0 && inBatches.skipped === 0
        ? 'session export: every missing segment is in a batch not yet imported.'
        : 'session export: every missing segment is in a batch not yet imported or a recorded Message Batch.'
    );
    return { code: 0, written: [] };
  }

  const tmByLang = store.readAllTM(targets);
  const queue = readSessionQueue(work);
  const pending = { ...worklist, items };
  const plan = planRequests({
    pages: await adapter.pages(),
    worklist: pending,
    tmByLang,
    targets,
    sectionTokens: settings.sectionTokens,
    attemptLimit: settings.attempts,
    queue,
    // A marked pair is a revision of itself, kept out of the search for changed segments' earlier versions.
    revisions: withMarkedRevisions(
      findRevisions({ worklist: withoutHeld(pending, marked.pairs).worklist, tmByLang, sources: store.readRecordedSources(), targets }),
      marked
    ),
  });

  // Batches of whole chunks in page order, each within `words` words to translate and `outputWords` words to write,
  // the bounds given, unless one chunk alone is more.
  const chunkWords = (chunk) => Object.values(chunk.items).reduce((n, item) => n + wordsOf(item.source), 0);
  const chunkOutput = (chunk) =>
    Object.values(chunk.requested).reduce((n, ids) => n + ids.reduce((m, id) => m + (chunk.items[id] ? wordsOf(chunk.items[id].source) : 0), 0), 0);
  const groups = [];
  let current = null;
  for (const chunk of chunksOf(plan.specs)) {
    const w = chunkWords(chunk);
    const o = chunkOutput(chunk);
    if (current && ((words !== null && current.words + w > words) || (outputWords !== null && current.output + o > outputWords))) {
      groups.push(current);
      current = null;
      if (groups.length === batches) break;
    }
    if (!current) current = { chunks: [], words: 0, output: 0 };
    current.chunks.push(chunk);
    current.words += w;
    current.output += o;
  }
  if (current && groups.length < batches) groups.push(current);

  const existing = listBatches(paths).map((b) => Number(b.id));
  let next = existing.length ? Math.max(...existing) + 1 : 1;
  const written = [];
  for (const group of groups) {
    const id = String(next++).padStart(4, '0');
    const dir = paths.batch(id);
    const chunks = joinByPage(group.chunks);
    const requested = {};
    const attempts = {};
    const revisions = {};
    const planItems = {};
    for (const chunk of chunks) {
      for (const [lang, ids] of Object.entries(chunk.requested)) {
        requested[lang] = [...(requested[lang] || []), ...ids];
        attempts[lang] = { ...(attempts[lang] || {}), ...chunk.attempts[lang] };
      }
      for (const [itemId, byLang] of Object.entries(chunk.revise)) {
        for (const [lang, r] of Object.entries(byLang)) revisions[lang] = { ...(revisions[lang] || {}), [itemId]: recordedRevision(r) };
      }
      for (const [itemId, item] of Object.entries(chunk.items)) {
        planItems[itemId] = {
          source: item.source,
          format: item.format,
          ...(item.context !== undefined ? { context: item.context } : {}),
          ...(item.protected !== undefined ? { protected: item.protected } : {}),
        };
      }
    }
    const locales = targets.filter((lang) => requested[lang] && requested[lang].length > 0);
    // The instructions of exactly the batch's locales, one file per set, rewritten only when their text changes.
    const instructionsFile = path.join(paths.root, instructionsName(locales));
    const instructions = sessionInstructions({
      sourceLang,
      targets: locales,
      glossary,
      generalPrompt,
      prompts,
      ...(adapter && adapter.identity && adapter.identity !== 'text' ? { identity: adapter.identity } : {}),
    });
    if (!fs.existsSync(instructionsFile) || fs.readFileSync(instructionsFile, 'utf8') !== instructions) writeWhole(instructionsFile, instructions);
    const task = {
      batch: id,
      instructions: instructionsFile,
      locales,
      output: Object.fromEntries(locales.map((lang) => [lang, path.join(dir, `${lang}.txt`)])),
      done: path.join(dir, 'done'),
      chunks: chunks.map((chunk) => ({
        page: chunk.page,
        ...(chunk.outline ? { outline: chunk.outline } : {}),
        segments: chunk.segments.map((segment) => {
          const langs = locales.filter((lang) => (chunk.requested[lang] || []).includes(segment.id));
          if (langs.length === 0) return segment;
          return {
            ...segment,
            translate: langs.length === locales.length ? 'all' : langs,
            ...(chunk.keep[segment.id] ? { keep: chunk.keep[segment.id] } : {}),
            ...(chunk.revise[segment.id] ? taskRevisions(segment.source, chunk.revise[segment.id]) : {}),
            ...(chunk.references[segment.id] ? { references: chunk.references[segment.id] } : {}),
            ...(chunk.corrections[segment.id] ? { corrections: chunk.corrections[segment.id] } : {}),
          };
        }),
      })),
    };
    writeJson(path.join(dir, 'plan.json'), { batch: id, createdAt: now(), words: group.words, outputWords: group.output, requested, attempts, revisions, items: planItems });
    writeWhole(path.join(dir, 'task.json'), taskText(task));
    written.push(id);
    const pageCount = new Set(chunks.map((c) => c.page)).size;
    log(
      `session export: batch ${id}: ${group.words} words on ${pageCount} page${pageCount === 1 ? '' : 's'}, into ${locales.join(', ')}` +
        `${locales.length > 1 ? `: ${group.output} words to write` : ''}.`
    );
    log(`  agent prompt: ${agentPrompt({ instructions: instructionsFile, task: path.join(dir, 'task.json') })}`);
  }
  for (const [lang, ids] of Object.entries(plan.exhausted)) {
    if (ids.length) log(`session export: ${lang}: ${ids.length} segment(s) rejected ${settings.attempts} times are left out; \`l10n session status\` lists them.`);
  }
  return { code: 0, written };
}

/**
 * The entries of an output file: each `@@@ <id>` line and the lines up to the
 * next, its text without the lines' trailing line break.
 *
 * @param {string} text
 * @returns {Array<{id:string, text:string}>}
 */
export function parseSessionOutput(text) {
  const entries = [];
  let current = null;
  for (const line of String(text).replace(/\r\n/g, '\n').split('\n')) {
    const header = HEADER_RE.exec(line);
    if (header) {
      current = { id: header[1], lines: [] };
      entries.push(current);
    } else if (current) current.lines.push(line);
  }
  return entries.map((e) => ({ id: e.id, text: e.lines.join('\n').replace(/^\n+|\n+$/g, '') }));
}

/** A translation given its source's leading and trailing whitespace, which the output format cannot carry. */
function withSourceEdges(source, text) {
  return source.match(/^\s*/)[0] + text.trim() + source.match(/\s*$/)[0];
}

/**
 * One locale's output file of a batch, judged by the one validation: the units
 * the plan requests in it, the entries the file holds, each given its source's
 * edges, and the verdict. `import` applies it and `check` reports it, so the two
 * never judge a file differently.
 *
 * @param {Object} args
 * @param {Object} args.plan     the batch's `plan.json`.
 * @param {string[]} args.ids    the segments the plan requests in the locale.
 * @param {string} args.text     the output file's text.
 * @param {Array} args.doNotTranslate
 * @param {boolean} args.caseSensitive
 */
function judgeOutput({ plan, ids, text, doNotTranslate, caseSensitive }) {
  const units = ids.map((id) => ({ srcHash: id, ...plan.items[id] }));
  const replies = parseSessionOutput(text).map((e) => (plan.items[e.id] ? { id: e.id, text: withSourceEdges(plan.items[e.id].source, e.text) } : e));
  return { units, replies, validation: validateTranslations({ items: units, entries: replies, doNotTranslate, caseSensitive }) };
}

/** The halt a session's rejection alarm recorded, as a line states it. */
const sessionHaltText = (halt) =>
  `the session is halted since ${halt.at}: batch ${halt.batch} had its translations rejected far more often than the recent batches (${halt.reason})`;

/**
 * Applies the finished batches.
 *
 * @param {Object} args
 * @param {ReturnType<import('./store.mjs').createStore>} args.store
 * @param {Object} [args.glossary]
 * @param {number} args.attemptLimit    `backend.attempts`: a segment rejected this many times is left out.
 * @param {string} args.work            the work directory, absolute.
 * @param {string[]|null} [args.batchIds]  the batches to apply whether or not their `done` file exists.
 * @param {string|null} [args.model]   the model the agents ran on, recorded in the job log.
 * @param {import('./config.mjs').TranslationSettings['alarm']} [args.alarm]  the rejection alarm's settings.
 * @param {() => string} [args.now]
 * @param {(...a:any[])=>void} [args.log]
 * @param {(...a:any[])=>void} [args.errlog]
 * @returns {{code:number, imported:string[], applied:number}}
 */
export function sessionImport({
  store,
  glossary = {},
  attemptLimit,
  work,
  batchIds = null,
  model = null,
  alarm = TRANSLATION_DEFAULTS.alarm,
  now = () => new Date().toISOString(),
  log = (...a) => console.log(...a),
  errlog = (...a) => console.error(...a),
}) {
  const paths = sessionPaths(work);
  const { entries: doNotTranslate, caseSensitive } = doNotTranslateOf(glossary);
  const batches = listBatches(paths);
  for (const id of batchIds || []) {
    if (!batches.some((b) => b.id === id)) {
      errlog(`session import: there is no batch ${id} in ${paths.batches}.`);
      return { code: 2, imported: [], applied: 0 };
    }
  }
  const queue = readSessionQueue(work);
  const imported = [];
  let applied = 0;

  for (const batch of batches) {
    const named = batchIds && batchIds.includes(batch.id);
    if (batch.imported) {
      if (named) log(`session import: batch ${batch.id} is already imported.`);
      continue;
    }
    if (batchIds ? !named : !batch.done) continue;
    const plan = readJson(path.join(batch.dir, 'plan.json'), null);
    if (!plan) {
      errlog(`session import: batch ${batch.id} has no plan.json; it was not written by \`session export\`.`);
      return { code: 2, imported, applied };
    }

    const at = now();
    const job = `session-${batch.id}-${at.replace(/[^0-9]/g, '').slice(0, 14)}`;
    const items = [];
    const failures = [];
    const internal = [];
    const dropped = [];
    const missingFiles = [];
    const accepted = {};
    const rejected = {};
    const unjudged = {};

    for (const [lang, ids] of Object.entries(plan.requested)) {
      const file = path.join(batch.dir, `${lang}.txt`);
      if (!fs.existsSync(file)) {
        missingFiles.push(lang);
        continue;
      }
      const { units, replies, validation } = judgeOutput({ plan, ids, text: fs.readFileSync(file, 'utf8'), doNotTranslate, caseSensitive });
      for (const id of validation.dropped) dropped.push({ id, lang, page: batch.id, section: null });

      const entries = {};
      const sources = {};
      for (const unit of units) {
        const text = validation.accepted[unit.srcHash];
        if (typeof text !== 'string') continue;
        const revision = plan.revisions && plan.revisions[lang] && plan.revisions[lang][unit.srcHash];
        entries[unit.srcHash] = machineEntry({ srcHash: unit.srcHash, text, job, at, revision });
        sources[unit.srcHash] = unit.source;
        const attempt = (plan.attempts && plan.attempts[lang] && plan.attempts[lang][unit.srcHash]) || 1;
        items.push({
          srcHash: unit.srcHash,
          lang,
          source: unit.source,
          text,
          status: STATUS.MACHINE,
          attempt,
          ...(model ? { model } : {}),
          ...(revision && revision.forced ? { forced: true, reason: revision.reason } : {}),
        });
      }
      if (Object.keys(entries).length > 0) {
        store.writeLayerEntries(LAYER.MACHINE, lang, entries);
        store.mergeSourceMap(sources);
        store.mergeMachineSources(sources);
        clearQueued(queue, lang, Object.keys(entries));
        settleAccepted({ store, lang, ids: Object.keys(entries), revisions: (plan.revisions && plan.revisions[lang]) || {} });
      }
      // What the agent wrote for each segment, recorded beside a rejection (`recordedText`).
      const returned = returnedTexts(replies);
      for (const [id, defect] of Object.entries(validation.rejected)) {
        const attempt = (plan.attempts && plan.attempts[lang] && plan.attempts[lang][id]) || 1;
        queueDefect(queue, { lang, ids: [id], attempt, defect: { [id]: defect } });
        failures.push({ srcHash: id, lang, error: defect, attempt, ...recordedText(returned.get(id)) });
      }
      // A segment a check could not judge is neither written nor queued: it returns to the pool, its attempt not counted.
      for (const [id, error] of Object.entries(validation.internal || {})) {
        const attempt = (plan.attempts && plan.attempts[lang] && plan.attempts[lang][id]) || 1;
        internal.push({ srcHash: id, lang, error, attempt, ...recordedText(returned.get(id)) });
      }
      accepted[lang] = Object.keys(entries).length;
      if (Object.keys(validation.rejected).length) rejected[lang] = Object.keys(validation.rejected).length;
      if (validation.internal) unjudged[lang] = Object.keys(validation.internal).length;
    }

    writeSessionQueue(work, queue);
    const exhausted = failures
      .filter((f) => queue[f.lang] && queue[f.lang][f.srcHash] && queue[f.lang][f.srcHash].attempts >= attemptLimit)
      .map(({ srcHash, lang, error }) => ({ srcHash, lang, error }));
    const result =
      failures.length === 0 && internal.length === 0 && missingFiles.length === 0 ? RESULT.OK : items.length === 0 ? RESULT.FAILED : RESULT.PARTIAL;
    const jobLog = {
      id: job,
      at,
      trigger: 'session',
      items,
      failures,
      exhausted,
      ...(internal.length ? { internal } : {}),
      ...(dropped.length ? { dropped } : {}),
      result,
    };
    // The rejection alarm judges this batch against the session's recent ones, and its job log records it.
    const warned = judgeBatch({ store, job: jobLog, settings: alarm });
    if (warned) jobLog.alarm = warned;
    const jobFile = store.appendJobLog(jobLog);
    writeJson(path.join(batch.dir, 'result.json'), {
      importedAt: at,
      job,
      accepted,
      rejected,
      ...(internal.length ? { internal: unjudged } : {}),
      missingFiles,
      ...(dropped.length ? { dropped } : {}),
    });
    imported.push(batch.id);
    applied += items.length;

    log(
      `session import: batch ${batch.id}: ${items.length} translation(s) written to the machine layer, ${failures.length - exhausted.length} rejected and queued, ` +
        `${exhausted.length} at the attempt limit` +
        (internal.length ? `, ${internal.length} returned to the pool after an internal error` : '') +
        (missingFiles.length ? `; no output for ${missingFiles.join(', ')}, which returns to the pool` : '') +
        `; job=${jobFile}`
    );
    for (const f of failures.slice(0, 5)) log(`  ${f.lang} ${f.srcHash}: ${f.error}`);
    if (failures.length > 5) log(`  … and ${failures.length - 5} more, each stated to its next batch.`);
    for (const f of internal) log(`  internal error, not a defect of the translation and not counted as an attempt: ${f.lang} ${f.srcHash}: ${f.error}`);
    for (const d of dropped) log(`  dropped an identifier the batch did not ask for: ${d.lang} ${JSON.stringify(d.id)}`);
    if (warned) {
      for (const line of alarmLines(warned)) errlog(`session import: batch ${batch.id}: ${line}`);
      if (alarm.stopSubmissions && !readSessionHalt(work)) {
        const halt = { at, batch: batch.id, reason: alarmReason(warned), kind: 'rejections' };
        writeJson(paths.halt, halt);
        errlog(`session import: ${sessionHaltText(halt)}; \`l10n session export\` writes no batch until \`l10n session export --resume\` is run (backend.alarm.stopSubmissions).`);
      }
    }
  }
  if (imported.length === 0) log('session import: no finished batch to import.');
  return { code: 0, imported, applied };
}

/**
 * The lines of an output file the format does not read as an agent meant them:
 * a line beginning `@@@` that is not `@@@ <id>`, which `import` reads as part of
 * the translation before it, and text before the first `@@@ <id>` line, which it
 * ignores.
 *
 * @param {string} text
 * @returns {Array<{line:number, text:string, why:string}>}
 */
export function malformedLines(text) {
  const found = [];
  let seenHeader = false;
  String(text)
    .replace(/\r\n/g, '\n')
    .split('\n')
    .forEach((line, index) => {
      if (HEADER_RE.test(line)) seenHeader = true;
      else if (HEADER_LIKE_RE.test(line)) found.push({ line: index + 1, text: line, why: 'it begins with @@@ but is not "@@@ <id>", so it is read as part of the translation before it' });
      else if (!seenHeader && line.trim() !== '') found.push({ line: index + 1, text: line, why: 'it comes before the first "@@@ <id>" line, so it is ignored' });
    });
  return found;
}

/**
 * Checks one batch's output files without importing them: per locale, the
 * segments asked for and not written, those written and not asked for, the lines
 * the format does not read as meant (`malformedLines`), the identifiers written
 * more than once, and the segments the import would reject and why, by the
 * import's own validation (`judgeOutput`). Reads the work directory alone and
 * writes nothing.
 *
 * @param {Object} args
 * @param {Object} [args.glossary]
 * @param {string} args.work          the work directory, absolute.
 * @param {string} args.batchId
 * @param {(...a:any[])=>void} [args.log]
 * @param {(...a:any[])=>void} [args.errlog]
 * @returns {{code:number, problems:number, rejected:number}}  code 1 when a locale has a problem, 2 for no such batch.
 */
export function sessionCheck({ glossary = {}, work, batchId, log = (...a) => console.log(...a), errlog = (...a) => console.error(...a) }) {
  const paths = sessionPaths(work);
  const batch = listBatches(paths).find((b) => b.id === batchId);
  if (!batch) {
    errlog(`session check: there is no batch ${batchId} in ${paths.batches}.`);
    return { code: 2, problems: 0, rejected: 0 };
  }
  const plan = readJson(path.join(batch.dir, 'plan.json'), null);
  if (!plan) {
    errlog(`session check: batch ${batch.id} has no plan.json; it was not written by \`session export\`.`);
    return { code: 2, problems: 0, rejected: 0 };
  }
  const { entries: doNotTranslate, caseSensitive } = doNotTranslateOf(glossary);
  const state = batch.imported ? 'already imported' : batch.done ? 'not yet imported, its done file written' : 'not yet imported, no done file yet';
  log(`session check: batch ${batch.id} (${state}): ${Object.keys(plan.requested).join(', ')}.`);
  let problems = 0;
  let rejectedTotal = 0;
  const failing = [];
  for (const [lang, ids] of Object.entries(plan.requested)) {
    const file = path.join(batch.dir, `${lang}.txt`);
    if (!fs.existsSync(file)) {
      log(`  ${lang}: ${ids.length} requested; no output file ${file}`);
      problems += 1;
      failing.push(lang);
      continue;
    }
    const text = fs.readFileSync(file, 'utf8');
    const malformed = malformedLines(text);
    const written = parseSessionOutput(text).map((e) => e.id);
    const counts = new Map();
    for (const id of written) counts.set(id, (counts.get(id) || 0) + 1);
    const requested = new Set(ids);
    const missing = ids.filter((id) => !counts.has(id));
    const extra = [...counts.keys()].filter((id) => !requested.has(id));
    const repeated = [...counts].filter(([id, n]) => n > 1 && requested.has(id)).map(([id, n]) => `${id} (${n} times)`);
    const { validation } = judgeOutput({ plan, ids, text, doNotTranslate, caseSensitive });
    const rejected = Object.entries(validation.rejected);
    const unjudged = Object.entries(validation.internal || {});
    const found = missing.length + extra.length + malformed.length + repeated.length + rejected.length + unjudged.length;
    rejectedTotal += rejected.length;
    if (found === 0) {
      log(`  ${lang}: ${ids.length} requested, ${counts.size} written: nothing to fix.`);
      continue;
    }
    problems += 1;
    failing.push(lang);
    log(
      `  ${lang}: ${ids.length} requested, ${counts.size} written: ${missing.length} missing, ${extra.length} not asked for, ` +
        `${malformed.length} malformed line(s), ${repeated.length} written more than once; ${rejected.length} would be rejected` +
        (unjudged.length ? `, ${unjudged.length} could not be judged` : '')
    );
    if (missing.length) log(`    missing: ${missing.join(', ')}`);
    if (extra.length) log(`    not asked for, so the import drops them: ${extra.join(', ')}`);
    for (const m of malformed) log(`    line ${m.line}: ${JSON.stringify(m.text)}: ${m.why}`);
    if (repeated.length) log(`    written more than once: ${repeated.join(', ')}`);
    for (const [id, defect] of rejected) if (!missing.includes(id)) log(`    would be rejected: ${id}: ${defect}`);
    for (const [id, error] of unjudged) log(`    could not be judged, a failure of the package: ${id}: ${error}`);
  }
  log(
    problems === 0
      ? `session check: batch ${batch.id}: every output file is complete, and the import would accept every segment.`
      : `session check: batch ${batch.id}: ${failing.join(', ')} ${failing.length === 1 ? 'has' : 'have'} something to fix; the import would reject ${rejectedTotal} segment(s).`
  );
  return { code: problems === 0 ? 0 : 1, problems, rejected: rejectedTotal };
}

/**
 * Prints the session's state: per locale what is missing as of the last
 * extract, the batches by state, the rejections, the queue's entries that no
 * longer stand for work, a halt, the translations awaiting a person's review,
 * and the translation's progress per locale and in total (`progress.mjs`), the
 * left-out and queued segments counted in both queues. Reads files only.
 *
 * @param {Object} args
 * @param {ReturnType<import('./engine.mjs').createEngine>} args.engine
 * @param {string[]} args.targets
 * @param {number} args.attemptLimit
 * @param {string} args.work
 * @param {(...a:any[])=>void} [args.log]
 * @returns {{code:number}}
 */
export function sessionStatus({ engine, targets, attemptLimit, work, log = (...a) => console.log(...a) }) {
  const paths = sessionPaths(work);
  const worklist = engine.gate({ targets });
  const missing = Object.fromEntries(targets.map((lang) => [lang, { segments: 0, words: 0 }]));
  for (const item of worklist.status === 'work' ? worklist.items : []) {
    for (const lang of item.missing) {
      if (!missing[lang]) continue;
      missing[lang].segments += 1;
      missing[lang].words += wordsOf(item.source);
    }
  }
  log('session status: missing, as of the last extract:');
  for (const lang of targets) log(`  ${lang}: ${missing[lang].segments} segment(s), ${missing[lang].words} words`);
  const batches = listBatches(paths);
  const open = batches.filter((b) => !b.imported);
  const waiting = open.filter((b) => b.done).map((b) => b.id);
  const running = open.filter((b) => !b.done).map((b) => b.id);
  log(
    `session status: ${batches.length - open.length} batch(es) imported, ${waiting.length} finished and waiting for import` +
      `${waiting.length ? ` (${waiting.join(', ')})` : ''}, ${running.length} open${running.length ? ` (${running.join(', ')})` : ''}.`
  );
  const queue = readSessionQueue(work);
  for (const lang of Object.keys(queue).sort()) {
    const rows = Object.entries(queue[lang]);
    const atLimit = rows.filter(([, e]) => e.attempts >= attemptLimit);
    log(`session status: ${lang}: ${rows.length - atLimit.length} rejected segment(s) queued for a later batch, ${atLimit.length} at the attempt limit.`);
    for (const [id, e] of atLimit) log(`  left out after ${e.attempts} attempts: ${id}: ${e.defect}`);
  }
  if (Object.values(queue).some((rows) => Object.values(rows).some((e) => e.attempts >= attemptLimit))) {
    log('session status: `l10n requeue --session` gives the segments left out their attempts again, their defect kept as a correction.');
  }
  const pending = engine.store.readPending();
  const stale = staleFromStore(engine.store, { targets, apiQueue: pending.queue, sessionQueue: queue, batchHeld: batchHeldPairs(pending), sessionHeld: openPairs(paths) });
  for (const line of staleLines(stale.session, { prefix: 'session status', queue: paths.queue })) log(line);
  for (const line of markLines(markedFromStore(engine.store, targets), { queue, attemptLimit, prefix: 'session status' })) log(line);
  const halt = readSessionHalt(work);
  if (halt) log(`session status: ${sessionHaltText(halt)}; \`l10n session export --resume\` writes batches again once the cause is found.`);
  const review = engine.review({ targets });
  const toReview = Object.values(review).reduce((n, rows) => n + rows.length, 0);
  if (toReview) log(`session status: ${toReview} machine translation(s) revise a reviewed translation; \`l10n review\` lists them.`);
  const rows = progressFromStore(engine.store, { targets, queues: [pending.queue, queue], attemptLimit });
  for (const line of progressLines(rows, 'session status')) log(line);
  return { code: 0 };
}

export default {
  DEFAULT_BATCH_WORDS,
  NO_HELPERS_SENTENCE,
  sessionPaths,
  sessionHeldPairs,
  instructionsName,
  sessionInstructions,
  agentPrompt,
  sessionExport,
  parseSessionOutput,
  malformedLines,
  sessionImport,
  sessionCheck,
  sessionStatus,
  readSessionHalt,
  CHECKED_SENTENCE,
  taskRevisions,
  LONG_SEGMENT_BYTES,
};
