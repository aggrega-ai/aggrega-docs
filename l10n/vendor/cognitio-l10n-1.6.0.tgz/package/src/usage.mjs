/**
 * usage.mjs — What the Message Batches API billed: the tokens each request's
 * reply reports, summed per batch, per locale and over every batch collected, and
 * priced with the package's rate table (`cost.mjs`).
 *
 * READS nothing and WRITES nothing: pure functions over the usage a reply carries
 * and the job logs the caller reads. `collect` records each request's usage in its
 * job log (`usageRecord`); `status` sums the job logs (`spendSummary`).
 *
 * THE FIGURES. A reply's `usage` reports its uncached input tokens
 * (`input_tokens`), its output tokens, reasoning included (`output_tokens`), and
 * the input tokens read from or written to the prompt cache
 * (`cache_read_input_tokens`, `cache_creation_input_tokens`, the last split by
 * duration under `cache_creation`). These are the billed figures, unlike the
 * estimates `submit` prints, which are upper bounds (`tokens.mjs`).
 *
 * THE PRICE of a request is its figures at its model's rates: a cache write at the
 * one-hour rate unless the reply reports it as a five-minute one, the only cache
 * marker a request carries being the one-hour one. A request on a model the table
 * does not hold makes the whole sum unpriced: tokens are printed alone, never a
 * figure that leaves some of them out.
 */

import { BATCH_RATES } from './cost.mjs';

/** Zero of every figure. */
export const emptyUsage = () => ({ input: 0, output: 0, cacheRead: 0, cacheWrite: 0, cacheWrite5m: 0 });

const count = (n) => (Number.isFinite(n) && n > 0 ? n : 0);

/**
 * The figures of one reply's `usage`, or null when the reply carries none.
 *
 * @param {Object|null|undefined} usage  a Messages API `usage` object.
 * @returns {{input:number, output:number, cacheRead:number, cacheWrite:number, cacheWrite5m:number}|null}
 *          `cacheWrite` counts every cache write, `cacheWrite5m` the five-minute ones among them.
 */
export function readUsage(usage) {
  if (!usage || typeof usage !== 'object') return null;
  const split = usage.cache_creation && typeof usage.cache_creation === 'object' ? usage.cache_creation : null;
  return {
    input: count(usage.input_tokens),
    output: count(usage.output_tokens),
    cacheRead: count(usage.cache_read_input_tokens),
    cacheWrite: count(usage.cache_creation_input_tokens),
    cacheWrite5m: split ? count(split.ephemeral_5m_input_tokens) : 0,
  };
}

/** The sum of a list of figures. */
export function sumUsage(list) {
  const total = emptyUsage();
  for (const u of list) for (const k of Object.keys(total)) total[k] += count(u && u[k]);
  return total;
}

/**
 * The price in US dollars of one request's figures on its model, or null when
 * the rate table holds no rate for the model.
 *
 * @param {string} model
 * @param {ReturnType<typeof readUsage>} u
 * @param {Object} [rates]
 */
export function usageCost(model, u, rates = BATCH_RATES) {
  const rate = Object.prototype.hasOwnProperty.call(rates, model) ? rates[model] : null;
  if (!rate || rate.input === undefined) return null;
  const write5m = Math.min(u.cacheWrite5m || 0, u.cacheWrite);
  return (
    (u.input * rate.input +
      u.output * rate.output +
      u.cacheRead * rate.cacheRead +
      write5m * rate.cacheWrite5m +
      (u.cacheWrite - write5m) * rate.cacheWrite) /
    1_000_000
  );
}

/** The price of a list of requests, `{model, ...figures}` each, or null when any one cannot be priced. */
export function requestsCost(requests, rates = BATCH_RATES) {
  let total = 0;
  for (const r of requests) {
    const c = usageCost(r.model, r, rates);
    if (c === null) return null;
    total += c;
  }
  return total;
}

/** A dollar amount: two decimals, three below a dollar. */
const usd = (amount) => `USD ${amount.toFixed(amount < 1 ? 3 : 2)}`;

/**
 * The figures as a line prints them, and the price when there is one.
 *
 * @param {ReturnType<typeof sumUsage>} total
 * @param {number|null|undefined} [cost]
 */
export function usageLine(total, cost) {
  const tokens = `input ${total.input}, output ${total.output}, cache read ${total.cacheRead}, cache write ${total.cacheWrite} tokens`;
  return typeof cost === 'number' ? `${tokens}, ${usd(cost)}` : tokens;
}

/**
 * The `usage` a batch's job log records: per request its locale, page, section,
 * model and figures, in the order the results were read; their sum; their price
 * when every request can be priced; and the estimate `submit` recorded for the
 * batch, when it recorded one. Empty when no reply reported usage.
 *
 * @param {{estimate?: {input:number, output:number}}} record  the batch's pending record.
 * @param {Array<{customId:string, lang:string, page:string, section:string|null, model:string, input:number, output:number, cacheRead:number, cacheWrite:number, cacheWrite5m:number}>} requests
 * @returns {{usage?: Object}}
 */
export function usageRecord(record, requests) {
  if (requests.length === 0) return {};
  const cost = requestsCost(requests);
  return {
    usage: {
      requests,
      total: sumUsage(requests),
      ...(cost !== null ? { cost } : {}),
      ...(record && record.estimate ? { estimate: record.estimate } : {}),
    },
  };
}

/**
 * The spend the job logs record: per batch, per locale and in total, each with its
 * price when every request in it can be priced, over the job logs that carry
 * `usage` (`usageRecord`), in the order given.
 *
 * @param {Array<{id:string, at:string, usage?: Object}>} jobs
 * @returns {{batches: Array<{id:string, at:string, total:Object, cost:number|null, estimate?:Object}>, byLang: Object.<string, {total:Object, cost:number|null}>, total:Object, cost:number|null}}
 */
export function spendSummary(jobs) {
  const batches = [];
  const requestsByLang = new Map();
  const all = [];
  for (const job of jobs) {
    const usage = job && job.usage;
    if (!usage || !Array.isArray(usage.requests)) continue;
    batches.push({ id: job.id, at: job.at, total: sumUsage(usage.requests), cost: requestsCost(usage.requests), ...(usage.estimate ? { estimate: usage.estimate } : {}) });
    for (const r of usage.requests) {
      if (!requestsByLang.has(r.lang)) requestsByLang.set(r.lang, []);
      requestsByLang.get(r.lang).push(r);
      all.push(r);
    }
  }
  const byLang = {};
  for (const lang of [...requestsByLang.keys()].sort()) {
    const list = requestsByLang.get(lang);
    byLang[lang] = { total: sumUsage(list), cost: requestsCost(list) };
  }
  return { batches, byLang, total: sumUsage(all), cost: all.length ? requestsCost(all) : null };
}

export default { emptyUsage, readUsage, sumUsage, usageCost, requestsCost, usageLine, usageRecord, spendSummary };
