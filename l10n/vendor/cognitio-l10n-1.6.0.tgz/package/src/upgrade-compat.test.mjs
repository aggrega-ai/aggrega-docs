import '../test/no-network.mjs';
import { describe, it, expect, beforeEach, afterEach } from 'vitest';
import fs from 'node:fs';
import path from 'node:path';

import { runCli } from './cli.mjs';
import { capture, copyMarkdownFixture, echoReply, fakeAnthropic, writeJson } from '../test/helpers.mjs';

// What 1.3.0 leaves on disk, read by this version in the middle of a run: a session batch exported with the one
// INSTRUCTIONS.md and a task naming no instructions file, and a Message Batch recorded with no estimate.

let project;
beforeEach(() => {
  project = copyMarkdownFixture('l10n-upgrade-');
});
afterEach(() => {
  fs.rmSync(project, { recursive: true, force: true });
});

const memory = (...p) => path.join(project, 'memory', ...p);
const work = (...p) => memory('session', ...p);
const readJson = (file) => JSON.parse(fs.readFileSync(file, 'utf8'));

async function run(argv, deps = {}) {
  const io = capture();
  const code = await runCli(argv, { cwd: project, env: { ANTHROPIC_API_KEY: 'test-key' }, log: io.log, errlog: io.errlog, ...deps });
  return { code, out: io.text(), err: io.errors() };
}

/** Turns the batch just exported into the shape 1.3.0 exported: the shared INSTRUCTIONS.md, and no `instructions` in the task. */
function asExportedBy130(batch) {
  const file = work('batches', batch, 'task.json');
  const task = readJson(file);
  fs.renameSync(task.instructions, work('INSTRUCTIONS.md'));
  delete task.instructions;
  fs.writeFileSync(file, JSON.stringify(task, null, 2) + '\n');
  return task;
}

describe('a session batch exported by 1.3.0', () => {
  it('imports, and a later export leaves its INSTRUCTIONS.md as it was', async () => {
    const [batch] = [...(await run(['session', 'export', '--words', '40'])).out.matchAll(/^session export: batch (\d{4}):/gm)].map((m) => m[1]);
    const task = asExportedBy130(batch);
    const legacy = fs.readFileSync(work('INSTRUCTIONS.md'), 'utf8');

    // An agent of the old batch is still reading INSTRUCTIONS.md while the next batch is exported.
    expect((await run(['session', 'export', '--words', '40'])).code).toBe(0);
    expect(fs.readFileSync(work('INSTRUCTIONS.md'), 'utf8')).toBe(legacy);

    for (const lang of task.locales) {
      const lines = task.chunks.flatMap((c) => c.segments).filter((s) => s.translate).flatMap((s) => [`@@@ ${s.id}`, `${s.source} ⟨${lang}⟩`]);
      fs.writeFileSync(task.output[lang], lines.join('\n') + '\n');
    }
    fs.writeFileSync(task.done, 'ok\n');
    const r = await run(['session', 'import']);
    expect(r.code).toBe(0);
    expect(r.out).toMatch(new RegExp(`session import: batch ${batch}: \\d+ translation\\(s\\) written to the machine layer, 0 rejected and queued, 0 at the attempt limit;`));
  });
});

describe('a Message Batch recorded by 1.3.0, with no estimate', () => {
  it('collects, records its usage, and status shows it without an estimate', async () => {
    expect((await run(['extract'])).code).toBe(0);
    const fake = fakeAnthropic({ reply: (params) => ({ ...echoReply(params), usage: { input_tokens: 10, output_tokens: 5 } }) });
    expect((await run(['submit', '--targets', 'it'], { ClientClass: fake.FakeAnthropic })).code).toBe(0);
    const pending = readJson(memory('pending.json'));
    delete pending.batches[0].estimate;
    writeJson(memory('pending.json'), pending);

    const collected = await run(['collect'], { ClientClass: fake.FakeAnthropic });
    expect(collected.code).toBe(0);
    const job = fs.readdirSync(memory('jobs')).map((f) => readJson(memory('jobs', f))).find((j) => j.trigger === 'collect');
    expect(job.usage.estimate).toBeUndefined();
    const status = await run(['status']);
    expect(status.out).toMatch(new RegExp(`^ {2}batch ${pending.batches[0].id}, created .*: input \\d+, output \\d+, cache read 0, cache write 0 tokens, USD [0-9.]+$`, 'm'));
  });

  it('a job log 1.3.0 wrote, with no usage, is left out of the sums', async () => {
    writeJson(memory('jobs', '2026-10-22T00-00-00-msgbatch_old.json'), { id: 'msgbatch_old', at: 'then', trigger: 'collect', items: [], failures: [], result: 'ok' });
    expect((await run(['status'])).out).toContain('status: no collected batch records its usage yet.');
  });
});
