import '../test/no-network.mjs';
import { describe, it, expect, beforeEach, afterEach } from 'vitest';
import fs from 'node:fs';
import path from 'node:path';

import os from 'node:os';

import { runCli } from './cli.mjs';
import { CHECKED_SENTENCE, instructionsName, malformedLines, NO_HELPERS_SENTENCE, parseSessionOutput, taskRevisions } from './session.mjs';
import { REVISE_SENTENCE, translationRules } from './translator-prompt.mjs';
import { keyOf } from './normalize.mjs';
import { createStore } from './store.mjs';
import { capture, copyMarkdownFixture, writeJson } from '../test/helpers.mjs';

let project;
beforeEach(() => {
  project = copyMarkdownFixture('l10n-session-');
});
afterEach(() => {
  fs.rmSync(project, { recursive: true, force: true });
});

const work = (...p) => path.join(project, 'memory', 'session', ...p);
const memory = (...p) => path.join(project, 'memory', ...p);
const readJson = (file) => JSON.parse(fs.readFileSync(file, 'utf8'));

async function run(argv) {
  const io = capture();
  const code = await runCli(argv, { cwd: project, env: {}, log: io.log, errlog: io.errlog });
  return { code, out: io.text(), err: io.errors() };
}

/**
 * Stands in for an agent: writes every output file a batch names, each requested
 * segment answered by `answer(source, lang, id)` — by default its source tagged
 * with the locale, which keeps every protected span, term and line — then, unless
 * `done` is false, the done file. `skip` names locales whose file is not written.
 */
function agent(batch, { answer = (source, lang) => `${source} ⟨${lang}⟩`, skip = [], done = true } = {}) {
  const task = readJson(work('batches', batch, 'task.json'));
  for (const lang of task.locales) {
    if (skip.includes(lang)) continue;
    const lines = [];
    for (const chunk of task.chunks) {
      for (const segment of chunk.segments) {
        if (!segment.translate || (segment.translate !== 'all' && !segment.translate.includes(lang))) continue;
        lines.push(`@@@ ${segment.id}`, answer(segment.source, lang, segment.id));
      }
    }
    fs.writeFileSync(task.output[lang], lines.join('\n') + '\n');
  }
  if (done) fs.writeFileSync(task.done, 'ok\n');
  return task;
}

/** Every batch the export printed, by number. */
const batchesIn = (out) => [...out.matchAll(/^session export: batch (\d{4}):/gm)].map((m) => m[1]);

describe('l10n session export: batches every locale of a segment together, with the instructions an agent reads', () => {
  it('writes the instructions, and each batch’s task and plan, and prints the prompt that starts its agent', async () => {
    const r = await run(['session', 'export', '--batches', '50']);
    expect(r.code).toBe(0);
    const batches = batchesIn(r.out);
    expect(batches.length).toBeGreaterThan(0);
    expect(r.out).toContain(`agent prompt: Translate the batch in ${work('batches', '0001', 'task.json')}. First read ${work('INSTRUCTIONS.it+de.md')}`);
    // One agent per batch: the prompt keeps it from starting others, and tells it a command checks what it writes.
    expect(r.out).toContain(NO_HELPERS_SENTENCE);
    expect(r.out).toContain(`${NO_HELPERS_SENTENCE} ${CHECKED_SENTENCE} Reply with one line.`);

    const instructions = fs.readFileSync(work('INSTRUCTIONS.it+de.md'), 'utf8');
    expect(instructions).toContain(translationRules({ glossary: {} }));
    expect(instructions).toContain(REVISE_SENTENCE);
    expect(instructions).toContain(NO_HELPERS_SENTENCE);
    expect(instructions).toContain('### Italian (`it`)');
    expect(instructions).toContain('Use an impersonal, professional register.');
    expect(instructions).toContain('@@@ <id>');
    // The instructions every locale shared before are no longer written.
    expect(fs.existsSync(work('INSTRUCTIONS.md'))).toBe(false);

    const task = readJson(work('batches', '0001', 'task.json'));
    expect(task.instructions).toBe(work('INSTRUCTIONS.it+de.md'));
    expect(task.locales).toEqual(['it', 'de']);
    expect(task.output).toEqual({ it: work('batches', '0001', 'it.txt'), de: work('batches', '0001', 'de.txt') });
    const plan = readJson(work('batches', '0001', 'plan.json'));
    const requested = task.chunks.flatMap((c) => c.segments).filter((s) => s.translate).map((s) => s.id);
    expect([...plan.requested.it].sort()).toEqual([...new Set(requested)].sort());
    // A Markdown segment's protected strings reach the agent as `keep`.
    const withCode = task.chunks.flatMap((c) => c.segments).find((s) => s.source.includes('`planted_inline_code`'));
    expect(withCode.keep).toContain('`planted_inline_code`');
  });

  it('writes the guides of a batch’s own locales alone, one instructions file per set of locales', async () => {
    const r = await run(['session', 'export', '--targets', 'de']);
    expect(r.code).toBe(0);
    const [batch] = batchesIn(r.out);
    const task = readJson(work('batches', batch, 'task.json'));
    expect(task.locales).toEqual(['de']);
    expect(task.instructions).toBe(work('INSTRUCTIONS.de.md'));
    const instructions = fs.readFileSync(work('INSTRUCTIONS.de.md'), 'utf8');
    expect(instructions).toContain('### German (`de`)');
    expect(instructions).not.toContain('### Italian (`it`)');
    expect(instructions).toContain('Terminology for German (rule 2):');
    expect(instructions).not.toContain('Terminology for Italian (rule 2):');
    expect(r.out).toContain(`First read ${work('INSTRUCTIONS.de.md')}`);
  });

  it('names a long set of locales by a digest, so the file name stays short', () => {
    const many = Array.from({ length: 37 }, (_, i) => `l${String(i).padStart(2, '0')}-XX`);
    expect(instructionsName(['it', 'de'])).toBe('INSTRUCTIONS.it+de.md');
    expect(instructionsName(many)).toMatch(/^INSTRUCTIONS\.[0-9a-f]{12}\.md$/);
    expect(instructionsName(many)).toBe(instructionsName([...many]));
  });

  it('never plans again a segment that a batch not yet imported holds', async () => {
    const first = await run(['session', 'export', '--words', '40']);
    const second = await run(['session', 'export', '--words', '40']);
    const ids = (batch) => readJson(work('batches', batch, 'plan.json')).requested.it;
    const [a] = batchesIn(first.out);
    const [b] = batchesIn(second.out);
    expect(b).not.toBe(a);
    expect(ids(b).filter((id) => ids(a).includes(id))).toEqual([]);
  });

  it('refuses a malformed --words, and a subcommand it does not know, writing nothing', async () => {
    expect((await run(['session', 'export', '--words', '0'])).code).toBe(2);
    const unknown = await run(['session', 'translate']);
    expect(unknown.code).toBe(2);
    expect(unknown.err).toContain('`l10n session export`, `l10n session import`, `l10n session status`');
    expect(fs.existsSync(work())).toBe(false);
  });
});

describe('l10n session import: validates what the agents wrote and writes the machine layer', () => {
  it('imports finished batches until nothing is missing, and generate writes the translated pages', async () => {
    for (let round = 0; round < 10; round++) {
      const r = await run(['session', 'export', '--batches', '50']);
      const batches = batchesIn(r.out);
      if (batches.length === 0) break;
      for (const batch of batches) agent(batch);
      const imported = await run(['session', 'import', '--model', 'test-agent']);
      expect(imported.code).toBe(0);
      expect(imported.out).not.toMatch(/[1-9]\d* rejected and queued/);
    }
    expect((await run(['gate', '--check'])).code).toBe(0);
    const machine = readJson(memory('machine', 'it.json'));
    const key = keyOf('Text with a footnote[^note].');
    expect(machine[key]).toMatchObject({ text: 'Text with a footnote[^note]. ⟨it⟩', status: 'machine' });
    expect(readJson(memory('machine', '_source.json'))[key]).toBe('Text with a footnote[^note].');
    const job = fs.readdirSync(memory('jobs')).map((f) => readJson(memory('jobs', f))).find((j) => j.trigger === 'session');
    expect(job.items[0].model).toBe('test-agent');

    expect((await run(['generate'])).code).toBe(0);
    expect(fs.readFileSync(path.join(project, 'out', 'it', 'README.md'), 'utf8')).toContain('Text with a footnote[^note]. ⟨it⟩');
  });

  it('rejects a translation that loses a protected string, queues its defect, and states it to the next batch', async () => {
    const [batch] = batchesIn((await run(['session', 'export', '--batches', '50'])).out);
    const lossy = (source, lang) => (lang === 'it' ? source.replace('`planted_inline_code`', 'planted inline code') : `${source} ⟨${lang}⟩`);
    agent(batch, { answer: lossy });
    const r = await run(['session', 'import']);
    expect(r.code).toBe(0);
    expect(r.out).toMatch(/1 rejected and queued/);
    const queue = readJson(work('queue.json'));
    const [id] = Object.keys(queue.it);
    expect(queue.it[id]).toMatchObject({ attempts: 1 });
    expect(queue.it[id].defect).toContain('`planted_inline_code`');

    // Only the rejected Italian segment is left, so the next batch is an Italian one.
    const next = batchesIn((await run(['session', 'export', '--batches', '50'])).out);
    expect(next).toHaveLength(1);
    const task = readJson(work('batches', next[0], 'task.json'));
    expect(task.locales).toEqual(['it']);
    const segment = task.chunks.flatMap((c) => c.segments).find((s) => s.id === id);
    expect(segment.translate).toBe('all');
    expect(segment.corrections.it).toContain('`planted_inline_code`');
    expect(readJson(work('batches', next[0], 'plan.json')).attempts.it[id]).toBe(2);
  });

  it('returns a locale with no output file to the pool, unqueued, and imports an unfinished batch only when named', async () => {
    const [batch] = batchesIn((await run(['session', 'export'])).out);
    agent(batch, { skip: ['de'], done: false });
    expect((await run(['session', 'import'])).out).toContain('session import: no finished batch to import.');
    const r = await run(['session', 'import', '--batch', batch]);
    expect(r.out).toContain('no output for de, which returns to the pool');
    expect(fs.existsSync(work('queue.json')) ? readJson(work('queue.json')).de : undefined).toBeUndefined();
    const ids = readJson(work('batches', batch, 'plan.json')).requested.de;
    const again = batchesIn((await run(['session', 'export'])).out);
    expect(readJson(work('batches', again[0], 'plan.json')).requested.de).toEqual(expect.arrayContaining(ids.slice(0, 1)));
    expect((await run(['session', 'import', '--batch', batch])).out).toContain(`batch ${batch} is already imported`);
  });

  it('rejects a Markdown translation that breaks a one-line source, so the page keeps its structure', async () => {
    const [batch] = batchesIn((await run(['session', 'export', '--batches', '50'])).out);
    const heading = keyOf('Lists');
    agent(batch, { answer: (source, lang, id) => (id === heading && lang === 'de' ? 'Listen\nund mehr' : `${source} ⟨${lang}⟩`) });
    await run(['session', 'import']);
    expect(readJson(work('queue.json')).de[heading].defect).toContain('write the translation on one line');
  });

  it('status reports what is missing, the batches by state and the rejections', async () => {
    const [batch] = batchesIn((await run(['session', 'export'])).out);
    const r = await run(['session', 'status']);
    expect(r.code).toBe(0);
    expect(r.out).toMatch(/^ {2}it: \d+ segment\(s\), \d+ words$/m);
    expect(r.out).toContain(`0 batch(es) imported, 0 finished and waiting for import, 1 open (${batch}).`);
  });
});

describe('a changed segment reaches its agent with the earlier translation to revise', () => {
  it('carries "revise" per locale, and the imported entry records where it came from', async () => {
    for (let round = 0; round < 10; round++) {
      const batches = batchesIn((await run(['session', 'export', '--batches', '50'])).out);
      if (batches.length === 0) break;
      for (const batch of batches) agent(batch);
      await run(['session', 'import']);
    }
    const page = path.join(project, 'docs', 'README.md');
    fs.writeFileSync(page, fs.readFileSync(page, 'utf8').replace('Text with a footnote[^note].', 'Text with a footnote[^note], now edited.'));

    const [batch] = batchesIn((await run(['session', 'export'])).out);
    const segment = readJson(work('batches', batch, 'task.json')).chunks.flatMap((c) => c.segments).find((s) => s.translate);
    expect(segment.source).toBe('Text with a footnote[^note], now edited.');
    // The earlier source once, every locale's translation of it beside.
    expect(segment.earlier).toBe('Text with a footnote[^note].');
    expect(segment.revise).toEqual({
      it: { translation: 'Text with a footnote[^note]. ⟨it⟩' },
      de: { translation: 'Text with a footnote[^note]. ⟨de⟩' },
    });
    agent(batch);
    await run(['session', 'import']);
    expect(readJson(memory('machine', 'it.json'))[keyOf('Text with a footnote[^note], now edited.')].revision).toEqual({
      from: keyOf('Text with a footnote[^note].'),
      reviewed: false,
    });
  });
});

describe('parseSessionOutput', () => {
  it('reads each segment to the next header, a translation spanning lines included, and accepts CRLF', () => {
    expect(parseSessionOutput('@@@ aaaa\nOne line\n@@@ bbbb\nFirst  \nsecond\n\n')).toEqual([
      { id: 'aaaa', text: 'One line' },
      { id: 'bbbb', text: 'First  \nsecond' },
    ]);
    expect(parseSessionOutput('@@@ aaaa\r\nUna riga\r\n')).toEqual([{ id: 'aaaa', text: 'Una riga' }]);
    expect(parseSessionOutput('stray text before a header\n@@@ aaaa\nx')).toEqual([{ id: 'aaaa', text: 'x' }]);
  });
});

/** Every file under `dir` with its bytes, so a test can show a command wrote nothing. */
function snapshot(dir) {
  if (!fs.existsSync(dir)) return {};
  return Object.fromEntries(
    fs
      .readdirSync(dir, { recursive: true })
      .filter((rel) => fs.statSync(path.join(dir, rel)).isFile())
      .sort()
      .map((rel) => [rel, fs.readFileSync(path.join(dir, rel), 'utf8')])
  );
}

describe('l10n session export --output-words: a batch filled by the words it asks to write', () => {
  const SIX = ['it', 'de', 'fr', 'es', 'pt', 'nl'];
  let root;
  beforeEach(() => {
    // Thirty pages of five paragraphs of twenty distinct words: 100 source words a page, no two segments alike.
    root = fs.mkdtempSync(path.join(os.tmpdir(), 'l10n-output-words-'));
    for (let p = 0; p < 30; p++) {
      const paragraphs = Array.from({ length: 5 }, (_, s) => Array.from({ length: 20 }, (_, w) => `p${p}s${s}w${w}`).join(' ') + '.');
      fs.mkdirSync(path.join(root, 'docs'), { recursive: true });
      fs.writeFileSync(path.join(root, 'docs', `page-${String(p).padStart(2, '0')}.md`), paragraphs.join('\n\n') + '\n');
    }
    for (const lang of SIX) {
      fs.mkdirSync(path.join(root, 'memory', 'prompts'), { recursive: true });
      fs.writeFileSync(path.join(root, 'memory', 'prompts', `${lang}.md`), 'Use a neutral register.\n');
    }
    writeJson(path.join(root, 'l10n.config.json'), {
      locales: { source: 'en', targets: SIX },
      memory: { dir: 'memory' },
      adapter: { kind: 'markdown', sourceDir: 'docs', include: ['**/*.md'], outDir: 'out' },
    });
  });
  afterEach(() => fs.rmSync(root, { recursive: true, force: true }));

  async function exportIn(workDir, argv) {
    const io = capture();
    const code = await runCli(['session', 'export', '--work', workDir, ...argv], { cwd: root, env: {}, log: io.log, errlog: io.errlog });
    const plan = fs.existsSync(path.join(workDir, 'batches', '0001', 'plan.json')) ? JSON.parse(fs.readFileSync(path.join(workDir, 'batches', '0001', 'plan.json'), 'utf8')) : null;
    return { code, out: io.text(), err: io.errors(), plan };
  }

  it('gives a one-locale batch six times the source words of a six-locale batch, at the same --output-words', async () => {
    const six = await exportIn(path.join(root, 'work-six'), ['--output-words', '1200']);
    const one = await exportIn(path.join(root, 'work-one'), ['--output-words', '1200', '--targets', 'it']);
    expect(six.code).toBe(0);
    expect(one.code).toBe(0);
    expect(six.plan).toMatchObject({ words: 200, outputWords: 1200 });
    expect(Object.keys(six.plan.requested)).toEqual(SIX);
    expect(one.plan).toMatchObject({ words: 1200, outputWords: 1200 });
    expect(one.plan.words / six.plan.words).toBe(6);
    expect(six.out).toContain('session export: batch 0001: 200 words on 2 pages, into it, de, fr, es, pt, nl: 1200 words to write.');
  });

  it('applies both bounds when both flags are given, and --words alone as before', async () => {
    expect((await exportIn(path.join(root, 'w1'), ['--words', '300', '--output-words', '1200'])).plan.words).toBe(200);
    expect((await exportIn(path.join(root, 'w2'), ['--words', '300', '--output-words', '100000'])).plan.words).toBe(300);
    expect((await exportIn(path.join(root, 'w3'), ['--words', '300'])).plan).toMatchObject({ words: 300, outputWords: 1800 });
  });

  it('refuses an --output-words that is not a positive integer, writing nothing', async () => {
    const r = await exportIn(path.join(root, 'w4'), ['--output-words', '0']);
    expect(r.code).toBe(2);
    expect(r.err).toContain('session export: --words, --output-words and --batches take a positive integer.');
    expect(fs.existsSync(path.join(root, 'w4'))).toBe(false);
  });
});

describe('a long paragraph revised in many locales: its earlier source written once, no line too long to read', () => {
  const SIX = ['it', 'de', 'fr', 'es', 'pt', 'nl'];
  let root;
  const paragraph = (edit) => Array.from({ length: 1300 }, (_, i) => (i === 700 ? edit : `w${i}`)).join(' ') + '.';
  const OLD = paragraph('before');
  const NEW = paragraph('after');
  beforeEach(() => {
    root = fs.mkdtempSync(path.join(os.tmpdir(), 'l10n-long-revision-'));
    fs.mkdirSync(path.join(root, 'docs'));
    fs.writeFileSync(path.join(root, 'docs', 'page.md'), `# Long\n\n${OLD}\n\nA short paragraph.\n`);
    fs.mkdirSync(path.join(root, 'memory', 'prompts'), { recursive: true });
    for (const lang of SIX) fs.writeFileSync(path.join(root, 'memory', 'prompts', `${lang}.md`), 'Use a neutral register.\n');
    writeJson(path.join(root, 'l10n.config.json'), {
      locales: { source: 'en', targets: SIX },
      memory: { dir: 'memory' },
      adapter: { kind: 'markdown', sourceDir: 'docs', include: ['**/*.md'], outDir: 'out' },
    });
  });
  afterEach(() => fs.rmSync(root, { recursive: true, force: true }));

  const sessionWork = (...p) => path.join(root, 'memory', 'session', ...p);
  async function runIn(argv) {
    const io = capture();
    const code = await runCli(argv, { cwd: root, env: {}, log: io.log, errlog: io.errlog });
    return { code, out: io.text(), err: io.errors() };
  }
  /** Writes every output file of a batch, each segment its source tagged with the locale, then its done file. */
  function translate(batch) {
    const task = JSON.parse(fs.readFileSync(sessionWork('batches', batch, 'task.json'), 'utf8'));
    for (const lang of task.locales) {
      const lines = task.chunks.flatMap((c) => c.segments).filter((s) => s.translate).flatMap((s) => [`@@@ ${s.id}`, `${s.source} ⟨${lang}⟩`]);
      fs.writeFileSync(task.output[lang], lines.join('\n') + '\n');
    }
    fs.writeFileSync(task.done, 'ok\n');
    return task;
  }

  it('writes the earlier source once for the six locales, every line of the task no longer than one text, and imports the revision', async () => {
    const [first] = batchesIn((await runIn(['session', 'export'])).out);
    translate(first);
    expect((await runIn(['session', 'import'])).code).toBe(0);
    fs.writeFileSync(path.join(root, 'docs', 'page.md'), `# Long\n\n${NEW}\n\nA short paragraph.\n`);

    const [second] = batchesIn((await runIn(['session', 'export'])).out);
    const text = fs.readFileSync(sessionWork('batches', second, 'task.json'), 'utf8');
    const task = JSON.parse(text);
    const segment = task.chunks.flatMap((c) => c.segments).find((s) => s.id === keyOf(NEW));
    expect(segment.earlier).toBe(OLD);
    expect(Object.keys(segment.revise)).toEqual(SIX);
    for (const lang of SIX) expect(segment.revise[lang]).toEqual({ translation: `${OLD} ⟨${lang}⟩` });
    // The earlier source is in the file once, not once per locale.
    expect(text.split(JSON.stringify(OLD)).length - 1).toBe(1);
    // No line holds more than one text: the longest is a translation of the paragraph, with its key and indentation.
    const longest = Buffer.byteLength(JSON.stringify(`${OLD} ⟨it⟩`), 'utf8') + 40;
    for (const line of text.split('\n')) expect(Buffer.byteLength(line, 'utf8')).toBeLessThanOrEqual(longest);

    translate(second);
    expect((await runIn(['session', 'import'])).code).toBe(0);
    const machine = JSON.parse(fs.readFileSync(path.join(root, 'memory', 'machine', 'de.json'), 'utf8'));
    expect(machine[keyOf(NEW)]).toMatchObject({ text: `${NEW} ⟨de⟩`, revision: { from: keyOf(OLD) } });
  });

  it('keeps an entry’s own source when a locale revises another earlier version, and none for a revision of the current source', () => {
    const out = taskRevisions('new', {
      it: { source: 'old', translation: 'vecchio' },
      de: { source: 'older', translation: 'älter', reviewed: true },
      fr: { source: 'new', translation: 'nouveau', forced: true, reason: 'too literal' },
    });
    expect(out).toEqual({
      earlier: 'old',
      revise: { it: { translation: 'vecchio' }, de: { translation: 'älter', reviewed: true, source: 'older' }, fr: { translation: 'nouveau', reason: 'too literal' } },
    });
  });
});

describe('l10n session check: a batch’s output files read without importing them', () => {
  it('passes a batch whose files are complete and would be accepted, writing nothing', async () => {
    const [batch] = batchesIn((await run(['session', 'export', '--batches', '50'])).out);
    agent(batch);
    const before = snapshot(memory());
    const r = await run(['session', 'check', batch]);
    expect(r.code).toBe(0);
    expect(r.out).toMatch(/^ {2}it: \d+ requested, \d+ written: nothing to fix\.$/m);
    expect(r.out).toContain(`session check: batch ${batch}: every output file is complete, and the import would accept every segment.`);
    expect(snapshot(memory())).toEqual(before);
  });

  it('names what is missing, not asked for, malformed or would be rejected, with the import’s own verdict, and exits 1', async () => {
    const [batch] = batchesIn((await run(['session', 'export', '--batches', '50'])).out);
    const lossy = (source, lang) => (lang === 'it' ? source.replace('`planted_inline_code`', 'planted inline code') : `${source} ⟨${lang}⟩`);
    const task = agent(batch, { answer: lossy, skip: ['de'] });
    const plan = readJson(work('batches', batch, 'plan.json'));
    const ids = plan.requested.it;
    const planted = ids.find((id) => plan.items[id].source.includes('`planted_inline_code`'));
    const dropped = ids.filter((id) => id !== planted).at(-1);
    // Drop one segment, add one never asked for, and break a header and the file's start.
    const lines = fs.readFileSync(task.output.it, 'utf8').split('\n');
    const start = lines.indexOf(`@@@ ${dropped}`);
    let end = start + 1;
    while (end < lines.length && !lines[end].startsWith('@@@ ')) end++;
    const kept = [...lines.slice(0, start), ...lines.slice(end)];
    fs.writeFileSync(task.output.it, ['Here are the translations:', ...kept, '@@@ ffffffffffffffff', 'Extra.', '@@@', 'Orphan line.'].join('\n') + '\n');
    const before = snapshot(memory());

    const r = await run(['session', 'check', batch]);
    expect(r.code).toBe(1);
    expect(r.out).toContain(`  de: ${plan.requested.de.length} requested; no output file ${work('batches', batch, 'de.txt')}`);
    expect(r.out).toMatch(/^ {2}it: \d+ requested, \d+ written: 1 missing, 1 not asked for, 2 malformed line\(s\), 0 written more than once; 2 would be rejected$/m);
    expect(r.out).toContain(`    missing: ${dropped}`);
    expect(r.out).toContain('    not asked for, so the import drops them: ffffffffffffffff');
    expect(r.out).toContain('    line 1: "Here are the translations:": it comes before the first "@@@ <id>" line, so it is ignored');
    expect(r.out).toMatch(/ {4}line \d+: "@@@": it begins with @@@ but is not "@@@ <id>", so it is read as part of the translation before it/);
    expect(r.out).toMatch(new RegExp(` {4}would be rejected: ${planted}: .*\`planted_inline_code\``));
    expect(r.out).toMatch(new RegExp(`session check: batch ${batch}: (it, de|de, it) have something to fix; the import would reject 2 segment\\(s\\)\\.`));
    expect(snapshot(memory())).toEqual(before);

    // The import judges the files exactly as the check said it would.
    await run(['session', 'import', '--batch', batch]);
    const queue = readJson(work('queue.json'));
    const rejected = [...r.out.matchAll(/would be rejected: ([0-9a-f]+): (.*)$/gm)].map((m) => [m[1], m[2]]);
    for (const [id, defect] of rejected) expect(queue.it[id].defect).toBe(defect);
  });

  it('refuses a batch that does not exist, and a call naming none', async () => {
    const missing = await run(['session', 'check', '0042']);
    expect(missing.code).toBe(2);
    expect(missing.err).toContain('session check: there is no batch 0042');
    expect((await run(['session', 'check'])).code).toBe(2);
  });

  it('reads the lines the format cannot read as meant', () => {
    expect(malformedLines('@@@ aaaa\nfine\n@@@  \n@@@bbbb\n')).toEqual([
      { line: 3, text: '@@@  ', why: 'it begins with @@@ but is not "@@@ <id>", so it is read as part of the translation before it' },
      { line: 4, text: '@@@bbbb', why: 'it begins with @@@ but is not "@@@ <id>", so it is read as part of the translation before it' },
    ]);
    expect(malformedLines('\n\n@@@ aaaa\nx\n')).toEqual([]);
  });
});

describe('l10n session import: the rejection alarm halts the session under stopSubmissions', () => {
  it('warns of a batch rejected far more often than the recent ones, and session export refuses until --resume', async () => {
    const configFile = path.join(project, 'l10n.config.json');
    writeJson(configFile, { ...readJson(configFile), backend: { kind: 'anthropic', alarm: { minPairs: 5, stopSubmissions: true } } });
    const store = createStore({ baseDir: memory() });
    for (let i = 0; i < 3; i++) {
      const items = Array.from({ length: 49 }, (_, k) => ({ srcHash: `a${k}`, lang: 'it', source: 's', text: 't', status: 'machine', attempt: 1 }));
      const failures = [{ srcHash: 'r', lang: 'it', error: 'the translation is empty', attempt: 1 }];
      store.appendJobLog({ id: `session-old-${i}`, at: `2026-10-0${i + 1}T00:00:00.000Z`, trigger: 'session', items, failures, exhausted: [], result: 'partial' });
    }
    const [batch] = batchesIn((await run(['session', 'export', '--batches', '50'])).out);
    agent(batch, { answer: (source, lang) => (lang === 'it' ? '' : `${source} ⟨${lang}⟩`) });
    const io = capture();
    expect(await runCli(['session', 'import'], { cwd: project, env: {}, log: io.log, errlog: io.errlog })).toBe(0);
    expect(io.errors()).toMatch(new RegExp(`session import: batch ${batch}: rejection alarm: \\d+ of \\d+ judged pairs were rejected`));
    expect(io.errors()).toMatch(/× the translation is empty; for example it [0-9a-f]+: the translation is empty/);
    expect(readJson(work('halt.json'))).toMatchObject({ batch, kind: 'rejections' });
    const job = fs.readdirSync(memory('jobs')).map((f) => readJson(memory('jobs', f))).find((j) => j.id.startsWith(`session-${batch}-`));
    expect(job.alarm.kinds[0]).toMatchObject({ kind: 'the translation is empty' });

    const refused = await run(['session', 'export']);
    expect(refused.code).toBe(1);
    expect(refused.err).toContain(`session export: the session is halted since`);
    expect(refused.err).toContain('then run `l10n session export --resume`. No batch written.');
    expect((await run(['session', 'status'])).out).toContain('`l10n session export --resume` writes batches again once the cause is found.');

    const resumed = await run(['session', 'export', '--resume']);
    expect(resumed.code).toBe(0);
    expect(resumed.out).toContain('session export: --resume: the halt is cleared');
    expect(batchesIn(resumed.out).length).toBeGreaterThan(0);
    expect(fs.existsSync(work('halt.json'))).toBe(false);
  });
});

describe('l10n session status: progress, and the queue entries that no longer stand for work', () => {
  it('prints each locale’s progress against the catalogue, by words, and a total', async () => {
    for (let round = 0; round < 10; round++) {
      const batches = batchesIn((await run(['session', 'export', '--batches', '50', '--targets', 'it'])).out);
      if (batches.length === 0) break;
      for (const batch of batches) agent(batch);
      await run(['session', 'import']);
    }
    const r = await run(['session', 'status']);
    expect(r.out).toContain('session status: progress against the catalogue of the last extract, per locale:');
    const units = Object.values(readJson(memory('source.json')).units);
    const words = units.reduce((n, u) => n + (u.source.match(/[\p{L}\p{N}]+/gu) || []).length, 0);
    expect(r.out).toContain(`  it: 100.0% done by words; translated ${units.length} of ${units.length} segments, ${words} of ${words} words; missing 0 segments, 0 words; 0 left out, 0 queued`);
    expect(r.out).toContain(`  de: 0.0% done by words; translated 0 of ${units.length} segments, 0 of ${words} words; missing ${units.length} segments, ${words} words; 0 left out, 0 queued`);
    expect(r.out).toContain(
      `  total over 2 locales: 50.0% done by words; translated ${units.length} of ${2 * units.length} segments, ${words} of ${2 * words} words; missing ${units.length} segments, ${words} words; 0 left out, 0 queued`
    );
  });

  it('names a queued segment translated since, and one a recorded Message Batch holds; requeue --prune removes them', async () => {
    const [batch] = batchesIn((await run(['session', 'export', '--batches', '50'])).out);
    // Every Italian and German segment of the batch is rejected, so the session queue holds them all.
    agent(batch, { answer: () => '' });
    await run(['session', 'import']);
    const queue = readJson(work('queue.json'));
    const [translated, held] = Object.keys(queue.it);
    // One is translated meanwhile, by a person; a recorded Message Batch requests another.
    writeJson(memory('messages', 'it.json'), { [translated]: { text: 'Tradotto a mano.', status: 'human' } });
    writeJson(memory('pending.json'), { batches: [{ id: 'msgbatch_x', createdAt: '2026-10-20T00:00:00Z', requests: { '000000-it': { lang: 'it', ids: [held], attempt: 1 } } }], queue: {} });

    const status = await run(['session', 'status']);
    expect(status.out).toContain(`session status: 2 entries of ${work('queue.json')} no longer stand for work; \`l10n requeue --prune\` removes them:`);
    expect(status.out).toContain(`  it ${translated}: already translated`);
    expect(status.out).toContain(`  it ${held}: held by a recorded Message Batch`);

    const before = snapshot(memory());
    const dry = await run(['requeue', '--prune', '--dry-run', '--session']);
    expect(dry.code).toBe(0);
    expect(dry.out).toContain(`requeue --prune: ${work('queue.json')}: would remove 2 entries that no longer stand for work.`);
    expect(snapshot(memory())).toEqual(before);

    const pruned = await run(['requeue', '--prune', '--session']);
    expect(pruned.out).toContain(`requeue --prune: ${work('queue.json')}: removed 2 entries that no longer stand for work.`);
    const after = readJson(work('queue.json'));
    expect(after.it[translated]).toBeUndefined();
    expect(after.it[held]).toBeUndefined();
    expect(Object.keys(after.it)).toHaveLength(Object.keys(queue.it).length - 2);
    expect(after.de).toEqual(queue.de);
    expect((await run(['session', 'status'])).out).not.toContain('no longer stand for work');
  });
});
