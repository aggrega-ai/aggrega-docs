import '../test/no-network.mjs';
import { describe, it, expect, beforeEach, afterEach } from 'vitest';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { recordCopies } from '@cognitio/languages';

import { runCli } from './cli.mjs';
import { findRevisions } from './revisions.mjs';
import { createStore, stableStringify } from './store.mjs';
import { LOCK_FILE } from './lock.mjs';
import { keyOf } from './normalize.mjs';
import { LAYER } from './types.mjs';
import { createAdapter } from './adapters/index.mjs';
import { loadConfig } from './config.mjs';
import { capture, copyFixtureProject, writeJson } from '../test/helpers.mjs';

const MODULE = '@cognitio/legal';
const TARGETS = ['content/en/home.json', 'ui/en.json'];

let dir;
let memory;

beforeEach(() => {
  dir = copyFixtureProject('l10n-seed-machine-');
  memory = path.join(dir, 'memory');
  writeJson(path.join(dir, 'package.json'), { name: 'site' });
});

afterEach(() => {
  fs.rmSync(dir, { recursive: true, force: true });
});

const readJson = (rel) => JSON.parse(fs.readFileSync(path.join(dir, rel), 'utf8'));
const exists = (rel) => fs.existsSync(path.join(dir, rel));

/**
 * Every string of a parsed JSON value as `[key path, text]`, the key path in the
 * form the record of copied texts writes (`blocks[0].data.heading`, a key that is
 * not a plain name quoted: `["nav.backToTop"]`), as `cognitio-languages copy`
 * records a whole file.
 */
function stringsOf(value, at = '') {
  if (typeof value === 'string') return [[at, value]];
  if (Array.isArray(value)) return value.flatMap((item, i) => stringsOf(item, `${at}[${i}]`));
  if (value && typeof value === 'object') {
    return Object.entries(value).flatMap(([key, item]) =>
      stringsOf(item, /^[A-Za-z_$][\w$-]*$/.test(key) ? (at === '' ? key : `${at}.${key}`) : `${at}[${JSON.stringify(key)}]`)
    );
  }
  return [];
}

/** Installs the module at `version` in the project, shipping the target's file, and records every text of `target` as copied from it. */
function recordCopy(target, version) {
  const shipped = `shipped/${target.replace(/\//g, '-')}`;
  const root = path.join(dir, 'node_modules', ...MODULE.split('/'));
  fs.mkdirSync(path.join(root, path.dirname(shipped)), { recursive: true });
  fs.copyFileSync(path.join(dir, target), path.join(root, shipped));
  writeJson(path.join(root, 'package.json'), { name: MODULE, version });
  const entries = stringsOf(readJson(target)).map(([at, text]) => ({ target, package: MODULE, version, file: shipped, path: at, text }));
  recordCopies(dir, entries);
}

const run = (argv, deps = {}) => {
  const io = capture();
  return runCli(argv, { cwd: dir, env: {}, log: io.log, errlog: io.errlog, ...deps }).then((code) => ({ code, io }));
};

describe('seed --layer machine', () => {
  it('writes machine/<lang>.json with status machine and machine/_source.json', async () => {
    TARGETS.forEach((t) => recordCopy(t, '1.1.0'));
    const { code, io } = await run(['seed', '--layer', 'machine', '--targets', 'en']);
    expect(code, io.errors()).toBe(0);
    const layer = readJson('memory/machine/en.json');
    const key = keyOf('Benvenuti');
    expect(layer[key]).toMatchObject({ text: 'Welcome', status: 'machine', srcHash: key, job: 'seed' });
    expect(typeof layer[key].at).toBe('string');
    expect(Object.values(layer).every((e) => e.status === 'machine')).toBe(true);
    expect(readJson('memory/machine/_source.json')[key]).toBe('Benvenuti');
    expect(exists('memory/messages/en.json')).toBe(true);
    const human = readJson('memory/messages/en.json');
    expect(Object.keys(layer).some((k) => k in human)).toBe(false);
  });

  it('records each entry’s module and version from copied-texts.json', async () => {
    recordCopy('content/en/home.json', '1.1.0');
    recordCopy('ui/en.json', '1.1.0');
    // A file copied again at another version carries that version.
    recordCopy('ui/en.json', '1.2.0');
    const { code, io } = await run(['seed', '--layer', 'machine', '--targets', 'en']);
    expect(code, io.errors()).toBe(0);
    const layer = readJson('memory/machine/en.json');
    const uiKey = keyOf('Torna su');
    const pageKey = keyOf('Benvenuti');
    expect(layer[pageKey].origin).toBe(`${MODULE}@1.1.0`);
    expect(layer[uiKey].origin).toBe(`${MODULE}@1.2.0`);
  });

  it('a language none of whose target files copied-texts.json records stops seed --layer machine, naming cognitio-languages copy', async () => {
    // The record holds a copy, but no target file of `en`.
    writeJson(path.join(dir, 'other', 'it.json'), { title: 'Altro' });
    recordCopy('other/it.json', '1.1.0');
    const { code, io } = await run(['seed', '--layer', 'machine', '--targets', 'en']);
    expect(code).toBe(2);
    expect(io.errors()).toContain('no target file of en');
    expect(io.errors()).toContain('cognitio-languages copy');
    expect(io.errors()).toContain('memory layers are unchanged');
    expect(exists('memory/machine')).toBe(false);
    expect(exists(`memory/${LOCK_FILE}`)).toBe(false);
  });

  it('a project with no record stops it the same way', async () => {
    const { code, io } = await run(['seed', '--layer', 'machine', '--targets', 'en']);
    expect(code).toBe(2);
    expect(io.errors()).toContain('cognitio-languages copy');
    expect(exists('memory/machine')).toBe(false);
  });

  it('seeds the copied target files and leaves out, listed, a target file the record does not hold', async () => {
    recordCopy('content/en/home.json', '1.1.0');
    // The UI dictionary was translated by a run: its entries are the machine's own.
    const ui = readJson('ui/en.json');
    const runEntries = Object.fromEntries(
      Object.entries(readJson('ui/it.json')).map(([k, source]) => [keyOf(source), { text: ui[k], status: 'machine', srcHash: keyOf(source), job: 'j1', at: 'T' }])
    );
    writeJson(path.join(memory, 'machine', 'en.json'), runEntries);
    const { code, io } = await run(['seed', '--layer', 'machine', '--targets', 'en']);
    expect(code, io.errors()).toBe(0);
    const layer = readJson('memory/machine/en.json');
    expect(layer[keyOf('Benvenuti')]).toMatchObject({ text: 'Welcome', job: 'seed', origin: `${MODULE}@1.1.0` });
    for (const [key, entry] of Object.entries(runEntries)) expect(layer[key]).toEqual(entry);
    expect(io.text()).toContain('ui/en.json');
    expect(io.text()).toContain('not recorded in copied-texts.json');
  });

  it('a re-seed after a section was retranslated keeps the run’s entry and lists the section', async () => {
    TARGETS.forEach((t) => recordCopy(t, '1.1.0'));
    expect((await run(['seed', '--layer', 'machine', '--targets', 'en'])).code).toBe(0);
    // The project edits the source of the heading; a run translates it as a revision of the seeded text,
    // and materialize writes the translation into the copy.
    const edited = 'Ciao a tutti';
    const source = readJson('content/it/home.json');
    source.blocks[0].data.heading = edited;
    writeJson(path.join(dir, 'content/it/home.json'), source);
    const target = readJson('content/en/home.json');
    target.blocks[0].data.heading = 'Hello everyone';
    writeJson(path.join(dir, 'content/en/home.json'), target);
    const key = keyOf(edited);
    const layerFile = path.join(memory, 'machine', 'en.json');
    const translated = { text: 'Hello everyone', status: 'machine', srcHash: key, job: 'j2', at: 'T', revision: { from: keyOf('Ciao mondo'), reviewed: false } };
    writeJson(layerFile, { ...readJson('memory/machine/en.json'), [key]: translated });
    const before = readJson('memory/machine/en.json');

    const { code, io } = await run(['seed', '--layer', 'machine', '--targets', 'en']);
    expect(code, io.errors()).toBe(0);
    const layer = readJson('memory/machine/en.json');
    expect(layer[key]).toEqual(translated);
    expect(layer).toEqual(before);
    expect(io.text()).toContain('content/en/home.json blocks[0].data.heading (customised)');
  });

  it('stops with exit 2 on a layer that is neither human nor machine', async () => {
    const { code, io } = await run(['seed', '--layer', 'reviewed', '--targets', 'en']);
    expect(code).toBe(2);
    expect(io.errors()).toContain('--layer');
  });

  it('a revision of a machine-seeded entry is not reviewed', async () => {
    TARGETS.forEach((t) => recordCopy(t, '1.1.0'));
    expect((await run(['seed', '--layer', 'machine', '--targets', 'en'])).code).toBe(0);
    const store = createStore({ baseDir: memory });
    const old = 'Benvenuti';
    const edited = 'Benvenuti, di nuovo';
    const revisions = findRevisions({
      worklist: { status: 'work', targets: ['en'], items: [{ srcHash: keyOf(edited), source: edited, format: 'text', missing: ['en'] }], orphans: [keyOf(old)] },
      tmByLang: store.readAllTM(['en']),
      sources: store.readRecordedSources(),
      targets: ['en'],
    });
    expect(revisions.en[keyOf(edited)]).toMatchObject({ from: keyOf(old), translation: 'Welcome', reviewed: false });
  });

  it('l10n review lists nothing for it', async () => {
    TARGETS.forEach((t) => recordCopy(t, '1.1.0'));
    expect((await run(['seed', '--layer', 'machine', '--targets', 'en'])).code).toBe(0);
    const { code, io } = await run(['review', '--targets', 'en']);
    expect(code).toBe(0);
    expect(io.text()).toContain('review: 0 machine translation(s)');
  });

  it('seed without --layer writes the human layer as today', async () => {
    const before = readJson('memory/messages/en.json');
    const { code, io } = await run(['seed', '--targets', 'en']);
    expect(code, io.errors()).toBe(0);
    const human = readJson('memory/messages/en.json');
    expect(human[keyOf('Benvenuti')]).toMatchObject({ text: 'Welcome', status: 'seed' });
    expect(human[keyOf('Benvenuti')].origin).toBeUndefined();
    expect(Object.keys(human).length).toBeGreaterThan(Object.keys(before).length);
    expect(exists('memory/machine')).toBe(false);
  });

  it('a key the human layer holds is left to it', async () => {
    TARGETS.forEach((t) => recordCopy(t, '1.1.0'));
    const held = keyOf('Benvenuti');
    const humanFile = path.join(memory, 'messages', 'en.json');
    const human = JSON.parse(fs.readFileSync(humanFile, 'utf8'));
    human[held] = { text: 'Welcome, hand-seeded', status: 'seed', srcHash: held };
    fs.writeFileSync(humanFile, stableStringify(human));
    const { code, io } = await run(['seed', '--layer', 'machine', '--targets', 'en']);
    expect(code, io.errors()).toBe(0);
    expect(readJson('memory/machine/en.json')[held]).toBeUndefined();
    expect(readJson('memory/messages/en.json')[held].text).toBe('Welcome, hand-seeded');
    expect(readJson('memory/machine/en.json')[keyOf('Torna su')]).toBeDefined();
  });

  it('seeding the same copies again changes no byte of the memory', async () => {
    TARGETS.forEach((t) => recordCopy(t, '1.1.0'));
    let tick = 0;
    const now = () => `2026-01-01T00:00:${String(tick++).padStart(2, '0')}.000Z`;
    expect((await run(['seed', '--layer', 'machine', '--targets', 'en'], { engineOptions: { now } })).code).toBe(0);
    const files = ['memory/machine/en.json', 'memory/machine/_source.json', 'memory/messages/_source.json'];
    const before = files.map((f) => fs.readFileSync(path.join(dir, f), 'utf8'));
    const again = await run(['seed', '--layer', 'machine', '--targets', 'en'], { engineOptions: { now } });
    expect(again.code, again.io.errors()).toBe(0);
    expect(files.map((f) => fs.readFileSync(path.join(dir, f), 'utf8'))).toEqual(before);
  });

  it('replaces a machine entry a translation run wrote for the same key', async () => {
    TARGETS.forEach((t) => recordCopy(t, '1.1.0'));
    const key = keyOf('Benvenuti');
    writeJson(path.join(memory, 'machine', 'en.json'), { [key]: { text: 'Welcome, machine', status: 'machine', srcHash: key, job: 'j1', at: 'T' } });
    expect((await run(['seed', '--layer', 'machine', '--targets', 'en'])).code).toBe(0);
    expect(readJson('memory/machine/en.json')[key]).toMatchObject({ text: 'Welcome', job: 'seed', origin: `${MODULE}@1.1.0` });
  });

  it('the lock is held while seeding', async () => {
    TARGETS.forEach((t) => recordCopy(t, '1.1.0'));
    // Held by another command: nothing is read or written.
    const lock = path.join(memory, LOCK_FILE);
    writeJson(lock, { command: 'collect', pid: 1, host: 'another-host', at: 'T' });
    const refused = await run(['seed', '--layer', 'machine', '--targets', 'en']);
    expect(refused.code).toBe(1);
    expect(refused.io.errors()).toContain('collect');
    expect(exists('memory/machine')).toBe(false);
    fs.rmSync(lock);

    // Held by the seed itself while it aligns and writes, and released after.
    const project = loadConfig({ configPath: path.join(dir, 'l10n.config.json') });
    const real = createAdapter({ project });
    let heldDuring = null;
    const adapter = Object.assign(Object.create(real), {
      seedAlign: (args) => {
        heldDuring = fs.existsSync(lock) ? JSON.parse(fs.readFileSync(lock, 'utf8')).command : null;
        return real.seedAlign(args);
      },
    });
    const { code, io } = await run(['seed', '--layer', 'machine', '--targets', 'en'], { adapter });
    expect(code, io.errors()).toBe(0);
    expect(heldDuring).toBe('seed');
    expect(fs.existsSync(lock)).toBe(false);
  });
});
