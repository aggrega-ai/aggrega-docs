import '../test/no-network.mjs';
import { describe, it, expect, beforeEach, afterEach } from 'vitest';
import fs from 'node:fs';
import path from 'node:path';

import { runCli } from './cli.mjs';
import { buildMessageParams, buildUserMessage } from './requests.mjs';
import { translationSettings } from './config.mjs';
import { MAX_OUTPUT_TOKENS, outputCeiling } from './tokens.mjs';
import { capture, copyFixtureProject, fakeAnthropic, requestBody, writeJson } from '../test/helpers.mjs';

const spec = (attempt, extra = {}) => ({
  page: 'p',
  section: null,
  lang: 'it',
  segments: [
    { id: 'a', format: 'text', source: 'Context.' },
    { id: 'b', format: 'text', source: 'Translate me.' },
  ],
  requested: ['b'],
  items: [{ srcHash: 'b', source: 'Translate me.', format: 'text' }],
  attempt,
  fallback: false,
  corrections: {},
  ...extra,
});

describe('the request marks each segment it asks for where it stands', () => {
  it('"translate": true on the requested segment, after its id, and on no context segment', () => {
    const context = JSON.parse(buildUserMessage(spec(1))[0].text);
    expect(context.segments).toEqual([
      { id: 'a', format: 'text', source: 'Context.' },
      { id: 'b', translate: true, format: 'text', source: 'Translate me.' },
    ]);
    expect(Object.keys(context.segments[1])[1]).toBe('translate');
  });
});

describe('backend.retryModel: a harder try for a hard segment', () => {
  const settings = (retryModel) =>
    translationSettings({ kind: 'anthropic', model: { id: 'claude-opus-5-5', effort: 'low', fallbackId: 'claude-sonnet-5-5' }, ...(retryModel ? { retryModel } : {}) });

  it('unset, every attempt runs on the model', () => {
    for (const attempt of [1, 2, 3]) {
      const params = buildMessageParams(spec(attempt), { model: settings().model, system: [] });
      expect(params.model).toBe('claude-opus-5-5');
      expect(params.output_config.effort).toBe('low');
    }
  });

  it('runs every resubmission on it by default, with its own effort and the largest max_tokens', () => {
    const { model } = settings({ id: 'claude-opus-5-5', effort: 'high' });
    expect(model.retry).toEqual({ id: 'claude-opus-5-5', effort: 'high', fromAttempt: 2 });
    const first = buildMessageParams(spec(1), { model, system: [] });
    expect(first.output_config.effort).toBe('low');
    expect(first.max_tokens).toBe(outputCeiling(['Translate me.']));
    const again = buildMessageParams(spec(2), { model, system: [] });
    expect(again.model).toBe('claude-opus-5-5');
    expect(again.output_config.effort).toBe('high');
    expect(again.max_tokens).toBe(MAX_OUTPUT_TOKENS);
  });

  it('runs from fromAttempt on: the last attempt alone, when it is backend.attempts', () => {
    const { model } = settings({ id: 'claude-opus-5-5', effort: 'max', fromAttempt: 3 });
    expect(buildMessageParams(spec(2), { model, system: [] }).output_config.effort).toBe('low');
    expect(buildMessageParams(spec(3), { model, system: [] }).output_config.effort).toBe('max');
  });

  it('leaves a refused request to the fallback model', () => {
    const { model } = settings({ id: 'claude-opus-5-5', effort: 'high' });
    const params = buildMessageParams(spec(2, { fallback: true }), { model, system: [] });
    expect(params.model).toBe('claude-sonnet-5-5');
    expect(params.output_config.effort).toBe('low');
  });

  it('a retry model that cannot reason keeps the ordinary ceiling', () => {
    const { model } = settings({ id: 'claude-sonnet-5-5', thinking: { type: 'disabled' } });
    const params = buildMessageParams(spec(2), { model, system: [] });
    expect(params.thinking).toEqual({ type: 'disabled' });
    expect(params.max_tokens).toBe(outputCeiling(['Translate me.'], { thinking: { type: 'disabled' } }));
  });
});

describe('backend.retryModel in a configuration', () => {
  let project;
  beforeEach(() => {
    project = copyFixtureProject('l10n-retry-');
  });
  afterEach(() => {
    fs.rmSync(project, { recursive: true, force: true });
  });
  const configPath = () => path.join(project, 'l10n.config.json');
  const memory = (...p) => path.join(project, 'memory', ...p);
  const editConfig = (mutate) => {
    const cfg = JSON.parse(fs.readFileSync(configPath(), 'utf8'));
    mutate(cfg);
    writeJson(configPath(), cfg);
  };
  async function run(argv, deps = {}) {
    const io = capture();
    const code = await runCli(argv, { cwd: project, env: { ANTHROPIC_API_KEY: 'test-key' }, log: io.log, errlog: io.errlog, ...deps });
    return { code, out: io.text(), err: io.errors() };
  }

  it('refuses a fromAttempt below 2 and a key it does not know, naming the key', async () => {
    editConfig((c) => (c.backend.retryModel = { id: 'claude-opus-5-5', fromAttempt: 1 }));
    expect((await run(['status'])).code).toBe(2);
    editConfig((c) => (c.backend.retryModel = { id: 'claude-opus-5-5', fallbackId: 'x' }));
    const r = await run(['status']);
    expect(r.code).toBe(2);
    expect(r.err).toContain('retryModel');
  });

  it('submit sends a resubmitted segment on the retry model, and the pending file records it', async () => {
    editConfig((c) => (c.backend.retryModel = { id: 'claude-sonnet-5-5', effort: 'high' }));
    expect((await run(['extract'])).code).toBe(0);
    const units = JSON.parse(fs.readFileSync(memory('source.json'), 'utf8')).units;
    const [retried] = Object.keys(units).filter((k) => units[k].source === 'Benvenuti');
    writeJson(memory('pending.json'), { batches: [], queue: { en: { [retried]: { attempts: 1, defect: 'the translation is empty' } } } });
    const fake = fakeAnthropic({ status: 'in_progress' });
    expect((await run(['submit'], { ClientClass: fake.FakeAnthropic })).code).toBe(0);
    const sent = fake.calls.batchCreate[0].requests.map((q) => q.params);
    const onRetry = sent.filter((p) => p.model === 'claude-sonnet-5-5');
    expect(onRetry.map((p) => requestBody(p).translate)).toEqual([expect.arrayContaining([retried])]);
    expect(onRetry[0].output_config.effort).toBe('high');
    expect(sent.filter((p) => !requestBody(p).translate.includes(retried)).every((p) => p.model !== 'claude-sonnet-5-5')).toBe(true);
    const recorded = Object.values(JSON.parse(fs.readFileSync(memory('pending.json'), 'utf8')).batches[0].requests);
    expect(recorded.find((q) => q.ids.includes(retried)).model).toBe('claude-sonnet-5-5');
  });
});
