import '../test/no-network.mjs';
import { describe, it, expect, beforeEach, afterEach } from 'vitest';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';

import { runCli } from './cli.mjs';
import { keyOf, normalize, usageKeyOf } from './normalize.mjs';
import { createIdentity, TEXT_IDENTITY } from './adapters/json-content/identity.mjs';
import { buildSystem, buildUserMessage, planRequests, REFERENCE_LIMIT } from './requests.mjs';
import { generalRules, PATH_SENTENCE, REFERENCES_SENTENCE } from './translator-prompt.mjs';
import { sessionInstructions } from './session.mjs';
import { rekeyByLang, rekeyLayer, rekeyMap } from './rekey.mjs';
import { narrowRequest } from './backends/claude-code.mjs';
import { capture, fakeAnthropic, replyMessage, requestBody, writeJson } from '../test/helpers.mjs';

// One English text under three dictionary keys and one content leaf, each Italian translation of its own gender or number.
const ACTIVE = 'Active';
const UI_SOURCE = { 'filter.product': ACTIVE, 'filter.campaign': ACTIVE, 'filter.users': ACTIVE, 'nav.welcome': 'Welcome' };
const UI_TARGET = { 'filter.product': 'Attivo', 'filter.campaign': 'Attiva', 'filter.users': 'Attivi', 'nav.welcome': 'Benvenuto' };
const CONTENT_SOURCE = { badge: { state: ACTIVE }, title: 'Welcome' };
const CONTENT_TARGET = { badge: { state: 'Attiva' }, title: 'Benvenuto' };
const UI_LABEL = 'ui/en.json';
const CONTENT_FILE = 'content/en/labels.json';

let project;
const at = (...p) => path.join(project, ...p);
const memory = (...p) => at('memory', ...p);
const readJson = (file) => JSON.parse(fs.readFileSync(file, 'utf8'));
const layer = (name, lang = 'it') => (fs.existsSync(memory(name, `${lang}.json`)) ? readJson(memory(name, `${lang}.json`)) : {});
const uiKey = (dictKey, text = ACTIVE) => usageKeyOf(text, UI_LABEL, dictKey);
const contentKey = (leaf, text = ACTIVE) => usageKeyOf(text, CONTENT_FILE, leaf);

/** A JSON-content project, English into Italian, in the local mode: whole documents and a flat UI dictionary, both translated by hand. */
function makeProject({ identity } = {}) {
  project = fs.mkdtempSync(path.join(os.tmpdir(), 'l10n-identity-'));
  writeConfig({ identity });
  writeJson(at('content', 'en', 'labels.json'), CONTENT_SOURCE);
  writeJson(at('content', 'it', 'labels.json'), CONTENT_TARGET);
  writeJson(at('ui', 'en.json'), UI_SOURCE);
  writeJson(at('ui', 'it.json'), UI_TARGET);
  fs.mkdirSync(memory('prompts'), { recursive: true });
  fs.writeFileSync(memory('prompts', 'it.md'), 'Italiano, registro neutro.\n');
}

function writeConfig({ identity } = {}) {
  writeJson(at('l10n.config.json'), {
    locales: { source: 'en', targets: ['it'] },
    memory: { dir: 'memory' },
    mode: 'local',
    adapter: {
      kind: 'json-content',
      ...(identity ? { identity } : {}),
      content: { source: 'content/{lang}', target: 'content/{lang}', staging: 'memory/generated/content/{lang}' },
      ui: { source: 'ui/{lang}.json', target: 'ui/{lang}.json', staging: 'memory/generated/ui/{lang}.json' },
      document: { walk: 'whole' },
      output: { langField: false, keyOrder: 'source', materialize: 'safe' },
      fields: {
        denylistKeys: [],
        pageFields: {},
        valueGuards: { refPrefixes: ['/'], assetExtensions: [], excludeNumbers: true, excludeBooleans: true },
      },
    },
    backend: { kind: 'anthropic' },
  });
}

async function run(argv, deps = {}) {
  const io = capture();
  const code = await runCli(argv, { cwd: project, env: { ANTHROPIC_API_KEY: 'test-key' }, log: io.log, errlog: io.errlog, ...deps });
  return { code, out: io.text(), err: io.errors() };
}

afterEach(() => {
  if (project) fs.rmSync(project, { recursive: true, force: true });
  project = null;
});

describe('the identity of a segment: its text, or its text and its usage', () => {
  it('the text identity is keyOf of the source, whatever the usage', () => {
    expect(TEXT_IDENTITY.content('a.json', 'x.y', ACTIVE)).toBe(keyOf(ACTIVE));
    expect(TEXT_IDENTITY.ui('filter.users', ` ${ACTIVE}\n`)).toBe(keyOf(ACTIVE));
    expect(createIdentity()).toBe(TEXT_IDENTITY);
  });

  it('text+path keys one text under two keys, or two files, as two segments, and one usage always alike', () => {
    const keys = createIdentity({ identity: 'text+path', contentLabel: 'content/en', uiLabel: UI_LABEL });
    expect(keys.byPath).toBe(true);
    expect(keys.ui('filter.product', ACTIVE)).toBe(uiKey('filter.product'));
    expect(keys.ui('filter.product', ACTIVE)).not.toBe(keys.ui('filter.users', ACTIVE));
    expect(keys.content('labels.json', 'badge.state', ACTIVE)).toBe(contentKey('badge.state'));
    expect(keys.content('labels.json', 'badge.state', ACTIVE)).not.toBe(keys.content('other.json', 'badge.state', ACTIVE));
    // The source is normalized as for keyOf; the key is as long as keyOf's, and never keyOf's.
    expect(keys.ui('filter.product', ` ${ACTIVE} `)).toBe(keys.ui('filter.product', ACTIVE));
    expect(uiKey('filter.product')).toMatch(/^[0-9a-f]{16}$/);
    expect(uiKey('filter.product')).not.toBe(keyOf(ACTIVE));
    expect(() => createIdentity({ identity: 'path' })).toThrow(/not supported/);
  });

  it('the configuration takes "text" and "text+path" under adapter.identity, and refuses any other value', async () => {
    makeProject({ identity: 'text+path' });
    expect((await run(['extract'])).code).toBe(0);
    writeConfig({ identity: 'path' });
    const refused = await run(['extract']);
    expect(refused.code).toBe(2);
    expect(refused.err).toMatch(/adapter\.identity/);
  });
});

describe('extract: one unit per text, or one per usage', () => {
  it('the default collapses the four usages of one text onto one unit, as 1.3.7 did', async () => {
    makeProject();
    await run(['extract']);
    const { units } = readJson(memory('source.json'));
    expect(Object.keys(units).sort()).toEqual([keyOf(ACTIVE), keyOf('Welcome')].sort());
    expect(units[keyOf(ACTIVE)].usages).toHaveLength(4);
  });

  it('text+path gives each usage its own unit, its source recorded under its key', async () => {
    makeProject({ identity: 'text+path' });
    await run(['extract']);
    const { units } = readJson(memory('source.json'));
    expect(Object.keys(units)).toHaveLength(6);
    for (const key of ['filter.product', 'filter.campaign', 'filter.users'].map((k) => uiKey(k))) {
      expect(units[key]).toMatchObject({ source: ACTIVE, usages: [{ file: UI_LABEL }] });
    }
    expect(units[contentKey('badge.state')]).toMatchObject({ source: ACTIVE, usages: [{ file: CONTENT_FILE, path: 'badge.state' }] });
    expect(readJson(memory('messages', '_source.json'))[uiKey('filter.users')]).toBe(ACTIVE);
  });
});

describe('seed, gate and materialize under text+path', () => {
  it('the default seed keeps the first target text of the text and reports the others as collisions', async () => {
    makeProject();
    expect((await run(['seed', '--targets', 'it'])).code).toBe(0);
    const report = readJson(memory('seed-report.json'));
    expect(report.counts.collisions).toBe(2);
    expect(layer('messages')[keyOf(ACTIVE)].text).toBe('Attiva');
  });

  it('seeds each key with its own target text, with no collision, and gate finds nothing missing', async () => {
    makeProject({ identity: 'text+path' });
    await run(['extract']);
    expect((await run(['seed', '--targets', 'it'])).code).toBe(0);
    const report = readJson(memory('seed-report.json'));
    expect(report.counts).toMatchObject({ seeded: 6, collisions: 0 });
    const human = layer('messages');
    expect(human[uiKey('filter.product')]).toMatchObject({ text: 'Attivo', status: 'seed', srcHash: uiKey('filter.product') });
    expect(human[uiKey('filter.campaign')].text).toBe('Attiva');
    expect(human[uiKey('filter.users')].text).toBe('Attivi');
    expect(human[contentKey('badge.state')].text).toBe('Attiva');
    expect((await run(['gate', '--check'])).code).toBe(0);
  });

  it('materialize writes the three translations to their keys, under the safe policy, and the drift guard is quiet', async () => {
    makeProject({ identity: 'text+path' });
    await run(['extract']);
    await run(['seed', '--targets', 'it']);
    fs.rmSync(at('ui', 'it.json'));
    fs.rmSync(at('content', 'it', 'labels.json'));
    const r = await run(['materialize']);
    expect(r.code).toBe(0);
    expect(readJson(at('ui', 'it.json'))).toEqual(UI_TARGET);
    expect(readJson(at('content', 'it', 'labels.json'))).toEqual(CONTENT_TARGET);
    expect((await run(['verify-drift'])).code).toBe(0);
    // generate writes the same into the staging area.
    await run(['generate']);
    expect(readJson(memory('generated', 'ui', 'it.json'))).toEqual(UI_TARGET);
  });

  it('the drift guard flags a hand edit of one key, and safe materialize keeps that file', async () => {
    makeProject({ identity: 'text+path' });
    await run(['extract']);
    await run(['seed', '--targets', 'it']);
    writeJson(at('ui', 'it.json'), { ...UI_TARGET, 'filter.users': 'Attive a mano' });
    expect((await run(['verify-drift'])).code).toBe(1);
    const r = await run(['materialize']);
    expect(r.out).toMatch(/left as it is: .*ui\/it\.json/);
    expect(readJson(at('ui', 'it.json'))['filter.users']).toBe('Attive a mano');
  });
});

/** A text+path project seeded, then one key's translation removed, so it alone is missing. */
async function oneKeyMissing(dictKey = 'filter.users') {
  makeProject({ identity: 'text+path' });
  await run(['extract']);
  await run(['seed', '--targets', 'it']);
  const human = layer('messages');
  delete human[uiKey(dictKey)];
  writeJson(memory('messages', 'it.json'), human);
}

describe('a request under text+path: the key path as context, the other keys’ translations as references', () => {
  const page = {
    id: UI_LABEL,
    segments: ['filter.product', 'filter.campaign', 'filter.users'].map((k) => ({ key: uiKey(k), source: ACTIVE, format: 'text', context: `ui:${k}`, path: k, section: 'filter' })),
  };
  const worklist = { status: 'work', items: [{ srcHash: uiKey('filter.users'), source: ACTIVE, format: 'text', missing: ['it'] }], orphans: [] };
  const tmByLang = { it: { [uiKey('filter.product')]: { text: 'Attivo' }, [uiKey('filter.campaign')]: { text: 'Attiva' } } };

  it('plans each segment with its path and the requested one with the translations of the same text', () => {
    const { specs } = planRequests({ pages: [page], worklist, tmByLang, targets: ['it'], sectionTokens: 8000, attemptLimit: 3 });
    expect(specs).toHaveLength(1);
    const [context, request] = buildUserMessage(specs[0]).map((b) => JSON.parse(b.text));
    expect(context.segments.map((s) => s.path)).toEqual(['filter.product', 'filter.campaign', 'filter.users']);
    expect(context.segments[2]).toEqual({ id: uiKey('filter.users'), translate: true, format: 'text', context: 'ui:filter.users', path: 'filter.users', source: ACTIVE });
    expect(request.references).toEqual({
      [uiKey('filter.users')]: [
        { page: UI_LABEL, path: 'filter.product', translation: 'Attivo' },
        { page: UI_LABEL, path: 'filter.campaign', translation: 'Attiva' },
      ],
    });
  });

  it('offers each distinct translation once, at most REFERENCE_LIMIT, and none for a text no other key translates', () => {
    const many = { id: 'p', segments: Array.from({ length: 12 }, (_, i) => ({ key: `k${i}`, source: ACTIVE, format: 'text', path: `a[${i}]`, section: 'a' })) };
    const tm = { it: Object.fromEntries(Array.from({ length: 11 }, (_, i) => [`k${i + 1}`, { text: i < 2 ? 'Attivo' : `Attivo ${i}` }])) };
    const wl = { status: 'work', items: [{ srcHash: 'k0', source: ACTIVE, format: 'text', missing: ['it'] }], orphans: [] };
    const { specs } = planRequests({ pages: [many], worklist: wl, tmByLang: tm, targets: ['it'], sectionTokens: 8000, attemptLimit: 3 });
    expect(specs[0].references.k0).toHaveLength(REFERENCE_LIMIT);
    expect(new Set(specs[0].references.k0.map((r) => r.translation)).size).toBe(REFERENCE_LIMIT);
    const alone = planRequests({ pages: [page], worklist, tmByLang: { it: {} }, targets: ['it'], sectionTokens: 8000, attemptLimit: 3 });
    expect(alone.specs[0].references).toBeUndefined();
  });

  it('a page view without paths plans the same request it planned before, with neither path nor references', () => {
    const plain = { id: UI_LABEL, segments: page.segments.map(({ path: _p, ...s }) => ({ ...s, key: keyOf(ACTIVE) })).slice(0, 1) };
    const wl = { status: 'work', items: [{ srcHash: keyOf(ACTIVE), source: ACTIVE, format: 'text', missing: ['it'] }], orphans: [] };
    const { specs } = planRequests({ pages: [plain], worklist: wl, tmByLang: { it: {} }, targets: ['it'], sectionTokens: 8000, attemptLimit: 3 });
    expect(specs[0].references).toBeUndefined();
    expect(buildUserMessage(specs[0])[0].text).not.toContain('"path"');
  });

  it('the general rules describe path and references under text+path alone; the default rules are unchanged', () => {
    const base = { lang: 'it', sourceLang: 'en' };
    expect(generalRules(base)).toBe(generalRules({ ...base, identity: 'text' }));
    expect(generalRules(base)).not.toContain('"path"');
    expect(generalRules(base)).not.toContain('"references"');
    const byPath = generalRules({ ...base, identity: 'text+path' });
    expect(byPath).toContain(PATH_SENTENCE);
    expect(byPath).toContain(REFERENCES_SENTENCE);
    expect(byPath).toContain('"path"?: string');
    expect(buildSystem({ ...base, languagePrompt: 'x', identity: 'text+path' })[0].text).toBe(byPath);
    expect(sessionInstructions({ sourceLang: 'en', targets: ['it'], prompts: { it: 'x' } })).not.toContain(PATH_SENTENCE);
    expect(sessionInstructions({ sourceLang: 'en', targets: ['it'], prompts: { it: 'x' }, identity: 'text+path' })).toContain(REFERENCES_SENTENCE);
  });

  it('a request narrowed for the Claude Code backend keeps only its own identifiers’ references', () => {
    const spec = { requested: ['a', 'b'], items: [{ srcHash: 'a' }, { srcHash: 'b' }], keep: {}, corrections: {}, references: { a: [1], b: [2] } };
    expect(narrowRequest(spec, ['b']).references).toEqual({ b: [2] });
  });

  it('translate sends the path, the references and the rules that describe them, and writes the key alone', async () => {
    await oneKeyMissing();
    const fake = fakeAnthropic({ reply: (params) => replyMessage(requestBody(params).translate.map((id) => ({ id, text: 'Attivi' }))) });
    const r = await run(['translate'], { ClientClass: fake.FakeAnthropic });
    expect(r.code).toBe(0);
    expect(fake.calls.create).toHaveLength(1);
    const params = fake.calls.create[0];
    const body = requestBody(params);
    expect(body.translate).toEqual([uiKey('filter.users')]);
    expect(body.segments.find((s) => s.id === uiKey('filter.users')).path).toBe('filter.users');
    // In page order: the content file before the dictionary, each distinct translation once.
    expect(body.references[uiKey('filter.users')].map((x) => x.translation)).toEqual(['Attiva', 'Attivo']);
    expect(params.system[0].text).toContain(PATH_SENTENCE);
    expect(layer('machine')[uiKey('filter.users')]).toMatchObject({ text: 'Attivi', srcHash: uiKey('filter.users') });
    expect(layer('machine')[uiKey('filter.product')]).toBeUndefined();
  });

  it('submit carries the same in a batch request', async () => {
    await oneKeyMissing();
    const fake = fakeAnthropic();
    expect((await run(['submit'], { ClientClass: fake.FakeAnthropic })).code).toBe(0);
    const [params] = fake.calls.batchCreate[0].requests.map((q) => q.params);
    expect(requestBody(params).references[uiKey('filter.users')]).toHaveLength(2);
    expect(params.system[0].text).toContain(REFERENCES_SENTENCE);
  });
});

describe('the session under text+path', () => {
  it('export carries the key path and the references, check passes, and import writes the key alone', async () => {
    await oneKeyMissing();
    const exported = await run(['session', 'export']);
    expect(exported.code).toBe(0);
    const work = (...p) => memory('session', 'batches', '0001', ...p);
    const task = readJson(work('task.json'));
    const segment = task.chunks.flatMap((c) => c.segments).find((s) => s.id === uiKey('filter.users'));
    expect(segment).toMatchObject({ path: 'filter.users', context: 'ui:filter.users', translate: 'all' });
    expect(segment.references).toEqual({
      it: [
        { page: CONTENT_FILE, path: 'badge.state', translation: 'Attiva' },
        { page: UI_LABEL, path: 'filter.product', translation: 'Attivo' },
      ],
    });
    expect(fs.readFileSync(task.instructions, 'utf8')).toContain(PATH_SENTENCE);

    fs.writeFileSync(task.output.it, `@@@ ${uiKey('filter.users')}\nAttivi\n`);
    fs.writeFileSync(task.done, 'ok\n');
    expect((await run(['session', 'check', '0001'])).code).toBe(0);
    expect((await run(['session', 'import'])).code).toBe(0);
    expect(layer('machine')[uiKey('filter.users')].text).toBe('Attivi');
    expect((await run(['session', 'status'])).code).toBe(0);
    expect((await run(['gate', '--check'])).code).toBe(0);
  });

  it('retranslate --context selects one key of a text, not the others', async () => {
    makeProject({ identity: 'text+path' });
    await run(['extract']);
    await run(['seed', '--targets', 'it']);
    const r = await run(['retranslate', '--context', 'ui:filter.users', '--include-human', '--reason', 'plural']);
    expect(r.code).toBe(0);
    expect(Object.keys(readJson(memory('retranslate.json')).it)).toEqual([uiKey('filter.users')]);
  });
});

describe('moving a memory from text to text+path: l10n rekey', () => {
  /** A text-identity project: seeded by hand, a machine translation, a mark, and a queue entry. */
  async function textProject() {
    makeProject();
    await run(['extract']);
    await run(['seed', '--targets', 'it']);
    // Seed's report names the collisions the text identity cannot hold.
    expect(readJson(memory('seed-report.json')).counts.collisions).toBe(2);
    // One key moved to the machine layer, as if translated by a model.
    const human = layer('messages');
    const welcome = human[keyOf('Welcome')];
    delete human[keyOf('Welcome')];
    writeJson(memory('messages', 'it.json'), human);
    writeJson(memory('machine', 'it.json'), { [keyOf('Welcome')]: { ...welcome, text: 'Benvenuti', status: 'machine', job: 'j1' } });
    writeJson(memory('machine', '_source.json'), { [keyOf('Welcome')]: 'Welcome' });
    writeJson(memory('retranslate.json'), { it: { [keyOf('Welcome')]: { reason: 'formal', markedAt: '2026-11-01T00:00:00.000Z' } } });
    writeJson(memory('pending.json'), { batches: [], queue: { it: { [keyOf(ACTIVE)]: { attempts: 1, defect: 'x' } } } });
    expect((await run(['gate', '--check'])).code).toBe(0);
  }

  it('maps each text key to every usage key of the text, and copies an entry only to a key that lacks one', () => {
    const units = { [uiKey('a')]: { source: ACTIVE }, [uiKey('b')]: { source: ACTIVE }, [keyOf('Plain')]: { source: 'Plain' } };
    const map = rekeyMap(units);
    expect([...map.keys()]).toEqual([keyOf(ACTIVE)]);
    expect(map.get(keyOf(ACTIVE)).keys).toEqual([uiKey('a'), uiKey('b')].sort());
    const { entries, archived } = rekeyLayer({ [keyOf(ACTIVE)]: { text: 'Attivo', srcHash: keyOf(ACTIVE) }, [uiKey('b')]: { text: 'Attivi' } }, map);
    expect(entries).toEqual({ [uiKey('a')]: { text: 'Attivo', srcHash: uiKey('a') } });
    expect(archived).toEqual([keyOf(ACTIVE)]);
    const { value, moved } = rekeyByLang({ it: { [keyOf(ACTIVE)]: { attempts: 2 } }, fr: { [keyOf(ACTIVE)]: 1 } }, map, ['it']);
    expect(moved).toBe(1);
    expect(value.it).toEqual({ [uiKey('a')]: { attempts: 2 }, [uiKey('b')]: { attempts: 2 } });
    expect(value.fr).toEqual({ [keyOf(ACTIVE)]: 1 });
  });

  it('refuses under the text identity, and while a batch is recorded', async () => {
    await textProject();
    const refused = await run(['rekey']);
    expect(refused.code).toBe(2);
    expect(refused.err).toContain('"identity": "text+path"');
    writeConfig({ identity: 'text+path' });
    const pending = readJson(memory('pending.json'));
    writeJson(memory('pending.json'), { ...pending, batches: [{ id: 'msgbatch_x', createdAt: '2026-11-01T00:00:00Z', requests: {} }] });
    const held = await run(['rekey']);
    expect(held.code).toBe(1);
    expect(held.err).toContain('msgbatch_x');
  });

  it('--dry-run names what would move and writes nothing', async () => {
    await textProject();
    writeConfig({ identity: 'text+path' });
    const before = fs.readFileSync(memory('messages', 'it.json'), 'utf8');
    const catalogue = fs.readFileSync(memory('source.json'), 'utf8');
    const r = await run(['rekey', '--dry-run']);
    expect(r.code).toBe(0);
    expect(r.out).toContain('it: human layer 4 key(s) from 1 text key(s); machine layer 2 key(s) from 1 text key(s).');
    expect(r.out).toContain('nothing was written');
    expect(fs.readFileSync(memory('messages', 'it.json'), 'utf8')).toBe(before);
    expect(fs.readFileSync(memory('source.json'), 'utf8')).toBe(catalogue);
  });

  it('moves every translation, mark and queue entry to the new keys, losing none; seed then gives each key its own text', async () => {
    await textProject();
    writeConfig({ identity: 'text+path' });
    const r = await run(['rekey']);
    expect(r.code).toBe(0);

    // Every usage of a text starts from the translation the text had, in its own layer.
    const human = layer('messages');
    for (const key of [uiKey('filter.product'), uiKey('filter.campaign'), uiKey('filter.users'), contentKey('badge.state')]) {
      expect(human[key]).toMatchObject({ text: 'Attiva', status: 'seed', srcHash: key });
    }
    expect(human[keyOf(ACTIVE)]).toBeUndefined();
    const machine = layer('machine');
    expect(machine[uiKey('nav.welcome', 'Welcome')]).toMatchObject({ text: 'Benvenuti', status: 'machine', srcHash: uiKey('nav.welcome', 'Welcome') });
    expect(machine[contentKey('title', 'Welcome')].text).toBe('Benvenuti');
    expect(machine[keyOf('Welcome')]).toBeUndefined();
    expect(readJson(memory('machine', '_source.json'))[contentKey('title', 'Welcome')]).toBe('Welcome');
    // The text keys are archived beside their layer, never deleted.
    expect(readJson(memory('messages', '_archive', 'it.json'))[keyOf(ACTIVE)].text).toBe('Attiva');
    expect(readJson(memory('machine', '_archive', 'it.json'))[keyOf('Welcome')].text).toBe('Benvenuti');
    // Marks and queue entries follow.
    expect(Object.keys(readJson(memory('retranslate.json')).it).sort()).toEqual([uiKey('nav.welcome', 'Welcome'), contentKey('title', 'Welcome')].sort());
    expect(Object.keys(readJson(memory('pending.json')).queue.it)).toHaveLength(4);
    // Nothing is missing and nothing is an orphan: no translation is requested again.
    const gate = await run(['gate', '--check']);
    expect(gate.code).toBe(0);
    expect(gate.out).toContain('no translation needed');
    // Generation is unchanged by the move.
    await run(['generate']);
    expect(readJson(memory('generated', 'ui', 'it.json'))['filter.users']).toBe('Attiva');

    // A second run moves nothing.
    expect((await run(['rekey'])).out).toContain('it: human layer 0 key(s) from 0 text key(s); machine layer 0 key(s) from 0 text key(s)');

    // seed now gives each key its own hand-written text, with no collision; materialize writes them.
    expect((await run(['seed', '--targets', 'it'])).code).toBe(0);
    expect(readJson(memory('seed-report.json')).counts.collisions).toBe(0);
    expect(layer('messages')[uiKey('filter.users')].text).toBe('Attivi');
    fs.rmSync(at('ui', 'it.json'));
    expect((await run(['materialize'])).code).toBe(0);
    expect(readJson(at('ui', 'it.json'))).toMatchObject({ 'filter.product': 'Attivo', 'filter.campaign': 'Attiva', 'filter.users': 'Attivi' });
    expect((await run(['gate', '--check'])).code).toBe(0);
  });
});

it('usageKeyOf hashes the normalized text, the file and the path, joined by U+0000', async () => {
  const { createHash } = await import('node:crypto');
  const expected = createHash('sha256').update(`${normalize(' Active ')}\u0000${UI_LABEL}\u0000filter.users`).digest('hex').slice(0, 16);
  expect(usageKeyOf(' Active ', UI_LABEL, 'filter.users')).toBe(expected);
});
