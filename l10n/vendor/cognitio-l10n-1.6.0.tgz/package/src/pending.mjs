/**
 * pending.mjs — The shapes the pending file holds: batch custom identifiers,
 * the recorded batches, and the resubmission queue with its two rules — what
 * counts as an attempt, and where a refused request is resubmitted.
 *
 * READS nothing and WRITES nothing: the pending file itself is read and written
 * by the store alone (`readPending` / `writePending` in `store.mjs`). The
 * functions here build and update the values the store persists, and the
 * synchronous transport keeps a queue of the same shape in memory.
 *
 * THE PENDING FILE, `<memory.dir>/pending.json`:
 *   { "batches": [ { "id", "createdAt", "estimate"?, "counts"?, "checkedAt"?, "canceledAt"?,
 *       "requests": { <custom_id>: { page, section, lang, ids, attempt, model, fallback, revisions? } } } ],
 *     "queue": { <lang>: { <srcHash>: { attempts, defect, whole?, fallback?, usedFallback? } } },
 *     "halt"?: { "at", "batch", "reason" } }
 * A recorded batch is one `submit` created and `collect` has not cleared; there
 * may be several, up to `backend.batches.maxInFlight`, no (segment, locale) pair
 * in two of them. `estimate` is what `submit` printed for it — input, its cached
 * share and output tokens, and `bound`, the most it can cost in US dollars
 * (`cost.mjs`) — and `counts` the API's `request_counts` as `collect` last read
 * them, at `checkedAt`; `canceledAt` is when `l10n cancel` asked for its
 * cancellation. A file an earlier version wrote holds at most one batch and none
 * of the optional fields, and reads the same. The queue holds every segment
 * whose last translation was rejected, refused or errored for its own content:
 * its next request states the defect, and a segment whose `attempts` reached the
 * configured limit is not requested again. A defect of the whole reply — one
 * defect queued for every segment of a request — is marked `whole`, so the next
 * request states it once rather than once per segment. `halt` is present while
 * `submit` refuses new batches after a collection found the account itself
 * failing (`resultFailure`).
 */

/**
 * The pattern a batch request's `custom_id` must match. Read from the Message
 * Batches API reference the SDK cites for `BatchCreateParams.Request.custom_id`
 * (https://platform.claude.com/docs/en/api/messages/batches/create):
 * "minLength: 1, maxLength: 64, pattern: ^[a-zA-Z0-9_-]{1,64}$". The installed
 * SDK's type declares the field as a plain `string` and states only that it
 * "Must be unique for each request within the Message Batch."
 */
export const CUSTOM_ID_PATTERN = /^[a-zA-Z0-9_-]{1,64}$/;

/** The longest custom identifier the pattern admits. */
const CUSTOM_ID_MAX = 64;

/** Every character the pattern does not admit, collapsed to one hyphen. */
const clean = (s) => String(s).replace(/[^a-zA-Z0-9_-]+/g, '-').replace(/^-+|-+$/g, '');

/**
 * The custom identifier of the request at `index` in a batch. The zero-padded
 * index, unique within the batch, comes first, so cutting the readable rest to
 * the pattern's length can never make two identifiers equal; the locale and the
 * page follow so a result can be read by eye. The mapping from identifier to
 * page, locale and segments lives in the pending file, never in the identifier.
 *
 * @param {Object} args
 * @param {number} args.index    the request's position in the batch.
 * @param {string} args.lang
 * @param {string} args.page
 * @param {string|null} [args.section]
 * @returns {string}
 */
export function customIdFor({ index, lang, page, section = null }) {
  const head = String(index).padStart(6, '0');
  const tail = clean(`${lang}-${page}${section ? `-${section}` : ''}`);
  const id = (tail ? `${head}-${tail}` : head).slice(0, CUSTOM_ID_MAX);
  return id.replace(/-+$/, '') || head;
}

/** The value of a pending file that records nothing. */
export function emptyPending() {
  return { batches: [], queue: {} };
}

/**
 * THE ONE REFUSAL RULE: a refused request is resubmitted once on the fallback
 * model, when the configuration names one and these segments have not used it.
 * Every other refusal is queued for the primary model like any other defect.
 *
 * @param {Object} args
 * @param {string} [args.fallbackId]     the configured `model.fallbackId`.
 * @param {boolean} args.wasFallback     whether the refused request already ran on the fallback.
 * @param {boolean} [args.usedFallback]  whether these segments ran on the fallback before.
 * @returns {boolean} whether the resubmission uses the fallback model.
 */
export function fallsBackAfterRefusal({ fallbackId, wasFallback, usedFallback = false }) {
  return Boolean(fallbackId) && !wasFallback && !usedFallback;
}

/**
 * Queues segments for resubmission with the defect their next request states.
 * The attempt count is SET to the attempt that just ran, never incremented, so
 * applying the same outcome twice leaves the queue as applying it once.
 *
 * @param {import('./types.mjs').Queue} queue  updated in place.
 * @param {Object} args
 * @param {string} args.lang
 * @param {string[]} args.ids
 * @param {number} args.attempt         the attempt that produced the defect.
 * @param {string|Object.<string,string>} args.defect  one defect for all, which marks each entry `whole`, or one per identifier.
 * @param {boolean} [args.refusal]      whether the request was refused.
 * @param {boolean} [args.wasFallback]  whether it ran on the fallback model.
 * @param {string} [args.fallbackId]
 */
export function queueDefect(queue, { lang, ids, attempt, defect, refusal = false, wasFallback = false, fallbackId }) {
  if (!queue[lang]) queue[lang] = {};
  for (const id of ids) {
    const before = queue[lang][id] || {};
    const usedFallback = Boolean(before.usedFallback || wasFallback);
    const entry = {
      attempts: Math.max(before.attempts || 0, attempt),
      defect: typeof defect === 'string' ? defect : defect[id],
    };
    if (typeof defect === 'string') entry.whole = true;
    if (refusal && fallsBackAfterRefusal({ fallbackId, wasFallback, usedFallback })) entry.fallback = true;
    if (usedFallback) entry.usedFallback = true;
    queue[lang][id] = entry;
  }
}

/**
 * The (segment, locale) pairs the recorded batches hold: what `collect` has still
 * to apply, which no other transport plans meanwhile.
 *
 * @param {import('./types.mjs').PendingFile} pending
 * @returns {Map<string, Set<string>>}  locale → the segments its recorded requests ask for.
 */
export function batchHeldPairs(pending) {
  const held = new Map();
  for (const batch of (pending && pending.batches) || []) {
    for (const req of Object.values(batch.requests || {})) {
      if (!held.has(req.lang)) held.set(req.lang, new Set());
      for (const id of req.ids || []) held.get(req.lang).add(id);
    }
  }
  return held;
}

/**
 * Removes segments from the queue: their translation was accepted.
 *
 * @param {import('./types.mjs').Queue} queue  updated in place.
 * @param {string} lang
 * @param {string[]} ids
 */
export function clearQueued(queue, lang, ids) {
  if (!queue[lang]) return;
  for (const id of ids) delete queue[lang][id];
  if (Object.keys(queue[lang]).length === 0) delete queue[lang];
}

/** The defect a refusal states, naming its category when the API gives one. */
export function refusalDefect(refusal) {
  const category = refusal && refusal.category;
  return `the model declined the request${category ? ` (refusal category: ${category})` : ''}`;
}

/**
 * The error types of an errored batch result that say nothing about the
 * request's content: the account, the rate limits and the API's own state. The
 * Message Batches API's error types are the SDK's `ErrorType`
 * (`@anthropic-ai/sdk`, `resources/shared`).
 */
export const TRANSPORT_ERROR_TYPES = Object.freeze([
  'authentication_error',
  'permission_error',
  'billing_error',
  'rate_limit_error',
  'timeout_error',
  'overloaded_error',
  'api_error',
]);

/** The transport error types that are the account's own: any more requests would fail the same way. */
export const ACCOUNT_ERROR_TYPES = Object.freeze(['authentication_error', 'permission_error', 'billing_error']);

/**
 * An error message about the account's money, whatever its type: the API reports
 * a credit balance too low as an `invalid_request_error`.
 */
export const BILLING_MESSAGE = /credit balance|spend(?:ing)? limit|usage limit|billing/i;

/**
 * THE ATTEMPT RULE: whether a batch result that is not `succeeded` counts as one
 * of the segments' attempts. A result `errored` for the request's own content —
 * `invalid_request_error`, which resubmitted unchanged would fail again,
 * `not_found_error`, or a type this package does not know — counts, like a
 * rejected or refused translation. A transport failure does not: an `errored`
 * result whose type is in `TRANSPORT_ERROR_TYPES` or whose message is about
 * billing, a result `expired` or `canceled`, and a request with no result. A
 * transport failure leaves the queue as it was, so the next request is the same
 * attempt, stating the same corrections. `account` marks the failures no more
 * requests can get past until a person acts: the account's error types, and any
 * message about billing.
 *
 * @param {Object|null|undefined} result  a batch result line's `result`, or nothing.
 * @returns {{counts:boolean, account:boolean, defect:string, type:string}}  `type` names the failure:
 *          the error type, `expired`, `canceled` or `missing`.
 */
export function resultFailure(result) {
  const type = result && result.type;
  if (type === 'errored') {
    const error = (result.error && result.error.error) || null;
    const kind = error && typeof error.type === 'string' ? error.type : 'unknown_error';
    const message = error && typeof error.message === 'string' ? error.message : '';
    const defect = `the request errored${error ? ` (${kind}: ${message})` : ''}`;
    const account = ACCOUNT_ERROR_TYPES.includes(kind) || BILLING_MESSAGE.test(message);
    return { counts: !account && !TRANSPORT_ERROR_TYPES.includes(kind), account, defect, type: kind };
  }
  if (type === 'canceled' || type === 'expired') return { counts: false, account: false, defect: `the request was ${type}`, type };
  return { counts: false, account: false, defect: 'no result was returned for the request', type: 'missing' };
}

export default {
  CUSTOM_ID_PATTERN,
  customIdFor,
  emptyPending,
  fallsBackAfterRefusal,
  queueDefect,
  batchHeldPairs,
  clearQueued,
  refusalDefect,
  resultFailure,
  TRANSPORT_ERROR_TYPES,
  ACCOUNT_ERROR_TYPES,
  BILLING_MESSAGE,
};
