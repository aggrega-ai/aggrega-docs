import '../test/no-network.mjs';
import { describe, it, expect, beforeEach, afterEach } from 'vitest';
import fs from 'node:fs';
import path from 'node:path';

import { runCli } from './cli.mjs';
import { REVISION_SIMILARITY, findRevisions, similarity } from './revisions.mjs';
import { buildUserMessage, planRequests } from './requests.mjs';
import { generalRules, REVISE_SENTENCE } from './translator-prompt.mjs';
import { keyOf } from './normalize.mjs';
import { capture, copyFixtureProject, fakeAnthropic, requestBody, writeJson } from '../test/helpers.mjs';

describe('similarity: the Dice coefficient of two sources’ words', () => {
  it('is 1 for the same words, whatever their casing and punctuation', () => {
    expect(similarity('Run the build.', 'run the build')).toBe(1);
  });
  it('stays high for a sentence with a word changed or a clause added', () => {
    expect(similarity('The compiler pipes the value into the recipe', 'The compiler pipes the string into the recipe')).toBeGreaterThan(0.8);
    expect(similarity('Primo paragrafo.', 'Primo paragrafo, appena modificato.')).toBeGreaterThanOrEqual(REVISION_SIMILARITY);
  });
  it('stays below the threshold for two different sentences on one subject', () => {
    expect(similarity('Install the package from its archive', 'The archive is published on each release tag')).toBeLessThan(REVISION_SIMILARITY);
  });
  it('counts a repeated word as often as both sources hold it', () => {
    expect(similarity('a a a b', 'a b')).toBeCloseTo((2 * 2) / 6);
  });
});

/** A worklist with one missing unit per source and the given orphans. */
const worklistOf = (missing, orphans, targets = ['it']) => ({
  status: 'work',
  targets,
  items: missing.map((source) => ({ srcHash: keyOf(source), source, format: 'text', missing: [...targets] })),
  orphans: orphans.map(keyOf).sort(),
});
const machine = (text) => ({ text, status: 'machine' });

describe('findRevisions: the earlier version of each missing segment', () => {
  const OLD = 'The build writes every page into its locale';
  const NEW = 'The build writes every page into its own locale';

  it('pairs a missing segment with the orphan whose source is most similar, in each locale that translates it', () => {
    const revisions = findRevisions({
      worklist: worklistOf([NEW], [OLD, 'Something else entirely'], ['it', 'de']),
      tmByLang: { it: { [keyOf(OLD)]: machine('La build scrive') }, de: {} },
      sources: { [keyOf(OLD)]: OLD, [keyOf('Something else entirely')]: 'Something else entirely' },
      targets: ['it', 'de'],
    });
    expect(revisions).toEqual({ it: { [keyOf(NEW)]: { from: keyOf(OLD), source: OLD, translation: 'La build scrive', reviewed: false } } });
  });

  it('marks a revision reviewed when the orphan’s translation is in the human layer', () => {
    const revisions = findRevisions({
      worklist: worklistOf([NEW], [OLD]),
      tmByLang: { it: { [keyOf(OLD)]: { text: 'Corretta', status: 'human' } } },
      sources: { [keyOf(OLD)]: OLD },
      targets: ['it'],
    });
    expect(revisions.it[keyOf(NEW)]).toMatchObject({ translation: 'Corretta', reviewed: true });
  });

  it('finds none below the threshold, none for an orphan with no recorded source, and none without orphans', () => {
    const far = 'An unrelated sentence about deployment';
    expect(findRevisions({ worklist: worklistOf([NEW], [far]), tmByLang: { it: { [keyOf(far)]: machine('x') } }, sources: { [keyOf(far)]: far }, targets: ['it'] })).toEqual({});
    expect(findRevisions({ worklist: worklistOf([NEW], [OLD]), tmByLang: { it: { [keyOf(OLD)]: machine('x') } }, sources: {}, targets: ['it'] })).toEqual({});
    expect(findRevisions({ worklist: worklistOf([NEW], []), tmByLang: {}, sources: {}, targets: ['it'] })).toEqual({});
  });

  it('pairs one to one: of two segments resembling one orphan, only the more similar starts from it', () => {
    const edited = 'The build writes every page into its locale tree';
    const resembling = 'The build writes no page into another tree';
    const revisions = findRevisions({
      worklist: worklistOf([edited, resembling], [OLD]),
      tmByLang: { it: { [keyOf(OLD)]: machine('La build scrive') } },
      sources: { [keyOf(OLD)]: OLD },
      targets: ['it'],
    });
    expect(similarity(resembling, OLD)).toBeGreaterThanOrEqual(REVISION_SIMILARITY);
    expect(Object.keys(revisions.it)).toEqual([keyOf(edited)]);
  });

  it('breaks a tie by the lower key, so the same memory gives the same revision every time', () => {
    const a = 'The build writes every page into its locale.';
    const b = 'The build writes every page into its locale!';
    const revisions = findRevisions({
      worklist: worklistOf([NEW], [a, b]),
      tmByLang: { it: { [keyOf(a)]: machine('A'), [keyOf(b)]: machine('B') } },
      sources: { [keyOf(a)]: a, [keyOf(b)]: b },
      targets: ['it'],
    });
    expect(revisions.it[keyOf(NEW)].from).toBe([keyOf(a), keyOf(b)].sort()[0]);
  });
});

describe('a request carries a revision as "revise"', () => {
  const OLD = 'The build writes every page';
  const NEW = 'The build writes every page twice';
  const pages = [{ id: 'p.md', segments: [{ key: keyOf(NEW), source: NEW, format: 'text', section: '' }] }];
  const revisions = { it: { [keyOf(NEW)]: { from: keyOf(OLD), source: OLD, translation: 'La build scrive ogni pagina', reviewed: true } } };

  it('gives the translator the earlier source and translation, marked reviewed, and never the orphan’s key', () => {
    const { specs } = planRequests({ pages, worklist: worklistOf([NEW], [OLD]), tmByLang: { it: {} }, targets: ['it'], sectionTokens: 8000, attemptLimit: 3, revisions });
    expect(specs[0].revise[keyOf(NEW)].from).toBe(keyOf(OLD));
    const body = Object.assign({}, ...buildUserMessage(specs[0]).map((block) => JSON.parse(block.text)));
    expect(body.revise).toEqual({ [keyOf(NEW)]: { source: OLD, translation: 'La build scrive ogni pagina', reviewed: true } });
  });

  it('carries no "revise" when no requested segment has a revision', () => {
    const { specs } = planRequests({ pages, worklist: worklistOf([NEW], []), tmByLang: { it: {} }, targets: ['it'], sectionTokens: 8000, attemptLimit: 3 });
    expect(specs[0].revise).toBeUndefined();
    expect(Object.keys(JSON.parse(buildUserMessage(specs[0])[1].text))).toEqual(['translate']);
  });

  it('is described to the translator in the general rules', () => {
    const rules = generalRules({ lang: 'it', sourceLang: 'en' });
    expect(rules).toContain('"revise"?: { [id]: { "source": string, "translation": string, "reviewed"?: true, "reason"?: string } }');
    expect(rules).toContain(REVISE_SENTENCE);
  });
});

describe('a changed segment starts from its earlier translation, on every transport', () => {
  let project;
  beforeEach(() => {
    project = copyFixtureProject('l10n-revisions-');
  });
  afterEach(() => {
    fs.rmSync(project, { recursive: true, force: true });
  });

  const memory = (...p) => path.join(project, 'memory', ...p);
  const readJson = (file) => JSON.parse(fs.readFileSync(file, 'utf8'));
  async function run(argv, deps = {}) {
    const io = capture();
    const code = await runCli(argv, { cwd: project, env: { ANTHROPIC_API_KEY: 'test-key' }, log: io.log, errlog: io.errlog, ...deps });
    return { code, out: io.text(), err: io.errors() };
  }
  /** Rewrites one string of the source page. */
  function editHome(from, to) {
    const file = path.join(project, 'content', 'it', 'home.json');
    fs.writeFileSync(file, fs.readFileSync(file, 'utf8').replace(JSON.stringify(from), JSON.stringify(to)));
  }
  /** The request, among those a fake client received, that asks for `key`. */
  const requestFor = (calls, key) => calls.map(requestBody).find((body) => body.translate.includes(key));

  const OLD = 'Primo paragrafo.';
  const NEW = 'Primo paragrafo, appena modificato.';

  it('translate: the request revises the earlier translation, and the entry records it', async () => {
    const first = fakeAnthropic();
    expect((await run(['extract'])).code).toBe(0);
    expect((await run(['translate'], { ClientClass: first.FakeAnthropic })).code).toBe(0);
    const earlier = readJson(memory('machine', 'en.json'))[keyOf(OLD)].text;
    expect(readJson(memory('machine', '_source.json'))[keyOf(OLD)]).toBe(OLD);

    editHome(OLD, NEW);
    expect((await run(['extract'])).code).toBe(0);
    const second = fakeAnthropic();
    expect((await run(['translate'], { ClientClass: second.FakeAnthropic })).code).toBe(0);
    expect(requestFor(second.calls.create, keyOf(NEW)).revise).toEqual({ [keyOf(NEW)]: { source: OLD, translation: earlier } });
    expect(readJson(memory('machine', 'en.json'))[keyOf(NEW)].revision).toEqual({ from: keyOf(OLD), reviewed: false });
  });

  it('finds the earlier version from the machine layer’s own sources, as a CI runner that holds only the machine layer does', async () => {
    const first = fakeAnthropic();
    expect((await run(['extract'])).code).toBe(0);
    expect((await run(['translate'], { ClientClass: first.FakeAnthropic })).code).toBe(0);
    fs.rmSync(memory('messages', '_source.json'));
    editHome(OLD, NEW);
    expect((await run(['extract'])).code).toBe(0);
    // The fresh extract recorded only the current sources: the earlier one is known from machine/_source.json alone.
    expect(readJson(memory('messages', '_source.json'))[keyOf(OLD)]).toBeUndefined();
    const second = fakeAnthropic();
    expect((await run(['translate'], { ClientClass: second.FakeAnthropic })).code).toBe(0);
    expect(requestFor(second.calls.create, keyOf(NEW)).revise[keyOf(NEW)].source).toBe(OLD);
  });

  it('submit and collect: the batch request revises it, the pending file records the revision, and collect writes it', async () => {
    const first = fakeAnthropic();
    expect((await run(['extract'])).code).toBe(0);
    expect((await run(['submit'], { ClientClass: first.FakeAnthropic })).code).toBe(0);
    expect((await run(['collect'], { ClientClass: first.FakeAnthropic })).code).toBe(0);

    editHome(OLD, NEW);
    expect((await run(['extract'])).code).toBe(0);
    const second = fakeAnthropic();
    expect((await run(['submit'], { ClientClass: second.FakeAnthropic })).code).toBe(0);
    const params = second.calls.batchCreate[0].requests.map((r) => r.params);
    expect(requestFor(params, keyOf(NEW)).revise[keyOf(NEW)].source).toBe(OLD);
    const mapping = Object.values(readJson(memory('pending.json')).batches[0].requests).find((req) => req.ids.includes(keyOf(NEW)));
    expect(mapping.revisions).toEqual({ [keyOf(NEW)]: { from: keyOf(OLD), reviewed: false } });
    expect((await run(['collect'], { ClientClass: second.FakeAnthropic })).code).toBe(0);
    expect(readJson(memory('machine', 'en.json'))[keyOf(NEW)].revision).toEqual({ from: keyOf(OLD), reviewed: false });
  });

  it('a segment whose earlier translation a person wrote: the request says so, and review lists the new one until a person reviews it', async () => {
    // The fixture's human layer translates "Ciao mondo"; its source is recorded by the first extract.
    const HUMAN_OLD = 'Ciao mondo';
    const HUMAN_NEW = 'Ciao mondo intero';
    expect(readJson(memory('messages', 'en.json'))[keyOf(HUMAN_OLD)].status).toBe('human');
    expect((await run(['extract'])).code).toBe(0);
    editHome(HUMAN_OLD, HUMAN_NEW);
    expect((await run(['extract'])).code).toBe(0);
    const fake = fakeAnthropic();
    expect((await run(['translate'], { ClientClass: fake.FakeAnthropic })).code).toBe(0);
    expect(requestFor(fake.calls.create, keyOf(HUMAN_NEW)).revise[keyOf(HUMAN_NEW)]).toEqual({ source: HUMAN_OLD, translation: 'Hello, world', reviewed: true });
    expect(readJson(memory('machine', 'en.json'))[keyOf(HUMAN_NEW)].revision).toEqual({ from: keyOf(HUMAN_OLD), reviewed: true });

    const listed = await run(['review']);
    expect(listed.code).toBe(0);
    expect(listed.out).toContain('review: 1 machine translation(s) revise a reviewed translation and await review.');
    expect(listed.out).toContain(`  en ${keyOf(HUMAN_NEW)}, revising ${keyOf(HUMAN_OLD)}: content/it/home.json`);
    expect((await run(['gate'])).out).toContain('review: 1 machine translation(s) revise a reviewed translation');

    // A person's entry for the new key in the human layer ends the review.
    const human = readJson(memory('messages', 'en.json'));
    human[keyOf(HUMAN_NEW)] = { text: 'Hello, whole world', status: 'reviewed', srcHash: keyOf(HUMAN_NEW) };
    writeJson(memory('messages', 'en.json'), human);
    expect((await run(['review'])).out).toContain('review: 0 machine translation(s)');
  });
});
