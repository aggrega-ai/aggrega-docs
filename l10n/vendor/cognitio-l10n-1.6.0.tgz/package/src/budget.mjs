/**
 * budget.mjs — The spending budget (`backend.budget`, or the environment's
 * `L10N_BUDGET_USD`): what is committed against it, and whether a new batch fits
 * under it.
 *
 * READS nothing and WRITES nothing: pure functions over the job logs `collect`
 * wrote, the pending file's recorded batches and the requests `submit` built,
 * which the caller supplies. `submit` checks each batch before it creates it;
 * `status` prints the same figures.
 *
 * THE ARITHMETIC. A batch's BOUND is the most it can cost: every estimated input
 * token at the one-hour cache-write rate and every `max_tokens` token at the
 * output rate, on each request's model (`batchCostUpperBound`, `cost.mjs`).
 * `submit` records it with the batch (`estimate.bound`); for a batch an earlier
 * version recorded, it is the recorded estimate's tokens at the dearest model the
 * batch's requests name, still an upper bound. The OBSERVED SHARE is the billed
 * spend of the collected batches that recorded both their cost and an estimate,
 * divided by the sum of their bounds — 1, the bound itself, while there is no
 * such batch. A batch's EXPECTED COST is its bound times that share.
 *
 *   committed = billed + expected in flight
 *   billed    = the cost the job logs record for the batches created at or after
 *               `since` (every collected batch without it) + `billedBefore`
 *   expected in flight = the expected cost of every batch recorded and not yet
 *               collected, whatever its age
 *
 * A new batch fits when committed plus its expected cost is at most `usd`. A
 * figure that cannot be priced — a collected batch billed on a model the rate
 * table does not hold, a batch in flight recording no estimate the table can
 * price, a request on such a model — makes the budget uncheckable, and `submit`
 * refuses rather than guess.
 *
 * THE LIMITS. The budget is the package's soft stop: it counts what the job logs
 * record and what the batches in flight are expected to cost, so spend it never
 * sees — a batch collected by an earlier version, the synchronous transport,
 * other work billed to the same key — counts only through `billedBefore`. The
 * API's own spending limits, set on the workspace or the organization, are the
 * hard stop under which it runs.
 */

import { BATCH_RATES, batchCostUpperBound, formatUsd } from './cost.mjs';
import { BUDGET_ENV } from './config.mjs';

/**
 * The names a message gives the budget and its figures: the configuration's keys,
 * or the environment variables (`BUDGET_ENV`) when the environment stated it, so
 * a message always names where the figure it reports was set.
 *
 * @param {'configuration'|'environment'} [source]
 * @returns {{budget:string, usd:string, billedBefore:string}}
 */
export function budgetNames(source = 'configuration') {
  return source === 'environment'
    ? { budget: BUDGET_ENV.usd, usd: BUDGET_ENV.usd, billedBefore: BUDGET_ENV.billedBefore }
    : { budget: 'backend.budget', usd: 'backend.budget.usd', billedBefore: 'backend.budget.billedBefore' };
}

/**
 * The upper-bound cost of built requests, each `{ params: { model }, estimate: { input, output } }`,
 * or null when one of them runs on a model the rate table does not hold.
 *
 * @param {Array<{params:{model:string}, estimate:{input:number, output:number}}>} built
 * @param {Object} [rates]
 * @returns {number|null}
 */
export function requestsBound(built, rates = BATCH_RATES) {
  let total = 0;
  for (const r of built) {
    const cost = batchCostUpperBound({ model: r.params.model, input: r.estimate.input, output: r.estimate.output, rates });
    if (cost === null) return null;
    total += cost;
  }
  return total;
}

/**
 * A recorded estimate's bound: the `bound` it records, else its tokens at the
 * dearest of `models` — or null when it records no estimate or a model has no rate.
 *
 * @param {{input:number, output:number, bound?:number}|undefined} estimate
 * @param {string[]} models  the models the batch's requests name.
 * @param {Object} [rates]
 * @returns {number|null}
 */
export function estimateBound(estimate, models, rates = BATCH_RATES) {
  if (!estimate) return null;
  if (typeof estimate.bound === 'number') return estimate.bound;
  let dearest = null;
  for (const model of new Set(models)) {
    const cost = batchCostUpperBound({ model, input: estimate.input || 0, output: estimate.output || 0, rates });
    if (cost === null) return null;
    dearest = dearest === null ? cost : Math.max(dearest, cost);
  }
  return dearest;
}

/** The models a collected batch's job log names, from the usage of its requests. */
const jobModels = (usage) => (Array.isArray(usage.requests) ? usage.requests.map((r) => r.model) : []);

/**
 * The share of their bound the collected batches were billed, over those whose
 * job log records both a cost and an estimate, or null when none does.
 *
 * @param {Array<{usage?: Object}>} jobs  the job logs `collect` wrote.
 * @returns {{share:number, batches:number}|null}
 */
export function observedShare(jobs) {
  let billed = 0;
  let bound = 0;
  let batches = 0;
  for (const job of jobs) {
    const usage = job && job.usage;
    if (!usage || typeof usage.cost !== 'number') continue;
    const b = estimateBound(usage.estimate, jobModels(usage));
    if (!(b > 0)) continue;
    billed += usage.cost;
    bound += b;
    batches += 1;
  }
  return batches ? { share: billed / bound, batches } : null;
}

/**
 * The committed spend against a budget (see the module comment).
 *
 * @param {Object} args
 * @param {{usd:number, since:string|null, billedBefore:number, source?:'configuration'|'environment'}} args.budget
 * @param {Array<{id:string, at:string, usage?: Object}>} args.jobs  the job logs `collect` wrote.
 * @param {{batches:Array<Object>}} args.pending  the pending file.
 * @returns {{usd:number, since:string|null, billed:number, recorded:number, before:number, inFlight:Array<{id:string, bound:number, expected:number}>,
 *            expectedInFlight:number, share:number, observed:{share:number, batches:number}|null, committed:number, unpriced:string|null,
 *            names:ReturnType<typeof budgetNames>}}
 */
export function committedSpend({ budget, jobs, pending }) {
  const sinceMs = budget.since ? Date.parse(budget.since) : null;
  let recorded = 0;
  let unpriced = null;
  for (const job of jobs) {
    const usage = job && job.usage;
    if (!usage) continue;
    if (sinceMs !== null && !(Date.parse(job.at) >= sinceMs)) continue;
    if (typeof usage.cost !== 'number') {
      unpriced = unpriced || `batch ${job.id} was billed on a model the package's rate table does not hold`;
      continue;
    }
    recorded += usage.cost;
  }
  const observed = observedShare(jobs);
  const share = observed ? observed.share : 1;
  const inFlight = [];
  for (const record of pending.batches || []) {
    const bound = estimateBound(record.estimate, Object.values(record.requests || {}).map((r) => r.model));
    if (bound === null) {
      unpriced = unpriced || `batch ${record.id}, in flight, records no estimate the package's rate table can price`;
      continue;
    }
    inFlight.push({ id: record.id, bound, expected: bound * share });
  }
  const billed = recorded + budget.billedBefore;
  const expectedInFlight = inFlight.reduce((n, b) => n + b.expected, 0);
  return {
    usd: budget.usd,
    since: budget.since,
    billed,
    recorded,
    before: budget.billedBefore,
    inFlight,
    expectedInFlight,
    share,
    observed,
    committed: billed + expectedInFlight,
    unpriced,
    names: budgetNames(budget.source),
  };
}

/**
 * Whether a new batch fits under the budget.
 *
 * @param {ReturnType<typeof committedSpend>} spend
 * @param {number|null} bound            the new batch's bound (`requestsBound`).
 * @param {number} [plannedExpected]     the expected cost of the batches planned before it in the same submission.
 * @returns {{fits:boolean, unpriced?:string, bound?:number, expected?:number, before?:number, after?:number}}
 *          `before` is the committed spend with the batches planned before it, `after` with it too.
 */
export function batchVerdict(spend, bound, plannedExpected = 0) {
  if (spend.unpriced) return { fits: false, unpriced: spend.unpriced };
  if (bound === null) return { fits: false, unpriced: "a request runs on a model the package's rate table does not hold" };
  const expected = bound * spend.share;
  const before = spend.committed + plannedExpected;
  return { fits: before + expected <= spend.usd, bound, expected, before, after: before + expected };
}

/** The observed share as a line prints it. */
function shareText(spend) {
  return spend.observed
    ? `the billed share of the bound observed over ${spend.observed.batches} collected batch(es), ${spend.share.toFixed(3)}`
    : 'share 1: no collected batch records both its cost and its estimate yet, so a batch is expected to cost its bound';
}

/**
 * The lines that state a budget's figures: the committed spend, and how a batch's
 * expected cost is counted.
 *
 * @param {ReturnType<typeof committedSpend>} spend
 * @returns {string[]}
 */
export function budgetLines(spend) {
  if (spend.unpriced) return [`budget ${formatUsd(spend.usd)}: cannot be checked: ${spend.unpriced}.`];
  const billed = [`${formatUsd(spend.recorded)} recorded by the collected batches${spend.since ? ` created since ${spend.since}` : ''}`];
  if (spend.before > 0) billed.push(`${formatUsd(spend.before)} before them (${spend.names.billedBefore})`);
  return [
    `budget ${formatUsd(spend.usd)}: billed ${formatUsd(spend.billed)} (${billed.join(', ')}), ` +
      `in flight ${formatUsd(spend.expectedInFlight)} expected (${spend.inFlight.length} batch(es)), remaining ${formatUsd(Math.max(0, spend.usd - spend.committed))}.`,
    `a batch's expected cost is its upper bound times ${shareText(spend)}.`,
  ];
}

/**
 * The line that states one batch's verdict.
 *
 * @param {ReturnType<typeof committedSpend>} spend
 * @param {ReturnType<typeof batchVerdict>} verdict
 * @returns {string}
 */
export function verdictLine(spend, verdict) {
  if (verdict.unpriced) return `the budget cannot be checked: ${verdict.unpriced}.`;
  const figures =
    `billed so far ${formatUsd(spend.billed)}, expected in flight ${formatUsd(verdict.before - spend.billed)}, ` +
    `this batch ${formatUsd(verdict.expected)} expected (upper bound ${formatUsd(verdict.bound)}), budget ${formatUsd(spend.usd)}`;
  return verdict.fits
    ? `within the budget: ${figures}; committed after it ${formatUsd(verdict.after)}.`
    : `over the budget: ${figures}; it would take the committed spend to ${formatUsd(verdict.after)}.`;
}

export default { budgetNames, requestsBound, estimateBound, observedShare, committedSpend, batchVerdict, budgetLines, verdictLine };
