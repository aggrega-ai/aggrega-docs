import '../test/no-network.mjs';
import { describe, it, expect, beforeEach, afterEach } from 'vitest';
import fs from 'node:fs';
import path from 'node:path';

import { runCli } from './cli.mjs';
import { withoutHeld } from './gate.mjs';
import { batchHeldPairs } from './pending.mjs';
import { capture, copyMarkdownFixture, fakeAnthropic } from '../test/helpers.mjs';

let project;
beforeEach(() => {
  project = copyMarkdownFixture('l10n-held-');
});
afterEach(() => {
  fs.rmSync(project, { recursive: true, force: true });
});

const memory = (...p) => path.join(project, 'memory', ...p);
const work = (...p) => memory('session', ...p);
const readJson = (file) => JSON.parse(fs.readFileSync(file, 'utf8'));

async function run(argv, deps = {}) {
  const io = capture();
  const code = await runCli(argv, { cwd: project, env: { ANTHROPIC_API_KEY: 'test-key' }, log: io.log, errlog: io.errlog, ...deps });
  return { code, out: io.text(), err: io.errors() };
}

/** Every (locale, segment) pair the recorded Message Batches request. */
const batchPairs = () =>
  readJson(memory('pending.json')).batches.flatMap((b) => Object.values(b.requests).flatMap((q) => q.ids.map((id) => `${q.lang} ${id}`)));

/** Every (locale, segment) pair the session's batches request. */
const sessionPairs = () =>
  fs
    .readdirSync(work('batches'))
    .flatMap((b) => Object.entries(readJson(work('batches', b, 'plan.json')).requested).flatMap(([lang, ids]) => ids.map((id) => `${lang} ${id}`)));

describe('two transports side by side never translate one pair twice', () => {
  it('submit leaves to the session the pairs its batches not yet imported hold, and says so', async () => {
    const exported = await run(['session', 'export', '--words', '40']);
    expect(exported.code).toBe(0);
    const held = sessionPairs();
    expect(held.length).toBeGreaterThan(0);

    const fake = fakeAnthropic();
    const r = await run(['submit'], { ClientClass: fake.FakeAnthropic });
    expect(r.code).toBe(0);
    expect(r.out).toContain(`submit: ${held.length} segment-locale pair(s) are held by session batches not yet imported (${work()}) and are left to the session.`);
    expect(batchPairs().filter((pair) => held.includes(pair))).toEqual([]);
  });

  it('session export leaves to collect the pairs a recorded Message Batch holds, and says so', async () => {
    expect((await run(['extract'])).code).toBe(0);
    const fake = fakeAnthropic({ status: 'in_progress' });
    expect((await run(['submit', '--targets', 'it'], { ClientClass: fake.FakeAnthropic })).code).toBe(0);
    const held = batchPairs();
    expect(held.length).toBeGreaterThan(0);

    const r = await run(['session', 'export', '--batches', '50']);
    expect(r.code).toBe(0);
    expect(r.out).toContain(`session export: ${held.length} segment-locale pair(s) are held by a recorded Message Batch (${memory('pending.json')}) and are left to \`l10n collect\`.`);
    expect(sessionPairs().filter((pair) => held.includes(pair))).toEqual([]);
    // German, which the batch does not hold, is still exported.
    expect(sessionPairs().some((pair) => pair.startsWith('de '))).toBe(true);
  });

  it('session export says how many pairs its own open batches hold', async () => {
    await run(['session', 'export', '--words', '40']);
    const held = sessionPairs().length;
    const r = await run(['session', 'export', '--words', '40']);
    expect(r.out).toContain(`session export: ${held} segment-locale pair(s) are in batches of this session not yet imported and are not planned again.`);
  });
});

describe('withoutHeld and batchHeldPairs', () => {
  it('leave out exactly the held pairs and count them', () => {
    const worklist = { status: 'work', items: [{ srcHash: 'a', missing: ['it', 'de'] }, { srcHash: 'b', missing: ['it'] }] };
    const held = batchHeldPairs({ batches: [{ requests: { x: { lang: 'it', ids: ['a', 'b'] } } }] });
    expect(withoutHeld(worklist, held)).toEqual({ worklist: { status: 'work', items: [{ srcHash: 'a', missing: ['de'] }] }, skipped: 2 });
    expect(withoutHeld(worklist, new Map())).toEqual({ worklist, skipped: 0 });
  });
});
