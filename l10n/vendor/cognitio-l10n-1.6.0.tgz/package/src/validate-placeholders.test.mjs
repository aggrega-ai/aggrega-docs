import '../test/no-network.mjs';
import { describe, it, expect } from 'vitest';

import { validateTranslations } from './validate.mjs';
import { PLACEHOLDER_SENTENCE, translationRules } from './translator-prompt.mjs';

const md = (source) => ({ srcHash: 'm', source, format: 'markdown', protected: [] });
const judge = (item, text) => validateTranslations({ items: [item], entries: [{ id: item.srcHash, text }] });

describe('validateTranslations — a placeholder the source holds inside inline code', () => {
  // An English message given as inline code, then its translation in parentheses: the placeholder comes along.
  const message = md('The halt reads `a registry is not trusted offline for <identity>` when no policy applies.');

  it('accepts the placeholder copied into inline code of its own', () => {
    const text = 'L’arresto riporta `a registry is not trusted offline for <identity>` (un registro non è attendibile offline per `<identity>`) quando nessuna politica si applica.';
    expect(judge(message, text).accepted).toEqual({ m: text });
  });

  it('rejects it written outside inline code, where the page reads it as a tag, and says why and how to keep it', () => {
    const text = 'L’arresto riporta `a registry is not trusted offline for <identity>` (un registro non è attendibile offline per <identity>) quando nessuna politica si applica.';
    const { rejected } = judge(message, text);
    expect(rejected.m).toBe(
      'HTML tags or comments differ from the source: "<identity>" comes from inline code in the source, and outside inline code the page reads it as an HTML tag: keep it inside inline code, as `<identity>`'
    );
  });

  it('accepts a source whose placeholders are all inside inline code, kept there, as before', () => {
    const item = md('Precedence is `--no-<flag>` over `--<flag>`.');
    expect(judge(item, 'La precedenza è `--no-<flag>` su `--<flag>`.').accepted).toEqual({ m: 'La precedenza è `--no-<flag>` su `--<flag>`.' });
  });
});

describe('validateTranslations — what stays refused around placeholders', () => {
  it('inline code added around a word of the source’s inline code', () => {
    const item = md('The message reads `the entity existed before`.');
    const { rejected } = judge(item, 'Il messaggio riporta `the entity existed before` (l’entità `existed` prima).');
    expect(rejected.m).toBe('inline code, a link or image destination, HTML or a reference differs from the source: added "`existed`"');
  });

  it('inline code holding a placeholder the source’s inline code does not hold', () => {
    const item = md('The message reads `failed for <identity>`.');
    const { rejected } = judge(item, 'Il messaggio riporta `failed for <identity>` (`<workspace>`).');
    expect(rejected.m).toBe('inline code, a link or image destination, HTML or a reference differs from the source: added "`<workspace>`"');
  });

  it('a tag the source writes outside inline code, dropped', () => {
    const item = md('Press <kbd>Ctrl</kbd> to stop.');
    expect(judge(item, 'Premi Ctrl per fermare.').rejected.m).toBe('HTML tags or comments differ from the source: missing "<kbd>", "</kbd>"');
  });

  it('a tag added outside inline code that no inline code of the source holds', () => {
    const item = md('The message reads `failed for <identity>`.');
    expect(judge(item, 'Il messaggio riporta `failed for <identity>` <b>ora</b>.').rejected.m).toBe('HTML tags or comments differ from the source: added "<b>", "</b>"');
  });

  it('inline code holding a tag, whose backticks the translation drops', () => {
    const unit = { ...md('Wrap it in `<div>` first.'), protected: [[11, 18]] };
    expect(judge(unit, 'Racchiudilo prima in <div>.').rejected.m).toBe(
      'HTML tags or comments differ from the source: "<div>" comes from inline code in the source, and outside inline code the page reads it as an HTML tag: keep it inside inline code, as `<div>`'
    );
  });

  it('a `text` unit, which has no inline code, counts every tag as before', () => {
    const item = { srcHash: 't', source: 'Reads `x <identity>`.', format: 'text' };
    expect(judge(item, 'Riporta `x <identity>` (`<identity>`).').rejected.t).toBe('HTML tags or comments differ from the source: added "<identity>"');
  });
});

describe('validateTranslations — a placeholder the source’s inline code quotes', () => {
  // An error message whose placeholders the source quotes inside their own inline code.
  const quoted = md('provider does not support omits (`"<provider-name>"`, node `"<node-id>"`). remove the omits key');

  it('accepts it copied, quotes included, into inline code of its own', () => {
    const text = 'provider does not support omits (`"<provider-name>"`, node `"<node-id>"`) (il provider `"<provider-name>"` sul nodo `"<node-id>"` non supporta omits). rimuovi la chiave omits';
    expect(judge(quoted, text).accepted).toEqual({ m: text });
  });

  it('accepts a placeholder whose words hold an apostrophe, as 1.3.1 does', () => {
    const item = md('The halt reads `rejected: <the schema\'s own objection>`.');
    const text = 'Arresto: `rejected: <the schema\'s own objection>` (odrzucono: `<the schema\'s own objection>`).';
    expect(judge(item, text).accepted).toEqual({ m: text });
  });

  it('accepts the bare placeholder in inline code too, as 1.3.1 does', () => {
    const text = 'provider does not support omits (`"<provider-name>"`, node `"<node-id>"`) (provider `<provider-name>`). rimuovi la chiave omits';
    expect(judge(quoted, text).accepted).toEqual({ m: text });
  });

  it('still rejects quotes the source does not write, other text in the code, or a placeholder the source does not hold', () => {
    const base = 'provider does not support omits (`"<provider-name>"`, node `"<node-id>"`)';
    for (const added of ["`'<provider-name>'`", '`il "<provider-name>"`', '`"<other-name>"`']) {
      expect(judge(quoted, `${base} (${added}). rimuovi la chiave omits`).rejected.m, added).toMatch(/^inline code, a link or image destination, HTML or a reference differs from the source: added /);
    }
  });
});

describe('rule 3 states where a copied placeholder goes', () => {
  it('in every transport’s rules', () => {
    expect(translationRules()).toContain(PLACEHOLDER_SENTENCE);
    expect(PLACEHOLDER_SENTENCE).toContain('stays inside inline code');
  });
});
