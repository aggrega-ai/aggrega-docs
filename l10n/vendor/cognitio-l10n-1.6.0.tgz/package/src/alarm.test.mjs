/**
 * alarm.test.mjs — The rejection alarm: a batch's rejections judged against the
 * recent batches' job logs, as pure functions over a store in a temporary
 * directory; and through the command line, `collect` warning of a batch, its job
 * log recording the warning, and `submit` refusing under
 * `backend.alarm.stopSubmissions` until `--resume`.
 *
 * READS and WRITES only temporary directories each test removes. No request
 * leaves the process.
 */

import '../test/no-network.mjs';
import { describe, it, expect, beforeEach, afterEach } from 'vitest';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';

import { runCli } from './cli.mjs';
import { createStore } from './store.mjs';
import { keyOf } from './normalize.mjs';
import { ALARM_MIN_HISTORY, defectKind, judgeBatch, judgedPairs, median } from './alarm.mjs';
import { TRANSLATION_DEFAULTS } from './config.mjs';
import { capture, copyFixtureProject, fakeAnthropic, replyMessage, requestBody, writeJson } from '../test/helpers.mjs';

/** A job log of a transport that judged `judged` pairs and rejected `rejected` of them, with the defects `defects` cycles through. */
function jobLog({ id, at, trigger = 'collect', judged, rejected, defects = ['the translation is empty'], extra = {} }) {
  const failures = Array.from({ length: rejected }, (_, i) => ({ srcHash: `r${String(i).padStart(4, '0')}`, lang: 'en', error: defects[i % defects.length], attempt: 1 }));
  const items = Array.from({ length: judged - rejected }, (_, i) => ({ srcHash: `a${i}`, lang: 'en', source: 's', text: 't', status: 'machine', attempt: 1 }));
  return { id, at, trigger, items, failures, exhausted: [], ...extra, result: rejected ? 'partial' : 'ok' };
}

const at = (n) => `2026-10-${String(1 + Math.floor(n / 24)).padStart(2, '0')}T${String(n % 24).padStart(2, '0')}:00:00.000Z`;

describe('the rejection alarm, judged against the job logs', () => {
  let dir;
  let store;
  beforeEach(() => {
    dir = fs.mkdtempSync(path.join(os.tmpdir(), 'l10n-alarm-'));
    store = createStore({ baseDir: dir });
  });
  afterEach(() => fs.rmSync(dir, { recursive: true, force: true }));

  /** Writes `count` earlier batches of `trigger`, each judging `judged` pairs and rejecting `rejected`; `tag` keeps their ids apart. */
  const history = (count, { judged = 100, rejected = 2, trigger = 'collect', tag = 'old' } = {}) => {
    for (let i = 0; i < count; i++) store.appendJobLog(jobLog({ id: `${trigger}-${tag}-${i}`, at: at(i), trigger, judged, rejected }));
  };

  it('warns of a batch rejected at 20% after a history at about 2%, naming the most frequent defect kinds with a count and an example', () => {
    history(20);
    const defects = [
      'line 3 of the translation is empty, and an empty line ends the paragraph in the page: remove it',
      'line 7 of the translation is empty, and an empty line ends the paragraph in the page: remove it',
      'HTML tags or comments differ from the source: missing "<b>"',
      'the do-not-translate term "Acme" is missing; keep it verbatim',
      'line 2 of the translation is empty, and an empty line ends the paragraph in the page: remove it',
    ];
    const job = jobLog({ id: 'msgbatch_new', at: at(30), judged: 100, rejected: 20, defects });
    const alarm = judgeBatch({ store, job });
    expect(alarm).toMatchObject({ rate: 0.2, rejected: 20, judged: 100, median: 0.02, history: 20, factor: 3, minRate: 0.05 });
    expect(alarm.kinds).toEqual([
      {
        kind: 'line N of the translation is empty, and an empty line ends the paragraph in the page',
        count: 12,
        example: { lang: 'en', srcHash: 'r0000', defect: defects[0] },
      },
      { kind: 'HTML tags or comments differ from the source', count: 4, example: { lang: 'en', srcHash: 'r0002', defect: defects[2] } },
      { kind: 'the do-not-translate term … is missing', count: 4, example: { lang: 'en', srcHash: 'r0003', defect: defects[3] } },
    ]);
  });

  it('does not warn of a single small batch, whatever its rate', () => {
    history(20);
    expect(judgeBatch({ store, job: jobLog({ id: 'small', at: at(30), judged: 10, rejected: 2 }) })).toBeNull();
    expect(judgeBatch({ store, job: jobLog({ id: 'small', at: at(30), judged: 10, rejected: 2 }), settings: { ...TRANSLATION_DEFAULTS.alarm, minPairs: 10 } })).not.toBeNull();
  });

  it(`does not warn while fewer than ${ALARM_MIN_HISTORY} earlier batches of the same transport judged enough pairs`, () => {
    history(ALARM_MIN_HISTORY - 1);
    history(5, { trigger: 'session', tag: 'other-transport' });
    history(5, { judged: 10, rejected: 0, tag: 'too-small' });
    expect(judgeBatch({ store, job: jobLog({ id: 'new', at: at(30), judged: 100, rejected: 40 }) })).toBeNull();
    history(1, { tag: 'one-more' });
    expect(judgeBatch({ store, job: jobLog({ id: 'new', at: at(30), judged: 100, rejected: 40 }) })).toMatchObject({ history: ALARM_MIN_HISTORY });
  });

  it('does not warn of a rate near the history’s, nor of one above it but under minRate', () => {
    history(20);
    expect(judgeBatch({ store, job: jobLog({ id: 'near', at: at(30), judged: 100, rejected: 5 }) })).toBeNull();
    const low = fs.mkdtempSync(path.join(os.tmpdir(), 'l10n-alarm-low-'));
    try {
      const quiet = createStore({ baseDir: low });
      for (let i = 0; i < 20; i++) quiet.appendJobLog(jobLog({ id: `old-${i}`, at: at(i), judged: 200, rejected: 1 }));
      expect(judgeBatch({ store: quiet, job: jobLog({ id: 'new', at: at(30), judged: 100, rejected: 4 }) })).toBeNull();
    } finally {
      fs.rmSync(low, { recursive: true, force: true });
    }
  });

  it('counts the pairs judged alone: a transport failure or an unjudged segment is neither accepted nor rejected', () => {
    const job = jobLog({
      id: 'x',
      at: at(1),
      judged: 100,
      rejected: 2,
      extra: { transport: Array.from({ length: 50 }, (_, i) => ({ srcHash: `t${i}`, lang: 'en', error: 'expired' })), internal: [{ srcHash: 'i', lang: 'en', error: 'a check failed' }] },
    });
    expect(judgedPairs(job)).toEqual({ judged: 100, rejected: 2 });
  });

  it('reads a defect’s kind as its sentence up to its first detail, quoted text and numbers left out', () => {
    expect(defectKind('this identifier was returned 2 times with different texts; return it exactly once')).toBe('this identifier was returned N times with different texts');
    expect(defectKind('the translation holds UTF-8 text decoded in a single-byte code page ("Ã¨"); write each character as itself')).toBe(
      'the translation holds UTF-8 text decoded in a single-byte code page'
    );
    expect(defectKind('line 2 of the translation begins with "# Foo: bar", which starts a new Markdown block in the page: move the line break')).toBe(
      'line N of the translation begins with …, which starts a new Markdown block in the page'
    );
    expect(median([0.3, 0.01, 0.02])).toBe(0.02);
    expect(median([0.01, 0.02, 0.03, 0.04])).toBe(0.025);
  });
});

describe('l10n collect and submit: the rejection alarm on the fixture project', () => {
  let project;
  beforeEach(() => {
    project = copyFixtureProject('l10n-alarm-project-');
  });
  afterEach(() => fs.rmSync(project, { recursive: true, force: true }));

  const memory = (...p) => path.join(project, 'memory', ...p);
  const readJson = (file) => JSON.parse(fs.readFileSync(file, 'utf8'));

  async function run(argv, deps = {}) {
    const io = capture();
    const code = await runCli(argv, { cwd: project, env: { ANTHROPIC_API_KEY: 'test-key' }, log: io.log, errlog: io.errlog, ...deps });
    return { code, out: io.text(), err: io.errors() };
  }

  /** Sets `backend.alarm`, and writes five earlier collections that rejected one pair in fifty. */
  function setUp(alarm) {
    const file = path.join(project, 'l10n.config.json');
    const config = readJson(file);
    if (alarm) config.backend.alarm = alarm;
    writeJson(file, config);
    const store = createStore({ baseDir: memory() });
    for (let i = 0; i < 5; i++) store.appendJobLog(jobLog({ id: `msgbatch_old${i}`, at: at(i), judged: 50, rejected: 1 }));
  }

  /** The fake model, answering every segment but "Benvenuti", which it leaves empty. */
  const rejectsOne = (params) => {
    const body = requestBody(params);
    const sources = new Map(body.segments.map((s) => [s.id, s.source]));
    return replyMessage(body.translate.map((id) => ({ id, text: id === keyOf('Benvenuti') ? '' : `[x] ${sources.get(id)}` })));
  };

  async function submitAndCollect(fake) {
    expect((await run(['extract'])).code).toBe(0);
    expect((await run(['submit'], { ClientClass: fake.FakeAnthropic })).code).toBe(0);
    return run(['collect'], { ClientClass: fake.FakeAnthropic });
  }

  it('warns of the batch, records the warning in its job log, and with stopSubmissions halts submit until --resume', async () => {
    setUp({ minPairs: 5, stopSubmissions: true });
    const fake = fakeAnthropic({ reply: rejectsOne });
    const collected = await submitAndCollect(fake);
    expect(collected.code).toBe(0);
    expect(collected.err).toContain(
      'collect: batch msgbatch_fake1: rejection alarm: 1 of 6 judged pairs were rejected (16.7%), above 3 times the median of the last 5 batches (2.0%) and above 5.0%.'
    );
    expect(collected.err).toContain(`1 × the translation is empty; for example en ${keyOf('Benvenuti')}: the translation is empty`);
    const job = fs.readdirSync(memory('jobs')).map((f) => readJson(memory('jobs', f))).find((j) => j.id === 'msgbatch_fake1');
    expect(job.alarm).toMatchObject({ rejected: 1, judged: 6, history: 5, kinds: [{ kind: 'the translation is empty', count: 1 }] });
    expect(readJson(memory('pending.json')).halt).toMatchObject({ batch: 'msgbatch_fake1', kind: 'rejections' });

    const refused = await run(['submit'], { ClientClass: fake.FakeAnthropic });
    expect(refused.code).toBe(1);
    expect(refused.err).toContain('submit: submission is halted since');
    expect(refused.err).toContain('had its translations rejected far more often than the recent batches (1 of 6 judged pairs rejected');
    expect(refused.err).toContain('then run `l10n submit --resume`. No batch created.');
    expect(fake.calls.batchCreate).toHaveLength(1);
    expect((await run(['status'])).out).toContain('`l10n submit --resume` submits again once the cause is found.');

    const resumed = await run(['submit', '--resume'], { ClientClass: fake.FakeAnthropic });
    expect(resumed.code).toBe(0);
    expect(resumed.out).toContain('submit: --resume: the halt is cleared');
    expect(fake.calls.batchCreate).toHaveLength(2);
    expect(readJson(memory('pending.json')).halt).toBeUndefined();
  });

  it('only warns without stopSubmissions: submit goes on', async () => {
    setUp({ minPairs: 5 });
    const fake = fakeAnthropic({ reply: rejectsOne });
    const collected = await submitAndCollect(fake);
    expect(collected.err).toContain('rejection alarm: 1 of 6 judged pairs were rejected');
    expect(readJson(memory('pending.json')).halt).toBeUndefined();
    expect((await run(['submit'], { ClientClass: fake.FakeAnthropic })).code).toBe(0);
  });

  it('does not warn of a single small batch under the default settings', async () => {
    setUp(null);
    const fake = fakeAnthropic({ reply: rejectsOne });
    const collected = await submitAndCollect(fake);
    expect(collected.code).toBe(0);
    expect(collected.err).not.toContain('rejection alarm');
    const job = fs.readdirSync(memory('jobs')).map((f) => readJson(memory('jobs', f))).find((j) => j.id === 'msgbatch_fake1');
    expect(job.alarm).toBeUndefined();
  });

  it('reads a halt an earlier version recorded, with no kind, as a failure of the account', async () => {
    setUp(null);
    writeJson(memory('pending.json'), { batches: [], queue: {}, halt: { at: '2026-10-20T00:00:00Z', batch: 'msgbatch_old', reason: 'billing_error' } });
    const refused = await run(['submit']);
    expect(refused.code).toBe(1);
    expect(refused.err).toContain('batch msgbatch_old failed for the account (billing_error)');
    expect(refused.err).toContain("Fix the account — its credit, its spending limit, the key's permissions — then run `l10n submit --resume`.");
  });
});
