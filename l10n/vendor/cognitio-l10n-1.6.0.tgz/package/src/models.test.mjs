/**
 * models.test.mjs — The models' reasoning settings: the table's rules as pure
 * functions, the README section generated from it, and `l10n doctor`'s model
 * settings check on a copy of the JSON-site example.
 *
 * READS the package README and the example. WRITES only the temporary copies it
 * makes. No request leaves the process.
 */

import '../test/no-network.mjs';
import { describe, it, expect, afterEach } from 'vitest';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

import { runCli } from './cli.mjs';
import { MODEL_REASONING, modelRules, reasoningProblem, renderModelTable } from './models.mjs';
import { MODEL_SECTION, readReference } from './config-reference.mjs';
import { capture, copyExample } from '../test/helpers.mjs';

const README = fileURLToPath(new URL('../README.md', import.meta.url));

/** The combinations a model refuses, and the words the refusal must name. */
const REFUSED = [
  { model: { id: 'claude-opus-5-5', thinking: { type: 'disabled' } }, names: ['Claude Opus 5.5', 'claude-opus-5-5', '"disabled"'] },
  { model: { id: 'claude-opus-5-5', thinking: { type: 'between_tools' }, effort: 'low' }, names: ['Claude Opus 5.5', '"between_tools"'] },
  { model: { id: 'claude-sonnet-5-5', thinking: { type: 'disabled' } }, names: ['Claude Sonnet 5.5', '"disabled"'] },
  { model: { id: 'claude-sonnet-5-5', thinking: { type: 'between_tools' }, effort: 'xhigh' }, names: ['Claude Sonnet 5.5', '"between_tools"', '"xhigh"'] },
  { model: { id: 'claude-sonnet-5-5', thinking: { type: 'between_tools' }, effort: 'max' }, names: ['Claude Sonnet 5.5', '"between_tools"', '"max"'] },
  { model: { id: 'claude-haiku-5-5', thinking: { type: 'between_tools' } }, names: ['Claude Haiku 5.5', '"between_tools"'] },
  { model: { id: 'claude-haiku-5-5', thinking: { type: 'disabled' }, effort: 'xhigh' }, names: ['Claude Haiku 5.5', '"disabled"', '"xhigh"'] },
  { model: { id: 'claude-haiku-5-5', thinking: { type: 'disabled' }, effort: 'max' }, names: ['Claude Haiku 5.5', '"disabled"', '"max"'] },
];

/** Combinations the models accept. */
const ACCEPTED = [
  { id: 'claude-opus-5-5', effort: 'low' },
  { id: 'claude-opus-5-5', thinking: { type: 'adaptive' }, effort: 'max' },
  { id: 'claude-sonnet-5-5', thinking: { type: 'between_tools' } },
  { id: 'claude-sonnet-5-5', thinking: { type: 'between_tools' }, effort: 'high' },
  { id: 'claude-haiku-5-5', thinking: { type: 'disabled' } },
  { id: 'claude-haiku-5-5', thinking: { type: 'disabled' }, effort: 'high' },
  { id: 'claude-haiku-5-5', thinking: { type: 'disabled' }, effort: 'low' },
];

describe('the reasoning settings each model accepts', () => {
  for (const row of REFUSED) {
    it(`refuses ${JSON.stringify(row.model)}, naming the model and the setting`, () => {
      const problem = reasoningProblem(row.model);
      expect(problem).not.toBeNull();
      for (const name of row.names) expect(problem).toContain(name);
    });
  }

  for (const model of ACCEPTED) {
    it(`accepts ${JSON.stringify(model)}`, () => {
      expect(reasoningProblem(model)).toBeNull();
    });
  }

  it('reads a dated id as its model, and holds no rules for an id it does not know', () => {
    expect(modelRules('claude-opus-5-5-20261001')).toBe(MODEL_REASONING[0]);
    expect(reasoningProblem({ id: 'claude-opus-5-5-20261001', thinking: { type: 'disabled' } })).toContain('Claude Opus 5.5');
    expect(modelRules('claude-opus-5-50')).toBeNull();
    expect(modelRules('some-other-model')).toBeNull();
    expect(reasoningProblem({ id: 'some-other-model', thinking: { type: 'disabled' }, effort: 'max' })).toBeNull();
  });

  it('every example the README shows is a setting its model accepts', () => {
    for (const m of MODEL_REASONING) expect(reasoningProblem(JSON.parse(m.example))).toBeNull();
  });

  it('the README’s model table is a fresh generation from the one table doctor checks against', () => {
    expect(readReference(fs.readFileSync(README, 'utf8'), MODEL_SECTION)).toBe(renderModelTable());
  });
});

describe('l10n doctor: the model settings check', () => {
  const dirs = [];
  afterEach(() => {
    for (const dir of dirs.splice(0)) fs.rmSync(dir, { recursive: true, force: true });
  });

  /** Runs doctor on a copy of the JSON-site example whose configuration `edit` changed. */
  async function doctor(edit) {
    const root = copyExample('json-site');
    dirs.push(root);
    const file = path.join(root, 'l10n.config.json');
    const config = JSON.parse(fs.readFileSync(file, 'utf8'));
    edit(config);
    fs.writeFileSync(file, JSON.stringify(config, null, 2) + '\n');
    const io = capture();
    const code = await runCli(['doctor'], { cwd: root, env: {}, log: io.log, errlog: io.errlog });
    const line = io.out.find((l) => l.includes(' model settings: ')) || '';
    return { code, line, status: line.trim().split(/\s{2,}/)[0], summary: io.out.at(-1) };
  }

  for (const row of REFUSED) {
    it(`fails on backend.model ${JSON.stringify(row.model)}, naming the model and the setting`, async () => {
      const run = await doctor((c) => (c.backend.model = row.model));
      expect(run.code).toBe(1);
      expect(run.status).toBe('FAIL');
      for (const name of row.names) expect(run.line).toContain(name);
      expect(run.summary).toContain('model settings');
    });
  }

  it('checks backend.retryModel as it checks backend.model', async () => {
    const run = await doctor((c) => (c.backend.retryModel = { id: 'claude-sonnet-5-5', thinking: { type: 'disabled' } }));
    expect(run.code).toBe(1);
    expect(run.line).toContain('backend.retryModel: Claude Sonnet 5.5 (claude-sonnet-5-5) refuses thinking "disabled"');
  });

  for (const model of ACCEPTED) {
    it(`passes on backend.model ${JSON.stringify(model)}`, async () => {
      const run = await doctor((c) => (c.backend.model = model));
      expect(run.code).toBe(0);
      expect(run.status).toBe('pass');
      expect(run.line).toContain('accepted');
    });
  }

  it('passes an id it holds no rules for, with a note that its settings are not checked', async () => {
    const run = await doctor((c) => (c.backend.model = { id: 'claude-future-9', thinking: { type: 'disabled' }, effort: 'max' }));
    expect(run.code).toBe(0);
    expect(run.status).toBe('pass');
    expect(run.line).toContain('claude-future-9: the package holds no rules for this model, so its reasoning settings are not checked');
  });

  it('checks the id the glossary’s model puts on the requests', async () => {
    const run = await doctor((c) => {
      c.backend.model = { id: 'claude-opus-5-5', thinking: { type: 'disabled' } };
      const glossary = path.join(dirs.at(-1), 'i18n', 'glossary.json');
      fs.writeFileSync(glossary, JSON.stringify({ ...JSON.parse(fs.readFileSync(glossary, 'utf8')), model: 'claude-haiku-5-5' }));
    });
    expect(run.code).toBe(0);
    expect(run.line).toContain('backend.model claude-haiku-5-5: thinking "disabled", accepted');
  });

  it('warns, and still exits 0, when backend.model.fallbackId is the model itself', async () => {
    const run = await doctor((c) => (c.backend.model = { id: 'claude-opus-5-5', effort: 'low', fallbackId: 'claude-opus-5-5' }));
    expect(run.code).toBe(0);
    expect(run.status).toBe('warn');
    expect(run.line).toContain('backend.model.fallbackId is claude-opus-5-5, the model itself');
    expect(run.summary).toBe('doctor: all 9 checks passed, 1 with a warning: model settings.');
  });
});
