/**
 * models.mjs — The reasoning settings each model accepts: the one table `doctor`
 * checks a configuration against and the package README prints
 * (`renderModelTable`, written by `npm run reference`).
 *
 * READS nothing and WRITES nothing: a table and pure functions over it.
 *
 * Reasoning is billed as output and translation does not need it, so a
 * configuration turns it off or down; but a model refuses a setting it does not
 * accept, and every request of a run then fails at the API. A model's rules here
 * are what Anthropic documents for it: the `thinking` types it refuses, and for a
 * type it accepts only up to some effort, that effort. A model id the table does
 * not hold is not checked.
 */

/** The effort levels, lowest first, as the configuration's schema names them. */
export const EFFORTS = Object.freeze(['low', 'medium', 'high', 'xhigh', 'max']);

/**
 * Each model's rules: `refuses`, the `thinking` types it refuses; `maxEffort`, for
 * a type it accepts only up to an effort, that effort; `example`, the
 * `backend.model` the README shows for it; `note`, what the README says of it.
 */
export const MODEL_REASONING = Object.freeze([
  Object.freeze({
    id: 'claude-opus-5-5',
    name: 'Claude Opus 5.5',
    refuses: Object.freeze(['disabled', 'between_tools']),
    maxEffort: Object.freeze({}),
    example: '{ "id": "claude-opus-5-5", "effort": "low" }',
    note: 'thinking omitted: this model cannot turn it off, so effort is the only control.',
  }),
  Object.freeze({
    id: 'claude-sonnet-5-5',
    name: 'Claude Sonnet 5.5',
    refuses: Object.freeze(['disabled']),
    maxEffort: Object.freeze({ between_tools: 'high' }),
    example: '{ "id": "claude-sonnet-5-5", "thinking": { "type": "between_tools" } }',
    note: 'it refuses `disabled`; `between_tools` is accepted at effort `high` or below.',
  }),
  Object.freeze({
    id: 'claude-haiku-5-5',
    name: 'Claude Haiku 5.5',
    refuses: Object.freeze(['between_tools']),
    maxEffort: Object.freeze({ disabled: 'high' }),
    example: '{ "id": "claude-haiku-5-5", "thinking": { "type": "disabled" } }',
    note: 'it refuses `between_tools`; `disabled` is accepted at effort `high` or below.',
  }),
]);

/** The rules of a model id — the id itself, or the id with a date or version suffix — or null when the table has none. */
export function modelRules(id) {
  if (typeof id !== 'string') return null;
  return MODEL_REASONING.find((m) => id === m.id || id.startsWith(`${m.id}-`)) || null;
}

/**
 * Why a model refuses a reasoning setting, or null when it accepts it or the
 * table has no rules for the model.
 *
 * @param {Object} args
 * @param {string} args.id
 * @param {{type:string}|undefined} [args.thinking]
 * @param {string|undefined} [args.effort]
 * @returns {string|null}
 */
export function reasoningProblem({ id, thinking, effort }) {
  const rules = modelRules(id);
  if (!rules || !thinking) return null;
  if (rules.refuses.includes(thinking.type)) return `${rules.name} (${id}) refuses thinking "${thinking.type}"`;
  const ceiling = rules.maxEffort[thinking.type];
  if (ceiling && effort && EFFORTS.indexOf(effort) > EFFORTS.indexOf(ceiling)) {
    return `${rules.name} (${id}) accepts thinking "${thinking.type}" only at effort "${ceiling}" or below, and the effort is "${effort}"`;
  }
  return null;
}

/** The README's table of the models' settings, rendered from `MODEL_REASONING`. */
export function renderModelTable() {
  return [
    'Generated from `MODEL_REASONING` in `src/models.mjs` by `npm run reference`; `l10n doctor` checks a configuration against the same table.',
    '',
    '| Model | `backend.model` |',
    '|---|---|',
    ...MODEL_REASONING.map((m) => `| ${m.name} | \`${m.example}\` — ${m.note} |`),
  ].join('\n');
}

export default { EFFORTS, MODEL_REASONING, modelRules, reasoningProblem, renderModelTable };
