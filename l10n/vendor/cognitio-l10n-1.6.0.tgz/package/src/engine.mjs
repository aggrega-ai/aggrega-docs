/**
 * engine.mjs — Orchestration of the translation engine (site-agnostic,
 * dependency-injected).
 *
 * The engine knows neither the site's content model nor the translation backend:
 * both are INJECTED.
 *   - `adapter` (per content model): `extract()`→catalog (plus optional `stats`,
 *     counts the adapter reports about what it read),
 *     `pages()`→the ordered pages a request is built from (see `requests.mjs`),
 *     `generate({tmByLang})`→writes the target artifacts,
 *     `seedAlign?({store, targets})`→seed pairs. It defines what "translatable"
 *     means. An adapter without `pages()` gets one page per catalogue usage file.
 *   - `backend` (the translator): `async translate({request, items, lang, sourceLang, glossary})`
 *     → the reply as `{entries:[{id,text}]}`, `{translations:{id→text}}` or a
 *     bare `{id→text}` map, or `{refusal}` / `{defect}`, with an optional `model`.
 *     `request` is the planned request; `items` are its requested units, each with
 *     its `srcHash`, `source`, `format` and, when the unit has them, its `context`
 *     and `protected` spans.
 *
 * The engine's own responsibilities: catalog and memory I/O (through the store),
 * the mechanical gate, the translate stage — page requests from the one request
 * builder, bounded concurrency, retry and backoff on transient errors only, the
 * one validation of every reply, resubmission of rejected and refused segments up
 * to the attempt limit, crash-safe per-request memory writes — a job log, and
 * non-destructive collection of orphans.
 *
 * THE LAYERS. A translation run writes only the MACHINE layer; `seed` writes the
 * HUMAN layer, or with `--layer machine` the machine layer. Every read the gate and generation make is the lookup view, in
 * which the human entry wins.
 *
 * READS and WRITES only through the store — the memory directory's
 * `source.json`, `messages/`, `machine/` and `jobs/`. It never touches the
 * content tree; writing target-locale artifacts is the adapter's job.
 *
 * No network call lives in here: the injected backend encapsulates it, and the
 * tests inject a fake backend.
 */

import { createStore } from './store.mjs';
import { computeWorklist, orphanKeys } from './gate.mjs';
import { LAYER, STATUS, RESULT } from './types.mjs';
import { TRANSLATION_DEFAULTS } from './config.mjs';
import { doNotTranslateOf, isTransient } from './translator-prompt.mjs';
import { pagesFromCatalog, planRequests } from './requests.mjs';
import { recordedText, returnedTexts, validateTranslations } from './validate.mjs';
import { clearQueued, queueDefect, refusalDefect } from './pending.mjs';
import { findRevisions } from './revisions.mjs';
import { markedFromStore, settleAccepted, withMarked, withMarkedRevisions } from './retranslate.mjs';

/**
 * The machine entry for an accepted translation, recording the revision it was
 * written from when its request carried one — for a pair marked for
 * re-translation, that it was forced, and the mark's reason. Every writer of the
 * machine layer builds its entries here, so they all record a revision the same
 * way.
 *
 * @param {Object} args
 * @param {string} args.srcHash
 * @param {string} args.text
 * @param {string} args.job
 * @param {string} args.at
 * @param {import('./types.mjs').Revision} [args.revision]
 * @returns {import('./types.mjs').TMEntry}
 */
export function machineEntry({ srcHash, text, job, at, revision }) {
  return {
    text,
    status: STATUS.MACHINE,
    srcHash,
    job,
    at,
    ...(revision
      ? { revision: { from: revision.from, reviewed: Boolean(revision.reviewed), ...(revision.forced ? { forced: true, reason: revision.reason } : {}) } }
      : {}),
  };
}

/**
 * The machine translations that revise a reviewed translation and that no
 * person has reviewed since, per locale: every machine entry whose revision is
 * marked reviewed, whose key the catalogue still holds and the human layer does
 * not. Each comes with the files its unit is used in, for the reviewer to find.
 *
 * @param {Object} args
 * @param {ReturnType<import('./store.mjs').createStore>} args.store
 * @param {string[]} args.targets
 * @returns {Object.<string, Array<{key:string, from:string, files:string[]}>>}
 */
export function reviewList({ store, targets }) {
  const units = store.readSourceCatalog().units || {};
  const out = {};
  for (const lang of targets) {
    const machine = store.readLayer(LAYER.MACHINE, lang);
    const humanLayer = store.readLayer(LAYER.HUMAN, lang);
    const rows = [];
    for (const key of Object.keys(machine).sort()) {
      const entry = machine[key];
      if (!entry || !entry.revision || !entry.revision.reviewed) continue;
      if (!units[key] || Object.prototype.hasOwnProperty.call(humanLayer, key)) continue;
      const files = [...new Set((units[key].usages || []).map((u) => u.file))].sort();
      rows.push({ key, from: entry.revision.from, files });
    }
    if (rows.length) out[lang] = rows;
  }
  return out;
}

/**
 * The engine's defaults. `attempts` bounds the retries of one call on a
 * transient error; `attemptLimit` bounds the requests per segment when its
 * translation is rejected or refused.
 */
const DEFAULTS = {
  concurrency: 4,
  attempts: 3,
  backoffMs: 500,
  model: undefined,
  attemptLimit: TRANSLATION_DEFAULTS.attempts,
  sectionTokens: TRANSLATION_DEFAULTS.sectionTokens,
  fallbackId: undefined,
};

/** The reply's entries, whichever of the accepted shapes a backend returned; null when it carried none. */
function replyEntries(raw) {
  if (!raw || typeof raw !== 'object') return null;
  if (Array.isArray(raw.entries)) return raw.entries;
  if (raw.refusal || typeof raw.defect === 'string') return null;
  const map = raw.translations && typeof raw.translations === 'object' ? raw.translations : raw;
  return Object.entries(map)
    .filter(([id]) => id !== 'model' && id !== 'tokensById')
    .map(([id, text]) => ({ id, text }));
}

const sleepReal = (ms) => new Promise((r) => setTimeout(r, ms));

/**
 * Runs `fn` with retry and backoff on transient errors ONLY. Application errors
 * are not retried: they propagate immediately.
 */
async function callWithRetry(fn, { attempts, backoffMs, sleep }) {
  let last;
  for (let attempt = 1; attempt <= attempts; attempt++) {
    try {
      return await fn();
    } catch (err) {
      last = err;
      if (attempt < attempts && isTransient(err)) {
        await sleep(backoffMs * attempt);
        continue;
      }
      throw err;
    }
  }
  throw last;
}

/** A bounded-concurrency pool: runs `worker(task)` over `tasks` with `size` runners. */
async function runPool(tasks, size, worker) {
  const results = new Array(tasks.length);
  let cursor = 0;
  const runnerCount = Math.max(1, Math.min(size, tasks.length || 1));
  const runners = Array.from({ length: runnerCount }, async () => {
    while (cursor < tasks.length) {
      const i = cursor++;
      results[i] = await worker(tasks[i], i);
    }
  });
  await Promise.all(runners);
  return results;
}

/**
 * Creates the engine.
 *
 * @param {Object} cfg
 * @param {Object} [cfg.adapter]   The per-site adapter (extract/pages/generate/seedAlign).
 * @param {Object} [cfg.backend]   The translation backend (translate()).
 * @param {Object} cfg.paths       { baseDir }: the memory directory, required.
 * @param {Object} [cfg.options]   { concurrency, attempts, backoffMs, model,
 *                                   attemptLimit, sectionTokens, fallbackId,
 *                                   idGen, now, sleep, fsImpl }.
 */
export function createEngine({ adapter = null, backend = null, paths = {}, options = {} } = {}) {
  const store = createStore({ baseDir: paths.baseDir, fsImpl: options.fsImpl });
  const opt = { ...DEFAULTS, ...options };
  const now = options.now || (() => new Date().toISOString());
  const idGen =
    options.idGen ||
    (() => Math.random().toString(16).slice(2, 10) + Date.now().toString(16).slice(-4));
  const sleep = options.sleep || sleepReal;

  /**
   * extract — delegates catalog production to the adapter, then persists it
   * (source.json) and updates the source map (srcHash→source). Returns the
   * catalog, its unit count and, when the adapter reports them, its `stats`.
   */
  async function extract() {
    if (!adapter || typeof adapter.extract !== 'function') {
      throw new Error('adapter.extract is not configured');
    }
    const produced = await adapter.extract();
    if (!produced || typeof produced.source_lang !== 'string' || produced.source_lang === '') {
      throw new Error('adapter.extract returned a catalog with no source_lang');
    }
    const units = produced.units || {};
    const catalog = {
      generated_at: produced.generated_at || now(),
      source_lang: produced.source_lang,
      units,
    };
    store.writeSourceCatalog(catalog);
    const sourceMap = {};
    for (const [key, unit] of Object.entries(units)) sourceMap[key] = unit.source;
    store.mergeSourceMap(sourceMap);
    return {
      catalog,
      unitCount: Object.keys(units).length,
      ...(produced.stats !== undefined ? { stats: produced.stats } : {}),
    };
  }

  /**
   * gate — reads the catalog plus the targets' TM from disk and computes the
   * worklist. Free of token cost: hashing and set arithmetic only.
   */
  function gate({ targets }) {
    const catalog = store.readSourceCatalog();
    const tmByLang = store.readAllTM(targets || []);
    return computeWorklist(catalog, { targets: targets || [], tmByLang });
  }

  /**
   * translate — the synchronous translate stage. Reads the worklist, finds the
   * earlier version each changed segment starts from (`revisions.mjs`), plans the
   * page requests (`requests.mjs`), sends each through the backend with bounded
   * concurrency and transient retry/backoff, validates every reply
   * (`validate.mjs`), writes the accepted segments to the MACHINE layer per
   * request (crash-safe) as it goes, and plans again for the rejected and
   * refused ones, stating each defect, until none is left or the attempt limit
   * is reached. A request that throws after its transient retries fails its
   * segments for this run. Every segment left untranslated is named in the job
   * log, which is appended at the end, and so is every identifier a reply
   * returned that its request did not ask for, which is dropped (`dropped`). The
   * pairs marked for re-translation are planned beside the missing ones, each as
   * a revision of itself (`retranslate.mjs`); an accepted one clears its mark and,
   * for a mark over a person's entry, archives that entry, the one write this
   * stage makes to the human layer, which it otherwise only reads.
   * Returns { result, job, jobFile, worklist }.
   */
  async function translate({ targets, glossary = {}, trigger = 'dispatch', languagesAdded } = {}) {
    if (!backend || typeof backend.translate !== 'function') {
      throw new Error('backend.translate is not configured');
    }
    const langs = targets || [];
    const { entries: doNotTranslate, caseSensitive } = doNotTranslateOf(glossary);
    const catalog = store.readSourceCatalog();
    const missing = computeWorklist(catalog, { targets: langs, tmByLang: store.readAllTM(langs) });
    const marked = markedFromStore(store, langs);
    const worklist = withMarked(missing, marked, langs);
    if (worklist.status === 'up-to-date') {
      return { result: RESULT.OK, job: null, jobFile: null, worklist };
    }

    const jobId = idGen();
    const jobAt = now();
    /** @type {import('./types.mjs').JobItem[]} */
    const jobItems = [];
    /** @type {import('./types.mjs').JobDropped[]} */
    const dropped = [];
    const hardFailures = new Map(); // `${lang} ${srcHash}` → the error that ended it this run
    const lastRejected = new Map(); // `${lang} ${srcHash}` → the text its last rejected or unjudged translation held
    const queue = {};
    const pages = adapter && typeof adapter.pages === 'function' ? await adapter.pages() : pagesFromCatalog(catalog);
    // Found once for the run: the orphans and their sources do not change between rounds. A marked pair is a revision
    // of itself, so it is kept out of the search for changed segments' earlier versions.
    const revisions = findRevisions({ worklist: missing, tmByLang: store.readAllTM(langs), sources: store.readRecordedSources(), targets: langs });
    let unplaced = {};

    for (let round = 1; round <= opt.attemptLimit; round++) {
      const tmByLang = store.readAllTM(langs);
      // The marks are read each round: an accepted re-translation has cleared its own.
      const markedNow = markedFromStore(store, langs);
      const current = withMarked(computeWorklist(catalog, { targets: langs, tmByLang }), markedNow, langs);
      if (current.status === 'up-to-date') break;
      const open = {
        ...current,
        items: current.items
          .map((it) => ({ ...it, missing: it.missing.filter((lang) => !hardFailures.has(`${lang} ${it.srcHash}`)) }))
          .filter((it) => it.missing.length > 0),
      };
      const plan = planRequests({
        pages,
        worklist: open,
        tmByLang,
        targets: langs,
        sectionTokens: opt.sectionTokens,
        attemptLimit: opt.attemptLimit,
        queue,
        revisions: withMarkedRevisions(revisions, markedNow),
      });
      if (round === 1) unplaced = plan.unplaced;
      if (plan.specs.length === 0) break;

      await runPool(plan.specs, opt.concurrency, async (spec) => {
        const { lang } = spec;
        let raw;
        try {
          raw = await callWithRetry(
            () =>
              backend.translate({
                request: spec,
                items: spec.items,
                lang,
                sourceLang: catalog.source_lang,
                glossary,
                ...(adapter && adapter.identity && adapter.identity !== 'text' ? { identity: adapter.identity } : {}),
              }),
            { attempts: opt.attempts, backoffMs: opt.backoffMs, sleep }
          );
        } catch (err) {
          const error = String((err && err.message) || err);
          for (const id of spec.requested) hardFailures.set(`${lang} ${id}`, error);
          return;
        }
        if (raw && raw.refusal) {
          queueDefect(queue, {
            lang,
            ids: spec.requested,
            attempt: spec.attempt,
            defect: refusalDefect(raw.refusal),
            refusal: true,
            wasFallback: spec.fallback,
            fallbackId: opt.fallbackId,
          });
          return;
        }
        const model = (raw && raw.model) || opt.model;
        const validation = validateTranslations({
          items: spec.items,
          entries: replyEntries(raw),
          replyDefect: raw && raw.defect,
          doNotTranslate,
          caseSensitive,
        });
        const { accepted, rejected } = validation;
        for (const id of validation.dropped) dropped.push({ id, lang, page: spec.page, section: spec.section ?? null });
        const entries = {};
        const sources = {};
        for (const item of spec.items) {
          const text = accepted[item.srcHash];
          if (typeof text !== 'string') continue;
          const revision = spec.revise && spec.revise[item.srcHash];
          entries[item.srcHash] = machineEntry({ srcHash: item.srcHash, text, job: jobId, at: jobAt, revision });
          sources[item.srcHash] = item.source;
          const jobItem = { srcHash: item.srcHash, lang, source: item.source, text, status: STATUS.MACHINE, attempt: spec.attempt };
          if (model) jobItem.model = model;
          if (revision && revision.forced) Object.assign(jobItem, { forced: true, reason: revision.reason });
          jobItems.push(jobItem);
        }
        // Crash-safe per-request write: whatever is accepted is persisted before
        // the next request's reply is read.
        if (Object.keys(entries).length > 0) {
          store.writeLayerEntries(LAYER.MACHINE, lang, entries);
          store.mergeSourceMap(sources);
          store.mergeMachineSources(sources);
          clearQueued(queue, lang, Object.keys(entries));
          settleAccepted({ store, lang, ids: Object.keys(entries), revisions: spec.revise });
        }
        const rejectedIds = Object.keys(rejected);
        if (rejectedIds.length > 0) {
          queueDefect(queue, { lang, ids: rejectedIds, attempt: spec.attempt, defect: validation.replyDefect ?? rejected, wasFallback: spec.fallback, fallbackId: opt.fallbackId });
        }
        const returned = returnedTexts(replyEntries(raw));
        for (const id of [...rejectedIds, ...Object.keys(validation.internal || {})]) {
          if (returned.has(id)) lastRejected.set(`${lang} ${id}`, returned.get(id));
        }
        // A segment a check could not judge is the package's failure: it is not queued, so no attempt counts, and it
        // is not requested again in this run.
        for (const [id, error] of Object.entries(validation.internal || {})) {
          hardFailures.set(`${lang} ${id}`, `internal error, not a defect of the translation: ${error}`);
        }
      });
    }

    // Every slot still missing, and every marked pair still waiting for its re-translation, is named, with why.
    const finalTm = store.readAllTM(langs);
    const stillMarked = markedFromStore(store, langs).pairs;
    /** @type {import('./types.mjs').JobFailure[]} */
    const failures = [];
    for (const item of worklist.items) {
      for (const lang of item.missing) {
        const waiting = marked.pairs.has(lang) && marked.pairs.get(lang).has(item.srcHash);
        if (waiting ? !(stillMarked.has(lang) && stillMarked.get(lang).has(item.srcHash)) : Object.prototype.hasOwnProperty.call(finalTm[lang] || {}, item.srcHash)) continue;
        const queued = queue[lang] && queue[lang][item.srcHash];
        const error =
          hardFailures.get(`${lang} ${item.srcHash}`) ||
          (queued
            ? `${queued.defect} (after ${queued.attempts} attempt${queued.attempts === 1 ? '' : 's'})`
            : (unplaced[lang] || []).includes(item.srcHash)
              ? 'appears on no page: the catalogue is older than the content; run extract'
              : waiting
                ? 'not re-translated; the current translation still serves'
                : 'not translated');
        failures.push({ srcHash: item.srcHash, lang, error, ...recordedText(lastRejected.get(`${lang} ${item.srcHash}`)) });
      }
    }

    const result =
      failures.length === 0
        ? RESULT.OK
        : jobItems.length === 0
          ? RESULT.FAILED
          : RESULT.PARTIAL;

    /** @type {import('./types.mjs').JobLog} */
    const job = { id: jobId, at: jobAt, trigger, items: jobItems, failures, result };
    if (languagesAdded && languagesAdded.length) job.languages_added = languagesAdded;
    if (dropped.length) job.dropped = dropped;
    const jobFile = store.appendJobLog(job);

    return { result, job, jobFile, worklist };
  }

  /**
   * generate — delegates the rewriting of the target artifacts to the adapter,
   * handing it the TM per language.
   */
  async function generate({ targets } = {}) {
    if (!adapter || typeof adapter.generate !== 'function') {
      throw new Error('adapter.generate is not configured');
    }
    const langs = targets && targets.length ? targets : store.listLangs();
    const tmByLang = store.readAllTM(langs);
    const outcome = await adapter.generate({ tmByLang, store, targets: langs });
    return outcome || { targets: langs };
  }

  /**
   * seed — imports existing translation pairs as entries of one layer. The
   * adapter supplies the alignment (and receives the store, so it compares
   * against the human layer and writes its report beside the memory); the
   * engine stamps the entries and persists them with the source map. It
   * returns { entriesByLang: {lang:{key:{text,...}}}, sourceEntries?:{key:source},
   * files?:{key:target file}, at?:{key:keys and indexes in that file} }.
   *
   * In the HUMAN layer (the default) the entries are `seed` entries. In the
   * MACHINE layer they are `machine` entries, as a translation run writes them
   * (`job: "seed"`), each with the `origin` its target file's copy record gives
   * (`originOf`), the source recorded beside the layer, and a key the human
   * layer holds left to it. Only a text the project still holds as copied
   * (`originOf` gives it the status `in sync`) is written; every other text is
   * left out and returned in `left`. A machine entry that already holds the
   * text is kept when a translation run wrote it (it has no `origin`) or when
   * its origin is the same, so a re-seed never gives a run's translation an
   * origin and seeding the same copies again changes no byte.
   *
   * @param {Object} [args]
   * @param {string[]} [args.targets]  the target locales to seed (the adapter's default when absent).
   * @param {'human'|'machine'} [args.layer]  the layer written (default human).
   * @param {(file:string, at:(string|number)[])=>{target:string, path:string, origin:string|null, status:string|null}} [args.originOf]
   *   for the machine layer: where a text sits (its target file and the keys and indexes leading to it) as the
   *   project's record of copied texts names it, the `@<scope>/<module>@<version>` the file was copied from
   *   (null when the record does not hold the file) and the text's status there (null when the record does not
   *   hold the text).
   * @returns {Promise<{seeded:number, languages:string[], left:Array<{target:string, path:string, origin:string|null, status:string|null}>, recorded:number}>}
   *   `left`, the texts the machine layer was not given; `recorded`, the number of target files read that the
   *   record holds (both empty for the human layer).
   */
  async function seed({ targets, layer = LAYER.HUMAN, originOf } = {}) {
    if (!adapter || typeof adapter.seedAlign !== 'function') {
      throw new Error('adapter.seedAlign is not configured');
    }
    const machine = layer === LAYER.MACHINE;
    if (machine && typeof originOf !== 'function') throw new Error('seed: the machine layer needs originOf');
    const aligned = (await adapter.seedAlign({ store, targets })) || {};
    const entriesByLang = aligned.entriesByLang || {};
    const files = aligned.files || {};
    const at = aligned.at || {};
    const sourceEntries = aligned.sourceEntries || {};
    const stampedAt = now();
    let seeded = 0;
    const stampedByLang = {};
    const seededSources = {};
    const left = [];
    const recordedFiles = new Set();
    for (const [lang, entries] of Object.entries(entriesByLang)) {
      const humanHeld = machine ? store.readLayer(LAYER.HUMAN, lang) : {};
      const machineHeld = machine ? store.readLayer(LAYER.MACHINE, lang) : {};
      const stamped = {};
      for (const [key, value] of Object.entries(entries)) {
        if (!machine) {
          stamped[key] = {
            text: value.text,
            status: value.status || STATUS.SEED,
            srcHash: key,
            at: value.at || stampedAt,
          };
        } else if (!(key in humanHeld)) {
          if (!files[key] || !Array.isArray(at[key])) throw new Error('seed: the adapter does not say where each text was read from');
          const place = originOf(files[key], at[key]);
          if (place.origin !== null) recordedFiles.add(place.target);
          if (place.status !== 'in sync') {
            left.push(place);
            continue;
          }
          const held = machineHeld[key];
          // A translation run's entry for the same text, or the same text from the same module, stays as it is.
          if (held && held.text === value.text && (held.origin === undefined || held.origin === place.origin)) continue;
          stamped[key] = { ...machineEntry({ srcHash: key, text: value.text, job: 'seed', at: value.at || stampedAt }), origin: place.origin };
          if (typeof sourceEntries[key] === 'string') seededSources[key] = sourceEntries[key];
        } else {
          continue;
        }
        seeded += 1;
      }
      stampedByLang[lang] = stamped;
    }
    for (const [lang, stamped] of Object.entries(stampedByLang)) {
      if (Object.keys(stamped).length > 0) store.writeLayerEntries(layer, lang, stamped);
    }
    if (machine) {
      if (Object.keys(seededSources).length > 0) {
        store.mergeSourceMap(seededSources);
        store.mergeMachineSources(seededSources);
      }
    } else if (aligned.sourceEntries) {
      store.mergeSourceMap(aligned.sourceEntries);
    }
    return { seeded, languages: Object.keys(entriesByLang), left, recorded: recordedFiles.size };
  }

  /**
   * gc — identifies the orphaned memory keys (those with no use in the catalog)
   * and, past the grace period, archives them from both layers, each beside its
   * own layer. Non-destructive by default (apply=false): it merely reports the
   * candidates.
   *
   * @param {Object} [args]
   * @param {number} [args.graceDays]  Grace days counted from the entry's `at` (default 0).
   * @param {boolean} [args.apply]     When true, archives the eligible candidates.
   */
  function gc({ graceDays = 0, apply = false } = {}) {
    const catalog = store.readSourceCatalog();
    const langs = store.listLangs();
    const tmByLang = store.readAllTM(langs);
    const orphans = orphanKeys(catalog, tmByLang);
    const orphanSet = new Set(orphans);
    const cutoff = Date.now() - graceDays * 24 * 60 * 60 * 1000;

    const byLang = {};
    for (const lang of langs) {
      const tm = tmByLang[lang] || {};
      const eligible = [];
      for (const key of Object.keys(tm)) {
        if (!orphanSet.has(key)) continue;
        const at = tm[key] && tm[key].at ? Date.parse(tm[key].at) : NaN;
        // With no valid `at`, an entry counts as eligible only when graceDays=0.
        const olderThanGrace = Number.isNaN(at) ? graceDays === 0 : at <= cutoff;
        if (olderThanGrace) eligible.push(key);
      }
      eligible.sort();
      let archived = 0;
      if (apply && eligible.length > 0) archived = store.archiveKeys(lang, eligible);
      byLang[lang] = { eligible, archived };
    }

    return { orphans, byLang, applied: !!apply };
  }

  /**
   * review — the machine translations that revise a reviewed translation and
   * await a person's review, per locale (`reviewList`).
   */
  function review({ targets } = {}) {
    return reviewList({ store, targets: targets && targets.length ? targets : store.listLangs() });
  }

  return { store, extract, gate, translate, generate, seed, gc, review };
}

export default { createEngine, machineEntry, reviewList };
