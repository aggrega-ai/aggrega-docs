/**
 * memory.test.mjs — `l10n memory commit` against a repository and a worktree of
 * its CI branch in a git sandbox, and the package lock it shares with `collect`,
 * `session import` and `requeue`.
 *
 * READS and WRITES only the sandbox's temporary directory, with its own empty
 * git configuration. There is no remote: nothing can be pushed. No request
 * leaves the process.
 */

import '../test/no-network.mjs';
import { describe, it, expect, beforeEach, afterEach } from 'vitest';
import { spawnSync } from 'node:child_process';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';

import { runCli } from './cli.mjs';
import { LOCK_FILE } from './lock.mjs';
import { parseAuthor } from './memory.mjs';
import { capture, copyFixtureProject, gitSandbox, writeJson } from '../test/helpers.mjs';

let sandbox;
let repo;
let wt;

beforeEach(() => {
  sandbox = gitSandbox('l10n-memory-commit-');
  repo = path.join(sandbox.dir, 'repo');
  wt = path.join(sandbox.dir, 'wt');
  const fixture = copyFixtureProject();
  fs.cpSync(fixture, repo, { recursive: true });
  fs.rmSync(fixture, { recursive: true, force: true });
  const configFile = path.join(repo, 'l10n.config.json');
  writeJson(configFile, { ...JSON.parse(fs.readFileSync(configFile, 'utf8')), ci: { branch: 'l10n-memory' } });
  sandbox.git(['init', '-q', '-b', 'main', repo]);
  sandbox.git(['add', '-A'], repo);
  sandbox.git(['commit', '-q', '-m', 'project'], repo);
  sandbox.git(['worktree', 'add', '-q', '-b', 'l10n-memory', wt], repo);
  // The machine layer and the marks the project holds, and a change of the worktree's own, staged, that is not the layer's.
  writeJson(path.join(repo, 'memory', 'machine', 'en.json'), { aaaa: { text: 'Welcome', status: 'machine' } });
  writeJson(path.join(repo, 'memory', 'machine', '_source.json'), { aaaa: 'Benvenuti' });
  writeJson(path.join(repo, 'memory', 'retranslate.json'), { en: { aaaa: { reason: 'too literal', markedAt: '2026-10-20T00:00:00Z' } } });
  fs.writeFileSync(path.join(wt, 'notes.txt'), 'not the layer\n');
  sandbox.git(['add', 'notes.txt'], wt);
});

afterEach(() => sandbox.cleanup());

async function run(argv) {
  const io = capture();
  const code = await runCli(argv, { cwd: repo, env: sandbox.env, log: io.log, errlog: io.errlog });
  return { code, out: io.text(), err: io.errors() };
}

const AUTHOR = 'Ada Lovelace <ada@example.test>';
const TRAILER = 'Co-Authored-By: Helper <helper@example.test>';

describe('l10n memory commit', () => {
  it('commits exactly the machine layer and retranslate.json on the CI branch, with the given author and trailer, and pushes nothing', async () => {
    const r = await run(['memory', 'commit', '--worktree', wt, '--message', 'chore(l10n): update the machine layer', '--author', AUTHOR, '--trailer', TRAILER]);
    expect(r.err).toBe('');
    expect(r.code).toBe(0);
    const head = sandbox.git(['rev-parse', 'HEAD'], wt);
    expect(r.out).toContain(`memory commit: ${head} on l10n-memory: chore(l10n): update the machine layer (3 file(s) changed). Nothing was pushed.`);
    expect(sandbox.git(['show', '--name-only', '--format=', 'HEAD'], wt).split('\n')).toEqual([
      'memory/machine/_source.json',
      'memory/machine/en.json',
      'memory/retranslate.json',
    ]);
    expect(sandbox.git(['log', '-1', '--format=%an <%ae>|%cn <%ce>'], wt)).toBe(`${AUTHOR}|${AUTHOR}`);
    expect(sandbox.git(['log', '-1', '--format=%B'], wt)).toBe(`chore(l10n): update the machine layer\n\n${TRAILER}`);
    expect(JSON.parse(sandbox.git(['show', 'HEAD:memory/machine/en.json'], wt))).toEqual({ aaaa: { text: 'Welcome', status: 'machine' } });
    // The worktree's own staged change is still staged and not committed; the main branch is untouched; there is no remote.
    expect(sandbox.git(['diff', '--cached', '--name-only'], wt)).toBe('notes.txt');
    expect(sandbox.git(['log', '--format=%s', 'main'], repo)).toBe('project');
    expect(sandbox.git(['remote'], repo)).toBe('');
    expect(fs.existsSync(path.join(repo, 'memory', LOCK_FILE))).toBe(false);

    // Nothing changed since: nothing to commit.
    const again = await run(['memory', 'commit', '--worktree', wt]);
    expect(again.code).toBe(0);
    expect(again.out).toContain("memory commit: the worktree's memory/machine/ already holds the project's: nothing to commit.");
    expect(sandbox.git(['rev-parse', 'HEAD'], wt)).toBe(head);
  });

  it('refuses a worktree on another branch, copying and committing nothing', async () => {
    sandbox.git(['checkout', '-q', '-b', 'elsewhere'], wt);
    const head = sandbox.git(['rev-parse', 'HEAD'], wt);
    const r = await run(['memory', 'commit', '--worktree', wt]);
    expect(r.code).toBe(2);
    expect(r.err).toContain(`memory commit: ${wt} has the branch elsewhere checked out, not the CI branch l10n-memory. Nothing was copied or committed.`);
    expect(sandbox.git(['rev-parse', 'HEAD'], wt)).toBe(head);
    expect(fs.existsSync(path.join(wt, 'memory', 'machine'))).toBe(false);
  });

  it('refuses a directory that is not the top of a worktree, an --author not written "Name <email>", and a missing --worktree', async () => {
    expect((await run(['memory', 'commit', '--worktree', path.join(wt, 'memory')])).err).toContain('is not the top of a git worktree');
    const author = await run(['memory', 'commit', '--worktree', wt, '--author', 'Ada Lovelace']);
    expect(author.code).toBe(2);
    expect(author.err).toContain('--author "Ada Lovelace" is not "Name <email>".');
    expect((await run(['memory', 'commit'])).code).toBe(2);
    expect((await run(['memory', 'push'])).code).toBe(2);
    expect(parseAuthor(' Ada Lovelace  <ada@example.test> ')).toEqual({ name: 'Ada Lovelace', email: 'ada@example.test' });
  });

  it('refuses while another command holds the package lock, and takes over a lock left by a process that no longer runs', async () => {
    const lock = path.join(repo, 'memory', LOCK_FILE);
    writeJson(lock, { command: 'session import', pid: process.pid, host: os.hostname(), at: '2026-10-23T10:00:00.000Z' });
    const held = await run(['memory', 'commit', '--worktree', wt]);
    expect(held.code).toBe(1);
    expect(held.err).toContain(`memory commit: ${lock} is held by \`l10n session import\` (process ${process.pid} on ${os.hostname()}) since 2026-10-23T10:00:00.000Z`);
    expect(fs.existsSync(path.join(wt, 'memory', 'machine'))).toBe(false);
    // collect and requeue refuse the same way, and leave the holder's lock in place.
    const collect = await run(['collect']);
    expect(collect.code).toBe(1);
    expect(collect.err).toContain(`collect: ${lock} is held by \`l10n session import\``);
    expect((await run(['requeue'])).code).toBe(1);
    expect(JSON.parse(fs.readFileSync(lock, 'utf8')).command).toBe('session import');

    const gone = spawnSync(process.execPath, ['-e', '']).pid;
    writeJson(lock, { command: 'collect', pid: gone, host: os.hostname(), at: '2026-10-23T09:00:00.000Z' });
    const r = await run(['memory', 'commit', '--worktree', wt]);
    expect(r.code).toBe(0);
    expect(r.out).toContain(`memory commit: took over ${lock}, left by \`l10n collect\` (process ${gone}, since 2026-10-23T09:00:00.000Z), which no longer runs.`);
    expect(fs.existsSync(lock)).toBe(false);
  });
});
