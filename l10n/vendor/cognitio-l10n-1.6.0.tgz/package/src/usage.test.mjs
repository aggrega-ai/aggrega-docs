import '../test/no-network.mjs';
import { describe, it, expect, beforeEach, afterEach } from 'vitest';
import fs from 'node:fs';
import path from 'node:path';

import { runCli } from './cli.mjs';
import { readUsage, requestsCost, spendSummary, usageCost } from './usage.mjs';
import { capture, copyFixtureProject, echoReply, fakeAnthropic } from '../test/helpers.mjs';

describe('usage.mjs: the billed figures and their price', () => {
  const reply = {
    input_tokens: 1000,
    output_tokens: 500,
    cache_read_input_tokens: 4000,
    cache_creation_input_tokens: 2000,
    cache_creation: { ephemeral_1h_input_tokens: 2000, ephemeral_5m_input_tokens: 0 },
  };

  it('reads a reply’s usage, and nothing from a reply without one', () => {
    expect(readUsage(reply)).toEqual({ input: 1000, output: 500, cacheRead: 4000, cacheWrite: 2000, cacheWrite5m: 0 });
    expect(readUsage(undefined)).toBeNull();
  });

  it('prices each figure at its Message Batches rate', () => {
    // Claude Opus 5.5 through the Message Batches API: USD 2 input, 0.2 cache read, 4 one-hour cache write, 10 output per million.
    expect(usageCost('claude-opus-5-5', readUsage(reply))).toBeCloseTo((1000 * 2 + 4000 * 0.2 + 2000 * 4 + 500 * 10) / 1e6, 12);
    const fiveMinutes = readUsage({ ...reply, cache_creation: { ephemeral_5m_input_tokens: 2000 } });
    expect(usageCost('claude-opus-5-5', fiveMinutes)).toBeCloseTo((1000 * 2 + 4000 * 0.2 + 2000 * 2.5 + 500 * 10) / 1e6, 12);
  });

  it('prices nothing when one request ran on a model the table does not hold', () => {
    const known = { model: 'claude-opus-5-5', ...readUsage(reply) };
    expect(requestsCost([known])).toBeGreaterThan(0);
    expect(requestsCost([known, { ...known, model: 'some-other-model' }])).toBeNull();
  });

  it('sums the spend per batch, per locale and in total, leaving out job logs without usage', () => {
    const r = (lang, model = 'claude-opus-5-5') => ({ lang, model, ...readUsage(reply) });
    const spend = spendSummary([
      { id: 'b1', at: 't1', usage: { requests: [r('ja'), r('ko')], estimate: { input: 9000, output: 9000 } } },
      { id: 'old', at: 't0', items: [] },
      { id: 'b2', at: 't2', usage: { requests: [r('ja')] } },
    ]);
    expect(spend.batches.map((b) => [b.id, b.total.input, b.estimate])).toEqual([
      ['b1', 2000, { input: 9000, output: 9000 }],
      ['b2', 1000, undefined],
    ]);
    expect(Object.keys(spend.byLang)).toEqual(['ja', 'ko']);
    expect(spend.byLang.ja.total.output).toBe(1000);
    expect(spend.total.cacheRead).toBe(12000);
    expect(spend.cost).toBeCloseTo(3 * usageCost('claude-opus-5-5', readUsage(reply)), 12);
  });
});

describe('collect records what each request was billed, and status sums it', () => {
  let project;
  beforeEach(() => {
    project = copyFixtureProject('l10n-usage-');
  });
  afterEach(() => {
    fs.rmSync(project, { recursive: true, force: true });
  });
  const memory = (...p) => path.join(project, 'memory', ...p);
  const readJson = (file) => JSON.parse(fs.readFileSync(file, 'utf8'));
  async function run(argv, deps = {}) {
    const io = capture();
    const code = await runCli(argv, { cwd: project, env: { ANTHROPIC_API_KEY: 'test-key' }, log: io.log, errlog: io.errlog, ...deps });
    return { code, out: io.text(), err: io.errors() };
  }
  const billed = { input_tokens: 120, output_tokens: 40, cache_read_input_tokens: 300, cache_creation_input_tokens: 0 };

  it('per request in the job log, with the estimate submit recorded, and in tokens and dollars in status', async () => {
    expect((await run(['extract'])).code).toBe(0);
    const fake = fakeAnthropic({ reply: (params) => ({ ...echoReply(params), usage: billed }) });
    const submitted = await run(['submit'], { ClientClass: fake.FakeAnthropic });
    expect(submitted.out).toContain('submit: both estimates are upper bounds: the input counts one token per UTF-8 byte, and the output is the requests\' max_tokens');
    const [record] = readJson(memory('pending.json')).batches;
    expect(record.estimate).toEqual({ input: expect.any(Number), cached: expect.any(Number), output: expect.any(Number), bound: expect.any(Number) });
    const requests = Object.keys(record.requests).length;

    const collected = await run(['collect'], { ClientClass: fake.FakeAnthropic });
    expect(collected.out).toContain(`  usage: input ${120 * requests}, output ${40 * requests}, cache read ${300 * requests}, cache write 0 tokens`);
    const job = fs.readdirSync(memory('jobs')).map((f) => readJson(memory('jobs', f))).find((j) => j.trigger === 'collect');
    expect(job.usage.requests).toHaveLength(requests);
    expect(job.usage.requests[0]).toMatchObject({ customId: expect.any(String), lang: 'en', model: expect.any(String), input: 120, output: 40, cacheRead: 300, cacheWrite: 0 });
    expect(job.usage.total).toEqual({ input: 120 * requests, output: 40 * requests, cacheRead: 300 * requests, cacheWrite: 0, cacheWrite5m: 0 });
    expect(job.usage.estimate).toEqual(record.estimate);

    const status = await run(['status']);
    expect(status.code).toBe(0);
    expect(status.out).toContain('status: billed, as the replies of 1 collected batch(es) report it:');
    expect(status.out).toMatch(new RegExp(`^ {2}batch ${record.id}, created .*: input ${120 * requests}, output ${40 * requests}, cache read ${300 * requests}, cache write 0 tokens.*; estimated input ${record.estimate.input}, output ${record.estimate.output} tokens$`, 'm'));
    expect(status.out).toMatch(/^ {2}en: input \d+, output \d+, cache read \d+, cache write 0 tokens/m);
    expect(status.out).toMatch(/^ {2}total: input \d+, output \d+, cache read \d+, cache write 0 tokens, USD \d+\.\d+$/m);

    // The next submission says what share of their estimates the collected batches were billed.
    fs.rmSync(memory('machine'), { recursive: true, force: true });
    const again = await run(['submit', '--dry-run'], { ClientClass: fake.FakeAnthropic });
    expect(again.out).toMatch(/the 1 batch\(es\) collected since their estimate was recorded were billed \d+% of their estimated input and \d+% of their estimated output/);
  });

  it('status says when no collected batch records usage, as a batch collected before 1.3.1 does not', async () => {
    const status = await run(['status']);
    expect(status.out).toContain('status: no collected batch records its usage yet.');
  });
});
