import '../test/no-network.mjs';
import { describe, it, expect } from 'vitest';

import { validateTranslations } from './validate.mjs';
import { protectedPieces, segmentMarkdown, standaloneProtectedTexts } from './adapters/markdown/segment.mjs';
import { planRequests } from './requests.mjs';

/** A Markdown unit as the catalogue stores it: its spans computed by the adapter, touching ones merged. */
function unit(source) {
  const [segment] = segmentMarkdown(source).segments;
  return { srcHash: 'u', source, format: 'markdown', protected: segment.protected.map(([s, e]) => [s - segment.start, e - segment.start]) };
}
const judge = (item, text) => validateTranslations({ items: [item], entries: [{ id: 'u', text }] });

describe('two protected strings the translation sets side by side, where the source has text between them', () => {
  // Inline code, then a word, in a link's text: a language that puts the word first makes the code end the text.
  const tool = unit('An assistant reaches it through the [`import` tool](../x.md#y) of `acme sync`.');

  it('are compared each on its own: the reordered link passes', () => {
    const text = 'Asystent korzysta z [narzędzia `import`](../x.md#y) serwera `acme sync`.';
    expect(judge(tool, text)).toEqual({ accepted: { u: text }, rejected: {}, dropped: [] });
  });

  it('a link whose text is inline code and a word, in either order, as the evidence’s pages hold them', () => {
    const reference = unit('What it requires is in the [`acme sync` reference](../cli/acme-sync.md#over-https).');
    expect(judge(reference, 'Wymagania opisano w [dokumentacji `acme sync`](../cli/acme-sync.md#over-https).').accepted.u).toBeDefined();
    const entity = unit('The fields are under `spec.commands` on the [`Plugin` entity page](../entities/plugin.md).');
    expect(judge(entity, 'Поля описаны в `spec.commands` на [странице сущности `Plugin`](../entities/plugin.md).').accepted.u).toBeDefined();
  });

  it('still fails when the code span or the destination changes', () => {
    expect(judge(tool, 'Asystent korzysta z [narzędzia `importu`](../x.md#y) serwera `acme sync`.').rejected.u).toMatch(/missing or altered "`import`"/);
    expect(judge(tool, 'Asystent korzysta z [narzędzia `import`](../x.md#z) serwera `acme sync`.').rejected.u).toMatch(/missing or altered "\]\(\.\.\/x\.md#y\)"/);
    expect(judge(tool, 'Asystent korzysta z [narzędzia import](../x.md#y) serwera `acme sync`.').rejected.u).toMatch(/missing or altered "`import`"/);
  });

  it('the converse: a source that joins them, a translation that sets them apart', () => {
    const joined = unit('Use the [run `import`](../x.md#y) command.');
    expect(joined.protected).toHaveLength(1); // stored as one string, as the catalogue stores touching spans
    const text = 'Użyj polecenia [`import` uruchom](../x.md#y).';
    expect(judge(joined, text).accepted.u).toBe(text);
  });
});

describe('protectedPieces', () => {
  it('cuts a stored span where two of the source’s own spans touch, and nowhere else', () => {
    const source = 'Use the [run `import`](../x.md#y) command.';
    expect(protectedPieces(source, unit(source).protected)).toEqual(['`import`', '](../x.md#y)']);
    // A reference the standalone reading cannot see stays whole.
    const reference = 'See [`code` here][ref].';
    expect(protectedPieces(reference, [[4, 22]])).toEqual(['[`code` here][ref]']);
  });

  it('standalone spans that touch stay apart', () => {
    expect(standaloneProtectedTexts('[run `import`](../x.md#y)')).toEqual(['`import`', '](../x.md#y)']);
  });

  it('the keep list a request carries names each string on its own', () => {
    const item = { ...unit('Use the [run `import`](../x.md#y) command.'), missing: ['pl'] };
    const plan = planRequests({
      pages: [{ id: 'p', segments: [{ key: 'u', source: item.source, format: 'markdown', protected: item.protected, section: '' }] }],
      worklist: { status: 'work', targets: ['pl'], items: [item] },
      tmByLang: {},
      targets: ['pl'],
      sectionTokens: 8000,
      attemptLimit: 3,
    });
    expect(plan.specs[0].keep).toEqual({ u: ['`import`', '](../x.md#y)'] });
  });
});
