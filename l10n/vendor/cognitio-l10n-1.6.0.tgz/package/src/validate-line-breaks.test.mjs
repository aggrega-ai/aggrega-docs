import '../test/no-network.mjs';
import { describe, it, expect } from 'vitest';

import { validateTranslations } from './validate.mjs';

describe('validateTranslations — a Markdown line break the page cannot take', () => {
  /** A Markdown unit whose source is `source` as a page holds it, continuation lines and their prefixes included. */
  const unit = (source) => ({ srcHash: 'p', source, format: 'markdown', protected: [] });
  const judge = (source, text) => validateTranslations({ items: [unit(source)], entries: [{ id: 'p', text }] });

  const rows = [
    // A source on one line: a heading, a table cell or a one-line paragraph.
    { scenario: 'a one-line source answered on one line', source: 'Run the build.', text: 'Esegui la build.', rejects: null },
    { scenario: 'a one-line source answered on two lines', source: 'Run the build and read the log.', text: 'Esegui la build\ne leggi il log.', rejects: 'write the translation on one line' },
    // A paragraph spanning lines: soft breaks are free, and a continuation line is read past its container's prefix.
    { scenario: 'a top-level paragraph re-wrapped', source: 'Run the build\nand read the log.', text: 'Esegui\nla build e leggi il log.', rejects: null },
    { scenario: 'a list item paragraph keeping its indent', source: 'Run the build\n  and read the log.', text: 'Esegui la build\n  e leggi il log.', rejects: null },
    { scenario: 'a list item paragraph continued lazily', source: 'Run the build\n  and read the log.', text: 'Esegui la build\ne leggi il log.', rejects: null },
    { scenario: 'a blockquote paragraph keeping its marker', source: 'Run the build\n> and read the log.', text: 'Esegui la build\n> e leggi il log.', rejects: null },
    { scenario: 'a hard line break kept', source: 'First line  \nsecond line', text: 'Prima riga  \nseconda riga', rejects: null },
    // Lines that would change the page's structure.
    { scenario: 'an empty line, which ends the paragraph', source: 'Run the build\nand read the log.', text: 'Esegui la build\n\ne leggi il log.', rejects: 'is empty' },
    { scenario: 'a line opening a bullet list', source: 'Run the build\nand read the log.', text: 'Esegui la build\n- e leggi il log.', rejects: 'starts a new Markdown block' },
    { scenario: 'a line opening an ordered list at 1', source: 'Run the build\nand read the log.', text: 'Esegui la build\n1. e leggi il log.', rejects: 'starts a new Markdown block' },
    { scenario: 'a line opening a heading', source: 'Run the build\nand read the log.', text: 'Esegui la build\n# e leggi il log.', rejects: 'starts a new Markdown block' },
    { scenario: 'a setext underline, which turns the paragraph into a heading', source: 'Run the build\nand read the log.', text: 'Esegui la build\n===', rejects: 'starts a new Markdown block' },
    { scenario: 'a line opening a blockquote inside a list item', source: 'Run the build\n  and read the log.', text: 'Esegui la build\n  > e leggi il log.', rejects: 'starts a new Markdown block' },
    { scenario: 'a line opening a code fence', source: 'Run the build\nand read the log.', text: 'Esegui la build\n``` e leggi il log.', rejects: 'starts a new Markdown block' },
    // An added tag is refused by the markup check first; a processing instruction carries no tag and opens an HTML block.
    { scenario: 'a line opening an HTML block', source: 'Run the build\nand read the log.', text: 'Esegui la build\n<? e leggi il log.', rejects: 'starts a new Markdown block' },
    // A number that cannot open a list where it stands.
    { scenario: 'a line beginning with a number other than 1', source: 'Run the build\nand read the log.', text: 'Esegui la build\n2. e leggi il log.', rejects: null },
  ];
  for (const row of rows) {
    it(row.scenario, () => {
      const { accepted, rejected } = judge(row.source, row.text);
      if (row.rejects === null) {
        expect(rejected).toEqual({});
        expect(accepted).toEqual({ p: row.text });
      } else {
        expect(accepted).toEqual({});
        expect(rejected.p).toContain(row.rejects);
      }
    });
  }

  it('applies to Markdown alone: a text or HTML segment may span lines', () => {
    for (const format of ['text', 'html']) {
      const item = { srcHash: 't', source: 'One line', format };
      expect(validateTranslations({ items: [item], entries: [{ id: 't', text: 'Una\nriga' }] }).accepted).toEqual({ t: 'Una\nriga' });
    }
  });
});
