/**
 * progress.test.mjs — `l10n status --progress`, the stale entries `status` names
 * in the pending file's queue, and `l10n requeue --prune` on that queue, run
 * through the command line against the fixture project; and the progress rows as
 * a pure function.
 *
 * READS the fixture project's copy. WRITES only that copy, in a temporary
 * directory each test removes. No request leaves the process.
 */

import '../test/no-network.mjs';
import { describe, it, expect, beforeEach, afterEach } from 'vitest';
import fs from 'node:fs';
import path from 'node:path';

import { runCli } from './cli.mjs';
import { keyOf } from './normalize.mjs';
import { progressLines, progressRows } from './progress.mjs';
import { capture, copyFixtureProject, writeJson } from '../test/helpers.mjs';

let project;
beforeEach(() => {
  project = copyFixtureProject('l10n-progress-');
});
afterEach(() => fs.rmSync(project, { recursive: true, force: true }));

const memory = (...p) => path.join(project, 'memory', ...p);
const readJson = (file) => JSON.parse(fs.readFileSync(file, 'utf8'));

async function run(argv) {
  const io = capture();
  const code = await runCli(argv, { cwd: project, env: { ANTHROPIC_API_KEY: 'test-key' }, log: io.log, errlog: io.errlog });
  return { code, out: io.text(), err: io.errors() };
}

const words = (text) => (text.match(/[\p{L}\p{N}]+/gu) || []).length;

describe('l10n status --progress', () => {
  it('prints each locale’s translated and missing segments and words, the share done by words, the left-out and queued, and a total from the catalogue', async () => {
    expect((await run(['extract'])).code).toBe(0);
    const units = readJson(memory('source.json')).units;
    const keys = Object.keys(units);
    const translated = keyOf('Benvenuti');
    const before = readJson(memory('messages', 'en.json'));
    // A machine translation of one missing unit; two others queued, one of them at the attempt limit.
    writeJson(memory('machine', 'en.json'), { [translated]: { text: 'Welcome', status: 'machine' } });
    writeJson(memory('pending.json'), {
      batches: [],
      queue: { en: { [keyOf('Scopri')]: { attempts: 3, defect: 'the translation is empty' }, [keyOf('Menu')]: { attempts: 1, defect: 'the translation is empty' } } },
    });
    const done = keys.filter((k) => k in before || k === translated);
    const total = keys.reduce((n, k) => n + words(units[k].source), 0);
    const doneWords = done.reduce((n, k) => n + words(units[k].source), 0);
    const share = `${((doneWords / total) * 100).toFixed(1)}%`;

    const r = await run(['status', '--progress']);
    expect(r.code).toBe(0);
    expect(r.out).toContain('status: progress against the catalogue of the last extract, per locale:');
    const line =
      `${share} done by words; translated ${done.length} of ${keys.length} segments, ${doneWords} of ${total} words; ` +
      `missing ${keys.length - done.length} segments, ${total - doneWords} words; 1 left out, 1 queued`;
    expect(r.out).toContain(`  en: ${line}`);
    expect(r.out).toContain(`  total over 1 locale: ${line}`);

    // Without the flag, status prints no progress, as before.
    expect((await run(['status'])).out).not.toContain('progress against the catalogue');
  });

  it('sums every locale into the total line, by words', () => {
    const rows = progressRows({
      units: { a: { source: 'one two three' }, b: { source: 'four' } },
      tmByLang: { it: { a: {} }, de: { a: {}, b: {} } },
      targets: ['it', 'de'],
      queues: [{ it: { b: { attempts: 1 } } }],
      attemptLimit: 3,
    });
    expect(progressLines(rows, 'x')).toEqual([
      'x: progress against the catalogue of the last extract, per locale:',
      '  it: 75.0% done by words; translated 1 of 2 segments, 3 of 4 words; missing 1 segments, 1 words; 0 left out, 1 queued',
      '  de: 100.0% done by words; translated 2 of 2 segments, 4 of 4 words; missing 0 segments, 0 words; 0 left out, 0 queued',
      '  total over 2 locales: 87.5% done by words; translated 3 of 4 segments, 7 of 8 words; missing 1 segments, 1 words; 0 left out, 1 queued',
    ]);
  });
});

describe('stale entries of the pending file’s queue', () => {
  /** Queues three missing units: one translated since, one a session batch holds, one still work. */
  async function setUp() {
    expect((await run(['extract'])).code).toBe(0);
    const [translated, held, live] = [keyOf('Benvenuti'), keyOf('Scopri'), keyOf('Menu')];
    writeJson(memory('machine', 'en.json'), { [translated]: { text: 'Welcome', status: 'machine' } });
    const queue = { en: { [translated]: { attempts: 1, defect: 'x' }, [held]: { attempts: 3, defect: 'y' }, [live]: { attempts: 1, defect: 'z' } } };
    writeJson(memory('pending.json'), { batches: [], queue });
    writeJson(memory('session', 'batches', '0001', 'plan.json'), { batch: '0001', requested: { en: [held] }, attempts: {}, revisions: {}, items: {} });
    return { translated, held, live, queue };
  }

  it('status names them, with why each no longer stands for work', async () => {
    const { translated, held } = await setUp();
    const r = await run(['status']);
    expect(r.out).toContain(`status: 2 entries of ${memory('pending.json')} no longer stand for work; \`l10n requeue --prune\` removes them:`);
    expect(r.out).toContain(`  en ${translated}: already translated`);
    expect(r.out).toContain(`  en ${held}: held by a session batch not yet imported`);
  });

  it('requeue --prune --dry-run names them and writes nothing; requeue --prune removes them alone', async () => {
    const { translated, held, live, queue } = await setUp();
    const dry = await run(['requeue', '--prune', '--api', '--dry-run']);
    expect(dry.code).toBe(0);
    expect(dry.out).toContain(`requeue --prune: ${memory('pending.json')}: would remove 2 entries that no longer stand for work.`);
    expect(readJson(memory('pending.json')).queue).toEqual(queue);

    const pruned = await run(['requeue', '--prune', '--api']);
    expect(pruned.code).toBe(0);
    expect(pruned.out).toContain(`  en ${translated}: already translated`);
    expect(readJson(memory('pending.json')).queue).toEqual({ en: { [live]: queue.en[live] } });
    expect(readJson(memory('pending.json')).queue.en[held]).toBeUndefined();
    expect((await run(['status'])).out).not.toContain('no longer stand for work');
  });

  it('keeps an entry of a pair marked for re-translation, whose translation serves while it is redone', async () => {
    const { translated } = await setUp();
    writeJson(memory('retranslate.json'), { en: { [translated]: { reason: 'too literal', markedAt: '2026-10-20T00:00:00Z' } } });
    const r = await run(['status']);
    expect(r.out).toContain('status: 1 entry of');
    expect(r.out).not.toContain(`  en ${translated}: already translated`);
  });
});
