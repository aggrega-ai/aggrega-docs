/**
 * rekey.mjs — `l10n rekey`: moves a memory keyed by source text alone onto the
 * per-key identity (`adapter.identity: "text+path"`), losing no translation.
 *
 * READS the configuration's adapter (its catalogue, under the identity the
 * configuration now names), both memory layers, the pending file, the
 * re-translation marks and the session's work directory. WRITES, unless
 * `--dry-run`: the catalogue and the source map (through `engine.extract`), both
 * layers and their archives, the machine layer's sources, `retranslate.json`, the
 * pending file's queue and the session's queue. It makes no network call.
 *
 * Under the text identity a segment's key is `keyOf(source)`, one key for every
 * usage of a text; under `text+path` each usage has its own key
 * (`usageKeyOf`). Switching the configuration alone would leave every segment
 * missing and every old key an orphan, and the next run would translate the
 * whole site again as revisions of those orphans. Rekeying instead gives each new
 * key, in each layer and each target locale, a copy of the entry its text's old
 * key holds — the machine entry stays a machine entry, a person's stays a
 * person's — and then archives the old key beside its layer (`archiveLayerKeys`,
 * as `gc --apply` does), so it is no orphan and stays known to the drift guard.
 * A new key that already has an entry keeps it. A mark for re-translation and a
 * queue entry move from the old key to every new key the same way.
 *
 * Every usage of a text starts with the translation the text had: what was one
 * translation stays one until the project gives a key its own — `l10n seed`, for
 * hand-written targets, replaces each copied seed entry with that key's own
 * target text; `l10n retranslate --file` or the human layer, for the rest.
 *
 * It refuses while a Message Batch is recorded in the pending file or a batch of
 * the session is not yet imported: their plans name the old keys, and what they
 * return would land on keys nothing uses any more.
 */

import { keyOf } from './normalize.mjs';
import { LAYER } from './types.mjs';
import { readSessionQueue, sessionHeldPairs, writeSessionQueue } from './session.mjs';

const has = (object, key) => Object.prototype.hasOwnProperty.call(object || {}, key);

/**
 * Which new keys each old text key becomes: for every unit of a catalogue keyed
 * by its usage, the text key of its source → the unit's key, the new keys sorted.
 * A unit whose key is its text key (an adapter under the text identity) moves
 * nowhere.
 *
 * @param {Object.<string, {source:string}>} units  the catalogue's units, under the new identity.
 * @returns {Map<string, {source:string, keys:string[]}>}
 */
export function rekeyMap(units) {
  const map = new Map();
  for (const [key, unit] of Object.entries(units || {})) {
    if (!unit || typeof unit.source !== 'string') continue;
    const old = keyOf(unit.source);
    if (old === key) continue;
    if (!map.has(old)) map.set(old, { source: unit.source, keys: [] });
    map.get(old).keys.push(key);
  }
  for (const value of map.values()) value.keys.sort();
  return map;
}

/**
 * The entries one layer gains, and the old keys it archives: each old key the
 * layer holds gives a copy of its entry to every new key the layer lacks, its
 * `srcHash` (when it records one) set to the new key.
 *
 * @param {Object} tm  the layer.
 * @param {ReturnType<typeof rekeyMap>} map
 * @returns {{entries:Object.<string, Object>, archived:string[]}}
 */
export function rekeyLayer(tm, map) {
  const entries = {};
  const archived = [];
  for (const [old, { keys }] of map) {
    if (!has(tm, old)) continue;
    archived.push(old);
    for (const key of keys) {
      if (has(tm, key)) continue;
      const entry = tm[old];
      entries[key] = entry && typeof entry === 'object' && has(entry, 'srcHash') ? { ...entry, srcHash: key } : entry;
    }
  }
  return { entries, archived: archived.sort() };
}

/**
 * Moves a per-locale map keyed by segment (the re-translation marks, a
 * resubmission queue) from the old keys to the new ones: an old key's value is
 * copied to every new key that has none, and the old key removed.
 *
 * @param {Object.<string, Object.<string, *>>} byLang
 * @param {ReturnType<typeof rekeyMap>} map
 * @param {string[]} targets
 * @returns {{value:Object, moved:number}}  the map rewritten, and how many old keys it moved.
 */
export function rekeyByLang(byLang, map, targets) {
  const value = { ...(byLang || {}) };
  let moved = 0;
  for (const lang of targets) {
    const pairs = value[lang];
    if (!pairs) continue;
    const next = { ...pairs };
    for (const [old, { keys }] of map) {
      if (!has(next, old)) continue;
      for (const key of keys) if (!has(next, key)) next[key] = next[old];
      delete next[old];
      moved += 1;
    }
    value[lang] = next;
  }
  return { value, moved };
}

/**
 * Runs `l10n rekey`.
 *
 * @param {Object} args
 * @param {Object} args.adapter        the configured adapter: JSON-content, under `adapter.identity: "text+path"`.
 * @param {ReturnType<import('./engine.mjs').createEngine>} args.engine
 * @param {string[]} args.targets      the locales to rekey.
 * @param {string} args.work           the session's work directory, absolute.
 * @param {boolean} [args.dryRun]      print what would move; write nothing.
 * @param {(...a:any[])=>void} [args.log]
 * @param {(...a:any[])=>void} [args.errlog]
 * @returns {Promise<{code:number, map?:ReturnType<typeof rekeyMap>, byLang?:Object}>}
 */
export async function runRekey({ adapter, engine, targets, work, dryRun = false, log = (...a) => console.log(...a), errlog = (...a) => console.error(...a) }) {
  if (!adapter || adapter.kind !== 'json-content') {
    errlog('rekey: the configured adapter is not json-content; per-key identity is a setting of the JSON-content adapter. Nothing was read or written.');
    return { code: 2 };
  }
  if (adapter.identity !== 'text+path') {
    errlog(
      `rekey: adapter.identity is "${adapter.identity || 'text'}"; rekey moves a memory keyed by text onto "text+path". ` +
        'Set "identity": "text+path" under "adapter" first. Nothing was read or written.'
    );
    return { code: 2 };
  }
  const store = engine.store;
  const pending = store.readPending();
  if (pending.batches.length > 0) {
    errlog(
      `rekey: ${pending.batches.length} Message Batch(es) recorded in ${store.paths.pending} (${pending.batches.map((b) => b.id).join(', ')}) ` +
        'name the old keys; collect or cancel them first. Nothing was written.'
    );
    return { code: 1 };
  }
  const open = sessionHeldPairs(work);
  if (open.size > 0) {
    errlog(`rekey: the session in ${work} has batches not yet imported, which name the old keys; import them first. Nothing was written.`);
    return { code: 1 };
  }

  const catalog = dryRun ? await adapter.extract() : (await engine.extract()).catalog;
  const map = rekeyMap(catalog.units);
  const prefix = dryRun ? 'rekey (dry run)' : 'rekey';
  log(`${prefix}: ${Object.keys(catalog.units || {}).length} segments under "text+path", from ${map.size} source texts.`);

  const byLang = {};
  const machineSources = {};
  for (const lang of targets) {
    const counts = {};
    for (const layer of [LAYER.HUMAN, LAYER.MACHINE]) {
      const { entries, archived } = rekeyLayer(store.readLayer(layer, lang), map);
      counts[layer] = { copied: Object.keys(entries).length, archived: archived.length };
      if (dryRun) continue;
      if (Object.keys(entries).length) store.writeLayerEntries(layer, lang, entries);
      if (archived.length) store.archiveLayerKeys(layer, lang, archived);
      if (layer === LAYER.MACHINE) for (const key of Object.keys(entries)) machineSources[key] = catalog.units[key].source;
    }
    byLang[lang] = counts;
    log(
      `  ${lang}: human layer ${counts[LAYER.HUMAN].copied} key(s) from ${counts[LAYER.HUMAN].archived} text key(s); ` +
        `machine layer ${counts[LAYER.MACHINE].copied} key(s) from ${counts[LAYER.MACHINE].archived} text key(s)` +
        `${dryRun ? '' : '; the text keys archived'}.`
    );
  }

  const marks = rekeyByLang(store.readRetranslate(), map, targets);
  const queue = rekeyByLang(pending.queue, map, targets);
  const sessionQueue = rekeyByLang(readSessionQueue(work), map, targets);
  if (marks.moved) log(`  ${marks.moved} mark(s) for re-translation moved to the new keys.`);
  if (queue.moved) log(`  ${queue.moved} entr(ies) of the pending file's queue moved to the new keys.`);
  if (sessionQueue.moved) log(`  ${sessionQueue.moved} entr(ies) of the session's queue moved to the new keys.`);
  if (!dryRun) {
    store.mergeMachineSources(machineSources);
    if (marks.moved) store.writeRetranslate(marks.value);
    if (queue.moved) store.writePending({ ...pending, queue: queue.value });
    if (sessionQueue.moved) writeSessionQueue(work, sessionQueue.value);
    log(
      'rekey: done. Each key starts from the translation its text had. A project with hand-written targets runs ' +
        '`l10n seed --targets <locale>` for each locale, so each key takes its own target text; then `l10n gate --check`.'
    );
  } else {
    log(`${prefix}: nothing was written.`);
  }
  return { code: 0, map, byLang };
}

export default { rekeyMap, rekeyLayer, rekeyByLang, runRekey };
