import '../test/no-network.mjs';
import { describe, it, expect } from 'vitest';

import { literalAutolinks, segmentMarkdown, standaloneProtectedTexts } from './adapters/markdown/segment.mjs';
import { validateTranslations } from './validate.mjs';

/** Every node of a tree, depth first. */
function* nodes(node) {
  yield node;
  for (const child of node.children || []) yield* nodes(child);
}

describe('a bare link GitHub-flavoured Markdown finds after its tokenizer', () => {
  // After „ or —, the tokenizer does not link www.example.com and the extension's tree transform does: the
  // transform's nodes had no position, and reading one crashed the comparison of a translation with its source.
  const AFTER_PUNCTUATION = [
    'see „www.example.com” now',
    'x—www.example.com',
    '**Bold line**\nthen „https://example.org/a” and more',
    'mail —me@host.org.',
  ];

  it('leaves every node of the tree with its position in the text', () => {
    for (const text of AFTER_PUNCTUATION) {
      const { tree } = segmentMarkdown(text);
      for (const node of nodes(tree)) expect(node.position, `${node.type} in ${JSON.stringify(text)}`).toBeDefined();
    }
  });

  it('still protects the link, whole', () => {
    expect(standaloneProtectedTexts('see „www.example.com” now')).toEqual(['www.example.com”']);
    expect(standaloneProtectedTexts('x—www.example.com')).toEqual(['www.example.com']);
    expect(standaloneProtectedTexts('mail —me@host.org.')).toEqual(['me@host.org']);
    // A link the tokenizer finds itself is protected as before.
    expect(standaloneProtectedTexts('see www.example.com now')).toEqual(['www.example.com']);
  });

  it('finds links by the extension’s own rules', () => {
    const rows = [
      // [text, the links found]
      ['see „www.example.com” now', ['www.example.com”']],
      ['xwww.example.com', []], // a letter before it
      ['http://a_b.c_d www.ok.com', ['www.ok.com']], // an underscore in the last labels
      ['see (www.example.com/a(b)) now', ['www.example.com/a(b)']], // a closing parenthesis it opened is kept
      ['end www.example.com.', ['www.example.com']], // trailing punctuation is left out
      ['path/me@host.org', []], // an address after a slash
      ['x —me@host.org-', []], // an address whose last label ends in "-"
      ['plain text', []],
    ];
    for (const [text, links] of rows) {
      expect(literalAutolinks(text).map(([s, e]) => text.slice(s, e)), text).toEqual(links);
    }
  });

  it('never searches the text of a link', () => {
    expect(standaloneProtectedTexts('a [see www.x.com](https://y.z) b')).toEqual(['](https://y.z)']);
  });
});

describe('validateTranslations — a paragraph with a bold first line, a soft line break and inline code', () => {
  const source = '**Domain 2: The Split Schema (`usesSchema` & `schema`)**\nTo keep the catalog whole, see „www.example.com” and the `values` pillar.';
  const item = { srcHash: 'p', source, format: 'markdown', protected: [] };

  it('accepts a faithful translation, which 1.3.0 rejected with a TypeError read as a defect', () => {
    const text = '**Domena 2: Schemat dzielony (`usesSchema` i `schema`)**\nAby katalog był spójny, zobacz „www.example.com” i filar `values`.';
    expect(validateTranslations({ items: [item], entries: [{ id: 'p', text }] })).toEqual({ accepted: { p: text }, rejected: {}, dropped: [] });
  });

  it('rejects a translation that adds a bare link, naming the link', () => {
    const plain = { ...item, source: '**Domain 2**\nTo keep the catalog whole, see the `values` pillar.' };
    const text = '**Domena 2**\nAby katalog był spójny, zobacz filar `values` („www.example.com”).';
    const { rejected } = validateTranslations({ items: [plain], entries: [{ id: 'p', text }] });
    expect(rejected.p).toBe('inline code, a link or image destination, HTML or a reference differs from the source: added "www.example.com”"');
  });
});

describe('validateTranslations — a check that fails itself', () => {
  it('leaves the segment in `internal`, neither accepted nor rejected, and judges the others', () => {
    const items = [
      { srcHash: 'a', source: 'Keep Acme.', format: 'text' },
      { srcHash: 'b', source: 'Plain.', format: 'text' },
    ];
    // A do-not-translate entry whose term cannot be read stands in for a check that throws.
    const broken = { caseSensitive: false };
    Object.defineProperty(broken, 'term', { get: () => { throw new TypeError('boom'); } });
    const result = validateTranslations({ items, entries: [{ id: 'a', text: 'Tieni Acme.' }, { id: 'b', text: 'Semplice.' }], doNotTranslate: [broken] });
    expect(result.internal).toEqual({ a: 'a check failed (boom)', b: 'a check failed (boom)' });
    expect(result.accepted).toEqual({});
    expect(result.rejected).toEqual({});
  });

  it('adds no `internal` key when every check ran', () => {
    const result = validateTranslations({ items: [{ srcHash: 'b', source: 'Plain.', format: 'text' }], entries: [{ id: 'b', text: 'Semplice.' }] });
    expect(Object.keys(result)).toEqual(['accepted', 'rejected', 'dropped']);
  });
});
