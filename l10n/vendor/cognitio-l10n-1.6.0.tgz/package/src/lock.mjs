/**
 * lock.mjs — The package lock: one file in the memory directory, held while a
 * command rewrites the machine layer or a resubmission queue — `collect` (and
 * `ci` and `local` through it), `session import`, `requeue` — and while
 * `memory commit` copies the layer, so the copy is never taken half-written and
 * two of them never interleave.
 *
 * READS and WRITES `<memory.dir>/l10n.lock`: created exclusively, holding the
 * command, its process id, its host and when it started, and removed when the
 * command ends. A command that finds it held stops before reading or writing
 * anything else, naming the holder. A lock whose holder is gone — a process of
 * this host that no longer runs — is taken over, and the takeover is reported;
 * a lock from another host, or one that cannot be read, is never taken over,
 * since nothing here can tell whether its holder still runs.
 */

import nodeFs from 'node:fs';
import os from 'node:os';
import path from 'node:path';

/** The lock's file name, in the memory directory. */
export const LOCK_FILE = 'l10n.lock';

/** The lock is held by another command. */
export class LockHeldError extends Error {
  constructor(file, holder) {
    super(
      holder
        ? `${file} is held by \`l10n ${holder.command}\` (process ${holder.pid} on ${holder.host}) since ${holder.at}; run this again once it has ended`
        : `${file} is held, and cannot be read; if no l10n command runs, remove it`
    );
    this.name = 'LockHeldError';
    this.file = file;
    this.holder = holder;
  }
}

/** The lock's holder as its file records it, or null when it cannot be read. */
function readHolder(file, fsImpl) {
  try {
    const value = JSON.parse(fsImpl.readFileSync(file, 'utf8'));
    return value && typeof value === 'object' && Number.isInteger(value.pid) ? value : null;
  } catch {
    return null;
  }
}

/** Whether a holder is a process of this host that no longer runs. */
function isGone(holder) {
  if (holder.host !== os.hostname()) return false;
  try {
    process.kill(holder.pid, 0);
    return false;
  } catch (err) {
    return err && err.code === 'ESRCH';
  }
}

/**
 * Takes the lock, or throws a LockHeldError naming its holder.
 *
 * @param {Object} args
 * @param {string} args.memoryDir
 * @param {string} args.command        the command that holds it, as the error names it.
 * @param {typeof nodeFs} [args.fsImpl]
 * @param {() => string} [args.now]
 * @returns {{file:string, tookOver:Object|null, release:() => void}}
 */
export function acquireLock({ memoryDir, command, fsImpl = nodeFs, now = () => new Date().toISOString() }) {
  const file = path.join(memoryDir, LOCK_FILE);
  const record = { command, pid: process.pid, host: os.hostname(), at: now() };
  fsImpl.mkdirSync(memoryDir, { recursive: true });
  let tookOver = null;
  for (;;) {
    try {
      fsImpl.writeFileSync(file, JSON.stringify(record) + '\n', { flag: 'wx' });
      break;
    } catch (err) {
      if (!err || err.code !== 'EEXIST') throw err;
      const holder = readHolder(file, fsImpl);
      if (!holder || tookOver || !isGone(holder)) throw new LockHeldError(file, holder);
      fsImpl.rmSync(file, { force: true });
      tookOver = holder;
    }
  }
  const release = () => {
    const holder = readHolder(file, fsImpl);
    if (holder && holder.pid === record.pid && holder.at === record.at) fsImpl.rmSync(file, { force: true });
  };
  return { file, tookOver, release };
}

/**
 * Runs `fn` holding the lock and releases it after, whether `fn` returns,
 * resolves, throws or rejects. A held lock is reported through `errlog` and
 * `fn` does not run: the result is `{ code: 1, action: 'locked' }`.
 *
 * @template T
 * @param {Object} args
 * @param {string} args.memoryDir
 * @param {string} args.command
 * @param {() => T|Promise<T>} fn
 * @param {typeof nodeFs} [args.fsImpl]
 * @param {(...a:any[])=>void} [args.log]
 * @param {(...a:any[])=>void} [args.errlog]
 * @returns {Promise<T|{code:number, action:'locked'}>}
 */
export async function withLock({ memoryDir, command, fsImpl = nodeFs, log = (...a) => console.log(...a), errlog = (...a) => console.error(...a) }, fn) {
  let lock;
  try {
    lock = acquireLock({ memoryDir, command, fsImpl });
  } catch (err) {
    if (!(err instanceof LockHeldError)) throw err;
    errlog(`${command}: ${err.message}. Nothing was read or written.`);
    return { code: 1, action: 'locked' };
  }
  if (lock.tookOver) {
    log(`${command}: took over ${lock.file}, left by \`l10n ${lock.tookOver.command}\` (process ${lock.tookOver.pid}, since ${lock.tookOver.at}), which no longer runs.`);
  }
  try {
    return await fn();
  } finally {
    lock.release();
  }
}

export default { LOCK_FILE, LockHeldError, acquireLock, withLock };
