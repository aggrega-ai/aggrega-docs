/**
 * batch.mjs — The Message Batches transport: `submit`, `collect`, `status`,
 * `cancelBatch` and `runCancel`.
 *
 * READS the catalogue, both memory layers, the pending file and the job logs
 * through the store, the pages through the adapter, and — for `submit`,
 * `collect`, `cancelBatch` and `runCancel` — the Message Batches API through the
 * client the caller's factory creates. WRITES, through the store, the pending
 * file (`submit`, `collect`, `runCancel`), the MACHINE layer of the memory and a
 * job log per collected batch (`collect`). It never writes the human layer, and
 * `status`, `submit --dry-run`, `runCancel --dry-run` and `cancelBatch` write no
 * file at all.
 *
 * SEVERAL BATCHES MAY BE IN FLIGHT, up to `backend.batches.maxInFlight` (default
 * 1), and no (segment, locale) pair is ever in two places at once: a submission
 * leaves out every pair a batch in flight holds (`batchHeldPairs`) and every pair
 * a translating session's batch not yet imported holds (`sessionHeldPairs`), and
 * says how many of each, so the transports and the batches run side by side
 * without translating a pair twice.
 *
 * SUBMIT refuses while the pending file records a halt (see COLLECT), unless
 * `--resume` clears it, and while the batches in flight fill
 * `backend.batches.maxInFlight`, or the lower ceiling `--max-in-flight` sets for
 * one run, naming them. It runs the gate; with no work it
 * stops there, creating no client. It plans the page requests (`requests.mjs`),
 * builds each with the one builder, and takes them in their stable order while
 * they fit the per-submission budgets: the estimated input (`tokens.mjs`) and the
 * sum of the requests' `max_tokens`, a ceiling the API enforces per request. It
 * stops at the first request that does not fit and leaves it and the rest for
 * the next batch. With `--batches <n>` it plans up to that many batches, as many
 * as the free slots allow, each within the per-submission budgets and holding
 * pairs no other holds. Under a spending budget (`backend.budget`, `budget.mjs`)
 * each batch's expected cost must fit under what is already committed: the
 * first that does not is refused, with the figures, and no batch after it is
 * planned. It creates each batch and records it in the pending file with its
 * estimate — tokens, and the bound in US dollars — and each request's mapping —
 * custom identifier to page, section, locale, segment identifiers, attempt and
 * model — writing the file after each, so a later failure never loses an
 * earlier record. When that file cannot be written after a batch was created,
 * the batch would be recorded nowhere and its units requested again by the next
 * submission, so `submit` cancels it (`cancelBatch`), prints its id and whether
 * the API accepted the cancellation, and returns 1. `--dry-run` builds the same
 * requests, prints per locale the page count and the estimated input and output
 * tokens, and the budget's figures, and creates no client and writes nothing.
 * Every estimate it and `submit` print splits the input into its cached and
 * uncached shares (`cachedEstimates`, over the selected requests in their order);
 * the budgets count the whole input, since a cache hit inside a batch is
 * best-effort. Both estimates are upper bounds (`tokens.mjs`), which `submit`
 * states after them, with the share of their estimates the batches collected so
 * far were billed, once job logs record it.
 *
 * COLLECT retrieves every recorded batch, in creation order, and prints for each
 * its processing status, how long it has been in flight and the API's
 * `request_counts`, which the pending file keeps as the last known — except
 * under `ci`, whose CI branch changes only when a batch ends; one in flight past
 * `backend.batches.staleAfterHours` is flagged stale. One still
 * processing is left recorded. One that has ended has its results read and keyed
 * by custom identifier — never by position, since results arrive in any order.
 * Each succeeded reply is read and validated (`validate.mjs`) and its accepted
 * segments are written to the machine layer; rejected and refused segments, and
 * those of a request errored for its own content, are queued for resubmission
 * with their defect, a refusal on the fallback model when the configuration
 * names one. A request that failed for the transport — errored for the account,
 * the rate limits or the API's own state, expired, canceled, or with no result
 * (`resultFailure`, the attempt rule) — counts no attempt: its segments are left
 * as the queue had them, so the next submission requests them again at the same
 * attempt, and they are named in the output and in the job log's `transport`.
 * When such a failure is the account's own, the pending file records a halt, and
 * `submit` refuses new batches until a person acts and runs `submit --resume`.
 * Each batch's rejections are judged against the recent batches' (`alarm.mjs`):
 * a batch far above them is named with its most frequent defects, the warning is
 * recorded in its job log, and under `backend.alarm.stopSubmissions` the pending
 * file records a halt of the kind `rejections`, which `submit --resume` clears
 * the same way.
 * An identifier a reply returned that its request did not ask for is dropped: it
 * is named in the output and in the job log, and nothing is written or queued
 * for it. A segment the validation could not judge, a failure of the package
 * rather than of the translation (`validate.mjs`), is neither written nor
 * queued, so no attempt is counted for it: it is named in the output and in the
 * job log's `internal`, and the next submission requests it as before. The usage
 * each reply reports is recorded in the job log, per request and summed
 * (`usageRecord`). The batch is then cleared from the pending file, which is
 * written before the next batch is applied, so a failure while applying one
 * batch neither loses nor applies twice what another applied. A machine entry
 * carries the batch's identifier and recorded creation time, and a queued
 * segment's attempt count is set from the recorded attempt, so applying the same
 * results twice writes the same bytes.
 *
 * STATUS prints the recorded batches — each with how long it has been in flight,
 * its last known request counts and whether it is stale — the halt, the queue,
 * what the collected batches were billed (`spendSummary`) and, under a spending
 * budget, its figures, and makes no network call.
 *
 * CANCELBATCH asks the API to cancel one batch, by identifier, and reports the
 * outcome without printing or throwing. A canceled batch enters `canceling`;
 * the API may still complete requests in progress that cannot be interrupted,
 * and those, like any it had already processed, may be billed. RUNCANCEL, the
 * `l10n cancel` command, cancels a recorded batch, or every stale one, and
 * records when it asked; the next `collect` applies what the batch finished and
 * leaves the rest for the next submission, counting no attempt.
 */

import { computeWorklist, withoutHeld } from './gate.mjs';
import { buildMessageParams, buildSystem, pagesFromCatalog, planRequests } from './requests.mjs';
import { cachedEstimates, estimateRequest, REASONING_OUTPUT_TOKENS, reservesReasoning } from './tokens.mjs';
import { recordedText, returnedTexts, validateTranslations } from './validate.mjs';
import { doNotTranslateOf, readTranslationMessage } from './translator-prompt.mjs';
import { batchHeldPairs, clearQueued, customIdFor, queueDefect, refusalDefect, resultFailure } from './pending.mjs';
import { classifyClientError, MissingApiKeyError } from './client.mjs';
import { findRevisions } from './revisions.mjs';
import { machineEntry } from './engine.mjs';
import { readUsage, spendSummary, usageLine, usageRecord } from './usage.mjs';
import { batchVerdict, budgetLines, committedSpend, requestsBound, verdictLine } from './budget.mjs';
import { readSessionQueue, sessionHeldPairs } from './session.mjs';
import { markedFromStore, markLines, recordedRevision, settleAccepted, withMarked, withMarkedRevisions } from './retranslate.mjs';
import { alarmLines, alarmReason, judgeBatch } from './alarm.mjs';
import { progressFromStore, progressLines, staleFromStore, staleLines } from './progress.mjs';
import { TRANSLATION_DEFAULTS } from './config.mjs';
import { LAYER, RESULT, STATUS } from './types.mjs';

/** The most requests one batch holds, from the Message Batches API reference. */
export const MAX_BATCH_REQUESTS = 100000;

/** The API's `request_counts` fields, in the order a line prints them. */
const COUNT_FIELDS = Object.freeze(['processing', 'succeeded', 'errored', 'canceled', 'expired']);

/** The request counts the API reported, each field a number, or null when it reported none. */
function countsOf(requestCounts) {
  if (!requestCounts || typeof requestCounts !== 'object') return null;
  return Object.fromEntries(COUNT_FIELDS.map((field) => [field, Number.isFinite(requestCounts[field]) ? requestCounts[field] : 0]));
}

/** Request counts as a line prints them. */
const countsText = (counts) => (counts ? `(${COUNT_FIELDS.map((field) => `${field} ${counts[field]}`).join(', ')})` : '(no request counts read yet)');

/** How long ago `createdAt` was at `now`, in milliseconds, or null when either is not a date. */
export function batchAge(createdAt, now) {
  const age = Date.parse(now) - Date.parse(createdAt);
  return Number.isFinite(age) ? age : null;
}

/** An age as a line prints it: minutes, then hours and minutes, then days and hours. */
export function formatAge(ms) {
  if (ms === null || ms < 0) return 'an unknown time';
  const minutes = Math.floor(ms / 60000);
  if (minutes < 60) return `${minutes} min`;
  const hours = Math.floor(minutes / 60);
  if (hours < 48) return `${hours} h ${minutes % 60} min`;
  return `${Math.floor(hours / 24)} d ${hours % 24} h`;
}

/** Whether a recorded batch has been in flight for longer than `backend.batches.staleAfterHours` at `now`. */
export function isStale(record, settings, now) {
  const age = batchAge(record.createdAt, now);
  return age !== null && age > settings.batches.staleAfterHours * 3600 * 1000;
}

/** What a line says of a stale batch. */
const staleText = (record, settings) =>
  `stale: in flight for more than backend.batches.staleAfterHours (${settings.batches.staleAfterHours} h); \`l10n cancel ${record.id}\` cancels it`;

/** The batch ids, as a sentence names them. */
const batchNames = (ids) => `batch${ids.length === 1 ? '' : 'es'} ${ids.join(', ')}`;

/**
 * The halt the pending file records, as a line states it: one the rejection
 * alarm recorded (`kind: "rejections"`), or one a failure of the account did —
 * a halt with no `kind`, as every version before the alarm wrote one.
 */
const haltText = (halt) =>
  halt.kind === 'rejections'
    ? `submission is halted since ${halt.at}: batch ${halt.batch} had its translations rejected far more often than the recent batches (${halt.reason})`
    : `submission is halted since ${halt.at}: batch ${halt.batch} failed for the account (${halt.reason}), and submitting more would fail the same way`;

/** What a person does about a halt before `submit --resume`. */
const haltAdvice = (halt) =>
  halt.kind === 'rejections'
    ? "Find the cause in the defects `collect` named, which the batch's job log records — a prompt, the glossary, the model — then run `l10n submit --resume`."
    : "Fix the account — its credit, its spending limit, the key's permissions — then run `l10n submit --resume`.";

/**
 * Takes requests in order while they fit the budgets, stopping at the first that
 * does not.
 *
 * @param {Array<{estimate: {input:number, output:number}}>} requests  in their stable order.
 * @param {{inputTokens:number, outputTokens:number}} budget
 * @param {number} [maxRequests]
 * @returns {{selected: Array, deferred: Array, totals: {input:number, output:number}}}
 */
export function selectWithinBudget(requests, { inputTokens, outputTokens }, maxRequests = MAX_BATCH_REQUESTS) {
  const totals = { input: 0, output: 0 };
  let count = 0;
  for (const request of requests) {
    const input = totals.input + request.estimate.input;
    const output = totals.output + request.estimate.output;
    if (count >= maxRequests || input > inputTokens || output > outputTokens) break;
    totals.input = input;
    totals.output = output;
    count += 1;
  }
  return { selected: requests.slice(0, count), deferred: requests.slice(count), totals };
}

/** The cached and uncached shares of an input estimate, as printed after it. */
const inputSplit = (input, cached) => `(${cached} cached, ${input - cached} uncached)`;

/** One line per locale: the pages and the estimated tokens of the selected requests. */
function perLocaleLines(selected, targets) {
  const lines = [];
  for (const lang of targets) {
    const mine = selected.filter((r) => r.spec.lang === lang);
    if (mine.length === 0) continue;
    const pages = new Set(mine.map((r) => r.spec.page)).size;
    const input = mine.reduce((n, r) => n + r.estimate.input, 0);
    const cached = mine.reduce((n, r) => n + r.cached, 0);
    const output = mine.reduce((n, r) => n + r.estimate.output, 0);
    lines.push(`  ${lang}: ${pages} page${pages === 1 ? '' : 's'}, ${mine.length} request${mine.length === 1 ? '' : 's'}, estimated input ${input} tokens ${inputSplit(input, cached)}, estimated output ${output} tokens`);
  }
  return lines;
}

/** The job logs `collect` wrote with the usage the API reported, in file order. */
function collectedJobs(store) {
  const jobs = [];
  if (typeof store.listJobs !== 'function' || typeof store.readJobLog !== 'function') return jobs;
  for (const name of store.listJobs()) {
    const job = store.readJobLog(name);
    if (job && job.trigger === 'collect' && job.usage) jobs.push(job);
  }
  return jobs;
}

const percent = (part, whole) => (whole > 0 ? `${Math.round((part / whole) * 100)}%` : 'n/a');

/**
 * What the estimates of a submission are, stated after them: both are upper
 * bounds, the output one reserving the reasoning allowance on every request that
 * can reason; and, once batches submitted with a recorded estimate have been
 * collected, the share of their estimates they were billed.
 */
function upperBoundLines(selected, store) {
  const reasoning = selected.filter((r) => reservesReasoning(r.params.thinking)).length;
  const lines = [
    'both estimates are upper bounds: the input counts one token per UTF-8 byte, and the output is the requests\' max_tokens' +
      (reasoning ? `, which reserve ${REASONING_OUTPUT_TOKENS} tokens for reasoning on each of ${reasoning} request(s)` : '') +
      '; the bill counts what the replies generate.',
  ];
  const calibrated = collectedJobs(store).filter((job) => job.usage.estimate);
  if (calibrated.length) {
    const sum = (f) => calibrated.reduce((n, job) => n + f(job), 0);
    const billedInput = sum((j) => j.usage.total.input + j.usage.total.cacheRead + j.usage.total.cacheWrite);
    const billedOutput = sum((j) => j.usage.total.output);
    lines.push(
      `the ${calibrated.length} batch(es) collected since their estimate was recorded were billed ${percent(billedInput, sum((j) => j.usage.estimate.input))} ` +
        `of their estimated input and ${percent(billedOutput, sum((j) => j.usage.estimate.output))} of their estimated output (\`l10n status\` itemizes it).`
    );
  }
  return lines;
}

const describe = (spec) => `${spec.page}${spec.section !== null && spec.section !== undefined ? ` § ${spec.section}` : ''} (${spec.lang})`;

/**
 * Plans the requests a submission would make for a worklist and builds each
 * with the one builder, in their stable order, before any budget is applied:
 * the pages (the adapter's, else the catalogue's usage files), the plan
 * (`planRequests`), and per request its specification, its Messages API
 * parameters and its offline estimate (`estimateRequest`). `submit` takes from
 * these what fits its budgets; `prepush` sums them for its cost estimate. Reads
 * the pages through the adapter and nothing else; creates no client.
 *
 * @param {Object} args
 * @param {Object|null} args.adapter
 * @param {Object} args.catalog         the source catalogue.
 * @param {Object} args.worklist        the gate's worklist for `targets`.
 * @param {Object} args.tmByLang        the lookup view of the memory, per locale.
 * @param {string[]} args.targets
 * @param {import('./config.mjs').TranslationSettings} args.settings
 * @param {Object} [args.glossary]
 * @param {Object.<string,string>} args.prompts  locale → the per-language prompt text.
 * @param {string|null} [args.generalPrompt]
 * @param {Object} [args.queue]         the pending file's resubmission queue.
 * @param {Object.<string,string>} [args.sources]  every recorded source (`store.readRecordedSources`), from which
 *        each changed segment's earlier version is found (`findRevisions`).
 * @param {Object} [args.marked]  the marked work the worklist holds (`markedWork`): each marked pair is requested
 *        as a revision of itself, and kept out of the search for changed segments' earlier versions.
 * @returns {Promise<{pages:Array, plan:Object, built:Array<{spec:Object, params:Object, estimate:{input:number, output:number}}>}>}
 */
export async function planBatch({ adapter, catalog, worklist, tmByLang, targets, settings, glossary = {}, prompts, generalPrompt = null, queue = {}, sources = {}, marked = null }) {
  const pages = adapter && typeof adapter.pages === 'function' ? await adapter.pages() : pagesFromCatalog(catalog);
  const changed = marked && marked.count ? withoutHeld(worklist, marked.pairs).worklist : worklist;
  const plan = planRequests({
    pages,
    worklist,
    tmByLang,
    targets,
    sectionTokens: settings.sectionTokens,
    attemptLimit: settings.attempts,
    queue,
    revisions: withMarkedRevisions(findRevisions({ worklist: changed, tmByLang, sources, targets }), marked),
  });
  const systems = {};
  for (const lang of targets) {
    if (plan.specs.some((spec) => spec.lang === lang)) {
      systems[lang] = buildSystem({
        lang,
        sourceLang: catalog.source_lang,
        glossary,
        generalPrompt,
        languagePrompt: prompts[lang],
        ...(adapter && adapter.identity && adapter.identity !== 'text' ? { identity: adapter.identity } : {}),
      });
    }
  }
  const built = plan.specs.map((spec) => {
    const params = buildMessageParams(spec, { model: settings.model, system: systems[spec.lang] });
    return { spec, params, estimate: estimateRequest(params) };
  });
  return { pages, plan, built };
}

/**
 * Submits the missing translations as one batch, or as up to `batches` of them.
 *
 * @param {Object} args
 * @param {ReturnType<import('./store.mjs').createStore>} args.store
 * @param {Object|null} args.adapter            supplies `pages()`; without it, the catalogue's usage files are the pages.
 * @param {string[]} args.targets
 * @param {import('./config.mjs').TranslationSettings} args.settings
 * @param {Object} args.glossary
 * @param {Object.<string,string>} args.prompts  locale → the per-language prompt text.
 * @param {string|null} [args.generalPrompt]     the project general prompt's text, or null without one.
 * @param {boolean} [args.dryRun]
 * @param {() => Object} args.createClient      the one client factory, bound to the configuration.
 * @param {string|null} [args.sessionWork]      a translating session's work directory, whose batches not yet
 *        imported hold their segments: those pairs are left to the session (`sessionHeldPairs`).
 * @param {number} [args.batches]               the most batches to create, within the free slots (default 1).
 * @param {number|null} [args.maxInFlight]      the most batches in flight this run allows, at most `backend.batches.maxInFlight`
 *        (default null: that setting).
 * @param {boolean} [args.resume]               clears the halt a collection recorded, after a person acted on it.
 * @param {() => string} [args.now]
 * @param {(...a:any[])=>void} [args.log]
 * @param {(...a:any[])=>void} [args.errlog]
 * @returns {Promise<{code:number, action:string, batchId?:string, batchIds?:string[], canceled?:boolean, selected?:number, deferred?:number}>}
 *          `batchId` is the first batch created and `batchIds` every one: `action` is `submitted` when the pending file
 *          records them, `unrecorded` (code 1) when the file could not be written after the last, and `canceled` then
 *          says whether the API accepted that batch's cancellation. A refusal is `halted`, `in-progress`, `over-budget`
 *          or `over-spend`, each with code 1.
 */
export async function submit({
  store,
  adapter,
  targets,
  settings,
  glossary = {},
  prompts,
  generalPrompt = null,
  dryRun = false,
  createClient,
  sessionWork = null,
  batches: wanted = 1,
  maxInFlight = null,
  resume = false,
  now = () => new Date().toISOString(),
  log = (...a) => console.log(...a),
  errlog = (...a) => console.error(...a),
}) {
  const heading = dryRun ? 'submit --dry-run' : 'submit';
  const pending = store.readPending();
  if (pending.halt) {
    if (resume && !dryRun) {
      log(`submit: --resume: the halt is cleared (${haltText(pending.halt)}).`);
      delete pending.halt;
      store.writePending(pending);
    } else if (resume) {
      log(`submit --dry-run: --resume would clear the halt (${haltText(pending.halt)}).`);
    } else if (dryRun) {
      log(`submit --dry-run: ${haltText(pending.halt)}, so a submission now would be refused.`);
    } else {
      errlog(`submit: ${haltText(pending.halt)}. ${haltAdvice(pending.halt)} No batch created.`);
      return { code: 1, action: 'halted' };
    }
  }
  const inFlight = pending.batches.map((b) => b.id);
  // `--max-in-flight` lowers the configured ceiling for this run; the command line refuses one above it.
  const ceiling = maxInFlight ?? settings.batches.maxInFlight;
  const ceilingName = maxInFlight === null ? 'backend.batches.maxInFlight' : '--max-in-flight';
  const free = ceiling - inFlight.length;
  if (free <= 0 && !dryRun) {
    errlog(
      `submit: ${batchNames(inFlight)} ${inFlight.length === 1 ? 'is' : 'are'} recorded and not yet collected; run \`l10n collect\` first. ` +
        `${inFlight.length} batch(es) in flight is the most ${ceilingName} allows (${ceiling}). No batch created.`
    );
    return { code: 1, action: 'in-progress' };
  }

  const catalog = store.readSourceCatalog();
  const tmByLang = store.readAllTM(targets);
  // What is missing, and the pairs marked for re-translation beside it, each requested as a revision of itself.
  const marked = markedFromStore(store, targets);
  const missing = withMarked(computeWorklist(catalog, { targets, tmByLang }), marked, targets);
  if (missing.status === 'up-to-date') {
    log('submit: no translation needed: no batch created, no network call.');
    return { code: 0, action: 'noop' };
  }
  if (marked.count > 0) log(`submit: ${marked.count} pair(s) marked for re-translation are requested beside what is missing.`);
  if (dryRun && free <= 0) {
    log(`submit --dry-run: ${batchNames(inFlight)} ${inFlight.length === 1 ? 'is' : 'are'} recorded and not yet collected, so a submission now would be refused.`);
  }
  // A pair a session batch not yet imported holds is the session's, and one a batch in flight holds is that batch's:
  // requesting either here would translate it twice.
  const fromSession = withoutHeld(missing, sessionWork ? sessionHeldPairs(sessionWork) : new Map());
  if (fromSession.skipped > 0) {
    log(`submit: ${fromSession.skipped} segment-locale pair(s) are held by session batches not yet imported (${sessionWork}) and are left to the session.`);
  }
  const fromBatches = withoutHeld(fromSession.worklist, batchHeldPairs(pending));
  if (fromBatches.skipped > 0) {
    log(`submit: ${fromBatches.skipped} segment-locale pair(s) are held by the ${batchNames(inFlight)} in flight and are left to ${inFlight.length === 1 ? 'it' : 'them'}.`);
  }
  const worklist = fromBatches.worklist;
  if (worklist.items.length === 0) {
    log(
      fromBatches.skipped > 0
        ? 'submit: every missing segment is held by a batch in flight or a session batch not yet imported: no batch created, no network call.'
        : 'submit: every missing segment is held by a session batch not yet imported: no batch created, no network call.'
    );
    return { code: 0, action: 'nothing-to-request' };
  }

  const { plan, built } = await planBatch({
    adapter,
    catalog,
    worklist,
    tmByLang,
    targets,
    settings,
    glossary,
    prompts,
    generalPrompt,
    queue: pending.queue,
    sources: store.readRecordedSources(),
    marked,
  });
  for (const lang of targets) {
    const exhausted = plan.exhausted[lang] || [];
    const unplaced = plan.unplaced[lang] || [];
    if (exhausted.length) log(`submit: ${lang}: ${exhausted.length} segment(s) reached the attempt limit and stay untranslated (named in the job log).`);
    if (unplaced.length) errlog(`submit: ${lang}: ${unplaced.length} missing unit(s) appear on no page: the catalogue is older than the content; run extract.`);
  }
  if (plan.specs.length === 0) {
    log('submit: work remains but nothing can be requested: no batch created, no network call.');
    return { code: 0, action: 'nothing-to-request' };
  }

  // The batches this submission plans, each the prefix of what is left that fits the per-submission budgets and,
  // under a spending budget, what is not yet committed. Each holds pairs no other holds: the plan places a pair once.
  const count = Math.max(1, Math.min(wanted, free));
  const spend = settings.budget ? committedSpend({ budget: settings.budget, jobs: collectedJobs(store), pending }) : null;
  const planned = [];
  let rest = built;
  let refused = null;
  let plannedExpected = 0;
  while (planned.length < count && rest.length > 0) {
    const { selected, deferred, totals } = selectWithinBudget(rest, settings.submission);
    if (selected.length === 0) {
      if (planned.length > 0) break;
      const first = rest[0];
      errlog(
        `submit: the first request, ${describe(first.spec)}, is estimated at ${first.estimate.input} input and ` +
          `${first.estimate.output} output tokens, above the per-submission budget (${settings.submission.inputTokens} input, ` +
          `${settings.submission.outputTokens} output); raise backend.submission or backend.sectionTokens. No batch created.`
      );
      return { code: 1, action: 'over-budget' };
    }
    const bound = requestsBound(selected);
    const verdict = spend ? batchVerdict(spend, bound, plannedExpected) : null;
    if (verdict && !verdict.fits) {
      refused = verdict;
      break;
    }
    if (verdict) plannedExpected += verdict.expected;
    // The cached share is reported beside the whole input and never subtracted from a budget: a cache hit
    // inside a batch is best-effort, so the budgets count each request's whole input estimate.
    const cached = cachedEstimates(selected.map((r) => r.params));
    selected.forEach((r, index) => {
      r.cached = cached[index];
    });
    planned.push({ selected, totals, cached: cached.reduce((n, c) => n + c, 0), bound, verdict });
    rest = deferred;
  }

  if (planned.length === 0) {
    // The spending budget refused the first batch.
    const lines = [...budgetLines(spend), verdictLine(spend, refused)];
    if (dryRun) {
      for (const line of lines) log(`${heading}: ${line}`);
      log(`submit --dry-run: a submission now would be refused by ${spend.names.budget}; no batch created, no file written.`);
      return { code: 0, action: 'dry-run', selected: 0, deferred: built.length };
    }
    for (const line of lines) errlog(`submit: ${line}`);
    errlog(
      refused.unpriced
        ? `submit: refused: ${spend.names.budget} cannot be checked, so no batch is created.`
        : `submit: refused by ${spend.names.budget}: no batch created. Raise ${spend.names.usd}, or collect the batches in flight first: they are expected to cost less than their bound.`
    );
    return { code: 1, action: 'over-spend' };
  }

  const all = planned.flatMap((p) => p.selected);
  const estimateText = (p) => `estimated input ${p.totals.input} tokens ${inputSplit(p.totals.input, p.cached)}, estimated output ${p.totals.output} tokens`;
  if (planned.length === 1) {
    log(`${heading}: ${all.length} request(s), ${estimateText(planned[0])}; ${rest.length} request(s) left for the next submission.`);
    for (const line of perLocaleLines(all, targets)) log(line);
  } else {
    planned.forEach((p, k) => {
      log(`${heading}: batch ${k + 1} of ${planned.length}: ${p.selected.length} request(s), ${estimateText(p)}.`);
      for (const line of perLocaleLines(p.selected, targets)) log(line);
    });
    log(`${heading}: ${rest.length} request(s) left for the next submission.`);
  }
  for (const line of upperBoundLines(all, store)) log(`${heading}: ${line}`);
  if (spend) {
    for (const line of budgetLines(spend)) log(`${heading}: ${line}`);
    planned.forEach((p, k) => log(`${heading}: ${planned.length > 1 ? `batch ${k + 1}: ` : ''}${verdictLine(spend, p.verdict)}`));
    if (refused) log(`${heading}: no further batch: ${verdictLine(spend, refused)}`);
  }
  if (dryRun) {
    planned.forEach((p, k) =>
      p.selected.forEach(({ spec, estimate, cached: share }, index) =>
        log(
          `  ${planned.length > 1 ? `batch ${k + 1}, ` : ''}request ${index + 1}: ${describe(spec)}: ` +
            `estimated input ${estimate.input} ${inputSplit(estimate.input, share)}, output ${estimate.output}`
        )
      )
    );
    log('submit --dry-run: no batch created, no file written.');
    return { code: 0, action: 'dry-run', selected: all.length, deferred: rest.length };
  }

  let client;
  try {
    client = createClient();
  } catch (err) {
    if (err instanceof MissingApiKeyError) {
      errlog(`submit: ${err.message}`);
      errlog('submit: no network call was made and no file was written.');
      return { code: 1, action: 'missing-key' };
    }
    throw err;
  }

  const created = [];
  for (const p of planned) {
    const requests = [];
    const mapping = {};
    p.selected.forEach(({ spec, params }, index) => {
      const customId = customIdFor({ index, lang: spec.lang, page: spec.page, section: spec.section });
      requests.push({ custom_id: customId, params });
      mapping[customId] = {
        page: spec.page,
        section: spec.section,
        lang: spec.lang,
        ids: spec.requested,
        attempt: spec.attempt,
        model: params.model,
        fallback: spec.fallback,
        ...(spec.revise
          ? { revisions: Object.fromEntries(Object.entries(spec.revise).map(([id, r]) => [id, recordedRevision(r)])) }
          : {}),
      };
    });
    let batch;
    try {
      batch = await client.messages.batches.create({ requests });
    } catch (err) {
      throw classifyClientError(err);
    }
    pending.batches.push({
      id: batch.id,
      createdAt: batch.created_at || now(),
      estimate: { input: p.totals.input, cached: p.cached, output: p.totals.output, ...(p.bound !== null ? { bound: p.bound } : {}) },
      requests: mapping,
    });
    try {
      store.writePending(pending);
    } catch (err) {
      // The batch exists and nothing records it, so the next submission would request its units again.
      // The write error is named by its code alone, like every other failure this module reports.
      const why = (err && (err.code || err.name)) || 'Error';
      errlog(`submit: batch ${batch.id} was created, but ${store.paths.pending} could not be written (${why}): the batch is recorded nowhere.`);
      const canceled = await cancelBatch({ batchId: batch.id, createClient });
      if (canceled.code === 0) {
        errlog(
          `submit: batch ${batch.id} was canceled: the API accepted the cancellation (processing status: ${canceled.status}); ` +
            'requests it had already processed may still be billed.'
        );
      } else {
        errlog(`submit: batch ${batch.id} could NOT be canceled (${canceled.reason}): cancel it by hand, or the next submission requests its units again.`);
      }
      return {
        code: 1,
        action: 'unrecorded',
        batchId: batch.id,
        batchIds: [...created, batch.id],
        canceled: canceled.code === 0,
        selected: all.length,
        deferred: rest.length,
      };
    }
    created.push(batch.id);
    log(`submit: batch ${batch.id} created with ${requests.length} request(s) and recorded in ${store.paths.pending}.`);
  }
  return { code: 0, action: 'submitted', batchId: created[0], batchIds: created, selected: all.length, deferred: rest.length };
}

/** The units of a request's identifiers that the catalogue still holds. */
function requestItems(ids, units) {
  const items = [];
  const gone = [];
  for (const id of ids) {
    const unit = units[id];
    if (!unit) {
      gone.push(id);
      continue;
    }
    items.push({
      srcHash: id,
      source: unit.source,
      format: unit.format || 'text',
      ...(unit.protected !== undefined ? { protected: unit.protected } : {}),
    });
  }
  return { items, gone };
}

const byLangThenKey = (a, b) => (a.lang < b.lang ? -1 : a.lang > b.lang ? 1 : a.srcHash < b.srcHash ? -1 : a.srcHash > b.srcHash ? 1 : 0);

/** Dropped identifiers in a fixed order — locale, page, section, identifier — since results arrive in any order. */
const byDropped = (a, b) => {
  for (const field of ['lang', 'page', 'section', 'id']) {
    const x = a[field] ?? '';
    const y = b[field] ?? '';
    if (x !== y) return x < y ? -1 : 1;
  }
  return 0;
};

/** Recorded batches in creation order, the pending file's order among those created at the same time. */
function inCreationOrder(batches) {
  const at = (record) => {
    const ms = Date.parse(record.createdAt);
    return Number.isFinite(ms) ? ms : Infinity;
  };
  return batches.map((record, index) => ({ record, index })).sort((a, b) => at(a.record) - at(b.record) || a.index - b.index).map((e) => e.record);
}

/** Failures as one line names them: each distinct defect, with how many requests it ended. */
function groupedDefects(list) {
  const counts = new Map();
  for (const { defect } of list) counts.set(defect, (counts.get(defect) || 0) + 1);
  return [...counts].map(([defect, n]) => `${defect} (${n})`).join('; ');
}

/**
 * Collects every recorded batch that has ended, in creation order.
 *
 * @param {Object} args
 * @param {ReturnType<import('./store.mjs').createStore>} args.store
 * @param {import('./config.mjs').TranslationSettings} args.settings
 * @param {Object} args.glossary
 * @param {() => Object} args.createClient
 * @param {boolean} [args.keepCounts]  whether the pending file keeps the request counts read for a batch still in flight
 *        (default true). `ci` passes false: the CI branch then changes only when a batch ends, never at every poll.
 * @param {() => string} [args.now]
 * @param {(...a:any[])=>void} [args.log]
 * @param {(...a:any[])=>void} [args.errlog]
 * @returns {Promise<{code:number, action:string, applied:number, collected?:string[], waiting?:string[], transport?:number, halted?:boolean}>}
 *          `applied` is the number of segments written to the machine layer; `transport`, the requests that failed for
 *          the transport; `halted`, whether the pending file records a halt once the collection is done.
 */
export async function collect({
  store,
  settings,
  glossary = {},
  createClient,
  keepCounts = true,
  now = () => new Date().toISOString(),
  log = (...a) => console.log(...a),
  errlog = (...a) => console.error(...a),
}) {
  const pending = store.readPending();
  if (pending.batches.length === 0) {
    log('collect: no batch is pending: no network call.');
    return { code: 0, action: 'noop', applied: 0 };
  }
  const { entries: doNotTranslate, caseSensitive } = doNotTranslateOf(glossary);
  let client;
  try {
    client = createClient();
  } catch (err) {
    if (err instanceof MissingApiKeyError) {
      errlog(`collect: ${err.message}`);
      errlog('collect: no network call was made and no file was written.');
      return { code: 1, action: 'missing-key', applied: 0 };
    }
    throw err;
  }

  const units = (store.readSourceCatalog().units) || {};
  const fallbackId = settings.model.fallbackId;
  const collected = [];
  const waiting = [];
  let applied = 0;
  let transportRequests = 0;

  for (const record of inCreationOrder(pending.batches)) {
    let batch;
    try {
      batch = await client.messages.batches.retrieve(record.id);
    } catch (err) {
      throw classifyClientError(err);
    }
    const checkedAt = now();
    const counts = countsOf(batch.request_counts);
    if (keepCounts && counts) {
      record.counts = counts;
      record.checkedAt = checkedAt;
    }
    const age = formatAge(batchAge(record.createdAt, checkedAt));
    if (batch.processing_status !== 'ended') {
      const stale = isStale(record, settings, checkedAt) ? `; ${staleText(record, settings)}` : '';
      log(`collect: batch ${record.id} is ${batch.processing_status}, in flight for ${age} ${countsText(counts)}; left recorded${stale}.`);
      waiting.push(record.id);
      continue;
    }
    log(`collect: batch ${record.id} has ended, ${age} after it was created ${countsText(counts)}.`);

    const items = [];
    const failures = [];
    const internal = [];
    const dropped = [];
    const usage = [];
    // The requests that failed for the transport, each segment of them in `transport`; and those errored for their
    // own content, which count an attempt.
    const transport = [];
    const transportFailed = [];
    const contentErrored = [];
    const seen = new Set();
    // `texts`: what the reply returned for each identifier, recorded beside its defect (`recordedText`).
    const queueAll = (req, ids, defect, extra = {}, texts = new Map()) => {
      queueDefect(pending.queue, { lang: req.lang, ids, attempt: req.attempt, defect, wasFallback: Boolean(req.fallback), fallbackId, ...extra });
      for (const id of ids) {
        failures.push({ srcHash: id, lang: req.lang, error: typeof defect === 'string' ? defect : defect[id], attempt: req.attempt, ...recordedText(texts.get(id)) });
      }
    };

    const apply = (req, result) => {
      const { items: reqItems, gone } = requestItems(req.ids, units);
      if (gone.length) clearQueued(pending.queue, req.lang, gone);
      const ids = reqItems.map((item) => item.srcHash);
      if (ids.length === 0) return;
      if (!result || result.type !== 'succeeded') {
        // The attempt rule: a failure of the request's own content counts; a transport failure leaves the queue as it was.
        const failure = resultFailure(result);
        if (failure.counts) {
          contentErrored.push(failure);
          queueAll(req, ids, failure.defect);
          return;
        }
        transportFailed.push(failure);
        for (const id of ids) transport.push({ srcHash: id, lang: req.lang, error: failure.defect, attempt: req.attempt });
        return;
      }
      const read = readTranslationMessage(result.message);
      if (read.refusal) {
        queueAll(req, ids, refusalDefect(read.refusal), { refusal: true });
        return;
      }
      const validation = validateTranslations({
        items: reqItems,
        entries: read.entries || null,
        replyDefect: read.defect,
        doNotTranslate,
        caseSensitive,
      });
      const { accepted, rejected } = validation;
      for (const id of validation.dropped) dropped.push({ id, lang: req.lang, page: req.page, section: req.section ?? null });
      const entries = {};
      const sources = {};
      for (const item of reqItems) {
        const text = accepted[item.srcHash];
        if (typeof text !== 'string') continue;
        const revision = req.revisions && req.revisions[item.srcHash];
        entries[item.srcHash] = machineEntry({ srcHash: item.srcHash, text, job: record.id, at: record.createdAt, revision });
        sources[item.srcHash] = item.source;
        items.push({
          srcHash: item.srcHash,
          lang: req.lang,
          source: item.source,
          text,
          status: STATUS.MACHINE,
          model: req.model,
          attempt: req.attempt,
          ...(revision && revision.forced ? { forced: true, reason: revision.reason } : {}),
        });
      }
      if (Object.keys(entries).length > 0) {
        store.writeLayerEntries(LAYER.MACHINE, req.lang, entries);
        store.mergeSourceMap(sources);
        store.mergeMachineSources(sources);
        clearQueued(pending.queue, req.lang, Object.keys(entries));
        settleAccepted({ store, lang: req.lang, ids: Object.keys(entries), revisions: req.revisions });
      }
      const returned = returnedTexts(read.entries);
      const rejectedIds = Object.keys(rejected);
      if (rejectedIds.length > 0) queueAll(req, rejectedIds, validation.replyDefect ?? rejected, {}, returned);
      // A segment a check could not judge is neither written nor queued: its attempt is not counted.
      for (const [id, error] of Object.entries(validation.internal || {})) {
        internal.push({ srcHash: id, lang: req.lang, error, attempt: req.attempt, ...recordedText(returned.get(id)) });
      }
    };

    let results;
    try {
      results = await client.messages.batches.results(record.id);
    } catch (err) {
      throw classifyClientError(err);
    }
    for await (const line of results) {
      const req = record.requests[line.custom_id];
      if (!req) {
        errlog(`collect: batch ${record.id}: a result for the unknown custom identifier ${JSON.stringify(line.custom_id)} was ignored.`);
        continue;
      }
      if (seen.has(line.custom_id)) continue;
      seen.add(line.custom_id);
      const message = line.result && line.result.type === 'succeeded' ? line.result.message : null;
      const reported = message ? readUsage(message.usage) : null;
      if (reported) usage.push({ customId: line.custom_id, lang: req.lang, page: req.page, section: req.section ?? null, model: req.model, ...reported });
      apply(req, line.result);
    }
    for (const [customId, req] of Object.entries(record.requests)) {
      if (!seen.has(customId)) apply(req, null);
    }

    const exhausted = failures
      .filter((f) => {
        const entry = pending.queue[f.lang] && pending.queue[f.lang][f.srcHash];
        return entry && entry.attempts >= settings.attempts;
      })
      .map(({ srcHash, lang, error }) => ({ srcHash, lang, error }));
    const result =
      failures.length === 0 && internal.length === 0 && transport.length === 0 ? RESULT.OK : items.length === 0 ? RESULT.FAILED : RESULT.PARTIAL;
    dropped.sort(byDropped);
    /** @type {import('./types.mjs').JobLog} */
    const job = {
      id: record.id,
      at: record.createdAt,
      trigger: 'collect',
      items: items.sort(byLangThenKey),
      failures: failures.sort(byLangThenKey),
      exhausted: exhausted.sort(byLangThenKey),
      ...(internal.length ? { internal: internal.sort(byLangThenKey) } : {}),
      ...(transport.length ? { transport: transport.sort(byLangThenKey) } : {}),
      ...(dropped.length ? { dropped } : {}),
      ...usageRecord(record, usage),
      result,
    };
    // The rejection alarm judges this batch against the recent ones the job logs record, and its job log records it.
    const alarmSettings = settings.alarm || TRANSLATION_DEFAULTS.alarm;
    const alarm = judgeBatch({ store, job, settings: alarmSettings });
    if (alarm) job.alarm = alarm;
    const jobFile = store.appendJobLog(job);
    log(
      `collect: batch ${record.id} ended: ${items.length} segment(s) written to the machine layer, ` +
        `${failures.length - exhausted.length} queued for resubmission, ${exhausted.length} at the attempt limit` +
        `${internal.length ? `, ${internal.length} left for the next submission after an internal error` : ''}` +
        `${transport.length ? `, ${transport.length} left for the next submission after a transport failure` : ''}; job=${jobFile}`
    );
    if (transportFailed.length) {
      log(`  ${transportFailed.length} request(s) failed for the transport, not counted as attempts: ${groupedDefects(transportFailed)}`);
    }
    if (contentErrored.length) {
      log(
        `  ${contentErrored.length} request(s) errored for their own content, counted as attempts, since resubmitted unchanged they would ` +
          `fail again: ${groupedDefects(contentErrored)}`
      );
    }
    for (const f of exhausted) log(`  untranslated after ${settings.attempts} attempts: ${f.lang} ${f.srcHash}: ${f.error}`);
    for (const f of internal) log(`  internal error, not a defect of the translation and not counted as an attempt: ${f.lang} ${f.srcHash}: ${f.error}`);
    for (const d of dropped) log(`  dropped an identifier the request did not ask for: ${describe(d)}: ${JSON.stringify(d.id)}`);
    if (job.usage) log(`  usage: ${usageLine(job.usage.total, job.usage.cost)}`);
    if (alarm) {
      for (const line of alarmLines(alarm)) errlog(`collect: batch ${record.id}: ${line}`);
      if (alarmSettings.stopSubmissions && !pending.halt) {
        pending.halt = { at: checkedAt, batch: record.id, reason: alarmReason(alarm), kind: 'rejections' };
        errlog(`collect: ${haltText(pending.halt)}; \`l10n submit\` refuses new batches until \`l10n submit --resume\` is run (backend.alarm.stopSubmissions).`);
      }
    }
    // A failure of the account itself halts submission: any more requests would fail the same way.
    const account = transportFailed.find((f) => f.account);
    if (account) {
      pending.halt = { at: checkedAt, batch: record.id, reason: account.defect };
      errlog(`collect: ${haltText(pending.halt)}; \`l10n submit\` refuses new batches until the account is fixed and \`l10n submit --resume\` is run.`);
    }
    // The batch is cleared and the file written before the next batch is read, so nothing this one applied is lost
    // or applied again when a later one fails.
    pending.batches = pending.batches.filter((b) => b !== record);
    store.writePending(pending);
    collected.push(record.id);
    applied += items.length;
    transportRequests += transportFailed.length;
  }

  // The request counts read for the batches still in flight.
  store.writePending(pending);
  return {
    code: 0,
    action: collected.length ? 'collected' : 'waiting',
    applied,
    collected,
    waiting,
    transport: transportRequests,
    halted: Boolean(pending.halt),
  };
}

/**
 * Asks the Message Batches API to cancel a batch. It never throws, never prints
 * and writes no file: a failure — no client, or the API refusing or not
 * answering — is returned with its error's class and HTTP status alone, never
 * the error's message, so no text an error carries reaches a log.
 *
 * @param {Object} args
 * @param {string} args.batchId
 * @param {() => Object} args.createClient   the one client factory, bound to the configuration.
 * @returns {Promise<{code:number, action:'canceled'|'cancel-failed', batchId:string, status?:string, reason?:string}>}
 *          `status` is the processing status the API answered; `reason` names the failure.
 */
export async function cancelBatch({ batchId, createClient }) {
  try {
    const client = createClient();
    const batch = await client.messages.batches.cancel(batchId);
    return { code: 0, action: 'canceled', batchId, status: (batch && batch.processing_status) || 'canceling' };
  } catch (err) {
    const kind = (err && err.constructor && err.constructor.name !== 'Object' && err.constructor.name) || 'Error';
    const status = err && typeof err.status === 'number' ? `, HTTP ${err.status}` : '';
    return { code: 1, action: 'cancel-failed', batchId, reason: `${kind}${status}` };
  }
}

/**
 * Cancels one recorded batch, or every stale one: the `l10n cancel` command. It
 * asks the API to cancel each (`cancelBatch`) and records in the pending file when
 * it asked (`canceledAt`); the next `collect` applies what each batch finished
 * once it has ended and leaves the rest for the next submission, the attempt rule
 * counting no attempt for a canceled request. A batch the pending file does not
 * record is refused, so nothing outside this project's work is canceled. With
 * `dryRun`, it names what it would cancel, creates no client and writes nothing.
 *
 * @param {Object} args
 * @param {ReturnType<import('./store.mjs').createStore>} args.store
 * @param {import('./config.mjs').TranslationSettings} args.settings
 * @param {string|null} [args.batchId]  the batch to cancel.
 * @param {boolean} [args.stale]        every batch in flight longer than `backend.batches.staleAfterHours`, in place of `batchId`.
 * @param {boolean} [args.dryRun]
 * @param {() => Object} args.createClient
 * @param {() => string} [args.now]
 * @param {(...a:any[])=>void} [args.log]
 * @param {(...a:any[])=>void} [args.errlog]
 * @returns {Promise<{code:number, canceled:string[], failed:string[]}>}  code 2 for a batch the pending file does not record.
 */
export async function runCancel({
  store,
  settings,
  batchId = null,
  stale = false,
  dryRun = false,
  createClient,
  now = () => new Date().toISOString(),
  log = (...a) => console.log(...a),
  errlog = (...a) => console.error(...a),
}) {
  const heading = dryRun ? 'cancel --dry-run' : 'cancel';
  const pending = store.readPending();
  const at = now();
  let chosen;
  if (stale) {
    chosen = pending.batches.filter((record) => isStale(record, settings, at));
    if (chosen.length === 0) {
      log(`${heading}: no batch has been in flight for more than backend.batches.staleAfterHours (${settings.batches.staleAfterHours} h): nothing to cancel.`);
      return { code: 0, canceled: [], failed: [] };
    }
  } else {
    const record = pending.batches.find((b) => b.id === batchId);
    if (!record) {
      errlog(`${heading}: batch ${batchId} is not recorded in ${store.paths.pending}: nothing was canceled. \`l10n status\` lists the batches in flight.`);
      return { code: 2, canceled: [], failed: [] };
    }
    chosen = [record];
  }
  const describeBatch = (record) =>
    `batch ${record.id}, created ${record.createdAt}, in flight for ${formatAge(batchAge(record.createdAt, at))}` +
    `${record.counts ? `, last read at ${record.checkedAt} ${countsText(record.counts)}` : ''}`;
  if (dryRun) {
    for (const record of chosen) log(`cancel --dry-run: would cancel ${describeBatch(record)}.`);
    log('cancel --dry-run: no request sent, no file written.');
    return { code: 0, canceled: [], failed: [] };
  }
  let client;
  try {
    client = createClient();
  } catch (err) {
    if (err instanceof MissingApiKeyError) {
      errlog(`cancel: ${err.message}`);
      errlog('cancel: no network call was made and no file was written.');
      return { code: 1, canceled: [], failed: chosen.map((r) => r.id) };
    }
    throw err;
  }
  const canceled = [];
  const failed = [];
  for (const record of chosen) {
    const outcome = await cancelBatch({ batchId: record.id, createClient: () => client });
    if (outcome.code === 0) {
      record.canceledAt = at;
      canceled.push(record.id);
      log(
        `cancel: ${describeBatch(record)}: the API accepted the cancellation (processing status: ${outcome.status}). ` +
          '`l10n collect` applies what it finished once it has ended and leaves the rest for the next submission, counting no attempt; ' +
          'requests it had already processed may still be billed.'
      );
    } else {
      failed.push(record.id);
      errlog(`cancel: batch ${record.id} could NOT be canceled (${outcome.reason}); it stays recorded.`);
    }
  }
  if (canceled.length) store.writePending(pending);
  return { code: failed.length ? 1 : 0, canceled, failed };
}

/**
 * Prints what the pending file records — the batches not yet collected, each
 * with how long it has been in flight, the request counts `collect` last read,
 * when its cancellation was asked for and whether it is stale; the halt; and per
 * locale the queued segments and those at the attempt limit — then what the
 * collected batches were billed, from the usage their job logs record
 * (`usage.mjs`): per batch, beside the estimate `submit` recorded for it when it
 * recorded one, per locale, and in total, in tokens and, where the package's rate
 * table holds every model used, in US dollars. A batch collected before job logs
 * recorded usage counts in none of these. Under a spending budget it prints its
 * figures (`budget.mjs`): billed, expected in flight, remaining. It names the
 * pairs marked for re-translation (`markLines`), those left out at the attempt
 * limit among them, and the queue's entries that no longer stand for work
 * (`progress.mjs`). With `progress`, it ends with the translation's progress per
 * locale and in total, the left-out and queued segments counted in both queues.
 * No network call.
 *
 * @param {Object} args
 * @param {ReturnType<import('./store.mjs').createStore>} args.store
 * @param {import('./config.mjs').TranslationSettings} args.settings
 * @param {string[]|null} [args.targets]  the locales whose marks are named (default: every locale the marks hold).
 * @param {string|null} [args.sessionWork] a translating session's work directory, whose queue and held pairs are read.
 * @param {boolean} [args.progress]       whether to print the progress lines.
 * @param {() => string} [args.now]
 * @param {(...a:any[])=>void} [args.log]
 * @returns {{code:number, batches:number}}
 */
export function status({ store, settings, targets = null, sessionWork = null, progress = false, now = () => new Date().toISOString(), log = (...a) => console.log(...a) }) {
  const pending = store.readPending();
  const at = now();
  if (pending.batches.length === 0) log('status: no batch is pending.');
  else if (settings.batches.maxInFlight > 1) {
    log(`status: ${pending.batches.length} batch(es) in flight, of the ${settings.batches.maxInFlight} backend.batches.maxInFlight allows.`);
  }
  for (const record of pending.batches) {
    const reqs = Object.values(record.requests || {});
    const langs = [...new Set(reqs.map((r) => r.lang))].sort();
    const details = [`in flight for ${formatAge(batchAge(record.createdAt, at))}`];
    if (record.counts) details.push(`last read at ${record.checkedAt} ${countsText(record.counts)}`);
    if (record.canceledAt) details.push(`its cancellation asked for at ${record.canceledAt}`);
    if (isStale(record, settings, at)) details.push(staleText(record, settings));
    log(
      `status: batch ${record.id}, created ${record.createdAt}: ${reqs.length} request(s) (${langs.join(', ')}); ${details.join('; ')}; ` +
        'run `l10n collect` to apply it once it has ended.'
    );
  }
  if (pending.halt) {
    log(`status: ${haltText(pending.halt)}; \`l10n submit --resume\` submits again once ${pending.halt.kind === 'rejections' ? 'the cause is found' : 'the account is fixed'}.`);
  }
  const langs = Object.keys(pending.queue).sort();
  if (langs.length === 0) log('status: the resubmission queue is empty.');
  for (const lang of langs) {
    const entries = Object.entries(pending.queue[lang]);
    const atLimit = entries.filter(([, e]) => e.attempts >= settings.attempts);
    log(`status: ${lang}: ${entries.length - atLimit.length} segment(s) queued for resubmission, ${atLimit.length} at the attempt limit.`);
    for (const [id, e] of atLimit) log(`  untranslated after ${e.attempts} attempts: ${id}: ${e.defect}`);
  }
  if (langs.some((lang) => Object.values(pending.queue[lang]).some((e) => e.attempts >= settings.attempts))) {
    log('status: `l10n requeue` gives the segments at the attempt limit their attempts again, their defect kept as a correction.');
  }
  const markedLocales = targets || (typeof store.readRetranslate === 'function' ? Object.keys(store.readRetranslate()) : []);
  for (const line of markLines(markedFromStore(store, markedLocales), { queue: pending.queue, attemptLimit: settings.attempts, prefix: 'status' })) log(line);
  const sessionQueue = sessionWork ? readSessionQueue(sessionWork) : {};
  if (targets) {
    const stale = staleFromStore(store, {
      targets,
      apiQueue: pending.queue,
      sessionQueue,
      batchHeld: batchHeldPairs(pending),
      sessionHeld: sessionWork ? sessionHeldPairs(sessionWork) : new Map(),
    });
    for (const line of staleLines(stale.api, { prefix: 'status', queue: store.paths.pending })) log(line);
  }
  const spend = spendSummary(collectedJobs(store));
  if (spend.batches.length === 0) {
    log('status: no collected batch records its usage yet.');
  } else {
    log(`status: billed, as the replies of ${spend.batches.length} collected batch(es) report it:`);
    for (const b of spend.batches) {
      const estimate = b.estimate ? `; estimated input ${b.estimate.input}, output ${b.estimate.output} tokens` : '';
      log(`  batch ${b.id}, created ${b.at}: ${usageLine(b.total, b.cost)}${estimate}`);
    }
    for (const [lang, l] of Object.entries(spend.byLang)) log(`  ${lang}: ${usageLine(l.total, l.cost)}`);
    log(`  total: ${usageLine(spend.total, spend.cost)}`);
  }
  if (settings.budget) {
    for (const line of budgetLines(committedSpend({ budget: settings.budget, jobs: collectedJobs(store), pending }))) log(`status: ${line}`);
  }
  if (progress && targets) {
    const rows = progressFromStore(store, { targets, queues: [pending.queue, sessionQueue], attemptLimit: settings.attempts });
    for (const line of progressLines(rows, 'status')) log(line);
  }
  return { code: 0, batches: pending.batches.length };
}

export default { submit, collect, status, cancelBatch, runCancel, planBatch, selectWithinBudget, MAX_BATCH_REQUESTS };
