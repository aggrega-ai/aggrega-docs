# Polski

Translate into Polish. Each choice below is a default, made without a native speaker's review, and a native speaker may change any of it.

## Register

- Technical and plain, as Polish software documentation is written: precise, with no emphasis the source does not have.
- Where the English says "you", prefer impersonal forms ("należy", "można"); use the second person singular only where a sentence cannot do without it.
- Headings take sentence case: a capital on the first word and on proper nouns only.

## Quotation marks

- A quoted phrase takes „tak”, and a quotation inside it takes «tak».
- Inline code is never put in quotation marks: it keeps its backticks.

## English terms kept as they are

- The glossary's do-not-translate terms, as the glossary writes them, capital letter included, never declined. Where the sentence needs a case ending, put a Polish noun before the term and decline that noun: obiektu Pipeline, w obiekcie Stage.
- A kept term's singular and plural are two distinct terms: `Pipeline` and `Pipelines`, `Stage` and `Stages`. Write the form the source writes, a plural where the source has the plural and a singular where it has the singular, even where this language does not mark number.
- Everything in inline code, and every YAML key, CLI command and flag, object kind and file path.
- The names of other products and standards: Docker, Kubernetes, GitHub Actions, WebAssembly, JSON Schema, YAML, OCI.
- Abbreviations such as CLI, API, SDK and ABI stay; their expansion is translated where the source spells it out.

## The qualifiers

- `social contract`: umowa społeczna.
- `best practice`: dobra praktyka, the established Polish term with the same force, dobre praktyki; never "reguła" or "wymóg".
- `escape hatch`: furtka, in the sense of "zostawić sobie furtkę"; never "luka", which reads as a gap or a vulnerability.
- `convention`: konwencja; never "reguła" or "przepis".
- `unopinionated`: bez własnego zdania; "mathematically unopinionated" is "matematycznie bez własnego zdania".
- `content-neutral`: neutralny wobec treści.
- `agnostic to`: agnostyczny wobec, as in "agnostyczny wobec konwencji".

A native speaker who finds a default here wrong corrects this file; every translation made after the correction follows it.
