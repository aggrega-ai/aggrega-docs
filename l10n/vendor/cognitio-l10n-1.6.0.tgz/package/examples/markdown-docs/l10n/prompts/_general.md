# The Flowline documentation

These instructions hold for every language. The language guide after them refines register, quotation marks and wording for one language, and its renderings are the ones to use.

## What the corpus is and who reads it

The pages are the documentation of Flowline, a workflow automation tool whose pipelines are written in YAML: its concepts, its guides and its reference. Engineers read them, in three roles:

- engineers authoring pipeline YAML: a Pipeline, its Stages, a Trigger, a Connector, and the other object kinds;
- plugin authors, who write WebAssembly plugins against the interface the engine gives them;
- integration authors, who build on the published Go, Rust and TypeScript packages.

Write for an engineer reading in their own language: precise, plain and technical. A sentence that teaches how something works teaches the same thing in the translation, with every condition, limit and exception the source states.

## What stays exactly as written

- YAML keys, CLI commands and flags, object kinds, file paths, and every word inside inline code stay exactly as the source writes them, in the same spelling and case: `stages`, `needs`, `with`, `--dry-run`, `Pipeline`, `reference/schema/`.
- A YAML key, a flag, an object kind or a path that a sentence names outside inline code stays as written too.
- The glossary's do-not-translate terms are the product's nouns, and each one is a term only as the glossary writes it, capital letter included: keep it in English wherever it occurs so, even where the language has a word for it. The same word in lower case — a pipeline, a stage, a trigger — is an ordinary word: translate it like any other.
- An error message — the text a diagnostic of the engine prints, and the name of an error wherever the documentation gives one: a heading on an error page, a link to it, a message quoted in a sentence or a table — is written as the original English message first, then its translation in parentheses, in every language: `[The connector does not support retries (Il connettore non supporta i nuovi tentativi)](../errors/run-errors.md#the-connector-does-not-support-retries)`. A reader searches for an error by the English text the engine prints, so the English stays and comes first. Inside inline code or a code block the message stays exactly as written, with no translation added.

## The qualifiers

The documentation uses a small set of words to say what the engine does and does not do: `social contract`, `best practice`, `escape hatch`, `convention`, `unopinionated`, `content-neutral` and `agnostic to`. They carry the engine's stance. What the documentation calls a social contract, a best practice or a convention is upheld by the teams and the templates that follow it, and the engine does not enforce it; an escape hatch is a way out of such a default that the design provides on purpose; and the engine is content-neutral, unopinionated and agnostic to what the data it passes between stages means, by design.

- Translate each with the rendering the language guide gives, every time it occurs and on every page, so that a reader meets one word for one stance.
- Translate each faithfully: never render the engine's neutrality as a deficiency or an insult; and never strengthen one, so that a convention or a best practice never becomes a rule, a requirement or a guarantee.
- Keep each qualifier where the source puts it. Never drop one, move it to another clause, or add one the source does not have.

## The Markdown

The output keeps every Markdown construct the source has: emphasis and strong emphasis, inline code, links and images with their destinations, references, footnote references, line breaks, HTML tags and comments, and the cells of a table. Translate the text inside a construct and leave the construct itself as the source writes it. Never add a construct the source does not have, and never remove one.
