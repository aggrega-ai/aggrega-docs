# Türkçe

Translate into Turkish. Each choice below is a default, made without a native speaker's review, and a native speaker may change any of it.

## Register

- Technical and plain, as Turkish software documentation is written: precise, with no emphasis the source does not have.
- Address the reader as "siz" wherever the English says "you"; elsewhere prefer impersonal and passive forms.
- Headings take sentence case: a capital on the first word and on proper nouns only.

## Quotation marks

- A quoted phrase takes “böyle”, and a quotation inside it takes ‘böyle’.
- Inline code is never put in quotation marks: it keeps its backticks.

## English terms kept as they are

- The glossary's do-not-translate terms, as the glossary writes them, capital letter included. A suffix on a kept term follows an apostrophe and its English pronunciation: Pipeline'ın, Stage'i, Artifact'e.
- A kept term's singular and plural are two distinct terms: `Pipeline` and `Pipelines`, `Stage` and `Stages`. Write the form the source writes, a plural where the source has the plural and a singular where it has the singular, even where this language does not mark number.
- Everything in inline code, and every YAML key, CLI command and flag, object kind and file path; a suffix on one of them also follows an apostrophe.
- The names of other products and standards: Docker, Kubernetes, GitHub Actions, WebAssembly, JSON Schema, YAML, OCI.
- Abbreviations such as CLI, API, SDK and ABI stay; their expansion is translated where the source spells it out.

## The qualifiers

- `social contract`: toplumsal sözleşme.
- `best practice`: en iyi uygulama; never "kural" or "zorunluluk".
- `escape hatch`: kaçış yolu; never "açık", which reads as a loophole, nor "arka kapı", which reads as a back door.
- `convention`: uzlaşım; never "kural", which reads as a rule that is enforced.
- `unopinionated`: kendi görüşü olmayan; "mathematically unopinionated" is "matematiksel olarak kendi görüşü olmayan".
- `content-neutral`: içeriğe karşı tarafsız.
- `agnostic to`: -den bağımsız, with the ablative, as in "uzlaşımlardan bağımsız".

A native speaker who finds a default here wrong corrects this file; every translation made after the correction follows it.
