# Português do Brasil

Translate into Brazilian Portuguese. Each choice below is a default, made without a native speaker's review, and a native speaker may change any of it.

## Register

- Technical and plain, as Brazilian software documentation is written: precise, with no emphasis the source does not have.
- Address the reader as "você" wherever the English says "you"; elsewhere prefer impersonal forms ("é possível configurar").
- Headings take sentence case: a capital on the first word and on proper nouns only.
- Use Brazilian spelling and vocabulary (arquivo, tela, usuário), never the European variant.

## Quotation marks

- A quoted phrase takes “assim”, and a quotation inside it takes ‘assim’.
- Inline code is never put in quotation marks: it keeps its backticks.

## English terms kept as they are

- The glossary's do-not-translate terms, as the glossary writes them, capital letter included, with these genders: o Pipeline, o Stage, o Connector, o Trigger, o Runner, o Workspace, o Plugin, o Artifact, o PipelineTemplate.
- A kept term's singular and plural are two distinct terms: `Pipeline` and `Pipelines`, `Stage` and `Stages`. Write the form the source writes, a plural where the source has the plural and a singular where it has the singular, even where this language does not mark number.
- Everything in inline code, and every YAML key, CLI command and flag, object kind and file path.
- The names of other products and standards: Docker, Kubernetes, GitHub Actions, WebAssembly, JSON Schema, YAML, OCI.
- Abbreviations such as CLI, API, SDK and ABI stay; their expansion is translated where the source spells it out.

## The qualifiers

- `social contract`: contrato social, in the sense of an agreement the people who use something uphold; never a company's articles of incorporation.
- `best practice`: boa prática, the established term with the same force, as boas práticas; never "regra" or "obrigação".
- `escape hatch`: via de escape; never "brecha", which reads as a loophole.
- `convention`: convenção; never "regra" or "norma".
- `unopinionated`: sem opiniões próprias; "mathematically unopinionated" is "matematicamente sem opiniões próprias".
- `content-neutral`: neutro quanto ao conteúdo.
- `agnostic to`: agnóstico em relação a, as in "agnóstico em relação às convenções".

A native speaker who finds a default here wrong corrects this file; every translation made after the correction follows it.
