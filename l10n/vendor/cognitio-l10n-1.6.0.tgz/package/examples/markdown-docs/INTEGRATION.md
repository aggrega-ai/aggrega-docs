# Adopting this example in a documentation repository

What a documentation repository's own maintainers do to translate its corpus
with this example, in order. Each step ends with the check that shows it is
done. The paths assume the corpus at the repository's root and the
documentation site beside it; a repository laid out otherwise adjusts
`adapter.sourceDir`, `include` and `exclude`, and the workflows' push paths.

## 1. Copy the `l10n/` directory and the workflows

- Copy this example's `l10n/` directory to the repository's root, and
  `.github/workflows/l10n.yml` and `.github/workflows/l10n-collect.yml` to the
  repository's `.github/workflows/`.
- Replace the glossary's product nouns, `site_context` and the general prompt's
  description of the corpus and its readers with the repository's own, and
  `include`, `exclude` and the generated paths and sections in the
  configuration with the corpus's.
- Vendor the package with the `cognitio-modules` command, from the
  repository's root, with a credential for the tooling host in `~/.netrc`:
  `curl --netrc -fsSL https://tooling.cognitio.it/modules/install.sh -o install.sh && sh install.sh init`,
  then `sh install.sh add @cognitio/l10n`; commit `install.sh`,
  `cognitio-modules.json` and `vendor/` (see the package README, "Vendoring
  it"). From a repository holding this one as a submodule, the same commands
  take `--cwd` naming its directory.
- The workflows' Install step installs it from that archive alone, with the
  workflow-only install the package README states ("Without a `package.json`:
  only inside the translation workflow"), so the repository's root needs no
  `package.json`.

**Check:** from the repository's root, with the package installed,
`npx l10n extract --config l10n/l10n.config.json` prints the corpus's file,
segment and word counts, and writes nothing outside `l10n/memory/`.

## 2. Declare the target locales in the site's internationalization configuration

- Add one locale per entry of `locales.targets` in `l10n/l10n.config.json`,
  each keyed by the directory the package writes it to under `l10n/` (`it`,
  `pt-BR`, `zh-CN`, …), with that tag as its `lang` and a label for the
  language picker; English stays the root locale.
- Read the list from `l10n/l10n.config.json` rather than copying it, so the
  configuration stays the one list of the target locales.

**Check:** a build offers English and every target language in the language
picker.

## 3. Point the site's content at `l10n/<locale>/`

- Add the translated trees to the globs through which the site reads the
  corpus — for each target locale, `l10n/<locale>/README.md`,
  `l10n/<locale>/concepts/**/*.md`, `l10n/<locale>/guides/**/*.md` and
  `l10n/<locale>/reference/**/*.md`, with the same exclusions as the source —
  and drop the leading `l10n/` from a translated page's id, so it is
  `<locale>/<path>` and `<locale>/README` becomes the locale's root.
- Those globs never reach `l10n/memory/` or `l10n/prompts/`, which hold the
  memory and the prompt files.

**Check:** a locale's root renders `l10n/<locale>/README.md`, and a page that
has no translation yet renders the English text the package copied for it.

## 4. Register the heading-identifier plugin, and confirm an anchor resolves

- Every translated heading ends with `{#<source slug>}`. Add
  `remarkHeadingIds`, exported by `@cognitio/l10n`, to the site's remark
  plugins: it strips the suffix and sets the heading's id (see the package
  README, "The syntax-tree plugin").
- Wherever the site takes a page's title from its first `#` line, which on a
  translated page ends with the suffix, pass the heading through
  `parseHeadingId(heading).text`, also exported by the package.
- The site build then needs the package. Install it from the vendored
  archive, as the workflows do.

**Check:** build a translated page and confirm that each heading's `id`
attribute is the source page's slug and no `{#…}` text is shown; then follow an
anchor link from a translated page — a `page.md#some-heading` link written
against the source — and confirm it lands on its heading. Whether the site's
own heading-id step keeps an identifier the plugin set is unverified until this
check passes.

## 5. Show the machine-translation notice on every translated page

- Show a notice that the page was machine-translated on every page of a locale
  other than the root, wired under the same condition that turns on the target
  locales, so no translated page is built without it.

**Check:** every built page under a target locale's path holds the notice, and
no English page does.

## 6. Add the deploy-time overlay

- In the build that publishes the translated site, after a checkout of every
  branch that persists no credential (`fetch-depth: 0`,
  `persist-credentials: false`) and after installing the package, run
  `npx l10n overlay --config l10n/l10n.config.json`, then
  `npx l10n generate --config l10n/l10n.config.json`, then the site build.
- A publishing build also runs `npx l10n gate --check --config l10n/l10n.config.json`
  as a blocking step, so it waits until every source segment has a translation.

**Check:** the build log prints the commit of `l10n-memory` the overlay read —
or, before the first translation run, that the build uses the committed memory —
and the published translated pages are the ones `generate` wrote.

## 7. Set the secrets and the watcher's token

- Both workflows read `ANTHROPIC_API_KEY`, the API key, in their `l10n ci` step
  alone; their Install step reads no secret. It is a
  repository secret: on GitHub Free, environment secrets are available only in
  public repositories. GitHub provides the job's own token; a ruleset on
  `l10n-memory`, if one is added, lets that token push the branch.
- A maintainer who runs the watcher, `npx l10n watch --config l10n/l10n.config.json`
  under a supervisor, keeps a token that can read this repository in
  `L10N_GIT_READ_TOKEN`, in the environment or in the dotenv file `--env-file`
  names. It needs read access and nothing more.

**Check:** a manual run of the translation workflow ends green and creates
`l10n-memory` — that run submits the first batch, which is billed — the
repository's Actions page then shows the collector enabled, and disabled again
after the run that collects the batch, which confirms the job's token may
switch it; and the watcher prints no idle message.

## 8. Run `doctor`

- From the repository's root: `npx l10n doctor --config l10n/l10n.config.json`.

**Check:** it prints nine passing lines and `doctor: all 9 checks passed.`, and
exits 0.

## 9. Expect the first full pass to spread across submissions

- The per-submission budgets the configuration sets in `backend.submission`
  hold a small part of a large corpus's first full translation, so that
  translation spans many submissions, each made by a later run of either
  workflow once the batch before it has been collected. The README beside this
  file ("Cost planning") states the budgets, the most one submission can spend,
  and how to count the submissions the first pass takes.

**Check:** `npx l10n submit --dry-run --config l10n/l10n.config.json` prints
the requests the first submission takes, per locale, and how many are left for
the next; it creates no client and no batch.
