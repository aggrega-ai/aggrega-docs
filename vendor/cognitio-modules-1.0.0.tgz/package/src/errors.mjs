/**
 * errors.mjs — the one error the library throws.
 *
 * READS and WRITES nothing.
 */

/**
 * A command that cannot go on. `exitCode` is the command line's status for it:
 * 1 when the host, an archive or the working copy is not as expected, 2 for a
 * usage error or a refusal the developer can answer.
 */
export class ModulesError extends Error {
  /**
   * @param {string} message
   * @param {1 | 2} [exitCode]
   */
  constructor(message, exitCode = 1) {
    super(message);
    this.name = 'ModulesError';
    this.exitCode = exitCode;
  }
}
