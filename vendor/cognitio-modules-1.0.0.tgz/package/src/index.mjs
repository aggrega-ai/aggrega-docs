/**
 * index.mjs — the library of `@cognitio/modules`: the commands of
 * `cognitio-modules` as functions, and the pieces they are made of, for a caller
 * such as a site's local admin page.
 *
 * READS and WRITES nothing itself; each function states what it touches.
 */

export { add, archivePath, check, init, install, INSTALL_SCRIPT, INSTALL_SCRIPT_MARKER, list, remove, upgrade } from './commands.mjs';
export { main, parseArgs, USAGE } from './cli.mjs';
export { ModulesError } from './errors.mjs';
export { fetchArchive, fetchIndex, isSendable, refusalMessage, sha256, statusMessage } from './host.mjs';
export {
  archivePathOf,
  COMMAND_PACKAGE,
  DEFAULT_SCOPES,
  formatLockfile,
  LOCKFILE,
  parseLockfile,
  readLockfile,
  VENDOR_DIR,
} from './lockfile.mjs';
export { authorizationFor, defaultNetrcPath } from './netrc.mjs';
export { BUN_INSTALL, defaultRun, NPM_INSTALL } from './project.mjs';
