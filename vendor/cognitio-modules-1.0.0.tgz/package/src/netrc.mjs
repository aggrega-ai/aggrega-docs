/**
 * netrc.mjs — the consumer credential, read from `~/.netrc`.
 *
 * READS the netrc file only, when a request needs a credential; WRITES nothing.
 * The credential is turned into an `Authorization` header value and goes
 * nowhere else: it is never printed, logged or written to a file, and no error
 * message carries it.
 *
 * The file is read as curl reads it: whitespace-separated tokens, a token in
 * double quotes may hold spaces (with `\"` and `\\` escapes), `machine <host>`
 * starts an entry, `default` an entry for every other host, `login` and
 * `password` fill the current entry, and `macdef` skips the lines after it up to
 * the next blank one. A host is matched by its name alone, never by its port.
 */

import { existsSync, readFileSync } from 'node:fs';
import { homedir } from 'node:os';
import { join } from 'node:path';

/** The netrc file read when no other is named: `~/.netrc`. */
export function defaultNetrcPath() {
  return join(homedir(), '.netrc');
}

function lineTokens(line) {
  const out = [];
  let i = 0;
  while (i < line.length) {
    if (/\s/.test(line[i])) {
      i += 1;
      continue;
    }
    let value = '';
    if (line[i] === '"') {
      i += 1;
      while (i < line.length && line[i] !== '"') {
        if (line[i] === '\\' && i + 1 < line.length) i += 1;
        value += line[i];
        i += 1;
      }
      i += 1;
    } else {
      while (i < line.length && !/\s/.test(line[i])) {
        value += line[i];
        i += 1;
      }
    }
    out.push(value);
  }
  return out;
}

/**
 * The entries of a netrc text, in order.
 *
 * @param {string} text
 * @returns {{machine: string | null, login?: string, password?: string}[]}
 */
export function parseNetrc(text) {
  const list = [];
  let inMacro = false;
  for (const line of text.split(/\r?\n/)) {
    if (inMacro) {
      if (line.trim() === '') inMacro = false;
      continue;
    }
    for (const token of lineTokens(line)) {
      list.push(token);
      if (token === 'macdef') {
        inMacro = true;
        break;
      }
    }
  }
  const entries = [];
  let current = null;
  for (let i = 0; i < list.length; i++) {
    const token = list[i];
    if (token === 'machine') {
      current = { machine: list[i + 1] ?? '' };
      entries.push(current);
      i += 1;
    } else if (token === 'default') {
      current = { machine: null };
      entries.push(current);
    } else if (token === 'login' || token === 'password') {
      if (current && list[i + 1] !== undefined) current[token] = list[i + 1];
      i += 1;
    } else if (token === 'account') {
      i += 1;
    } else if (token === 'macdef') {
      // Its name and its body were skipped with the rest of its lines.
      current = null;
    }
  }
  return entries;
}

/**
 * The `Authorization` header value for a host, or null when the netrc file is
 * absent or names no entry for it. A `machine` entry for the host wins over
 * `default`.
 *
 * @param {string} hostname the URL's host name, without a port
 * @param {string} [netrcPath]
 * @returns {string | null}
 */
export function authorizationFor(hostname, netrcPath = defaultNetrcPath()) {
  if (!existsSync(netrcPath)) return null;
  const entries = parseNetrc(readFileSync(netrcPath, 'utf8'));
  const entry = entries.find((e) => e.machine === hostname) ?? entries.find((e) => e.machine === null);
  if (!entry || entry.login === undefined) return null;
  return `Basic ${Buffer.from(`${entry.login}:${entry.password ?? ''}`, 'utf8').toString('base64')}`;
}
