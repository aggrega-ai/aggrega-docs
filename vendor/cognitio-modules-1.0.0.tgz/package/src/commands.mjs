/**
 * commands.mjs — the commands of `cognitio-modules`, as library functions.
 *
 * READS the project's lockfile, its vendored archives and its package.json, and
 * the hosts' indexes and archives (`list`, `add`, `upgrade`, `install`, `init`);
 * WRITES only inside the project's directory: the archives under `vendor/`, the
 * lockfile, package.json and `install.sh`, and RUNS the package manager that
 * refreshes the project's own lockfiles. Nothing is committed.
 *
 * Every function takes the same options and reports each file it changes, as it
 * changes it, through `out`; it returns what it did, for a caller such as a local
 * admin page. A refusal or a failure is a thrown ModulesError.
 *
 * Three rules hold for every command:
 *
 * - The credential goes over https alone, and only to the host the lockfile
 *   maps the package's scope to: every request passes `isSendable` in
 *   `host.mjs` first, whether its URL came from an index or from the lockfile.
 * - An archive is written only after its sha256 is the one its index (or, for
 *   `install`, the lockfile) records, and an upgrade downloads and checks every
 *   accepted archive before it writes any file, so a refused archive leaves the
 *   working copy as it was.
 * - A file at a path the command would replace or delete, whose bytes are not the
 *   ones the lockfile records for it, was not written by the command: it is
 *   replaced or deleted only when `confirm` answers yes. `yes` accepts upgrades;
 *   it does not answer this question.
 */

import { existsSync, mkdirSync, readFileSync, renameSync, rmSync, statSync, writeFileSync } from 'node:fs';
import { join, resolve } from 'node:path';

import { ModulesError } from './errors.mjs';
import { fetchArchive, fetchIndex, sha256 } from './host.mjs';
import {
  COMMAND_PACKAGE,
  DEFAULT_SCOPES,
  LOCKFILE,
  VENDOR_DIR,
  archivePathOf,
  hostOf,
  readLockfile,
  splitName,
  writeLockfile,
} from './lockfile.mjs';
import { applyDependencies, defaultRun, dependencyOf, hasPackageJson, refreshPackageLocks } from './project.mjs';
import { readArchiveFile } from './tarball.mjs';

/** The project's entry point, at its root. */
export const INSTALL_SCRIPT = 'install.sh';

/**
 * The line every `install.sh` the command writes carries. A project's
 * `install.sh` holding it is replaced when the command upgrades itself; one
 * without it is replaced only on a yes.
 */
export const INSTALL_SCRIPT_MARKER = '# Written by cognitio-modules, which replaces this file when it upgrades itself.';

/**
 * @typedef {object} Options
 * @property {string} [cwd] the project's root; the current directory when absent
 * @property {boolean} [yes] accept every upgrade `upgrade` proposes
 * @property {boolean} [dev] a module new to package.json goes to `devDependencies`
 * @property {string} [netrc] the netrc file to read the credential from; `~/.netrc` when absent
 * @property {(line: string) => void} [out] receives a line per change and per finding
 * @property {(question: string, about: Question) => boolean | Promise<boolean>} [confirm] answers a yes/no
 *   question, given as the text a terminal shows and as what it asks about;
 *   when absent, every question is answered no and `upgrade` needs `yes`
 * @property {(command: string, args: string[], options: {cwd: string}) => number | Promise<number>} [run]
 *   runs a package manager and returns its exit status
 * @property {typeof fetch} [fetch]
 */

/**
 * What a question `confirm` is asked is about, so a caller answers it without
 * reading the question's text:
 *
 * - `{kind: 'upgrade', name, from, to}` — upgrade module `name` from version `from` to `to`;
 * - `{kind: 'replace', path, name?, version?}` — replace the file at `path` (relative to the
 *   project's root), which the command did not write, with module `name` at `version`, or with
 *   the `install.sh` the command carries when `path` is `install.sh`;
 * - `{kind: 'delete', path}` — delete the file at `path`, which the command did not write.
 *
 * @typedef {{kind: 'upgrade', name: string, from: string, to: string}
 *   | {kind: 'replace', path: string, name?: string, version?: string}
 *   | {kind: 'delete', path: string}} Question
 */

function context(options = {}) {
  const dir = resolve(options.cwd ?? process.cwd());
  if (!existsSync(dir) || !statSync(dir).isDirectory()) throw new ModulesError(`${dir} is not a directory`, 2);
  const lines = [];
  const out = options.out ?? (() => {});
  return {
    dir,
    yes: Boolean(options.yes),
    dev: Boolean(options.dev),
    confirm: options.confirm ?? null,
    run: options.run ?? defaultRun,
    http: { fetch: options.fetch, netrc: options.netrc },
    /** The lines naming a file changed, in order. */
    lines,
    /** Reports a finding that changes no file. */
    note(line) {
      out(line);
    },
    /** Reports a file changed, or a package manager run. */
    change(line) {
      lines.push(line);
      out(line);
    },
  };
}

function requireLock(ctx) {
  const lock = readLockfile(ctx.dir);
  if (!lock) throw new ModulesError(`${ctx.dir} has no ${LOCKFILE}: run init there first`, 2);
  return lock;
}

function fileSha(file) {
  return existsSync(file) ? sha256(readFileSync(file)) : null;
}

/** Asks `confirm`, with the question's text and what it is about (a Question). */
async function ask(ctx, question, about) {
  if (!ctx.confirm) return false;
  return Boolean(await ctx.confirm(question, about));
}

function notWritten(rel) {
  return `${rel} is not the file ${LOCKFILE} records, so cognitio-modules did not write it`;
}

function writeAtomically(file, bytes) {
  const temporary = `${file}.${process.pid}.tmp`;
  writeFileSync(temporary, bytes);
  renameSync(temporary, file);
}

/** The package and the version of `<package>[@<version>]`. */
function parseSpec(spec) {
  if (typeof spec !== 'string' || spec === '') throw new ModulesError('name a package: @<scope>/<module>[@<version>]', 2);
  const at = spec.lastIndexOf('@');
  const name = at > 0 ? spec.slice(0, at) : spec;
  const version = at > 0 ? spec.slice(at + 1) : undefined;
  splitName(name);
  return { name, version };
}

/**
 * An archive's bytes: the vendored copy when it already is the one recorded,
 * else downloaded from the URL an index names and checked — on the host the
 * lockfile maps the package's scope to, or refused with nothing sent.
 */
async function obtain(ctx, lock, name, entry) {
  const file = join(ctx.dir, archivePathOf(name, entry.version));
  if (fileSha(file) === entry.sha256) return readFileSync(file);
  return fetchArchive(hostOf(lock, name), name, entry, ctx.http);
}

async function writeInstallScript(ctx, commandArchive) {
  const script = readArchiveFile(commandArchive, `package/${INSTALL_SCRIPT}`);
  if (script === null) return;
  const file = join(ctx.dir, INSTALL_SCRIPT);
  if (!existsSync(file)) {
    writeFileSync(file, script);
    ctx.change(`wrote ${INSTALL_SCRIPT}`);
    return;
  }
  const current = readFileSync(file);
  if (current.equals(script)) return;
  if (
    current.toString('utf8').includes(INSTALL_SCRIPT_MARKER) ||
    (await ask(ctx, `${INSTALL_SCRIPT} was not written by cognitio-modules. Replace it with the one ${COMMAND_PACKAGE} carries?`, {
      kind: 'replace',
      path: INSTALL_SCRIPT,
    }))
  ) {
    writeFileSync(file, script);
    ctx.change(`updated ${INSTALL_SCRIPT}`);
    return;
  }
  ctx.note(`left ${INSTALL_SCRIPT} as it is: it was not written by cognitio-modules`);
}

/**
 * Applies a set of changes, each `{name, from, to, bytes, dev}` with `from` and
 * `to` lockfile entries (null for none): first every question, then every write.
 */
async function apply(ctx, lock, changes) {
  for (const change of changes) {
    if (change.to) {
      const rel = archivePathOf(change.name, change.to.version);
      const file = join(ctx.dir, rel);
      const have = fileSha(file);
      change.target = { rel, file, write: have !== change.to.sha256 };
      if (have !== null && have !== change.to.sha256) {
        const about = { kind: 'replace', path: rel, name: change.name, version: change.to.version };
        if (!(await ask(ctx, `${notWritten(rel)}. Replace it with ${change.name} ${change.to.version}?`, about))) {
          throw new ModulesError(`${notWritten(rel)}: it is not replaced. Remove it, or answer yes in a terminal`, 2);
        }
      }
    }
    if (change.from && (!change.to || change.to.version !== change.from.version)) {
      const rel = archivePathOf(change.name, change.from.version);
      const file = join(ctx.dir, rel);
      const have = fileSha(file);
      if (have === null) continue;
      if (have === change.from.sha256 || (await ask(ctx, `${notWritten(rel)}. Delete it?`, { kind: 'delete', path: rel }))) change.old = { rel, file };
      else change.kept = rel;
    }
  }

  if (changes.some((c) => c.target?.write)) mkdirSync(join(ctx.dir, VENDOR_DIR), { recursive: true });
  for (const change of changes) {
    if (change.target?.write) {
      writeAtomically(change.target.file, change.bytes);
      ctx.change(`vendored ${change.name} ${change.to.version}: ${change.target.rel} (sha256 ${change.to.sha256})`);
    }
    if (change.old) {
      rmSync(change.old.file);
      ctx.change(`removed ${change.old.rel}`);
    }
    if (change.kept) ctx.note(`left ${change.kept} in place: ${notWritten(change.kept)}`);
    if (change.to) lock.modules[change.name] = { version: change.to.version, url: change.to.url, sha256: change.to.sha256 };
    else delete lock.modules[change.name];
  }
  if (writeLockfile(ctx.dir, lock)) ctx.change(`wrote ${LOCKFILE}`);

  const command = changes.find((c) => c.name === COMMAND_PACKAGE && c.to);
  if (command) await writeInstallScript(ctx, command.bytes);

  if (!hasPackageJson(ctx.dir)) return;
  const touched = changes.filter((c) => c.target?.write && dependencyOf(ctx.dir, c.name) !== null);
  // The command itself is a development tool wherever it is new to package.json.
  const lines = applyDependencies(
    ctx.dir,
    changes.map((c) => ({ name: c.name, spec: c.to ? `file:${c.target.rel}` : null, dev: c.dev || c.name === COMMAND_PACKAGE })),
  );
  for (const line of lines) ctx.change(line);
  if (lines.length > 0 || touched.length > 0) {
    for (const line of await refreshPackageLocks(ctx.dir, ctx.run)) ctx.change(line);
  }
}

async function addModule(ctx, lock, name, version, dev) {
  const index = await fetchIndex(hostOf(lock, name), name, ctx.http);
  const entry = version === undefined ? index.versions.at(-1) : index.versions.find((e) => e.version === version);
  if (!entry) {
    throw new ModulesError(
      `${name} ${version} is not published: its index lists ${index.versions.map((e) => e.version).join(', ')}`,
      1,
    );
  }
  const from = lock.modules[name] ?? null;
  if (from && from.version === entry.version && from.sha256 !== entry.sha256) {
    throw new ModulesError(
      `the index records sha256 ${entry.sha256} for ${name} ${entry.version}, and ${LOCKFILE} records ${from.sha256}: nothing is changed`,
      1,
    );
  }
  const rel = archivePathOf(name, entry.version);
  if (from && from.version === entry.version && fileSha(join(ctx.dir, rel)) === entry.sha256) {
    ctx.note(`${name} ${entry.version} is already vendored at ${rel}`);
    return false;
  }
  const bytes = await obtain(ctx, lock, name, entry);
  await apply(ctx, lock, [{ name, from, to: entry, bytes, dev }]);
  return true;
}

/**
 * Starts a project: writes the lockfile when there is none (mapping `@cognitio`
 * to its host), vendors the newest `@cognitio/modules`, and writes `install.sh`
 * from it. A project already started is left as it is, `install.sh` put back if
 * it is missing.
 *
 * @param {Options} [options]
 * @returns {Promise<{changes: string[]}>}
 */
export async function init(options) {
  const ctx = context(options);
  const lock = readLockfile(ctx.dir) ?? { scopes: { ...DEFAULT_SCOPES }, modules: {} };
  if (!lock.modules[COMMAND_PACKAGE]) {
    await addModule(ctx, lock, COMMAND_PACKAGE, undefined, true);
  } else {
    const entry = lock.modules[COMMAND_PACKAGE];
    const file = join(ctx.dir, archivePathOf(COMMAND_PACKAGE, entry.version));
    if (!existsSync(join(ctx.dir, INSTALL_SCRIPT)) && fileSha(file) === entry.sha256) {
      await writeInstallScript(ctx, readFileSync(file));
    }
    ctx.note(`${ctx.dir} is already started: ${LOCKFILE} names ${COMMAND_PACKAGE} ${entry.version}`);
  }
  return { changes: ctx.lines };
}

/**
 * Vendors a module at a version, the newest when none is named, replacing the
 * version vendored before.
 *
 * @param {Options} options
 * @param {string} spec `<package>[@<version>]`
 * @returns {Promise<{changes: string[]}>}
 */
export async function add(options, spec) {
  const ctx = context(options);
  const { name, version } = parseSpec(spec);
  const lock = requireLock(ctx);
  await addModule(ctx, lock, name, version, ctx.dev);
  return { changes: ctx.lines };
}

/**
 * Removes a module: its archive, its lockfile entry and its package.json entry.
 *
 * @param {Options} options
 * @param {string} name
 * @returns {Promise<{changes: string[]}>}
 */
export async function remove(options, name) {
  const ctx = context(options);
  splitName(name ?? '');
  const lock = requireLock(ctx);
  const from = lock.modules[name];
  if (!from) throw new ModulesError(`${LOCKFILE} names no module ${name}`, 2);
  if (name === COMMAND_PACKAGE) {
    throw new ModulesError(
      `${COMMAND_PACKAGE} is the command itself, which ${INSTALL_SCRIPT} runs: it is not removed. To stop using it, delete ${INSTALL_SCRIPT}, ${LOCKFILE} and its archive by hand`,
      2,
    );
  }
  await apply(ctx, lock, [{ name, from, to: null, bytes: null, dev: false }]);
  return { changes: ctx.lines };
}

/**
 * Reads every module's index and proposes each newer version, newest of each
 * module only; applies those `confirm` accepts, or all with `yes`.
 *
 * @param {Options} [options]
 * @returns {Promise<{proposed: {name: string, from: string, to: string}[], upgraded: string[], changes: string[]}>}
 */
export async function upgrade(options) {
  const ctx = context(options);
  const lock = requireLock(ctx);
  const proposals = [];
  for (const name of Object.keys(lock.modules).sort()) {
    const from = lock.modules[name];
    const index = await fetchIndex(hostOf(lock, name), name, ctx.http);
    const newest = index.versions.at(-1);
    if (newest.version === from.version) continue;
    if (!index.versions.some((e) => e.version === from.version)) {
      ctx.note(`${name} ${from.version} is not in its index any more; its newest version is ${newest.version}`);
    }
    proposals.push({ name, from, to: newest });
  }
  const proposed = proposals.map((p) => ({ name: p.name, from: p.from.version, to: p.to.version }));
  if (proposals.length === 0) {
    ctx.note('every module is at its newest version');
    return { proposed, upgraded: [], changes: ctx.lines };
  }
  for (const p of proposals) ctx.note(`${p.name} ${p.from.version} → ${p.to.version}`);
  if (!ctx.yes && !ctx.confirm) {
    throw new ModulesError('upgrade asks before each module: run it in a terminal, or pass --yes to accept every one', 2);
  }
  const accepted = [];
  for (const p of proposals) {
    const about = { kind: 'upgrade', name: p.name, from: p.from.version, to: p.to.version };
    if (ctx.yes || (await ask(ctx, `Upgrade ${p.name} ${p.from.version} → ${p.to.version}?`, about))) accepted.push(p);
  }
  if (accepted.length === 0) {
    ctx.note('nothing upgraded');
    return { proposed, upgraded: [], changes: ctx.lines };
  }
  const changes = [];
  for (const p of accepted) {
    changes.push({ name: p.name, from: p.from, to: p.to, bytes: await obtain(ctx, lock, p.name, p.to), dev: ctx.dev });
  }
  await apply(ctx, lock, changes);
  return { proposed, upgraded: accepted.map((p) => p.name), changes: ctx.lines };
}

/**
 * Every module with its vendored version and the newest its index lists.
 *
 * @param {Options} [options]
 * @returns {Promise<{ok: boolean, modules: {name: string, version: string, newest: string | null, error: string | null}[]}>}
 */
export async function list(options) {
  const ctx = context(options);
  const lock = requireLock(ctx);
  const rows = [];
  for (const name of Object.keys(lock.modules).sort()) {
    const { version } = lock.modules[name];
    try {
      const index = await fetchIndex(hostOf(lock, name), name, ctx.http);
      rows.push({ name, version, newest: index.versions.at(-1).version, error: null });
    } catch (err) {
      if (!(err instanceof ModulesError)) throw err;
      rows.push({ name, version, newest: null, error: err.message });
    }
  }
  const width = Math.max(0, ...rows.map((r) => r.name.length));
  const versionWidth = Math.max(0, ...rows.map((r) => r.version.length));
  if (rows.length === 0) ctx.note(`${LOCKFILE} names no module`);
  for (const r of rows) {
    const state = r.error ? `newest unknown: ${r.error}` : r.newest === r.version ? 'newest' : `newest ${r.newest}`;
    ctx.note(`${r.name.padEnd(width)}  ${r.version.padEnd(versionWidth)}  ${state}`);
  }
  return { ok: rows.every((r) => r.error === null), modules: rows };
}

/**
 * Puts back every vendored archive the lockfile names and the working copy
 * lacks, downloading it from the URL the lockfile records — refused, with
 * nothing sent, unless it is on the host the lockfile maps the package's scope
 * to — and checking it against the lockfile's sha256. A copy that is there and
 * differs is replaced only on a yes.
 *
 * @param {Options} [options]
 * @returns {Promise<{restored: string[], changes: string[]}>}
 */
export async function install(options) {
  const ctx = context(options);
  const lock = requireLock(ctx);
  const restored = [];
  const refused = [];
  for (const name of Object.keys(lock.modules).sort()) {
    const entry = lock.modules[name];
    const rel = archivePathOf(name, entry.version);
    const file = join(ctx.dir, rel);
    const have = fileSha(file);
    if (have === entry.sha256) continue;
    const about = { kind: 'replace', path: rel, name, version: entry.version };
    if (have !== null && !(await ask(ctx, `${notWritten(rel)}. Replace it with ${name} ${entry.version}?`, about))) {
      refused.push(rel);
      continue;
    }
    // The lockfile's URL passes the same host rule as an index's: refused unless it is on the scope's host.
    const bytes = await fetchArchive(hostOf(lock, name), name, entry, ctx.http);
    mkdirSync(join(ctx.dir, VENDOR_DIR), { recursive: true });
    writeAtomically(file, bytes);
    restored.push(name);
    ctx.change(`${have === null ? 'restored' : 'replaced'} ${name} ${entry.version}: ${rel}`);
  }
  const command = lock.modules[COMMAND_PACKAGE];
  if (command && !existsSync(join(ctx.dir, INSTALL_SCRIPT))) {
    const file = join(ctx.dir, archivePathOf(COMMAND_PACKAGE, command.version));
    if (fileSha(file) === command.sha256) await writeInstallScript(ctx, readFileSync(file));
  }
  if (refused.length > 0) {
    throw new ModulesError(`${refused.join(', ')}: not replaced, so the working copy still differs from ${LOCKFILE}`, 2);
  }
  if (restored.length === 0) ctx.note(`every module ${LOCKFILE} names is in place`);
  return { restored, changes: ctx.lines };
}

/**
 * Compares every vendored archive with the lockfile, and package.json's entry
 * for each module with its archive's path. Reads no network and needs no
 * credential.
 *
 * @param {Options} [options]
 * @returns {{ok: boolean, problems: string[]}}
 */
export function check(options) {
  const ctx = context(options);
  const lock = requireLock(ctx);
  const problems = [];
  const names = Object.keys(lock.modules).sort();
  for (const name of names) {
    const entry = lock.modules[name];
    const rel = archivePathOf(name, entry.version);
    const have = fileSha(join(ctx.dir, rel));
    if (have === null) problems.push(`${rel} is missing: ${LOCKFILE} names ${name} ${entry.version}`);
    else if (have !== entry.sha256) problems.push(`${rel} differs from ${LOCKFILE}: its sha256 is ${have}, ${entry.sha256} is recorded`);
    const dependency = dependencyOf(ctx.dir, name);
    if (dependency && dependency.spec !== `file:${rel}`) {
      problems.push(`package.json: ${dependency.section}.${name} is ${dependency.spec}, not file:${rel}`);
    }
  }
  for (const problem of problems) ctx.note(problem);
  if (problems.length === 0) ctx.note(`${names.length} module(s) match ${LOCKFILE}`);
  return { ok: problems.length === 0, problems };
}

/**
 * The absolute path of a module's vendored archive, from the lockfile. Reads no
 * network and needs no credential; an archive that is not there is an error.
 *
 * @param {Options} options
 * @param {string} name
 */
export function archivePath(options, name) {
  const ctx = context(options);
  splitName(name ?? '');
  const lock = requireLock(ctx);
  const entry = lock.modules[name];
  if (!entry) throw new ModulesError(`${LOCKFILE} names no module ${name}`, 2);
  const rel = archivePathOf(name, entry.version);
  const file = join(ctx.dir, rel);
  if (!existsSync(file)) throw new ModulesError(`${rel} is missing: run install`, 1);
  return file;
}
