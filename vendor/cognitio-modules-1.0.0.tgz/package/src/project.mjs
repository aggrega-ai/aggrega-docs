/**
 * project.mjs — the project's own files the command keeps in step with its
 * lockfile: `package.json`, and the package managers' lockfiles.
 *
 * READS and WRITES the project's `package.json`; RUNS `npm install` (and
 * `npx -y bun install` when the project keeps a `bun.lock`) through a runner
 * the caller may replace. It never touches a package.json entry other than the
 * module's own.
 */

import { spawn } from 'node:child_process';
import { existsSync, readFileSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';

import { ModulesError } from './errors.mjs';

const SECTIONS = ['dependencies', 'devDependencies', 'optionalDependencies'];

/** The npm command that refreshes `package-lock.json`. */
export const NPM_INSTALL = ['npm', ['install', '--no-audit', '--no-fund']];
/** The command that refreshes `bun.lock`. */
export const BUN_INSTALL = ['npx', ['-y', 'bun', 'install']];

/**
 * Runs a command in a directory with this process's standard output and error,
 * and resolves with its exit status (127 when it cannot be started). It runs
 * asynchronously, so a caller serving requests — a development server's admin
 * page — keeps answering while the package manager works.
 *
 * @param {string} command
 * @param {string[]} args
 * @param {{cwd: string}} options
 * @returns {Promise<number>}
 */
export function defaultRun(command, args, options) {
  return new Promise((resolve) => {
    const child = spawn(command, args, { cwd: options.cwd, stdio: ['ignore', 'inherit', 'inherit'] });
    child.on('error', () => resolve(127));
    child.on('close', (status) => resolve(status ?? 1));
  });
}

function indentOf(text) {
  const match = /^[ \t]*\{\s*?\n([ \t]+)"/.exec(text);
  return match ? match[1] : 2;
}

function readPackageJson(dir) {
  const file = join(dir, 'package.json');
  if (!existsSync(file)) return null;
  const text = readFileSync(file, 'utf8');
  let json;
  try {
    json = JSON.parse(text);
  } catch (err) {
    throw new ModulesError(`package.json is not JSON: ${err.message}`, 2);
  }
  if (!json || typeof json !== 'object' || Array.isArray(json)) throw new ModulesError('package.json is not an object', 2);
  return { file, text, json };
}

function writePackageJson(pkg) {
  const indent = indentOf(pkg.text);
  const text = `${JSON.stringify(pkg.json, null, indent)}${pkg.text.endsWith('\n') ? '\n' : ''}`;
  if (text === pkg.text) return false;
  writeFileSync(pkg.file, text);
  return true;
}

/** Inserts a key into an object at its sorted place among the keys already there, keeping theirs. */
function insertSorted(object, key, value) {
  const out = {};
  let placed = false;
  for (const [k, v] of Object.entries(object)) {
    if (!placed && key < k) {
      out[key] = value;
      placed = true;
    }
    out[k] = v;
  }
  if (!placed) out[key] = value;
  return out;
}

/** True when the project has a `package.json`. */
export function hasPackageJson(dir) {
  return existsSync(join(dir, 'package.json'));
}

/**
 * The spec package.json gives a package in any dependency section, or null.
 *
 * @param {string} dir
 * @param {string} name
 * @returns {{section: string, spec: string} | null}
 */
export function dependencyOf(dir, name) {
  const pkg = readPackageJson(dir);
  if (!pkg) return null;
  for (const section of SECTIONS) {
    const deps = pkg.json[section];
    if (deps && typeof deps === 'object' && typeof deps[name] === 'string') return { section, spec: deps[name] };
  }
  return null;
}

/**
 * Applies the dependency entries of a set of changes to package.json: a module
 * set to an archive keeps the section it is in, or goes to `devDependencies`
 * (when `dev`) or `dependencies`; a module removed leaves every section. Returns
 * a line per entry changed, empty when package.json is absent or unchanged.
 *
 * @param {string} dir
 * @param {{name: string, spec: string | null, dev: boolean}[]} entries `spec` null removes
 * @returns {string[]}
 */
export function applyDependencies(dir, entries) {
  const pkg = readPackageJson(dir);
  if (!pkg) return [];
  const lines = [];
  for (const { name, spec, dev } of entries) {
    const present = SECTIONS.filter((s) => pkg.json[s] && typeof pkg.json[s] === 'object' && name in pkg.json[s]);
    if (spec === null) {
      for (const section of present) {
        delete pkg.json[section][name];
        lines.push(`package.json: removed ${section}.${name}`);
      }
      continue;
    }
    if (present.length > 0) {
      for (const section of present) {
        if (pkg.json[section][name] !== spec) {
          lines.push(`package.json: ${section}.${name} ${pkg.json[section][name]} → ${spec}`);
          pkg.json[section][name] = spec;
        }
      }
      continue;
    }
    const section = dev ? 'devDependencies' : 'dependencies';
    pkg.json[section] = insertSorted(pkg.json[section] ?? {}, name, spec);
    lines.push(`package.json: added ${section}.${name} ${spec}`);
  }
  if (lines.length > 0) writePackageJson(pkg);
  return lines;
}

/**
 * Refreshes the project's package-manager lockfiles after its dependencies
 * changed: `npm install`, then `npx -y bun install` when a `bun.lock` is
 * there. Returns a line per command run; a command that fails is a thrown error
 * saying what is already written.
 *
 * @param {string} dir
 * @param {(command: string, args: string[], options: {cwd: string}) => number | Promise<number>} run
 * @returns {Promise<string[]>}
 */
export async function refreshPackageLocks(dir, run) {
  const commands = [NPM_INSTALL];
  if (existsSync(join(dir, 'bun.lock'))) commands.push(BUN_INSTALL);
  const lines = [];
  for (const [command, args] of commands) {
    const shown = [command, ...args].join(' ');
    const status = await run(command, args, { cwd: dir });
    if (status !== 0) {
      throw new ModulesError(
        `${shown} exited ${status}; the vendored archives, the lockfile and package.json are already written: fix the cause and run ${shown} again`,
        1,
      );
    }
    lines.push(`ran ${shown}`);
  }
  return lines;
}
