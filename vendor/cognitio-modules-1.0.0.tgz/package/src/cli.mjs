/**
 * cli.mjs — the `cognitio-modules` command line over the library.
 *
 * READS the arguments and, in a terminal, the developer's answers; WRITES the
 * commands' report to standard output and every question and error to standard
 * error, so `path` prints the path alone. Everything else is the library's
 * (`commands.mjs`).
 *
 * Exit status: 0 done; 1 the host, an archive or the working copy is not as
 * expected (`check` finding a difference included); 2 a usage error or a
 * refusal.
 */

import { readFileSync } from 'node:fs';
import { relative, isAbsolute } from 'node:path';
import { createInterface } from 'node:readline/promises';

import { add, archivePath, check, init, install, list, remove, upgrade } from './commands.mjs';
import { ModulesError } from './errors.mjs';

export const USAGE = `usage: cognitio-modules [--cwd <dir>] [--yes] [--dev] <command> [<argument>]

Commands:
  init                          start the project: the lockfile, the command itself, install.sh
  add <package>[@<version>]     vendor a module, the newest version when none is named
  remove <package>              remove a module
  upgrade                       propose each newer version, module by module; --yes accepts all
  list                          the modules, their versions and the newest available
  install                       put back any vendored archive the working copy lacks
  path <package>                the vendored archive's path, for a workflow (no credential)
  check                         compare the vendored archives with the lockfile (no credential)

Run with no command in a terminal, it asks what to do.

Options:
  --cwd <dir>   run against the project in <dir> instead of the current directory
  --yes, -y     accept every upgrade upgrade proposes
  --dev         a module new to package.json goes to devDependencies
  --help, -h    this text
  --version     the command's version

The credential is read from ~/.netrc: machine <host> login <username> password <password>.`;

const COMMANDS = ['init', 'add', 'remove', 'upgrade', 'list', 'install', 'path', 'check'];
const TAKES_ARGUMENT = new Set(['add', 'remove', 'path']);

function version() {
  return JSON.parse(readFileSync(new URL('../package.json', import.meta.url), 'utf8')).version;
}

/**
 * The options and the command of an argument list, or a thrown usage error.
 *
 * @param {string[]} argv
 */
export function parseArgs(argv) {
  const parsed = { cwd: undefined, yes: false, dev: false, help: false, version: false, command: undefined, argument: undefined };
  const positional = [];
  for (let i = 0; i < argv.length; i++) {
    const arg = argv[i];
    if (arg === '--cwd') {
      if (argv[i + 1] === undefined) throw new ModulesError('--cwd needs a directory', 2);
      parsed.cwd = argv[++i];
    } else if (arg.startsWith('--cwd=')) parsed.cwd = arg.slice(6);
    else if (arg === '--yes' || arg === '-y') parsed.yes = true;
    else if (arg === '--dev') parsed.dev = true;
    else if (arg === '--help' || arg === '-h') parsed.help = true;
    else if (arg === '--version') parsed.version = true;
    else if (arg.startsWith('-')) throw new ModulesError(`${arg} is not an option\n\n${USAGE}`, 2);
    else positional.push(arg);
  }
  if (positional.length > 0) {
    const [command, ...rest] = positional;
    if (command === 'help') {
      parsed.help = true;
      return parsed;
    }
    if (!COMMANDS.includes(command)) throw new ModulesError(`${command} is not a command\n\n${USAGE}`, 2);
    const wanted = TAKES_ARGUMENT.has(command) ? 1 : 0;
    if (rest.length !== wanted) {
      throw new ModulesError(wanted ? `${command} takes one package\n\n${USAGE}` : `${command} takes no argument\n\n${USAGE}`, 2);
    }
    parsed.command = command;
    parsed.argument = rest[0];
  }
  return parsed;
}

/** A yes/no question and a free question in a terminal, asked on standard error. */
function terminal(stdin, stderr) {
  const ask = async (question) => {
    const rl = createInterface({ input: stdin, output: stderr, terminal: true });
    try {
      return (await rl.question(question)).trim();
    } finally {
      rl.close();
    }
  };
  return {
    ask,
    confirm: async (question) => /^y(es)?$/i.test(await ask(`${question} [y/N] `)),
  };
}

async function choose(io) {
  const menu = [
    ['list', 'list the modules and the newest versions'],
    ['add', 'add a module'],
    ['upgrade', 'upgrade modules'],
    ['remove', 'remove a module'],
    ['install', 'put back missing archives'],
    ['check', 'check the archives against the lockfile'],
    ['init', 'start this project'],
  ];
  io.err('What do you want to do?');
  menu.forEach(([command, text], i) => io.err(`  ${i + 1}) ${command.padEnd(8)} ${text}`));
  const answer = await io.ask('Number: ');
  const picked = menu[Number(answer) - 1] ?? menu.find(([command]) => command === answer);
  if (!picked) throw new ModulesError(`"${answer}" is not one of the choices`, 2);
  const [command] = picked;
  let argument;
  if (TAKES_ARGUMENT.has(command)) {
    argument = await io.ask(command === 'add' ? 'Package (@<scope>/<module>[@<version>]): ' : 'Package (@<scope>/<module>): ');
  }
  return { command, argument };
}

/**
 * Runs the command line and returns its exit status. `overrides` replace the
 * process's streams and the library's defaults; the tests use them.
 *
 * @param {string[]} argv
 * @param {object} [overrides]
 * @param {(line: string) => void} [overrides.out]
 * @param {(line: string) => void} [overrides.err]
 * @param {((question: string) => boolean | Promise<boolean>) | null} [overrides.confirm]
 * @param {((question: string) => string | Promise<string>) | null} [overrides.ask]
 * @param {string} [overrides.netrc]
 * @param {typeof fetch} [overrides.fetch]
 * @param {(command: string, args: string[], options: {cwd: string}) => number | Promise<number>} [overrides.run]
 * @param {string} [overrides.processCwd] the directory a printed path is relative to
 * @returns {Promise<number>}
 */
export async function main(argv, overrides = {}) {
  const out = overrides.out ?? ((line) => process.stdout.write(`${line}\n`));
  const err = overrides.err ?? ((line) => process.stderr.write(`${line}\n`));
  const interactive = process.stdin.isTTY ? terminal(process.stdin, process.stderr) : null;
  const io = {
    out,
    err,
    confirm: 'confirm' in overrides ? overrides.confirm : interactive?.confirm ?? null,
    ask: 'ask' in overrides ? overrides.ask : interactive?.ask ?? null,
  };
  try {
    const args = parseArgs(argv);
    if (args.help) {
      out(USAGE);
      return 0;
    }
    if (args.version) {
      out(version());
      return 0;
    }
    let { command, argument } = args;
    if (command === undefined) {
      if (!io.ask) {
        err(USAGE);
        return 2;
      }
      ({ command, argument } = await choose(io));
    }
    const options = {
      cwd: args.cwd,
      yes: args.yes,
      dev: args.dev,
      out,
      confirm: io.confirm ?? undefined,
      netrc: overrides.netrc,
      fetch: overrides.fetch,
      run: overrides.run,
    };
    let ok = true;
    let wrote = false;
    switch (command) {
      case 'init':
        wrote = (await init(options)).changes.length > 0;
        break;
      case 'add':
        wrote = (await add(options, argument)).changes.length > 0;
        break;
      case 'remove':
        wrote = (await remove(options, argument)).changes.length > 0;
        break;
      case 'upgrade':
        wrote = (await upgrade(options)).changes.length > 0;
        break;
      case 'list':
        ok = (await list(options)).ok;
        break;
      case 'install':
        wrote = (await install(options)).changes.length > 0;
        break;
      case 'check':
        ok = check(options).ok;
        break;
      case 'path': {
        const file = archivePath(options, argument);
        const shown = relative(overrides.processCwd ?? process.cwd(), file);
        // A bare `vendor/x.tgz` is read by npm as a GitHub repository; `./` makes it a path.
        out(isAbsolute(shown) || shown.startsWith('../') ? shown : `./${shown}`);
        break;
      }
      default:
        throw new ModulesError(`${command} is not a command`, 2);
    }
    if (wrote) out('Nothing is committed: review the change with git diff, and commit it.');
    return ok ? 0 : 1;
  } catch (error) {
    if (error instanceof ModulesError) {
      err(`cognitio-modules: ${error.message}`);
      return error.exitCode;
    }
    throw error;
  }
}
