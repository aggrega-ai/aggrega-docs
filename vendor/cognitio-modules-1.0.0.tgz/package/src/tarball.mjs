/**
 * tarball.mjs — reads one file out of a module's archive.
 *
 * READS and WRITES nothing but the bytes it is given. An archive is a gzipped
 * tar file as `npm pack` writes it, every path under `package/`. Only the ustar
 * header fields and a pax extended header's `path` are read; that is all a
 * packed archive uses, with the GNU long-name header a system `tar` may write.
 */

import { gunzipSync } from 'node:zlib';

import { ModulesError } from './errors.mjs';

function field(block, start, length) {
  const end = block.indexOf(0, start);
  return block.toString('utf8', start, end === -1 || end > start + length ? start + length : end);
}

function paxPath(body) {
  let i = 0;
  let path;
  while (i < body.length) {
    const space = body.indexOf(0x20, i);
    if (space === -1) break;
    const length = Number(body.toString('utf8', i, space));
    if (!Number.isInteger(length) || length <= 0) break;
    const record = body.toString('utf8', space + 1, i + length - 1);
    if (record.startsWith('path=')) path = record.slice(5);
    i += length;
  }
  return path;
}

/**
 * The bytes of the file at `path` in a gzipped tar archive, or null when the
 * archive holds no such file.
 *
 * @param {Buffer} archive
 * @param {string} path such as `package/package.json`
 * @returns {Buffer | null}
 */
export function readArchiveFile(archive, path) {
  let tar;
  try {
    tar = gunzipSync(archive);
  } catch {
    throw new ModulesError('the archive is not gzipped', 1);
  }
  let offset = 0;
  let nextPath;
  while (offset + 512 <= tar.length) {
    const header = tar.subarray(offset, offset + 512);
    if (header.every((b) => b === 0)) break;
    const size = parseInt(field(header, 124, 12).trim() || '0', 8);
    if (!Number.isInteger(size) || size < 0) throw new ModulesError('the archive is not a tar archive', 1);
    const type = String.fromCharCode(header[156] || 0x30);
    const prefix = field(header, 345, 155);
    const name = nextPath ?? (prefix ? `${prefix}/${field(header, 0, 100)}` : field(header, 0, 100));
    const body = tar.subarray(offset + 512, offset + 512 + size);
    offset += 512 + Math.ceil(size / 512) * 512;
    if (type === 'x') {
      nextPath = paxPath(body);
      continue;
    }
    if (type === 'L') {
      nextPath = body.toString('utf8').replace(/\0+$/, '');
      continue;
    }
    nextPath = undefined;
    if (type === 'g') continue;
    if (type === '0' && name === path) return Buffer.from(body);
  }
  return null;
}

/**
 * The `name` and `version` of an archive's `package/package.json`, or a thrown
 * error when it holds none.
 *
 * @param {Buffer} archive
 * @returns {{name: string, version: string}}
 */
export function manifestOf(archive) {
  const bytes = readArchiveFile(archive, 'package/package.json');
  if (bytes === null) throw new ModulesError('the archive holds no package/package.json', 1);
  let manifest;
  try {
    manifest = JSON.parse(bytes.toString('utf8'));
  } catch {
    throw new ModulesError("the archive's package/package.json is not JSON", 1);
  }
  return { name: manifest.name, version: manifest.version };
}
