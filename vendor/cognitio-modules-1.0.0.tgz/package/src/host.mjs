/**
 * host.mjs — what the command reads from a module's host: its index and its
 * archives.
 *
 * READS `<host>/<module>/index.json` and the archive URLs an index or the
 * lockfile names, with the credential `~/.netrc` holds for the host; WRITES
 * nothing. A 401, 403 or 404 is reported in words that say what to do about it.
 *
 * WHERE THE CREDENTIAL MAY GO. Every request the library makes goes through
 * `download`, and `download` first asks `isSendable`, the one place the rule is
 * decided: a URL is fetched only when it is on the host the lockfile maps the
 * package's scope to (the same scheme, host name and port) and over https —
 * plain http is allowed to a loopback host alone (127.0.0.1, ::1, localhost),
 * which is what the tests' stand-in host is. Any other URL, whether an index
 * named it or the lockfile, is refused before anything is sent. A redirect is
 * never followed, so no answer can move a request to another host either.
 */

import { createHash } from 'node:crypto';

import { ModulesError } from './errors.mjs';
import { SEMVER, SHA256, splitName } from './lockfile.mjs';
import { authorizationFor, defaultNetrcPath } from './netrc.mjs';
import { manifestOf } from './tarball.mjs';

const TIMEOUT_MS = 120_000;

/** The hex SHA-256 of some bytes. */
export function sha256(bytes) {
  return createHash('sha256').update(bytes).digest('hex');
}

/**
 * The message for a status that is not 200, in the words a developer acts on.
 *
 * @param {string} url
 * @param {number} status
 * @param {string} subject what the URL serves, such as `l10n 1.2.0` or `l10n`
 * @param {string} netrcShown how the netrc file is named in the message
 */
export function statusMessage(url, status, subject, netrcShown = '~/.netrc') {
  const parsed = new URL(url);
  const publication = parsed.pathname.split('/')[1] ?? '';
  switch (status) {
    case 401:
      return `${url} answered 401: no credential for ${parsed.hostname} in ${netrcShown}, or one the host does not know`;
    case 403:
      return `${url} answered 403: the credential in ${netrcShown} is not allowed the publication ${publication}`;
    case 404:
      return `${url} answered 404: ${subject} is not published`;
    default:
      return `${url} answered ${status}`;
  }
}

/** The host names plain http may be sent to: the loopback interface alone. */
const LOOPBACK = new Set(['127.0.0.1', '[::1]', 'localhost']);

/**
 * True when a URL may be requested, and so receive the credential: it is on
 * `host` — the same scheme, host name and port — carries no user name or
 * password of its own, and is https, or plain http to a loopback host. Pure.
 *
 * @param {string} url
 * @param {string} host the host the lockfile maps the package's scope to, such as `https://tooling.cognitio.it`
 */
export function isSendable(url, host) {
  let target;
  let home;
  try {
    target = new URL(url);
    home = new URL(host);
  } catch {
    return false;
  }
  if (target.origin !== home.origin || target.username || target.password) return false;
  return target.protocol === 'https:' || (target.protocol === 'http:' && LOOPBACK.has(target.hostname));
}

/**
 * The message for a URL `isSendable` refuses.
 *
 * @param {string} url
 * @param {string} scope such as `@cognitio`
 * @param {string} host the host the lockfile maps `scope` to
 */
export function refusalMessage(url, scope, host) {
  return `${url} is refused and nothing is sent to it: the credential goes over https alone (plain http to a loopback host only), and only to ${host}, the host ${scope} maps to`;
}

/**
 * The bytes at a URL, fetched with the credential for its host, or a thrown
 * error naming the status. A URL `isSendable` refuses is a thrown error before
 * anything is sent.
 *
 * @param {string} url
 * @param {string} subject
 * @param {{scope: string, host: string}} to the package's scope and the host the lockfile maps it to
 * @param {{fetch?: typeof fetch, netrc?: string}} options
 */
export async function download(url, subject, to, options = {}) {
  if (!isSendable(url, to.host)) throw new ModulesError(refusalMessage(url, to.scope, to.host), 1);
  const fetchImpl = options.fetch ?? globalThis.fetch;
  const netrc = options.netrc ?? defaultNetrcPath();
  const netrcShown = netrc === defaultNetrcPath() ? '~/.netrc' : netrc;
  const headers = {};
  const authorization = authorizationFor(new URL(url).hostname, netrc);
  if (authorization) headers.authorization = authorization;
  let res;
  try {
    res = await fetchImpl(url, { headers, redirect: 'manual', signal: AbortSignal.timeout(TIMEOUT_MS) });
  } catch (err) {
    throw new ModulesError(`could not reach ${url}: ${(err && err.cause && err.cause.message) || (err && err.message) || err}`, 1);
  }
  if (res.status !== 200) throw new ModulesError(statusMessage(url, res.status, subject, netrcShown), 1);
  return Buffer.from(await res.arrayBuffer());
}

/**
 * A module's index from its host: the package name and every published
 * version, newest last, each with its archive's URL and sha256.
 *
 * @param {string} host such as `https://tooling.cognitio.it`
 * @param {string} name the package, such as `@cognitio/l10n`
 * @param {{fetch?: typeof fetch, netrc?: string}} [options]
 * @returns {Promise<{name: string, versions: {version: string, sha256: string, url: string}[]}>}
 */
export async function fetchIndex(host, name, options = {}) {
  const { scope, module } = splitName(name);
  const url = `${host}/${module}/index.json`;
  const bytes = await download(url, module, { scope, host }, options);
  let index;
  try {
    index = JSON.parse(bytes.toString('utf8'));
  } catch {
    throw new ModulesError(`${url} is not JSON`, 1);
  }
  const ok =
    index &&
    typeof index.name === 'string' &&
    Array.isArray(index.versions) &&
    index.versions.length > 0 &&
    index.versions.every(
      (e) => e && typeof e.version === 'string' && SEMVER.test(e.version) && typeof e.sha256 === 'string'
        && SHA256.test(e.sha256) && typeof e.url === 'string' && /^https?:\/\//.test(e.url),
    );
  if (!ok) throw new ModulesError(`${url} is not an index: {"name", "versions": [{"version", "sha256", "url"}]}`, 1);
  if (index.name !== name) {
    throw new ModulesError(`${url} is the index of ${index.name}, not of ${name}`, 1);
  }
  return { name: index.name, versions: index.versions.map(({ version, sha256: digest, url: at }) => ({ version, sha256: digest, url: at })) };
}

/**
 * An archive, downloaded and checked: its URL must be on the scope's host (see
 * `isSendable`), its sha256 must be the one given and its `package/package.json`
 * must name the package and the version. Nothing is written; a refusal or a
 * mismatch is a thrown error.
 *
 * @param {string} host the host the lockfile maps the package's scope to
 * @param {string} name
 * @param {{version: string, url: string, sha256: string}} entry from an index, or from the lockfile
 * @param {{fetch?: typeof fetch, netrc?: string}} [options]
 */
export async function fetchArchive(host, name, entry, options = {}) {
  const { scope, module } = splitName(name);
  const bytes = await download(entry.url, `${module} ${entry.version}`, { scope, host }, options);
  const digest = sha256(bytes);
  if (digest !== entry.sha256) {
    throw new ModulesError(
      `${entry.url} has sha256 ${digest}, not ${entry.sha256} as recorded for ${name} ${entry.version}: the archive is refused and nothing is written`,
      1,
    );
  }
  const manifest = manifestOf(bytes);
  if (manifest.name !== name || manifest.version !== entry.version) {
    throw new ModulesError(
      `${entry.url} holds ${manifest.name} ${manifest.version}, not ${name} ${entry.version}: the archive is refused and nothing is written`,
      1,
    );
  }
  return bytes;
}
