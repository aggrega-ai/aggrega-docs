/**
 * lockfile.mjs — the project's lockfile, `cognitio-modules.json`.
 *
 * READS and WRITES only the lockfile at a project's root. Parsing refuses any
 * shape but the one below, so a hand edit with a typo stops the command instead
 * of being half understood. Formatting is canonical: keys in a fixed order, the
 * scopes and the modules sorted by name, two-space indentation and a final
 * newline, so the same set of modules always gives the same bytes and a diff
 * shows only what changed.
 *
 *   {
 *     "scopes": { "@cognitio": "https://tooling.cognitio.it" },
 *     "modules": {
 *       "@cognitio/l10n": { "version": "1.2.0", "url": "<archive URL>", "sha256": "<hex>" }
 *     }
 *   }
 */

import { existsSync, readFileSync, renameSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';

import { ModulesError } from './errors.mjs';

/** The lockfile's name, at the project's root. */
export const LOCKFILE = 'cognitio-modules.json';

/** The directory, under the project's root, that holds the vendored archives. */
export const VENDOR_DIR = 'vendor';

/** The package of the command itself. */
export const COMMAND_PACKAGE = '@cognitio/modules';

/** The scope → host map a new lockfile starts with. */
export const DEFAULT_SCOPES = Object.freeze({ '@cognitio': 'https://tooling.cognitio.it' });

/** A scope's or a module's name: lowercase letters, digits and hyphens. */
const NAME_PART = /^[a-z0-9][a-z0-9-]*$/;
/**
 * A version: X.Y.Z with an optional pre-release. A version becomes part of a
 * file name under `vendor/`, so nothing else is accepted from a lockfile or an
 * index.
 */
export const SEMVER = /^(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)(?:-([0-9A-Za-z-]+(?:\.[0-9A-Za-z-]+)*))?$/;
export const SHA256 = /^[0-9a-f]{64}$/;

/**
 * The scope and the module of a package name `@<scope>/<module>`, or a thrown
 * usage error naming what is wrong.
 *
 * @param {string} name
 * @returns {{scope: string, module: string}}
 */
export function splitName(name) {
  const match = /^@([^/]+)\/([^/]+)$/.exec(name);
  if (!match || !NAME_PART.test(match[1]) || !NAME_PART.test(match[2])) {
    throw new ModulesError(
      `"${name}" is not a package name: @<scope>/<module>, each lowercase letters, digits and hyphens`,
      2,
    );
  }
  return { scope: `@${match[1]}`, module: match[2] };
}

/**
 * The vendored archive's path, relative to the project's root:
 * `vendor/<scope>-<module>-<version>.tgz`.
 *
 * @param {string} name
 * @param {string} version
 */
export function archivePathOf(name, version) {
  const { scope, module } = splitName(name);
  if (!SEMVER.test(version)) throw new ModulesError(`"${version}" is not a version: X.Y.Z`, 2);
  return `${VENDOR_DIR}/${scope.slice(1)}-${module}-${version}.tgz`;
}

function isHostUrl(value) {
  if (typeof value !== 'string') return false;
  try {
    const url = new URL(value);
    return (url.protocol === 'https:' || url.protocol === 'http:') && url.pathname === '/' && !url.search && !url.hash
      && !url.username && !url.password && !value.endsWith('/');
  } catch {
    return false;
  }
}

function isArchiveUrl(value) {
  if (typeof value !== 'string') return false;
  try {
    const url = new URL(value);
    return (url.protocol === 'https:' || url.protocol === 'http:') && !url.username && !url.password;
  } catch {
    return false;
  }
}

/**
 * The lockfile a text holds, or a thrown error naming the first thing that is
 * not as the format above states.
 *
 * @param {string} text
 * @param {string} [where] the file's name, for the message
 * @returns {{scopes: Record<string, string>, modules: Record<string, {version: string, url: string, sha256: string}>}}
 */
export function parseLockfile(text, where = LOCKFILE) {
  let raw;
  try {
    raw = JSON.parse(text);
  } catch (err) {
    throw new ModulesError(`${where} is not JSON: ${err.message}`, 2);
  }
  const fail = (message) => {
    throw new ModulesError(`${where}: ${message}`, 2);
  };
  if (!raw || typeof raw !== 'object' || Array.isArray(raw)) fail('it is not an object');
  for (const key of Object.keys(raw)) {
    if (key !== 'scopes' && key !== 'modules') fail(`"${key}" is not a key of the lockfile: it holds "scopes" and "modules"`);
  }
  const scopes = raw.scopes ?? {};
  const modules = raw.modules ?? {};
  if (typeof scopes !== 'object' || Array.isArray(scopes) || scopes === null) fail('"scopes" is not an object');
  if (typeof modules !== 'object' || Array.isArray(modules) || modules === null) fail('"modules" is not an object');
  const out = { scopes: {}, modules: {} };
  for (const [scope, host] of Object.entries(scopes)) {
    if (!/^@[a-z0-9][a-z0-9-]*$/.test(scope)) fail(`"${scope}" is not a scope: @ and lowercase letters, digits and hyphens`);
    if (!isHostUrl(host)) fail(`the host of ${scope} is not a URL of a host alone, such as "https://tooling.cognitio.it"`);
    out.scopes[scope] = host;
  }
  for (const [name, entry] of Object.entries(modules)) {
    try {
      splitName(name);
    } catch (err) {
      fail(err.message);
    }
    if (!entry || typeof entry !== 'object' || Array.isArray(entry)) fail(`${name} is not an object`);
    for (const key of Object.keys(entry)) {
      if (!['version', 'url', 'sha256'].includes(key)) fail(`${name}: "${key}" is not a key of a module: it holds "version", "url" and "sha256"`);
    }
    if (typeof entry.version !== 'string' || !SEMVER.test(entry.version)) fail(`${name}: "version" is not a version: X.Y.Z`);
    if (!isArchiveUrl(entry.url)) fail(`${name}: "url" is not an http or https URL`);
    if (typeof entry.sha256 !== 'string' || !SHA256.test(entry.sha256)) fail(`${name}: "sha256" is not 64 lowercase hex digits`);
    out.modules[name] = { version: entry.version, url: entry.url, sha256: entry.sha256 };
  }
  return out;
}

const byName = (a, b) => (a < b ? -1 : a > b ? 1 : 0);

/**
 * The lockfile's canonical text: fixed key order, scopes and modules sorted by
 * name, two-space indentation, a final newline.
 *
 * @param {{scopes: Record<string, string>, modules: Record<string, {version: string, url: string, sha256: string}>}} lock
 */
export function formatLockfile(lock) {
  const scopes = {};
  for (const scope of Object.keys(lock.scopes).sort(byName)) scopes[scope] = lock.scopes[scope];
  const modules = {};
  for (const name of Object.keys(lock.modules).sort(byName)) {
    const { version, url, sha256 } = lock.modules[name];
    modules[name] = { version, url, sha256 };
  }
  return `${JSON.stringify({ scopes, modules }, null, 2)}\n`;
}

/**
 * The project's lockfile, or null when it has none.
 *
 * @param {string} dir the project's root
 */
export function readLockfile(dir) {
  const file = join(dir, LOCKFILE);
  if (!existsSync(file)) return null;
  return parseLockfile(readFileSync(file, 'utf8'));
}

/**
 * Writes the lockfile in its canonical form, through a temporary file renamed
 * into place. True when its bytes changed.
 *
 * @param {string} dir
 * @param {Parameters<typeof formatLockfile>[0]} lock
 */
export function writeLockfile(dir, lock) {
  const file = join(dir, LOCKFILE);
  const text = formatLockfile(lock);
  if (existsSync(file) && readFileSync(file, 'utf8') === text) return false;
  const temporary = `${file}.${process.pid}.tmp`;
  writeFileSync(temporary, text);
  renameSync(temporary, file);
  return true;
}

/**
 * The host a package's scope maps to in the lockfile, or a thrown error naming
 * the entry to add.
 *
 * @param {{scopes: Record<string, string>}} lock
 * @param {string} name
 */
export function hostOf(lock, name) {
  const { scope } = splitName(name);
  const host = lock.scopes[scope];
  if (!host) {
    throw new ModulesError(
      `${LOCKFILE} maps no host to the scope ${scope}: add "${scope}": "https://<host>" under "scopes"`,
      2,
    );
  }
  return host;
}
