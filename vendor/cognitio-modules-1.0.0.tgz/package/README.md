# `@cognitio/modules` — add, remove and upgrade a project's site modules

A project keeps every site module it uses in its own repository, at a pinned
version, so a clone of it installs with no credential. `cognitio-modules` is
the command that chooses those modules: it adds, removes and upgrades them on a
developer's machine, with the developer's consumer credential, and records
exactly what is vendored in a lockfile. Nothing upgrades on its own, and
nothing is committed: the developer reviews the change and commits it.

The package needs Node.js 20 or later and nothing outside Node's own library.
Its entry point is a short POSIX script, `install.sh`, which also needs `curl`
and `tar`. [`CHANGELOG.md`](CHANGELOG.md) lists what each version holds.

## Getting the command

With a consumer credential for the tooling host in `~/.netrc`:

```text
machine tooling.cognitio.it login <username> password <password>
```

a project starts from one line, run at its root:

```sh
curl --netrc -fsSL https://tooling.cognitio.it/modules/install.sh -o install.sh && sh install.sh init
```

`init` writes the lockfile, `cognitio-modules.json`, vendors the newest
`@cognitio/modules` itself, and keeps `install.sh`. From then on every command
is `sh install.sh <command>`: the script runs the vendored copy of the command,
so it needs no credential to start, and `upgrade` upgrades the command like any
other module. Commit `install.sh`, `cognitio-modules.json` and `vendor/`.

When the vendored copy is missing, `install.sh` downloads the version the
lockfile names and checks its sha256 against the lockfile before running it; with
no lockfile, or one naming no copy, it downloads the newest the host's index
lists and checks it against the index.

## The commands

| Command | What it does | Credential |
|---|---|---|
| `init` | Starts the project: the lockfile, the command itself, `install.sh`. A project already started is left as it is. | yes |
| `add <package>[@<version>]` | Vendors a module, at the newest version when none is named; a module already vendored moves to that version. | yes |
| `remove <package>` | Removes a module's archive, its lockfile entry and its `package.json` entry. | no |
| `upgrade` | Reads every module's index, lists each module with a newer version (installed → newest) and asks, module by module; `--yes` accepts every one. | yes |
| `list` | Each module, its vendored version and the newest its index lists. | yes |
| `install` | Puts back any vendored archive the lockfile names and the working copy lacks, from the URL the lockfile records. | yes |
| `path <package>` | Prints the vendored archive's path, from the lockfile, for a workflow. | no |
| `check` | Compares every vendored archive with the lockfile, and each module's `package.json` entry with its archive's path; exits 1 on any difference. | no |

Run with no command in a terminal, `sh install.sh` asks what to do. Every
command that changes a file prints each file it changed.

Options, before or after the command:

- `--cwd <dir>` runs the command against the project in `<dir>`. From a
  repository whose sub-projects keep modules of their own, a developer manages
  each one from the root: `sh install.sh --cwd docs init`, then
  `sh install.sh --cwd docs add @cognitio/l10n`. Each sub-project has its own
  lockfile, `vendor/` and `install.sh`.
- `--yes`, `-y` accepts every upgrade `upgrade` proposes. With neither a terminal
  nor `--yes`, `upgrade` lists what it would propose and changes nothing.
- `--dev` puts a module new to `package.json` in `devDependencies`.
- `--help`, `--version`.

Exit status: 0 done; 1 the host, an archive or the working copy is not as
expected; 2 a usage error, or a change refused because it needs the developer's
yes.

## What lands in the project

**Each module is vendored as its published archive**, byte for byte, at
`vendor/<scope>-<module>-<version>.tgz` — `@cognitio/l10n` 1.2.0 is
`vendor/cognitio-l10n-1.2.0.tgz` — and the archive of the version before is
removed.

**A project with a `package.json`** depends on the archive:

```json
"devDependencies": { "@cognitio/l10n": "file:vendor/cognitio-l10n-1.2.0.tgz" }
```

An entry already in `dependencies` or `devDependencies` stays where it is; a new
one goes to `dependencies`, or to `devDependencies` with `--dev` (the command
itself always goes there). After `add`, `remove` or `upgrade` the command runs
`npm install --no-audit --no-fund`, so `package-lock.json` records the archive
and its sha512 integrity, and also `npx -y bun install` when the project keeps a
`bun.lock`, so every lockfile the project keeps agrees. npm then installs no
bytes but the recorded ones: `npm ci` refuses an archive that has changed,
unless its cache already holds the recorded bytes, which it installs instead.

**A project with no `package.json`** gets the archive alone, and its workflow
installs it from the path the lockfile names, with no credential and no version
written in the workflow:

```sh
npm install --no-save --no-audit --no-fund "$(sh install.sh path @cognitio/l10n)"
```

`path` prints a path starting with `./` (or `../`), which npm reads as a file;
a bare `vendor/…` would be read as a GitHub repository.

**A project's CI checks the working copy** with no credential:

```sh
sh install.sh check
```

## The lockfile

`cognitio-modules.json`, at the project's root:

```json
{
  "scopes": {
    "@cognitio": "https://tooling.cognitio.it"
  },
  "modules": {
    "@cognitio/l10n": {
      "version": "1.2.0",
      "url": "https://tooling.cognitio.it/l10n/archives/l10n-1.2.0.tgz",
      "sha256": "<the archive's sha256, as its index states it>"
    },
    "@cognitio/modules": {
      "version": "1.0.0",
      "url": "https://tooling.cognitio.it/modules/archives/modules-1.0.0.tgz",
      "sha256": "<hex>"
    }
  }
}
```

- `scopes` maps each package scope to the host that serves it. A module
  `@<scope>/<module>` is read from `<host>/<module>/index.json`. A customer's own
  scope maps to its host the same way: add `"@<customer>": "https://<host>"`.
- `modules` holds, per module, its vendored version, its archive's URL and the
  archive's sha256, as the module's index states them.

The file is written in one canonical form: these keys in this order, scopes and
modules sorted by name, two-space indentation and a final newline. The same set
of modules always gives the same bytes, so a diff shows only what changed. Every
command refuses a lockfile that is not this shape, naming the first thing that
is not.

## Credential and integrity

- The credential is read from `~/.netrc` (`machine <host> login … password …`, or
  a `default` entry) and never printed, logged or written. It is sent as Basic
  authentication over https alone, and only to the host the lockfile maps the
  package's scope to (`@cognitio` → `https://tooling.cognitio.it`). Every URL the
  command would request — an index's, an archive URL an index names, an archive
  URL the lockfile records — must be on that host, with the same scheme and port;
  any other, and any plain-http URL, is refused before anything is sent:

  ```text
  cognitio-modules: https://elsewhere.example/l10n/archives/l10n-1.2.0.tgz is refused and nothing is sent to it: the credential goes over https alone (plain http to a loopback host only), and only to https://tooling.cognitio.it, the host @cognitio maps to
  ```

  Plain http is allowed to a loopback host alone (127.0.0.1, ::1, localhost), so
  a stand-in host on the developer's own machine can be used for tests. A redirect
  is never followed. `install.sh` holds to the same rule before it runs `curl`.
- A 401 means `~/.netrc` holds no credential for the host, or one it does not
  know; a 403, that the credential is not allowed the publication; a 404, that the
  module or the version is not published. Each is reported in those words, with
  the URL.
- An archive is written only when its sha256 is the one its index records (for
  `install`, the one the lockfile records) and its `package/package.json` names
  the package and the version. `upgrade` downloads and checks every accepted
  archive before it writes anything, so one refused archive leaves the project as
  it was.
- A file at a path the command would replace or delete, whose bytes are not the
  ones the lockfile records, was not written by the command: it is replaced or
  deleted only when the developer answers yes in a terminal. `--yes` does not
  answer that question. `install` asks it for an archive that has changed, and
  `check` then passes again.
- `install.sh` carries a line saying the command wrote it; the command replaces
  an `install.sh` carrying that line when it upgrades itself, and asks before
  replacing one without it.

## The library

The commands are functions of the package, so a tool such as a site's local
admin page lists, adds, removes and upgrades modules through the same code:

```js
import { add, check, init, install, list, remove, upgrade } from '@cognitio/modules';

const { modules } = await list({ cwd: '/path/to/project' });
await add({ cwd: '/path/to/project', out: console.log }, '@cognitio/l10n@1.2.0');
```

Every function takes one options object — `cwd`, `yes`, `dev`, `netrc` (the
netrc file, `~/.netrc` when absent), `out` (receives each line the command
reports), `confirm` (answers a yes/no question; every question is answered no
when it is absent), `run` (runs a package manager and returns its exit status)
and `fetch` — and returns what it did; a refusal or a failure is a thrown
`ModulesError` carrying the command line's `exitCode`. The package also exports
`archivePath`, the lockfile's `parseLockfile`, `formatLockfile` and
`readLockfile`, `fetchIndex`, `fetchArchive(host, name, entry, options)` (which
refuses an entry whose URL is not on `host`), `isSendable(url, host)` — the rule
above, as a pure function — and `main`, the command line itself.

`confirm` is called with two arguments: the question's text, as a terminal
shows it, and what the question is about, so a caller answers it without
reading the text — `{kind: 'upgrade', name, from, to}` before upgrading a
module, `{kind: 'replace', path, name, version}` before replacing an archive the
command did not write (`{kind: 'replace', path: 'install.sh'}` for an
`install.sh` it did not write), and `{kind: 'delete', path}` before deleting
one. `path` is relative to the project's root.

## Tests

```sh
npm test
```

They need Node, npm, `sh`, `curl` and `tar` on `PATH`, and reach no network: a
stand-in for the host runs on the loopback interface, a guard refuses any other
connection from the tests' own process, npm runs offline with a throwaway cache,
and HOME is a throwaway directory holding a fake netrc, so no test can read a
developer's own credential.

## Licence

Apache License 2.0; see [`LICENSE`](LICENSE).
