/**
 * commands.test.mjs — the library's commands against the stand-in host.
 *
 * READS and WRITES throwaway projects under the temporary directory only, and
 * reaches the loopback stand-in host only (see helpers.mjs).
 */

import { collector, commandArchive, fakeNetrc, LOGIN, makeArchive, makeProject, PASSWORD, recordingRunner, sha256, startHost } from './helpers.mjs';
import { networkAttempts } from './no-network.mjs';

import assert from 'node:assert/strict';
import { existsSync, readFileSync, unlinkSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';
import { after, before, describe, test } from 'node:test';

import {
  add,
  archivePath,
  check,
  formatLockfile,
  init,
  install,
  INSTALL_SCRIPT_MARKER,
  list,
  LOCKFILE,
  readLockfile,
  refusalMessage,
  remove,
  upgrade,
} from '../src/index.mjs';

let host;
let netrc;

before(async () => {
  host = await startHost();
  netrc = fakeNetrc();
  host.publish('@cognitio/modules', '1.0.0', commandArchive('1.0.0'));
  host.publish('@cognitio/alpha', '1.0.0');
  host.publish('@cognitio/alpha', '1.1.0');
  host.publish('@cognitio/beta', '2.0.0');
  host.publish('@cognitio/beta', '2.1.0');
});

after(() => host.close());

function options(dir, extra = {}) {
  const sink = collector();
  return { sink, opts: { cwd: dir, netrc: netrc.file, out: sink.out, run: recordingRunner().run, ...extra } };
}

async function started(extra = {}) {
  const dir = makeProject({ host: host.base, ...extra });
  await init(options(dir).opts);
  return dir;
}

const lockOf = (dir) => readLockfile(dir);
const vendored = (dir, file) => existsSync(join(dir, 'vendor', file));

describe('init', () => {
  test('vendors the command itself, writes the lockfile and install.sh', async () => {
    const dir = makeProject({ host: host.base });
    const { sink, opts } = options(dir);
    const result = await init(opts);
    const lock = lockOf(dir);
    assert.deepEqual(Object.keys(lock.modules), ['@cognitio/modules']);
    assert.equal(lock.modules['@cognitio/modules'].version, '1.0.0');
    assert.equal(lock.scopes['@cognitio'], host.base);
    assert.ok(vendored(dir, 'cognitio-modules-1.0.0.tgz'));
    assert.equal(sha256(readFileSync(join(dir, 'vendor', 'cognitio-modules-1.0.0.tgz'))), lock.modules['@cognitio/modules'].sha256);
    const script = readFileSync(join(dir, 'install.sh'), 'utf8');
    assert.ok(script.includes(INSTALL_SCRIPT_MARKER));
    assert.equal(script, readFileSync(new URL('../install.sh', import.meta.url), 'utf8'));
    assert.ok(result.changes.includes(`wrote ${LOCKFILE}`));
    assert.ok(result.changes.includes('wrote install.sh'));
    assert.ok(sink.lines.some((l) => l.startsWith('vendored @cognitio/modules 1.0.0: vendor/cognitio-modules-1.0.0.tgz')));
  });

  test('a project with no lockfile gets @cognitio mapped to tooling.cognitio.it', async () => {
    const dir = makeProject();
    // The real host is never reached: the fetch answers as a host would with no credential.
    const fetch = async () => new Response(null, { status: 401 });
    await assert.rejects(init({ cwd: dir, netrc: netrc.file, fetch }), /https:\/\/tooling\.cognitio\.it\/modules\/index\.json answered 401/);
    assert.equal(existsSync(join(dir, LOCKFILE)), false, 'nothing is written when the download fails');
  });

  test('a project already started is left as it is', async () => {
    const dir = await started();
    const before = readFileSync(join(dir, LOCKFILE));
    const result = await init(options(dir).opts);
    assert.deepEqual(result.changes, []);
    assert.deepEqual(readFileSync(join(dir, LOCKFILE)), before);
  });

  test('a project with a package.json gets the command in devDependencies, and npm install runs', async () => {
    const dir = makeProject({ host: host.base, packageJson: { name: 'site', private: true } });
    const runner = recordingRunner();
    await init({ ...options(dir).opts, run: runner.run });
    const pkg = JSON.parse(readFileSync(join(dir, 'package.json'), 'utf8'));
    assert.deepEqual(pkg.devDependencies, { '@cognitio/modules': 'file:vendor/cognitio-modules-1.0.0.tgz' });
    assert.deepEqual(runner.calls, [{ command: 'npm', args: ['install', '--no-audit', '--no-fund'], cwd: dir }]);
  });
});

describe('add', () => {
  test('vendors the newest version when none is named', async () => {
    const dir = await started();
    const { sink, opts } = options(dir);
    await add(opts, '@cognitio/alpha');
    assert.equal(lockOf(dir).modules['@cognitio/alpha'].version, '1.1.0');
    assert.ok(vendored(dir, 'cognitio-alpha-1.1.0.tgz'));
    assert.ok(sink.lines.includes(`wrote ${LOCKFILE}`));
  });

  test('vendors the version named, byte for byte as published', async () => {
    const dir = await started();
    await add(options(dir).opts, '@cognitio/alpha@1.0.0');
    const entry = lockOf(dir).modules['@cognitio/alpha'];
    assert.equal(entry.version, '1.0.0');
    assert.equal(entry.url, `${host.base}/alpha/archives/alpha-1.0.0.tgz`);
    assert.equal(sha256(readFileSync(join(dir, 'vendor', 'cognitio-alpha-1.0.0.tgz'))), entry.sha256);
  });

  test('moving to another version removes the archive of the version before', async () => {
    const dir = await started();
    await add(options(dir).opts, '@cognitio/alpha@1.0.0');
    const { sink, opts } = options(dir);
    await add(opts, '@cognitio/alpha@1.1.0');
    assert.ok(vendored(dir, 'cognitio-alpha-1.1.0.tgz'));
    assert.equal(vendored(dir, 'cognitio-alpha-1.0.0.tgz'), false);
    assert.ok(sink.lines.includes('removed vendor/cognitio-alpha-1.0.0.tgz'));
  });

  test('a version the index does not list is not published', async () => {
    const dir = await started();
    await assert.rejects(add(options(dir).opts, '@cognitio/alpha@9.9.9'), /@cognitio\/alpha 9\.9\.9 is not published: its index lists 1\.0\.0, 1\.1\.0/);
  });

  test('package.json: an existing entry keeps its section; a new one goes where --dev says', async () => {
    const dir = await started({
      packageJson: { name: 'site', dependencies: { '@cognitio/alpha': 'file:vendor/alpha', zeta: '1.0.0' } },
    });
    const runner = recordingRunner();
    await add({ ...options(dir).opts, run: runner.run }, '@cognitio/alpha');
    await add({ ...options(dir).opts, run: runner.run, dev: true }, '@cognitio/beta');
    const pkg = JSON.parse(readFileSync(join(dir, 'package.json'), 'utf8'));
    assert.deepEqual(pkg.dependencies, { '@cognitio/alpha': 'file:vendor/cognitio-alpha-1.1.0.tgz', zeta: '1.0.0' });
    assert.equal(pkg.devDependencies['@cognitio/beta'], 'file:vendor/cognitio-beta-2.1.0.tgz');
    assert.equal(runner.calls.length, 2);
    assert.ok(runner.calls.every((c) => c.command === 'npm' && c.args.join(' ') === 'install --no-audit --no-fund'));
  });

  test('a project keeping a bun.lock also runs npx -y bun install', async () => {
    const dir = await started({ packageJson: { name: 'site' } });
    writeFileSync(join(dir, 'bun.lock'), '{}\n');
    const runner = recordingRunner();
    const { sink } = options(dir);
    await add({ ...options(dir).opts, out: sink.out, run: runner.run }, '@cognitio/alpha');
    assert.deepEqual(
      runner.calls.map((c) => [c.command, ...c.args].join(' ')),
      ['npm install --no-audit --no-fund', 'npx -y bun install'],
    );
    assert.ok(sink.lines.includes('ran npx -y bun install'));
  });

  test('a package manager that fails is reported, naming what is already written', async () => {
    const dir = await started({ packageJson: { name: 'site' } });
    await assert.rejects(add({ ...options(dir).opts, run: recordingRunner(1).run }, '@cognitio/alpha'), /npm install --no-audit --no-fund exited 1; the vendored archives, the lockfile and package.json are already written/);
  });

  test('a project with no package.json gets the archive alone', async () => {
    const dir = await started();
    const runner = recordingRunner();
    await add({ ...options(dir).opts, run: runner.run }, '@cognitio/alpha');
    assert.equal(existsSync(join(dir, 'package.json')), false);
    assert.deepEqual(runner.calls, []);
  });

  test('an archive at the path that the command did not write is not replaced without a yes', async () => {
    const dir = await started();
    writeFileSync(join(dir, 'vendor', 'cognitio-alpha-1.1.0.tgz'), 'a file of the developer\'s own');
    await assert.rejects(add(options(dir).opts, '@cognitio/alpha'), /vendor\/cognitio-alpha-1\.1\.0\.tgz is not the file cognitio-modules\.json records, so cognitio-modules did not write it: it is not replaced/);
    assert.equal(readFileSync(join(dir, 'vendor', 'cognitio-alpha-1.1.0.tgz'), 'utf8'), 'a file of the developer\'s own');
    assert.equal(lockOf(dir).modules['@cognitio/alpha'], undefined);
    const questions = [];
    await add({ ...options(dir).opts, confirm: (q, about) => (questions.push({ q, about }), true) }, '@cognitio/alpha');
    assert.equal(questions.length, 1);
    assert.deepEqual(questions[0].about, { kind: 'replace', path: 'vendor/cognitio-alpha-1.1.0.tgz', name: '@cognitio/alpha', version: '1.1.0' });
    assert.equal(sha256(readFileSync(join(dir, 'vendor', 'cognitio-alpha-1.1.0.tgz'))), lockOf(dir).modules['@cognitio/alpha'].sha256);
  });
});

describe('integrity', () => {
  test('an archive whose sha256 is not the index\'s is refused and nothing is written', async () => {
    const own = await startHost();
    own.publish('@cognitio/modules', '1.0.0', commandArchive('1.0.0'));
    own.publish('@cognitio/gamma', '1.0.0', makeArchive('@cognitio/gamma', '1.0.0'), { sha256: '0'.repeat(64) });
    try {
      const dir = makeProject({ host: own.base });
      await init({ cwd: dir, netrc: netrc.file });
      const before = readFileSync(join(dir, LOCKFILE));
      await assert.rejects(add({ cwd: dir, netrc: netrc.file }, '@cognitio/gamma'), /has sha256 [0-9a-f]{64}, not 0{64} as recorded for @cognitio\/gamma 1\.0\.0: the archive is refused and nothing is written/);
      assert.equal(vendored(dir, 'cognitio-gamma-1.0.0.tgz'), false);
      assert.deepEqual(readFileSync(join(dir, LOCKFILE)), before);
    } finally {
      await own.close();
    }
  });

  test('an archive whose package.json names another package is refused', async () => {
    const own = await startHost();
    own.publish('@cognitio/modules', '1.0.0', commandArchive('1.0.0'));
    own.publish('@cognitio/delta', '1.0.0', makeArchive('@cognitio/other', '1.0.0'));
    try {
      const dir = makeProject({ host: own.base });
      await init({ cwd: dir, netrc: netrc.file });
      await assert.rejects(add({ cwd: dir, netrc: netrc.file }, '@cognitio/delta'), /holds @cognitio\/other 1\.0\.0, not @cognitio\/delta 1\.0\.0: the archive is refused/);
      assert.equal(vendored(dir, 'cognitio-delta-1.0.0.tgz'), false);
    } finally {
      await own.close();
    }
  });
});

describe('credential', () => {
  test('401 with no credential, in the words of the host\'s answer', async () => {
    const dir = await started();
    const none = join(dir, 'no-such-netrc');
    await assert.rejects(add({ cwd: dir, netrc: none }, '@cognitio/alpha'), (err) => {
      assert.equal(err.message, `${host.base}/alpha/index.json answered 401: no credential for 127.0.0.1 in ${none}, or one the host does not know`);
      return true;
    });
  });

  test('401 with a credential the host does not know', async () => {
    const dir = await started();
    const wrong = fakeNetrc({ password: 'not-the-password' });
    await assert.rejects(add({ cwd: dir, netrc: wrong.file }, '@cognitio/alpha'), /answered 401: no credential for 127\.0\.0\.1 in .*, or one the host does not know/);
  });

  test('403 when the credential is not allowed the publication', async () => {
    const own = await startHost({ publications: ['modules'] });
    own.publish('@cognitio/modules', '1.0.0', commandArchive('1.0.0'));
    own.publish('@cognitio/alpha', '1.0.0');
    try {
      const dir = makeProject({ host: own.base });
      await init({ cwd: dir, netrc: netrc.file });
      await assert.rejects(add({ cwd: dir, netrc: netrc.file }, '@cognitio/alpha'), (err) => {
        assert.equal(err.message, `${own.base}/alpha/index.json answered 403: the credential in ${netrc.file} is not allowed the publication alpha`);
        return true;
      });
    } finally {
      await own.close();
    }
  });

  test('404 when the module is not published', async () => {
    const dir = await started();
    await assert.rejects(add(options(dir).opts, '@cognitio/absent'), (err) => {
      assert.equal(err.message, `${host.base}/absent/index.json answered 404: absent is not published`);
      return true;
    });
  });

  test('404 when an archive the index names is gone', async () => {
    const own = await startHost();
    own.publish('@cognitio/modules', '1.0.0', commandArchive('1.0.0'));
    own.publish('@cognitio/alpha', '1.0.0');
    own.answer('/alpha/archives/alpha-1.0.0.tgz', 404);
    try {
      const dir = makeProject({ host: own.base });
      await init({ cwd: dir, netrc: netrc.file });
      await assert.rejects(add({ cwd: dir, netrc: netrc.file }, '@cognitio/alpha'), /alpha-1\.0\.0\.tgz answered 404: alpha 1\.0\.0 is not published/);
    } finally {
      await own.close();
    }
  });

  test('a redirect is not followed, so the credential reaches no other host', async () => {
    const own = await startHost();
    own.publish('@cognitio/modules', '1.0.0', commandArchive('1.0.0'));
    try {
      const dir = makeProject({ host: own.base });
      await init({ cwd: dir, netrc: netrc.file });
      own.answer('/alpha/index.json', 302, '');
      await assert.rejects(add({ cwd: dir, netrc: netrc.file }, '@cognitio/alpha'), /alpha\/index\.json answered 302$/);
    } finally {
      await own.close();
    }
  });

  test('the credential is sent to the host and never printed, logged or written', async () => {
    const dir = await started({ packageJson: { name: 'site' } });
    const { sink, opts } = options(dir);
    await add(opts, '@cognitio/alpha');
    await upgrade({ ...opts, yes: true });
    await list(opts);
    const basic = Buffer.from(`${LOGIN}:${PASSWORD}`).toString('base64');
    assert.ok(host.requests.some((r) => r.authorized), 'the host received the credential');
    for (const line of sink.lines) {
      assert.equal(line.includes(PASSWORD), false);
      assert.equal(line.includes(basic), false);
    }
    for (const file of [LOCKFILE, 'package.json']) {
      const text = readFileSync(join(dir, file), 'utf8');
      assert.equal(text.includes(PASSWORD) || text.includes(basic) || text.includes(LOGIN), false, file);
    }
  });
});

describe('upgrade', () => {
  test('proposes every module with a newer version and applies the one accepted', async () => {
    const dir = await started();
    await add(options(dir).opts, '@cognitio/alpha@1.0.0');
    await add(options(dir).opts, '@cognitio/beta@2.0.0');
    const questions = [];
    const { sink, opts } = options(dir, { confirm: (q) => (questions.push(q), q.includes('@cognitio/alpha')) });
    const result = await upgrade(opts);
    assert.deepEqual(result.proposed, [
      { name: '@cognitio/alpha', from: '1.0.0', to: '1.1.0' },
      { name: '@cognitio/beta', from: '2.0.0', to: '2.1.0' },
    ]);
    assert.deepEqual(questions, ['Upgrade @cognitio/alpha 1.0.0 → 1.1.0?', 'Upgrade @cognitio/beta 2.0.0 → 2.1.0?']);
    assert.deepEqual(result.upgraded, ['@cognitio/alpha']);
    assert.ok(sink.lines.includes('@cognitio/alpha 1.0.0 → 1.1.0'));
    assert.ok(sink.lines.includes('@cognitio/beta 2.0.0 → 2.1.0'));
    const lock = lockOf(dir);
    assert.equal(lock.modules['@cognitio/alpha'].version, '1.1.0');
    assert.equal(lock.modules['@cognitio/beta'].version, '2.0.0');
    assert.ok(vendored(dir, 'cognitio-alpha-1.1.0.tgz'));
    assert.equal(vendored(dir, 'cognitio-alpha-1.0.0.tgz'), false);
    assert.ok(vendored(dir, 'cognitio-beta-2.0.0.tgz'));
    assert.equal(vendored(dir, 'cognitio-beta-2.1.0.tgz'), false);
  });

  test('confirm is told what each upgrade question is about, and is answered from that alone', async () => {
    const dir = await started();
    await add(options(dir).opts, '@cognitio/alpha@1.0.0');
    await add(options(dir).opts, '@cognitio/beta@2.0.0');
    const asked = [];
    const confirm = (question, about) => {
      asked.push({ question, about });
      return about.kind === 'upgrade' && about.name === '@cognitio/beta' && about.from === '2.0.0' && about.to === '2.1.0';
    };
    const result = await upgrade(options(dir, { confirm }).opts);
    assert.deepEqual(asked, [
      { question: 'Upgrade @cognitio/alpha 1.0.0 → 1.1.0?', about: { kind: 'upgrade', name: '@cognitio/alpha', from: '1.0.0', to: '1.1.0' } },
      { question: 'Upgrade @cognitio/beta 2.0.0 → 2.1.0?', about: { kind: 'upgrade', name: '@cognitio/beta', from: '2.0.0', to: '2.1.0' } },
    ]);
    assert.deepEqual(result.upgraded, ['@cognitio/beta']);
    assert.equal(lockOf(dir).modules['@cognitio/alpha'].version, '1.0.0');
    assert.equal(lockOf(dir).modules['@cognitio/beta'].version, '2.1.0');
  });

  test('--yes accepts every proposal; nothing is proposed once every module is newest', async () => {
    const dir = await started();
    await add(options(dir).opts, '@cognitio/alpha@1.0.0');
    await add(options(dir).opts, '@cognitio/beta@2.0.0');
    const result = await upgrade(options(dir, { yes: true }).opts);
    assert.deepEqual(result.upgraded, ['@cognitio/alpha', '@cognitio/beta']);
    const { sink, opts } = options(dir, { yes: true });
    const again = await upgrade(opts);
    assert.deepEqual(again.proposed, []);
    assert.ok(sink.lines.includes('every module is at its newest version'));
  });

  test('with neither a terminal nor --yes it asks for one and changes nothing', async () => {
    const dir = await started();
    await add(options(dir).opts, '@cognitio/alpha@1.0.0');
    const before = readFileSync(join(dir, LOCKFILE));
    await assert.rejects(upgrade({ cwd: dir, netrc: netrc.file }), /upgrade asks before each module: run it in a terminal, or pass --yes/);
    assert.deepEqual(readFileSync(join(dir, LOCKFILE)), before);
  });

  test('one refused archive among the accepted writes nothing at all', async () => {
    const own = await startHost();
    own.publish('@cognitio/modules', '1.0.0', commandArchive('1.0.0'));
    own.publish('@cognitio/alpha', '1.0.0');
    own.publish('@cognitio/beta', '2.0.0');
    try {
      const dir = makeProject({ host: own.base });
      await init({ cwd: dir, netrc: netrc.file });
      await add({ cwd: dir, netrc: netrc.file }, '@cognitio/alpha');
      await add({ cwd: dir, netrc: netrc.file }, '@cognitio/beta');
      own.publish('@cognitio/alpha', '1.1.0');
      own.publish('@cognitio/beta', '2.1.0', makeArchive('@cognitio/beta', '2.1.0'), { sha256: 'f'.repeat(64) });
      const before = readFileSync(join(dir, LOCKFILE));
      await assert.rejects(upgrade({ cwd: dir, netrc: netrc.file, yes: true }), /the archive is refused and nothing is written/);
      assert.deepEqual(readFileSync(join(dir, LOCKFILE)), before);
      assert.equal(vendored(dir, 'cognitio-alpha-1.1.0.tgz'), false);
      assert.ok(vendored(dir, 'cognitio-alpha-1.0.0.tgz'));
    } finally {
      await own.close();
    }
  });
});

describe('remove', () => {
  test('removes the archive, the lockfile entry and the package.json entry', async () => {
    const dir = await started({ packageJson: { name: 'site' } });
    await add(options(dir).opts, '@cognitio/alpha');
    const runner = recordingRunner();
    const { sink } = options(dir);
    await remove({ ...options(dir).opts, out: sink.out, run: runner.run }, '@cognitio/alpha');
    assert.equal(lockOf(dir).modules['@cognitio/alpha'], undefined);
    assert.equal(vendored(dir, 'cognitio-alpha-1.1.0.tgz'), false);
    const pkg = JSON.parse(readFileSync(join(dir, 'package.json'), 'utf8'));
    assert.equal(pkg.dependencies['@cognitio/alpha'], undefined);
    assert.deepEqual(sink.lines.slice(0, 3), ['removed vendor/cognitio-alpha-1.1.0.tgz', `wrote ${LOCKFILE}`, 'package.json: removed dependencies.@cognitio/alpha']);
    assert.equal(runner.calls.length, 1);
  });

  test('a module the lockfile does not name, and the command itself, are refused', async () => {
    const dir = await started();
    await assert.rejects(remove(options(dir).opts, '@cognitio/alpha'), /names no module @cognitio\/alpha/);
    await assert.rejects(remove(options(dir).opts, '@cognitio/modules'), /is the command itself/);
  });
});

describe('list', () => {
  test('lists each module, its version and the newest available', async () => {
    const dir = await started();
    await add(options(dir).opts, '@cognitio/alpha@1.0.0');
    await add(options(dir).opts, '@cognitio/beta');
    const { sink, opts } = options(dir);
    const result = await list(opts);
    assert.equal(result.ok, true);
    assert.deepEqual(result.modules.map((m) => [m.name, m.version, m.newest]), [
      ['@cognitio/alpha', '1.0.0', '1.1.0'],
      ['@cognitio/beta', '2.1.0', '2.1.0'],
      ['@cognitio/modules', '1.0.0', '1.0.0'],
    ]);
    assert.deepEqual(sink.lines, [
      '@cognitio/alpha    1.0.0  newest 1.1.0',
      '@cognitio/beta     2.1.0  newest',
      '@cognitio/modules  1.0.0  newest',
    ]);
  });
});

describe('install and check', () => {
  test('install puts back a deleted archive; check needs no credential and no network', async () => {
    const dir = await started();
    await add(options(dir).opts, '@cognitio/alpha');
    unlinkSync(join(dir, 'vendor', 'cognitio-alpha-1.1.0.tgz'));
    const seen = host.requests.length;
    const missing = check({ cwd: dir });
    assert.equal(host.requests.length, seen, 'check made no request');
    assert.equal(missing.ok, false);
    assert.deepEqual(missing.problems, ['vendor/cognitio-alpha-1.1.0.tgz is missing: cognitio-modules.json names @cognitio/alpha 1.1.0']);
    const { sink, opts } = options(dir);
    const result = await install(opts);
    assert.deepEqual(result.restored, ['@cognitio/alpha']);
    assert.ok(sink.lines.includes('restored @cognitio/alpha 1.1.0: vendor/cognitio-alpha-1.1.0.tgz'));
    assert.equal(check({ cwd: dir }).ok, true);
  });

  test('check fails on one changed byte and passes after install replaces the copy on a yes', async () => {
    const dir = await started();
    await add(options(dir).opts, '@cognitio/alpha');
    const file = join(dir, 'vendor', 'cognitio-alpha-1.1.0.tgz');
    const bytes = readFileSync(file);
    bytes[bytes.length - 1] ^= 0xff;
    writeFileSync(file, bytes);
    const changed = check({ cwd: dir });
    assert.equal(changed.ok, false);
    assert.match(changed.problems[0], /^vendor\/cognitio-alpha-1\.1\.0\.tgz differs from cognitio-modules\.json: its sha256 is [0-9a-f]{64}, [0-9a-f]{64} is recorded$/);
    await assert.rejects(install({ cwd: dir, netrc: netrc.file }), /vendor\/cognitio-alpha-1\.1\.0\.tgz: not replaced/);
    assert.equal(check({ cwd: dir }).ok, false, 'without a yes the changed copy stays');
    await install({ cwd: dir, netrc: netrc.file, confirm: () => true });
    assert.equal(check({ cwd: dir }).ok, true);
  });

  test('check reports a package.json entry that is not the vendored archive', async () => {
    const dir = await started({ packageJson: { name: 'site' } });
    await add(options(dir).opts, '@cognitio/alpha');
    const pkg = JSON.parse(readFileSync(join(dir, 'package.json'), 'utf8'));
    pkg.dependencies['@cognitio/alpha'] = 'file:vendor/alpha';
    writeFileSync(join(dir, 'package.json'), JSON.stringify(pkg));
    assert.deepEqual(check({ cwd: dir }).problems, ['package.json: dependencies.@cognitio/alpha is file:vendor/alpha, not file:vendor/cognitio-alpha-1.1.0.tgz']);
  });

  test('archivePath names the vendored archive from the lockfile, with no request', async () => {
    const dir = await started();
    await add(options(dir).opts, '@cognitio/alpha');
    const seen = host.requests.length;
    assert.equal(archivePath({ cwd: dir }, '@cognitio/alpha'), join(dir, 'vendor', 'cognitio-alpha-1.1.0.tgz'));
    assert.equal(host.requests.length, seen);
    await assert.rejects(async () => archivePath({ cwd: dir }, '@cognitio/beta'), /names no module @cognitio\/beta/);
  });
});

describe('where the credential may go: over https, to the scope\'s host alone', () => {
  /** A fetch that records every call and answers nothing: a refusal must leave it uncalled. */
  function spyFetch() {
    const calls = [];
    const fetch = async (url) => {
      calls.push(String(url));
      return new Response(null, { status: 500 });
    };
    return { calls, fetch };
  }

  test('an archive URL an index names on another host is refused, and that host receives nothing', async () => {
    const own = await startHost();
    const other = await startHost();
    other.publish('@cognitio/alpha', '1.0.0');
    const elsewhere = `${other.base}/alpha/archives/alpha-1.0.0.tgz`;
    own.publish('@cognitio/modules', '1.0.0', commandArchive('1.0.0'));
    own.publish('@cognitio/alpha', '1.0.0', makeArchive('@cognitio/alpha', '1.0.0'), { url: elsewhere });
    try {
      const dir = makeProject({ host: own.base });
      await init({ cwd: dir, netrc: netrc.file });
      const before = readFileSync(join(dir, LOCKFILE));
      const attempts = networkAttempts().length;
      await assert.rejects(add({ cwd: dir, netrc: netrc.file }, '@cognitio/alpha'), (err) => {
        assert.equal(err.message, refusalMessage(elsewhere, '@cognitio', own.base));
        return true;
      });
      assert.equal(other.requests.length, 0, 'the other host received no request');
      assert.equal(networkAttempts().length, attempts, 'no other connection was attempted');
      assert.equal(vendored(dir, 'cognitio-alpha-1.0.0.tgz'), false);
      assert.deepEqual(readFileSync(join(dir, LOCKFILE)), before);
    } finally {
      await own.close();
      await other.close();
    }
  });

  test('an archive URL the lockfile names on another host is refused by install, and that host receives nothing', async () => {
    const other = await startHost();
    const published = other.publish('@cognitio/alpha', '1.0.0');
    try {
      const dir = await started();
      const lock = readLockfile(dir);
      lock.modules['@cognitio/alpha'] = { version: '1.0.0', url: published.url, sha256: published.sha256 };
      writeFileSync(join(dir, LOCKFILE), formatLockfile(lock));
      await assert.rejects(install({ cwd: dir, netrc: netrc.file }), (err) => {
        assert.equal(err.message, refusalMessage(published.url, '@cognitio', host.base));
        return true;
      });
      assert.equal(other.requests.length, 0, 'the other host received no request');
      assert.equal(vendored(dir, 'cognitio-alpha-1.0.0.tgz'), false);
    } finally {
      await other.close();
    }
  });

  test('a scope mapped to a non-loopback plain-http host is refused before anything is sent', async () => {
    const dir = makeProject({ scopes: { '@cognitio': 'http://192.0.2.1' } });
    const spy = spyFetch();
    await assert.rejects(init({ cwd: dir, netrc: netrc.file, fetch: spy.fetch }), (err) => {
      assert.equal(err.message, refusalMessage('http://192.0.2.1/modules/index.json', '@cognitio', 'http://192.0.2.1'));
      return true;
    });
    assert.deepEqual(spy.calls, [], 'fetch was never called');
    // With the real fetch, the network guard records no attempt either.
    const attempts = networkAttempts().length;
    await assert.rejects(init({ cwd: dir, netrc: netrc.file }), /is refused and nothing is sent to it/);
    assert.equal(networkAttempts().length, attempts);
    assert.equal(existsSync(join(dir, 'vendor')), false);
  });

  test('a non-loopback plain-http archive URL in an index is refused before anything is sent', async () => {
    const own = await startHost();
    const plain = 'http://192.0.2.1/beta/archives/beta-1.0.0.tgz';
    own.publish('@cognitio/modules', '1.0.0', commandArchive('1.0.0'));
    own.publish('@cognitio/beta', '1.0.0', makeArchive('@cognitio/beta', '1.0.0'), { url: plain });
    try {
      const dir = makeProject({ host: own.base });
      await init({ cwd: dir, netrc: netrc.file });
      const attempts = networkAttempts().length;
      const seen = own.requests.length;
      await assert.rejects(add({ cwd: dir, netrc: netrc.file }, '@cognitio/beta'), (err) => {
        assert.equal(err.message, refusalMessage(plain, '@cognitio', own.base));
        return true;
      });
      assert.equal(networkAttempts().length, attempts, 'no connection to 192.0.2.1 was attempted');
      assert.deepEqual(own.requests.slice(seen).map((r) => r.path), ['/beta/index.json'], 'only the index was read');
    } finally {
      await own.close();
    }
  });

  test('an https URL on the scope\'s host is sent, with the credential the netrc file holds for it', async () => {
    const dir = makeProject({ scopes: { '@cognitio': 'https://tooling.example' } });
    const file = join(dir, 'netrc');
    writeFileSync(file, 'machine tooling.example login someone password fake-secret\n');
    const seen = [];
    const fetch = async (url, request) => {
      seen.push({ url: String(url), authorization: request.headers.authorization });
      return new Response(null, { status: 404 });
    };
    await assert.rejects(init({ cwd: dir, netrc: file, fetch }), /answered 404: modules is not published/);
    assert.deepEqual(seen, [{ url: 'https://tooling.example/modules/index.json', authorization: `Basic ${Buffer.from('someone:fake-secret').toString('base64')}` }]);
  });
});

describe('the lockfile', () => {
  test('its bytes depend on the set of modules alone, not on the order they were added in', async () => {
    const one = await started();
    await add(options(one).opts, '@cognitio/beta');
    await add(options(one).opts, '@cognitio/alpha');
    const two = await started();
    await add(options(two).opts, '@cognitio/alpha');
    await add(options(two).opts, '@cognitio/beta');
    const text = readFileSync(join(one, LOCKFILE), 'utf8');
    assert.equal(text, readFileSync(join(two, LOCKFILE), 'utf8'));
    assert.equal(text, formatLockfile(readLockfile(one)));
    assert.deepEqual(Object.keys(JSON.parse(text)), ['scopes', 'modules']);
    assert.deepEqual(Object.keys(JSON.parse(text).modules), ['@cognitio/alpha', '@cognitio/beta', '@cognitio/modules']);
    assert.deepEqual(Object.keys(JSON.parse(text).modules['@cognitio/alpha']), ['version', 'url', 'sha256']);
  });

  test('a customer scope maps to its host the same way', async () => {
    const dir = makeProject({ scopes: { '@cognitio': host.base, '@acme': host.base } });
    await init({ cwd: dir, netrc: netrc.file });
    host.publish('@acme/widget', '0.1.0');
    await add({ cwd: dir, netrc: netrc.file }, '@acme/widget');
    assert.ok(vendored(dir, 'acme-widget-0.1.0.tgz'));
    await assert.rejects(add({ cwd: dir, netrc: netrc.file }, '@other/thing'), /maps no host to the scope @other/);
  });

  test('an index naming another package is refused', async () => {
    const dir = makeProject({ scopes: { '@cognitio': host.base, '@acme': host.base } });
    await init({ cwd: dir, netrc: netrc.file });
    await assert.rejects(add({ cwd: dir, netrc: netrc.file }, '@acme/alpha'), /alpha\/index\.json is the index of @cognitio\/alpha, not of @acme\/alpha/);
  });
});
