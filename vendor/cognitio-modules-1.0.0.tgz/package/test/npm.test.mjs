/**
 * npm.test.mjs — what npm itself does with a vendored archive: the integrity it
 * records, the changed archive it refuses, and the install a project with no
 * package.json runs from `path`.
 *
 * RUNS the npm on PATH, offline, with a throwaway cache and HOME, against
 * throwaway projects under the temporary directory; its every dependency is a
 * local archive, so it needs no registry.
 */

import { commandArchive, fakeNetrc, makeArchive, makeProject, startHost, tempDir } from './helpers.mjs';

import assert from 'node:assert/strict';
import { spawn } from 'node:child_process';
import { createHash } from 'node:crypto';
import { existsSync, readFileSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';
import { after, before, test } from 'node:test';

import { add, archivePath, init } from '../src/index.mjs';

let host;
let netrc;

before(async () => {
  host = await startHost();
  netrc = fakeNetrc();
  host.publish('@cognitio/modules', '1.0.0', commandArchive('1.0.0'));
  host.publish('@cognitio/alpha', '1.0.0');
});

after(() => host.close());

/** A child still running after this long is killed, and its null status fails the test. */
const CHILD_TIMEOUT_MS = 120_000;

/**
 * Runs a command and resolves with its status and output. Asynchronous, so the
 * stand-in host in this process stays free to answer while a child runs.
 */
function runChild(command, args, { cwd, env }) {
  return new Promise((resolve, reject) => {
    const child = spawn(command, args, { cwd, env, timeout: CHILD_TIMEOUT_MS });
    let stdout = '';
    let stderr = '';
    child.stdout.setEncoding('utf8').on('data', (chunk) => (stdout += chunk));
    child.stderr.setEncoding('utf8').on('data', (chunk) => (stderr += chunk));
    child.on('error', reject);
    child.on('close', (status) => resolve({ status, stdout, stderr }));
  });
}

/** npm's environment: offline, with a cache and a HOME of its own. */
function npmEnv(cache = tempDir('cognitio-modules-npm-cache-')) {
  return {
    ...process.env,
    HOME: tempDir('cognitio-modules-npm-home-'),
    npm_config_cache: cache,
    npm_config_offline: 'true',
    npm_config_update_notifier: 'false',
  };
}

/** A runner for the library that runs npm in that environment. */
function npmRunner() {
  const env = npmEnv();
  return async (command, args, options) => {
    const result = await runChild(command, args, { cwd: options.cwd, env });
    if (result.status !== 0) process.stderr.write(`${result.stdout}\n${result.stderr}\n`);
    return result.status ?? 1;
  };
}

const sha512 = (bytes) => `sha512-${createHash('sha512').update(bytes).digest('base64')}`;

test('npm records the vendored archive\'s sha512 in package-lock.json, and npm ci refuses a changed archive', async () => {
  const dir = makeProject({ host: host.base, packageJson: { name: 'site', version: '0.0.0', private: true } });
  const run = npmRunner();
  await init({ cwd: dir, netrc: netrc.file, run });
  await add({ cwd: dir, netrc: netrc.file, run }, '@cognitio/alpha');
  const lock = JSON.parse(readFileSync(join(dir, 'package-lock.json'), 'utf8'));
  const archive = join(dir, 'vendor', 'cognitio-alpha-1.0.0.tgz');
  assert.deepEqual(lock.packages['node_modules/@cognitio/alpha'], {
    version: '1.0.0',
    resolved: 'file:vendor/cognitio-alpha-1.0.0.tgz',
    integrity: sha512(readFileSync(archive)),
  });
  assert.equal(lock.packages['node_modules/@cognitio/modules'].resolved, 'file:vendor/cognitio-modules-1.0.0.tgz');

  // Another VALID archive of the same package and version at the same path, so what
  // npm meets is an integrity mismatch rather than a damaged gzip stream; and a
  // cache that does not already hold the recorded bytes, as on a fresh CI machine.
  const changed = makeArchive('@cognitio/alpha', '1.0.0', { 'changed.js': 'module.exports = "changed";\n' });
  assert.notEqual(sha512(changed), lock.packages['node_modules/@cognitio/alpha'].integrity);
  writeFileSync(archive, changed);
  const ci = await runChild('npm', ['ci', '--no-audit', '--no-fund'], { cwd: dir, env: npmEnv() });
  assert.notEqual(ci.status, 0);
  assert.match(ci.stderr, /EINTEGRITY/);
});

test('a project with no package.json installs a module from the path the command prints', async () => {
  const dir = makeProject({ host: host.base });
  await init({ cwd: dir, netrc: netrc.file });
  await add({ cwd: dir, netrc: netrc.file }, '@cognitio/alpha');
  const status = await npmRunner()('npm', ['install', '--no-save', '--no-audit', '--no-fund', archivePath({ cwd: dir }, '@cognitio/alpha')], { cwd: dir });
  assert.equal(status, 0);
  assert.ok(existsSync(join(dir, 'node_modules', '@cognitio', 'alpha', 'package.json')));
  assert.equal(existsSync(join(dir, 'package.json')), false, 'nothing is saved');
});
