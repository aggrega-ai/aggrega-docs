/**
 * no-network.mjs — the network guard of the package's tests.
 *
 * READS nothing and WRITES nothing. Imported first by every test file (through
 * helpers.mjs), it replaces `net.Socket.prototype.connect`, through which Node's
 * own `fetch` connects, with a function that lets a connection to the loopback
 * interface through — the stand-in host the tests start — and refuses every
 * other one, recording it, so a test that reached a real host fails loudly.
 *
 * Installed once per process; the attempts are kept on a global so every file
 * sees the same record.
 */

import net from 'node:net';

const STATE = Symbol.for('@cognitio/modules/test/no-network');
const LOOPBACK = new Set(['127.0.0.1', '::1', 'localhost']);

/** A test attempted to reach a host other than the loopback stand-in. */
export class NetworkAttemptError extends Error {
  constructor(message) {
    super(message);
    this.name = 'NetworkAttemptError';
  }
}

if (!globalThis[STATE]) {
  const state = { attempts: [], connect: net.Socket.prototype.connect };
  globalThis[STATE] = state;
  net.Socket.prototype.connect = function guardedConnect(...args) {
    // `net.connect` passes its normalised arguments as one array, options first.
    const [first, second] = Array.isArray(args[0]) ? args[0] : args;
    const options = first && typeof first === 'object' ? first : { port: first, host: typeof second === 'string' ? second : undefined };
    if (options.path === undefined && !LOOPBACK.has(options.host ?? 'localhost')) {
      const target = `${options.host}:${options.port}`;
      state.attempts.push(target);
      throw new NetworkAttemptError(`a test attempted network access (${target}); tests use the loopback stand-in host`);
    }
    return state.connect.apply(this, args);
  };
}

/** The connections the guard refused in this process, in order. */
export function networkAttempts() {
  return [...globalThis[STATE].attempts];
}
