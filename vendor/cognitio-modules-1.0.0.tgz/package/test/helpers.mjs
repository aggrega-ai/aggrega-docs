/**
 * helpers.mjs — what the package's tests share: a stand-in for the modules'
 * host on the loopback interface, archives built on the fly, a fake netrc file
 * and throwaway projects.
 *
 * READS the package's own files (to pack the command itself); WRITES only under
 * the operating system's temporary directory. Importing it first does two
 * things for every test file: it points HOME at an empty temporary directory, so
 * nothing a test runs can read the developer's own ~/.netrc, and it installs the
 * network guard, so nothing reaches a host other than the loopback stand-in.
 */

import './no-network.mjs';

import { execFileSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import { cpSync, mkdirSync, mkdtempSync, readFileSync, writeFileSync } from 'node:fs';
import { createServer } from 'node:http';
import { tmpdir } from 'node:os';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

/** The package's own directory. */
export const PACKAGE_DIR = join(dirname(fileURLToPath(import.meta.url)), '..');

/** A new empty directory under the temporary directory. */
export function tempDir(prefix = 'cognitio-modules-test-') {
  return mkdtempSync(join(tmpdir(), prefix));
}

// No test may read the developer's own credential: HOME is a fresh empty directory.
process.env.HOME = tempDir('cognitio-modules-home-');

/** The fake credential every test host accepts. It is never a real one. */
export const LOGIN = 'site-developer';
export const PASSWORD = 'fake-password-only-for-tests';

export function sha256(bytes) {
  return createHash('sha256').update(bytes).digest('hex');
}

/**
 * A gzipped tar archive laid out as `npm pack` lays one out: `package/` holding
 * a package.json naming `name` and `version`, and the files given.
 *
 * @param {string} name
 * @param {string} version
 * @param {Record<string, string>} [files] path under package/ → text
 * @returns {Buffer}
 */
export function makeArchive(name, version, files = {}) {
  const dir = tempDir('cognitio-modules-pack-');
  mkdirSync(join(dir, 'package'));
  writeFileSync(join(dir, 'package', 'package.json'), `${JSON.stringify({ name, version, main: 'index.js' }, null, 2)}\n`);
  writeFileSync(join(dir, 'package', 'index.js'), `module.exports = ${JSON.stringify(`${name} ${version}`)};\n`);
  for (const [path, text] of Object.entries(files)) {
    mkdirSync(dirname(join(dir, 'package', path)), { recursive: true });
    writeFileSync(join(dir, 'package', path), text);
  }
  const file = join(dir, 'archive.tgz');
  execFileSync('tar', ['-czf', file, '-C', dir, 'package']);
  return readFileSync(file);
}

/**
 * An archive of this package itself — its package.json (at `version`), its
 * sources, its entry point and its install.sh — as a release would pack it.
 *
 * @param {string} [version]
 */
export function commandArchive(version) {
  const dir = tempDir('cognitio-modules-self-');
  const root = join(dir, 'package');
  mkdirSync(root);
  const manifest = JSON.parse(readFileSync(join(PACKAGE_DIR, 'package.json'), 'utf8'));
  if (version) manifest.version = version;
  writeFileSync(join(root, 'package.json'), `${JSON.stringify(manifest, null, 2)}\n`);
  for (const path of ['src', 'bin', 'install.sh']) cpSync(join(PACKAGE_DIR, path), join(root, path), { recursive: true });
  const file = join(dir, 'archive.tgz');
  execFileSync('tar', ['-czf', file, '-C', dir, 'package']);
  return readFileSync(file);
}

/**
 * The modules' host, on 127.0.0.1: it answers as the real one does — 401 with
 * no or an unknown Basic credential, 403 when the credential is not allowed the
 * publication the path names, 404 when there is no such file — and records
 * every request.
 *
 * @param {{publications?: string[]}} [access] the publications the fake credential is allowed; all when absent
 */
export async function startHost(access = {}) {
  const files = new Map();
  const indexes = new Map();
  const requests = [];
  const overrides = new Map();
  const expected = `Basic ${Buffer.from(`${LOGIN}:${PASSWORD}`).toString('base64')}`;
  const server = createServer((req, res) => {
    requests.push({ path: req.url, authorized: req.headers.authorization === expected, authorization: req.headers.authorization });
    const override = overrides.get(req.url);
    if (override) {
      res.writeHead(override.status, override.headers ?? {});
      res.end(override.body ?? '');
      return;
    }
    if (req.headers.authorization !== expected) {
      res.writeHead(401, { 'www-authenticate': 'Basic realm="tooling files"' });
      res.end();
      return;
    }
    const publication = req.url.split('/')[1];
    if (access.publications && !access.publications.includes(publication)) {
      res.writeHead(403);
      res.end();
      return;
    }
    const body = files.get(req.url);
    if (body === undefined) {
      res.writeHead(404);
      res.end();
      return;
    }
    res.writeHead(200);
    res.end(body);
  });
  await new Promise((done) => server.listen(0, '127.0.0.1', done));
  const base = `http://127.0.0.1:${server.address().port}`;
  return {
    base,
    requests,
    /**
     * Publishes an archive and appends it to its module's index, newest last.
     * `sha256` and `url` replace what the index records for it, to plant a
     * mismatch or an archive URL on another host.
     */
    publish(name, version, bytes = makeArchive(name, version), { sha256: recorded, url } = {}) {
      const module = name.split('/')[1];
      const path = `/${module}/archives/${module}-${version}.tgz`;
      files.set(path, bytes);
      const index = indexes.get(module) ?? { name, versions: [] };
      index.versions.push({ version, sha256: recorded ?? sha256(bytes), url: url ?? `${base}${path}` });
      indexes.set(module, index);
      files.set(`/${module}/index.json`, `${JSON.stringify(index, null, 2)}\n`);
      return { url: `${base}${path}`, sha256: sha256(bytes), bytes };
    },
    /** Answers a path with a fixed status from now on, whatever the credential. */
    answer(path, status, body = '') {
      overrides.set(path, { status, body });
    },
    close: () => new Promise((done) => server.close(done)),
  };
}

/**
 * A netrc file holding the fake credential for 127.0.0.1, in a directory of its
 * own; `home` is that directory, for a child process's HOME.
 */
export function fakeNetrc({ login = LOGIN, password = PASSWORD } = {}) {
  const home = tempDir('cognitio-modules-netrc-');
  const file = join(home, '.netrc');
  writeFileSync(file, `machine 127.0.0.1 login ${login} password ${password}\n`, { mode: 0o600 });
  return { home, file };
}

/**
 * A throwaway project. With `packageJson` it carries that package.json; its
 * lockfile maps `@cognitio` to the host given, so `init` reads the stand-in.
 *
 * @param {{host?: string, packageJson?: object, scopes?: Record<string, string>}} [shape]
 */
export function makeProject({ host, packageJson, scopes } = {}) {
  const dir = tempDir('cognitio-modules-project-');
  if (packageJson) writeFileSync(join(dir, 'package.json'), `${JSON.stringify(packageJson, null, 2)}\n`);
  if (host || scopes) {
    writeFileSync(
      join(dir, 'cognitio-modules.json'),
      `${JSON.stringify({ scopes: scopes ?? { '@cognitio': host }, modules: {} }, null, 2)}\n`,
    );
  }
  return dir;
}

/** A runner that records the package-manager commands instead of running them. */
export function recordingRunner(status = 0) {
  const calls = [];
  const run = (command, args, options) => {
    calls.push({ command, args, cwd: options.cwd });
    return status;
  };
  return { calls, run };
}

/** Collects the lines a command reports. */
export function collector() {
  const lines = [];
  return { lines, out: (line) => lines.push(line) };
}
