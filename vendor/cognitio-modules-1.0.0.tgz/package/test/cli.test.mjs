/**
 * cli.test.mjs — the command line: its arguments, `--cwd`, `path`, the
 * question it asks with no command, and its exit statuses.
 *
 * READS and WRITES throwaway projects under the temporary directory only, and
 * reaches the loopback stand-in host only (see helpers.mjs).
 */

import { commandArchive, fakeNetrc, makeProject, recordingRunner, startHost, tempDir } from './helpers.mjs';

import assert from 'node:assert/strict';
import { mkdirSync, readFileSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';
import { after, before, describe, test } from 'node:test';

import { main, parseArgs, USAGE } from '../src/index.mjs';

let host;
let netrc;

before(async () => {
  host = await startHost();
  netrc = fakeNetrc();
  host.publish('@cognitio/modules', '1.0.0', commandArchive('1.0.0'));
  host.publish('@cognitio/alpha', '1.0.0');
  host.publish('@cognitio/alpha', '1.1.0');
});

after(() => host.close());

async function run(argv, extra = {}) {
  const out = [];
  const err = [];
  const code = await main(argv, {
    out: (l) => out.push(l),
    err: (l) => err.push(l),
    confirm: null,
    ask: null,
    netrc: netrc.file,
    run: recordingRunner().run,
    ...extra,
  });
  return { code, out, err };
}

describe('arguments', () => {
  test('options go before or after the command', () => {
    assert.deepEqual(parseArgs(['--cwd', 'docs', 'add', '@cognitio/alpha', '--dev']), {
      cwd: 'docs', yes: false, dev: true, help: false, version: false, command: 'add', argument: '@cognitio/alpha',
    });
    assert.equal(parseArgs(['upgrade', '-y']).yes, true);
  });

  test('a usage error exits 2 and names it', async () => {
    for (const [argv, message] of [
      [['frobnicate'], 'frobnicate is not a command'],
      [['add'], 'add takes one package'],
      [['list', 'extra'], 'list takes no argument'],
      [['--force', 'list'], '--force is not an option'],
      [['--cwd'], '--cwd needs a directory'],
    ]) {
      const result = await run(argv);
      assert.equal(result.code, 2, argv.join(' '));
      assert.ok(result.err[0].startsWith(`cognitio-modules: ${message}`), result.err[0]);
    }
  });

  test('--help prints the usage and exits 0', async () => {
    const result = await run(['--help']);
    assert.equal(result.code, 0);
    assert.deepEqual(result.out, [USAGE]);
  });

  test('--version prints the package version', async () => {
    const result = await run(['--version']);
    assert.deepEqual(result.out, [JSON.parse(readFileSync(new URL('../package.json', import.meta.url), 'utf8')).version]);
  });
});

describe('--cwd', () => {
  test('runs every command against another directory, as from an umbrella root into a submodule', async () => {
    const umbrella = tempDir();
    const submodule = join(umbrella, 'docs');
    mkdirSync(submodule);
    writeFileSync(join(submodule, 'cognitio-modules.json'), JSON.stringify({ scopes: { '@cognitio': host.base }, modules: {} }));
    const init = await run(['--cwd', submodule, 'init']);
    assert.equal(init.code, 0, init.err.join('\n'));
    const added = await run(['--cwd', submodule, 'add', '@cognitio/alpha@1.0.0']);
    assert.equal(added.code, 0, added.err.join('\n'));
    assert.ok(added.out.includes('Nothing is committed: review the change with git diff, and commit it.'));
    const listed = await run(['list', '--cwd', submodule]);
    assert.equal(listed.code, 0);
    assert.ok(listed.out.some((l) => /^@cognitio\/alpha +1\.0\.0 +newest 1\.1\.0$/.test(l)), listed.out.join('\n'));
    const checked = await run(['--cwd', submodule, 'check'], { netrc: join(umbrella, 'none') });
    assert.equal(checked.code, 0);
    const path = await run(['--cwd', submodule, 'path', '@cognitio/alpha'], { processCwd: umbrella });
    assert.deepEqual(path.out, ['./docs/vendor/cognitio-alpha-1.0.0.tgz']);
    const fromInside = await run(['--cwd', submodule, 'path', '@cognitio/alpha'], { processCwd: submodule });
    assert.deepEqual(fromInside.out, ['./vendor/cognitio-alpha-1.0.0.tgz']);
    assert.ok(readFileSync(join(umbrella, 'docs', 'cognitio-modules.json'), 'utf8').includes('"@cognitio/alpha"'));
  });

  test('a directory that does not exist is a usage error', async () => {
    const result = await run(['--cwd', join(tempDir(), 'absent'), 'list']);
    assert.equal(result.code, 2);
    assert.match(result.err[0], /is not a directory$/);
  });
});

describe('exit statuses', () => {
  test('check exits 1 on a difference, 0 when everything matches', async () => {
    const dir = makeProject({ host: host.base });
    assert.equal((await run(['--cwd', dir, 'init'])).code, 0);
    assert.equal((await run(['--cwd', dir, 'check'])).code, 0);
    const file = join(dir, 'vendor', 'cognitio-modules-1.0.0.tgz');
    writeFileSync(file, 'changed');
    const result = await run(['--cwd', dir, 'check']);
    assert.equal(result.code, 1);
    assert.match(result.out[0], /differs from cognitio-modules\.json/);
  });

  test('a host answering 401 exits 1 with its message on standard error', async () => {
    const dir = makeProject({ host: host.base });
    const result = await run(['--cwd', dir, 'init'], { netrc: join(dir, 'none') });
    assert.equal(result.code, 1);
    assert.deepEqual(result.out, []);
    assert.match(result.err[0], /^cognitio-modules: http:\/\/127\.0\.0\.1:\d+\/modules\/index\.json answered 401: no credential for 127\.0\.0\.1/);
  });
});

describe('with no command', () => {
  test('in a terminal it asks what to do, then does it', async () => {
    const dir = makeProject({ host: host.base });
    assert.equal((await run(['--cwd', dir, 'init'])).code, 0);
    const answers = ['add', '@cognitio/alpha'];
    const result = await run(['--cwd', dir], { ask: async () => answers.shift() });
    assert.equal(result.code, 0, result.err.join('\n'));
    assert.ok(result.err.includes('What do you want to do?'));
    assert.ok(result.out.some((l) => l.startsWith('vendored @cognitio/alpha 1.1.0')));
  });

  test('a choice by number works too', async () => {
    const dir = makeProject({ host: host.base });
    assert.equal((await run(['--cwd', dir, 'init'])).code, 0);
    const result = await run(['--cwd', dir], { ask: async () => '1' });
    assert.equal(result.code, 0);
    assert.ok(result.out.some((l) => l.startsWith('@cognitio/modules')));
  });

  test('outside a terminal it prints the usage and exits 2', async () => {
    const result = await run([]);
    assert.equal(result.code, 2);
    assert.deepEqual(result.err, [USAGE]);
  });
});
