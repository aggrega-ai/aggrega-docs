/**
 * units.test.mjs — the lockfile's format, the netrc reader, the archive reader
 * and the network guard, each on its own.
 *
 * READS and WRITES nothing outside the temporary directory.
 */

import { makeArchive, tempDir } from './helpers.mjs';
import { networkAttempts } from './no-network.mjs';

import assert from 'node:assert/strict';
import { writeFileSync } from 'node:fs';
import { join } from 'node:path';
import { describe, test } from 'node:test';

import { archivePathOf, authorizationFor, formatLockfile, isSendable, parseLockfile } from '../src/index.mjs';
import { parseNetrc } from '../src/netrc.mjs';
import { manifestOf, readArchiveFile } from '../src/tarball.mjs';

const SHA = 'a'.repeat(64);

describe('the lockfile format', () => {
  test('formats canonically: fixed keys, sorted names, two spaces, a final newline', () => {
    const text = formatLockfile({
      scopes: { '@zeta': 'https://z.example', '@cognitio': 'https://tooling.cognitio.it' },
      modules: {
        '@cognitio/l10n': { sha256: SHA, url: 'https://tooling.cognitio.it/l10n/archives/l10n-1.2.0.tgz', version: '1.2.0' },
        '@cognitio/alpha': { version: '1.0.0', url: 'https://tooling.cognitio.it/alpha/archives/alpha-1.0.0.tgz', sha256: SHA },
      },
    });
    assert.equal(
      text,
      `{
  "scopes": {
    "@cognitio": "https://tooling.cognitio.it",
    "@zeta": "https://z.example"
  },
  "modules": {
    "@cognitio/alpha": {
      "version": "1.0.0",
      "url": "https://tooling.cognitio.it/alpha/archives/alpha-1.0.0.tgz",
      "sha256": "${SHA}"
    },
    "@cognitio/l10n": {
      "version": "1.2.0",
      "url": "https://tooling.cognitio.it/l10n/archives/l10n-1.2.0.tgz",
      "sha256": "${SHA}"
    }
  }
}
`,
    );
    assert.equal(formatLockfile(parseLockfile(text)), text);
  });

  test('refuses what is not its shape', () => {
    const good = { scopes: { '@cognitio': 'https://tooling.cognitio.it' }, modules: {} };
    const cases = [
      ['not json', /is not JSON/],
      [JSON.stringify({ ...good, extra: 1 }), /"extra" is not a key of the lockfile/],
      [JSON.stringify({ ...good, scopes: { cognitio: 'https://x' } }), /"cognitio" is not a scope/],
      [JSON.stringify({ ...good, scopes: { '@cognitio': 'https://x/path' } }), /is not a URL of a host alone/],
      [JSON.stringify({ ...good, modules: { l10n: { version: '1.0.0', url: 'https://x/a.tgz', sha256: SHA } } }), /is not a package name/],
      [JSON.stringify({ ...good, modules: { '@cognitio/l10n': { version: '1.0', url: 'https://x/a.tgz', sha256: SHA } } }), /"version" is not a version/],
      [JSON.stringify({ ...good, modules: { '@cognitio/l10n': { version: '1.0.0', url: 'ftp://x/a.tgz', sha256: SHA } } }), /"url" is not an http or https URL/],
      [JSON.stringify({ ...good, modules: { '@cognitio/l10n': { version: '1.0.0', url: 'https://x/a.tgz', sha256: 'ABC' } } }), /"sha256" is not 64 lowercase hex digits/],
      [JSON.stringify({ ...good, modules: { '@cognitio/l10n': { version: '1.0.0', url: 'https://x/a.tgz', sha256: SHA, dev: true } } }), /"dev" is not a key of a module/],
    ];
    for (const [text, message] of cases) assert.throws(() => parseLockfile(text), message, text);
  });

  test('the vendored archive is vendor/<scope>-<module>-<version>.tgz, and nothing else enters its name', () => {
    assert.equal(archivePathOf('@cognitio/l10n', '1.2.0'), 'vendor/cognitio-l10n-1.2.0.tgz');
    assert.equal(archivePathOf('@acme/widget', '2.0.0-rc.1'), 'vendor/acme-widget-2.0.0-rc.1.tgz');
    assert.throws(() => archivePathOf('@cognitio/l10n', '1.2.0/../../x'), /is not a version/);
    assert.throws(() => archivePathOf('@cognitio/../x', '1.0.0'), /is not a package name/);
  });
});

describe('the netrc reader', () => {
  test('reads machine, default, quoted tokens, and skips a macdef', () => {
    const entries = parseNetrc(
      'machine a.example login one password "two words"\n' +
        'macdef init\nmachine evil.example login x password y\n\n' +
        'machine b.example\n  login three\n  password four\ndefault login anyone password anything\n',
    );
    assert.deepEqual(entries, [
      { machine: 'a.example', login: 'one', password: 'two words' },
      { machine: 'b.example', login: 'three', password: 'four' },
      { machine: null, login: 'anyone', password: 'anything' },
    ]);
  });

  test('the credential of the host, else default, else none', () => {
    const file = join(tempDir(), 'netrc');
    writeFileSync(file, 'machine tooling.example login u password p\n');
    assert.equal(authorizationFor('tooling.example', file), `Basic ${Buffer.from('u:p').toString('base64')}`);
    assert.equal(authorizationFor('other.example', file), null);
    assert.equal(authorizationFor('tooling.example', join(tempDir(), 'absent')), null);
    writeFileSync(file, 'default login d password e\n');
    assert.equal(authorizationFor('other.example', file), `Basic ${Buffer.from('d:e').toString('base64')}`);
  });
});

describe('the archive reader', () => {
  test('reads package/package.json and any file of a packed archive', () => {
    const archive = makeArchive('@cognitio/alpha', '1.0.0', { 'install.sh': '#!/bin/sh\n' });
    assert.deepEqual(manifestOf(archive), { name: '@cognitio/alpha', version: '1.0.0' });
    assert.equal(readArchiveFile(archive, 'package/install.sh').toString(), '#!/bin/sh\n');
    assert.equal(readArchiveFile(archive, 'package/absent'), null);
    assert.throws(() => manifestOf(Buffer.from('not an archive')), /not gzipped/);
  });
});

describe('where a request may go', () => {
  test('only to the scope\'s host, over https, or plain http to a loopback host', () => {
    const cases = [
      ['https://tooling.cognitio.it/l10n/index.json', 'https://tooling.cognitio.it', true],
      ['https://TOOLING.cognitio.it:443/l10n/index.json', 'https://tooling.cognitio.it', true],
      ['http://127.0.0.1:8080/l10n/index.json', 'http://127.0.0.1:8080', true],
      ['http://[::1]:8080/l10n/index.json', 'http://[::1]:8080', true],
      ['http://localhost:8080/l10n/index.json', 'http://localhost:8080', true],
      ['http://tooling.cognitio.it/l10n/index.json', 'http://tooling.cognitio.it', false],
      ['http://tooling.cognitio.it/l10n/index.json', 'https://tooling.cognitio.it', false],
      ['https://elsewhere.example/l10n/archives/l10n-1.0.0.tgz', 'https://tooling.cognitio.it', false],
      ['https://tooling.cognitio.it.elsewhere.example/x.tgz', 'https://tooling.cognitio.it', false],
      ['https://tooling.cognitio.it:8443/x.tgz', 'https://tooling.cognitio.it', false],
      ['http://127.0.0.1:9090/x.tgz', 'http://127.0.0.1:8080', false],
      ['https://user:pass@tooling.cognitio.it/x.tgz', 'https://tooling.cognitio.it', false],
      ['ftp://tooling.cognitio.it/x.tgz', 'https://tooling.cognitio.it', false],
      ['not a url', 'https://tooling.cognitio.it', false],
    ];
    for (const [url, host, expected] of cases) assert.equal(isSendable(url, host), expected, `${url} → ${host}`);
  });
});

describe('the network guard', () => {
  test('refuses a connection to any host but the loopback interface', async () => {
    const before = networkAttempts().length;
    await assert.rejects(fetch('http://192.0.2.1/index.json'));
    const refused = networkAttempts().slice(before);
    assert.ok(refused.length > 0 && refused.every((target) => target.startsWith('192.0.2.1:')), refused.join(', '));
  });
});
