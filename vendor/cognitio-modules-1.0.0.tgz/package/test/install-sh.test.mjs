/**
 * install-sh.test.mjs — the project's entry point, `install.sh`, run by `sh`
 * as a developer runs it: the first `init` with nothing but the script and a
 * credential, every later command from the vendored copy with no credential,
 * `--cwd` from a parent directory, and its 401/403/404 words.
 *
 * RUNS sh, curl, tar and node on PATH against the loopback stand-in host, with
 * HOME pointed at a throwaway directory holding a fake netrc (or none), so
 * neither the developer's ~/.netrc nor a proxy is ever used.
 */

import { commandArchive, fakeNetrc, makeProject, PACKAGE_DIR, startHost, tempDir } from './helpers.mjs';

import assert from 'node:assert/strict';
import { spawn, spawnSync } from 'node:child_process';
import { copyFileSync, existsSync, mkdirSync, readFileSync, unlinkSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';
import { after, before, describe, test } from 'node:test';

import { formatLockfile, readLockfile, refusalMessage, statusMessage } from '../src/index.mjs';

let host;
let netrc;

before(async () => {
  host = await startHost();
  netrc = fakeNetrc();
  host.publish('@cognitio/modules', '1.0.0', commandArchive('1.0.0'));
  host.publish('@cognitio/alpha', '1.0.0');
});

after(() => host.close());

/** A child still running after this long is killed, and its null status fails the test. */
const CHILD_TIMEOUT_MS = 60_000;

/**
 * Runs `sh install.sh <args>` in `dir` and resolves with its status and output.
 * The child runs asynchronously: the stand-in host lives in this process, so a
 * synchronous spawn would block the event loop that has to answer the child.
 */
function sh(dir, args, home, extraEnv = {}) {
  const env = { ...process.env, HOME: home, NO_PROXY: '*', no_proxy: '*', ...extraEnv };
  for (const name of ['http_proxy', 'https_proxy', 'HTTP_PROXY', 'HTTPS_PROXY', 'ALL_PROXY', 'all_proxy', 'NODE_USE_ENV_PROXY']) delete env[name];
  return new Promise((resolve, reject) => {
    const child = spawn('sh', ['install.sh', ...args], { cwd: dir, env, timeout: CHILD_TIMEOUT_MS });
    let stdout = '';
    let stderr = '';
    child.stdout.setEncoding('utf8').on('data', (chunk) => (stdout += chunk));
    child.stderr.setEncoding('utf8').on('data', (chunk) => (stderr += chunk));
    child.on('error', reject);
    child.on('close', (status, signal) => resolve({ status, signal, stdout, stderr }));
  });
}

function withScript(dir) {
  copyFileSync(join(PACKAGE_DIR, 'install.sh'), join(dir, 'install.sh'));
  return dir;
}

const archiveRequests = () => host.requests.filter((r) => r.path.startsWith('/modules/archives/')).length;

/**
 * A `curl` placed first on PATH that records each call's arguments, one line
 * each, and then runs the real curl: `calls()` lists them, so a test shows
 * which URLs install.sh handed to curl — none, for a URL it refuses.
 */
function curlShim() {
  const real = spawnSync('sh', ['-c', 'command -v curl'], { encoding: 'utf8' }).stdout.trim();
  assert.ok(real, 'curl is on PATH');
  const dir = tempDir('cognitio-modules-curl-');
  const log = join(dir, 'calls.log');
  writeFileSync(join(dir, 'curl'), `#!/bin/sh\nprintf '%s\\n' "$*" >> '${log}'\nexec '${real}' "$@"\n`, { mode: 0o755 });
  return {
    env: { PATH: `${dir}:${process.env.PATH}` },
    calls: () => (existsSync(log) ? readFileSync(log, 'utf8').split('\n').filter(Boolean) : []),
  };
}

describe('install.sh', () => {
  test('the first init gets the command from the host; later commands run the vendored copy with no credential', async () => {
    const dir = withScript(makeProject({ host: host.base }));
    const first = await sh(dir, ['init'], netrc.home);
    assert.equal(first.status, 0, first.stderr);
    assert.match(first.stderr, /install\.sh: running @cognitio\/modules 1\.0\.0 from http:\/\/127\.0\.0\.1:\d+\/modules\/archives\/modules-1\.0\.0\.tgz/);
    assert.ok(first.stdout.includes('vendored @cognitio/modules 1.0.0: vendor/cognitio-modules-1.0.0.tgz'), first.stdout);
    assert.equal(readLockfile(dir).modules['@cognitio/modules'].version, '1.0.0');

    const seen = host.requests.length;
    const noCredential = tempDir();
    const check = await sh(dir, ['check'], noCredential);
    assert.equal(check.status, 0, check.stderr);
    assert.equal(check.stderr, '');
    const path = await sh(dir, ['path', '@cognitio/modules'], noCredential);
    assert.equal(path.stdout, './vendor/cognitio-modules-1.0.0.tgz\n');
    assert.equal(host.requests.length, seen, 'check and path made no request');

    const before = archiveRequests();
    const added = await sh(dir, ['add', '@cognitio/alpha'], netrc.home);
    assert.equal(added.status, 0, added.stderr);
    assert.equal(archiveRequests(), before, 'the vendored command ran; it was not downloaded again');
  });

  test('a vendored command that is missing is downloaded at the pinned version and checked', async () => {
    const dir = withScript(makeProject({ host: host.base }));
    assert.equal((await sh(dir, ['init'], netrc.home)).status, 0);
    const restored = await sh(dir, ['install'], netrc.home);
    assert.equal(restored.status, 0, restored.stderr);
    unlinkSync(join(dir, 'vendor', 'cognitio-modules-1.0.0.tgz'));
    const again = await sh(dir, ['install'], netrc.home);
    assert.equal(again.status, 0, again.stderr);
    assert.match(again.stderr, /running @cognitio\/modules 1\.0\.0 from/);
    assert.ok(again.stdout.includes('restored @cognitio/modules 1.0.0: vendor/cognitio-modules-1.0.0.tgz'));
  });

  test('--cwd from a parent directory manages a sub-project with its own lockfile and install.sh', async () => {
    const root = withScript(makeProject({ host: host.base }));
    assert.equal((await sh(root, ['init'], netrc.home)).status, 0);
    const sub = join(root, 'docs');
    mkdirSync(sub);
    writeFileSync(join(sub, 'cognitio-modules.json'), JSON.stringify({ scopes: { '@cognitio': host.base }, modules: {} }));
    const init = await sh(root, ['--cwd', 'docs', 'init'], netrc.home);
    assert.equal(init.status, 0, init.stderr);
    assert.ok(existsSync(join(sub, 'install.sh')));
    const added = await sh(root, ['--cwd', 'docs', 'add', '@cognitio/alpha'], netrc.home);
    assert.equal(added.status, 0, added.stderr);
    assert.ok(existsSync(join(sub, 'vendor', 'cognitio-alpha-1.0.0.tgz')));
    assert.equal(readLockfile(root).modules['@cognitio/alpha'], undefined, 'the parent project is unchanged');
  });

  for (const [status, subject] of [[401, 'modules'], [403, 'modules'], [404, 'modules']]) {
    test(`a ${status} from the host is reported in the command's own words`, async () => {
      const own = await startHost();
      own.answer('/modules/index.json', status);
      try {
        const dir = withScript(makeProject({ host: own.base }));
        const result = await sh(dir, ['init'], tempDir());
        assert.equal(result.status, 1);
        const url = `${own.base}/modules/index.json`;
        assert.equal(result.stderr, `install.sh: ${statusMessage(url, status, subject)}\n`);
      } finally {
        await own.close();
      }
    });
  }

  test('an archive whose sha256 is not the index\'s is refused', async () => {
    const own = await startHost();
    own.publish('@cognitio/modules', '1.0.0', commandArchive('1.0.0'), { sha256: '0'.repeat(64) });
    try {
      const dir = withScript(makeProject({ host: own.base }));
      const result = await sh(dir, ['init'], netrc.home);
      assert.equal(result.status, 1);
      assert.match(result.stderr, /has sha256 [0-9a-f]{64}, not 0{64}: the archive is refused/);
      assert.equal(existsSync(join(dir, 'vendor')), false);
    } finally {
      await own.close();
    }
  });

  test('a command archive the lockfile names on another host is refused before curl runs, and that host receives nothing', async () => {
    const other = await startHost();
    const published = other.publish('@cognitio/modules', '1.0.0', commandArchive('1.0.0'));
    try {
      const dir = withScript(makeProject());
      writeFileSync(join(dir, 'cognitio-modules.json'), formatLockfile({
        scopes: { '@cognitio': host.base },
        modules: { '@cognitio/modules': { version: '1.0.0', url: published.url, sha256: published.sha256 } },
      }));
      const curl = curlShim();
      const result = await sh(dir, ['list'], netrc.home, curl.env);
      assert.equal(result.status, 1);
      assert.equal(result.stderr, `install.sh: ${refusalMessage(published.url, '@cognitio', host.base)}\n`);
      assert.deepEqual(curl.calls(), [], 'curl was never invoked');
      assert.equal(other.requests.length, 0, 'the other host received no request');
    } finally {
      await other.close();
    }
  });

  test('a command archive the index names on another host is refused: curl reads the index alone', async () => {
    const own = await startHost();
    const other = await startHost();
    const elsewhere = `${other.base}/modules/archives/modules-1.0.0.tgz`;
    other.publish('@cognitio/modules', '1.0.0', commandArchive('1.0.0'));
    own.publish('@cognitio/modules', '1.0.0', commandArchive('1.0.0'), { url: elsewhere });
    try {
      const dir = withScript(makeProject({ host: own.base }));
      const curl = curlShim();
      const result = await sh(dir, ['init'], netrc.home, curl.env);
      assert.equal(result.status, 1);
      assert.equal(result.stderr, `install.sh: ${refusalMessage(elsewhere, '@cognitio', own.base)}\n`);
      const calls = curl.calls();
      assert.equal(calls.length, 1, calls.join('\n'));
      assert.ok(calls[0].endsWith(`${own.base}/modules/index.json`), calls[0]);
      assert.equal(other.requests.length, 0, 'the other host received no request');
      assert.equal(existsSync(join(dir, 'vendor')), false);
    } finally {
      await own.close();
      await other.close();
    }
  });

  test('a lockfile mapping @cognitio to a non-loopback plain-http host is refused before curl runs', async () => {
    const dir = withScript(makeProject({ scopes: { '@cognitio': 'http://192.0.2.1' } }));
    const curl = curlShim();
    const result = await sh(dir, ['init'], netrc.home, curl.env);
    assert.equal(result.status, 1);
    assert.equal(result.stderr, `install.sh: ${refusalMessage('http://192.0.2.1/modules/index.json', '@cognitio', 'http://192.0.2.1')}\n`);
    assert.deepEqual(curl.calls(), [], 'curl was never invoked');
  });

  test('is the file the package ships, carrying the line that lets the command replace it', () => {
    const text = readFileSync(join(PACKAGE_DIR, 'install.sh'), 'utf8');
    assert.ok(text.startsWith('#!/bin/sh\n'));
    assert.ok(text.includes('# Written by cognitio-modules, which replaces this file when it upgrades itself.'));
    // `sh -n` only parses the file; it reaches no host, so a synchronous spawn is safe here.
    assert.equal(spawnSync('sh', ['-n', join(PACKAGE_DIR, 'install.sh')]).status, 0);
  });
});
