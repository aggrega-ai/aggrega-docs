# Changelog

Each version of `@cognitio/modules` is a git tag of its repository,
`modules-vX.Y.Z`, whose release publishes the archive a project vendors from
`https://tooling.cognitio.it/modules/archives/modules-X.Y.Z.tgz`, and
`https://tooling.cognitio.it/modules/install.sh`, the script a project starts
from; `https://tooling.cognitio.it/modules/index.json` lists every published
version with its archive's sha256. 1.0.0 holds every feature the package has at
its first release; a feature added after it is recorded under the next version,
above this one.

## 1.0.0

- `cognitio-modules`, run through a project's `install.sh`: `init`, `add`,
  `remove`, `upgrade`, `list`, `install`, `path` and `check`, with `--cwd` to
  run against another directory, `--yes` to accept every upgrade and `--dev` for
  a module new to `package.json`; with no command in a terminal, it asks what to
  do.
- Each module is vendored as its published archive at
  `vendor/<scope>-<module>-<version>.tgz`, and a project's `package.json` depends
  on it as `file:vendor/<archive>`; `npm install`, and `npx -y bun install` where a
  `bun.lock` is kept, refresh the project's lockfiles.
- The lockfile `cognitio-modules.json` maps each scope to its host and records
  each module's version, archive URL and sha256, in one canonical form.
- The credential is read from `~/.netrc` and never printed, logged or written,
  and is sent over https alone, only to the host the lockfile maps the package's
  scope to: any other URL, from an index or from the lockfile, is refused before
  anything is sent, by the command and by `install.sh` alike (plain http to a
  loopback host alone is allowed);
  an archive whose sha256 is not its index's is refused and nothing is written; a
  file the command did not write is replaced only on the developer's yes.
- The commands are exported as library functions, for a tool such as a local
  admin page.
