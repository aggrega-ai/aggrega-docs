/**
 * session.mjs — Translating in a session: the translations are written by the
 * agents of an AI coding session, while the package plans the work, states the
 * rules and checks every translation before it reaches the memory.
 *
 *   l10n session export [--work <dir>] [--words <n>] [--batches <n>]
 *   l10n session import [--work <dir>] [--batch <ids>] [--model <name>]
 *   l10n session status [--work <dir>]
 *
 * It is a third transport beside the Messages API and the Message Batches API,
 * for a project that translates with no API key and no command-line model: the
 * session that runs these commands starts one agent per batch, each agent reads
 * the instructions and its batch and writes its translations to files, and
 * `import` applies them as `collect` applies a batch.
 *
 * READS the configuration's adapter pages, the catalogue (which `export` extracts
 * first), both memory layers, the recorded sources, the glossary, the prompt files
 * (`export`) and the work directory. WRITES the work directory, and, in `import`
 * alone and through the store, the machine layer, its sources, the source map and
 * one job log per batch. It never writes the human layer, makes no network call
 * and starts no process: the agents are the session's.
 *
 * THE WORK DIRECTORY, `<memory.dir>/session/` unless `--work` names another,
 * belongs to the session and is never committed:
 *   INSTRUCTIONS.<locales>.md    what an agent reads first: the formats below, the
 *                                package's rules, the glossary, the project's general
 *                                prompt and the terminology and language guide of each
 *                                locale its batches are written in, one file per distinct
 *                                set of locales (`instructionsName`); `export` rewrites
 *                                one when its text changes. A batch's task names its file.
 *   INSTRUCTIONS.md              the instructions of every configured locale, as a
 *                                version before the per-locale files wrote them; still
 *                                read by the batches exported then, and never rewritten.
 *   queue.json                   the session's resubmission queue, in the pending
 *                                file's shape (`pending.mjs`): per locale, per segment,
 *                                the attempts made and the defect the next batch states.
 *   batches/<NNNN>/task.json     the batch, as an agent reads it.
 *   batches/<NNNN>/plan.json     what `import` checks the batch against: each requested
 *                                unit as the catalogue held it, its attempt and revision.
 *   batches/<NNNN>/<locale>.txt  one output file per locale, written by the agent.
 *   batches/<NNNN>/done          written by the agent last, once every output file is.
 *   batches/<NNNN>/result.json   written by `import`: the batch is applied.
 *
 * A BATCH is whole pages, or runs of sections of a long page, in the adapter's
 * page order, up to `--words` source words to translate, with every locale of a
 * segment in the same batch: the agent reads the source once and writes it in
 * each language. The pages are cut into sections exactly as for a request
 * (`planRequests`, `backend.sectionTokens`), each section given the sections on
 * either side of it as context, and the sections of one page in one batch are
 * joined, each segment listed once. A segment in a batch not yet imported is
 * never planned again, so batches can be translated side by side; nor is one a
 * recorded Message Batch holds (`batchHeldPairs`), so a session and `submit` can
 * run side by side, and `export` says how many pairs each held back. A pair
 * marked for re-translation (`retranslate.mjs`) is planned beside the missing
 * ones, as a revision of itself, and its accepted translation clears its mark.
 *
 * THE OUTPUT FORMAT is plain text, so an agent escapes nothing: each segment is a
 * line `@@@ <id>` and its translation on the lines up to the next. The format
 * cannot carry a translation's leading or trailing whitespace, so `import` gives
 * each translation its source's (rule 4).
 *
 * IMPORT applies a batch whose `done` file exists, or one `--batch` names: every
 * locale's output file is validated with the one validation (`validate.mjs`), the
 * accepted translations are written to the machine layer (`machineEntry`), each
 * rejected one is queued with its defect, which the next batch states for it, up
 * to `backend.attempts` attempts, and a locale whose output file is absent
 * returns to the pool unqueued, since no translation of it was judged; so does a
 * segment the validation could not judge, a failure of the package rather than of
 * the translation, named in the output and the job log's `internal`. A batch
 * is applied once: its `result.json` marks it.
 */

import { createHash } from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';

import { planRequests } from './requests.mjs';
import { findRevisions } from './revisions.mjs';
import { recordedText, returnedTexts, validateTranslations } from './validate.mjs';
import { batchHeldPairs, clearQueued, queueDefect } from './pending.mjs';
import { withoutHeld } from './gate.mjs';
import { markedFromStore, markLines, recordedRevision, settleAccepted, withMarked, withMarkedRevisions } from './retranslate.mjs';
import { machineEntry } from './engine.mjs';
import { doNotTranslateOf, FORCED_REVISE_SENTENCE, glossaryTerms, languageName, REVISE_SENTENCE, terminologyRules, translationRules } from './translator-prompt.mjs';
import { LAYER, RESULT, STATUS } from './types.mjs';

/** The default size of a batch: the source words it asks to translate. */
export const DEFAULT_BATCH_WORDS = 3000;

/** The line opening a segment in an output file. */
const HEADER_RE = /^@@@ (\S+)[ \t]*$/;

const WORD = /[\p{L}\p{N}]+/gu;
const wordsOf = (text) => (String(text).match(WORD) || []).length;

const readJson = (file, fallback) => (fs.existsSync(file) ? JSON.parse(fs.readFileSync(file, 'utf8')) : fallback);

/** Writes a file whole: a temporary file, then a rename, so a reader never meets a half-written one. */
function writeWhole(file, text) {
  fs.mkdirSync(path.dirname(file), { recursive: true });
  const tmp = `${file}.tmp-${process.pid}-${Math.random().toString(36).slice(2)}`;
  fs.writeFileSync(tmp, text, 'utf8');
  fs.renameSync(tmp, file);
}
const writeJson = (file, value) => writeWhole(file, JSON.stringify(value, null, 2) + '\n');

/**
 * The work directory's layout.
 *
 * @param {string} root  the work directory, absolute.
 */
export function sessionPaths(root) {
  return {
    root,
    // The one instructions file versions before 1.3.1 wrote, kept for their batches; `instructionsName` names the rest.
    instructions: path.join(root, 'INSTRUCTIONS.md'),
    queue: path.join(root, 'queue.json'),
    batches: path.join(root, 'batches'),
    batch: (id) => path.join(root, 'batches', id),
  };
}

/** The session's resubmission queue (`queue.json`), in the pending file's shape; empty when there is none. */
export function readSessionQueue(work) {
  return readJson(sessionPaths(work).queue, {});
}

/** Writes the session's resubmission queue whole. */
export function writeSessionQueue(work, queue) {
  writeJson(sessionPaths(work).queue, queue);
}

/** Every batch, in order, with its state: imported, done (waiting for import), or open. */
function listBatches(paths) {
  if (!fs.existsSync(paths.batches)) return [];
  return fs
    .readdirSync(paths.batches)
    .filter((name) => /^\d{4,}$/.test(name))
    .sort()
    .map((id) => {
      const dir = paths.batch(id);
      return { id, dir, imported: fs.existsSync(path.join(dir, 'result.json')), done: fs.existsSync(path.join(dir, 'done')) };
    });
}

/** Per locale, the segments some batch not yet imported asks for. */
function openPairs(paths) {
  const open = new Map();
  for (const batch of listBatches(paths)) {
    if (batch.imported) continue;
    const plan = readJson(path.join(batch.dir, 'plan.json'), { requested: {} });
    for (const [lang, ids] of Object.entries(plan.requested || {})) {
      if (!open.has(lang)) open.set(lang, new Set());
      for (const id of ids) open.get(lang).add(id);
    }
  }
  return open;
}

/**
 * The (segment, locale) pairs a session holds: those its batches not yet imported
 * ask for, which no other transport plans meanwhile. A work directory that does
 * not exist holds none.
 *
 * @param {string} work  the work directory, absolute.
 * @returns {Map<string, Set<string>>}  locale → the segments held in it.
 */
export function sessionHeldPairs(work) {
  return openPairs(sessionPaths(work));
}

/** The longest name `instructionsName` spells out; a longer locale set is named by a digest. */
const MAX_INSTRUCTIONS_NAME = 100;

/**
 * The file name of the instructions for a set of locales: `INSTRUCTIONS.<a>+<b>.md`,
 * or `INSTRUCTIONS.<digest>.md` when the locales spelled out would make it longer
 * than `MAX_INSTRUCTIONS_NAME`.
 *
 * @param {string[]} locales  in the order the batch lists them.
 */
export function instructionsName(locales) {
  const spelled = `INSTRUCTIONS.${locales.join('+')}.md`;
  if (spelled.length <= MAX_INSTRUCTIONS_NAME) return spelled;
  return `INSTRUCTIONS.${createHash('sha256').update(locales.join('+')).digest('hex').slice(0, 12)}.md`;
}

/**
 * The instructions an agent reads before its batch: the batch and output
 * formats, then the package's rules (`translationRules`), the glossary
 * (`glossaryTerms`, and `terminologyRules` per locale), the project's general
 * prompt and the language guide of each locale, each as the package or the
 * project writes it. `export` writes one per set of locales its batches are
 * written in, so an agent reads only the guides of the locales it writes.
 *
 * @param {Object} args
 * @param {string} args.sourceLang
 * @param {string[]} args.targets          the locales of the batches that read them.
 * @param {Object} [args.glossary]
 * @param {string|null} [args.generalPrompt]
 * @param {Object.<string,string>} args.prompts  locale → its language guide.
 * @returns {string}
 */
export function sessionInstructions({ sourceLang, targets, glossary = {}, generalPrompt = null, prompts }) {
  const names = (glossary && glossary.target_lang_names) || {};
  const source = languageName(sourceLang, names);
  return [
    `# Translating a batch from ${source}`,
    '',
    `You translate segments of a site or a documentation corpus from ${source} into several languages at once. A batch is one file, \`task.json\`: read it once, then write one output file per locale.`,
    '',
    '## The batch',
    '',
    '`task.json` holds:',
    '',
    '- `instructions`: the file of these instructions.',
    '- `locales`: the target locales of the batch.',
    '- `output`: for each locale, the absolute path of the file you write its translations to.',
    '- `done`: the absolute path of the file you write last, holding `ok`, once every output file is written.',
    '- `chunks`: the parts of pages to translate, in reading order. A chunk is a whole page, or a run of sections of a long page, given with the sections around it as context:',
    '  - `page`: the page. `outline`, for a long page: every section of the page in order, with its headings, so you see where the chunk sits.',
    '  - `segments`: the source segments in reading order, each `{ "id", "format", "context"?, "source", "translate"?, "keep"?, "revise"?, "corrections"? }`.',
    '    - A segment without `translate` is context: read it, and never translate it or write it to an output file. The import discards every identifier the batch does not ask for, so writing one is wasted work.',
    '    - `translate` is `"all"`, every locale of the batch, or the list of the locales to translate the segment into.',
    '    - `format` is `markdown`, `html` or `text`, and rule 3 below says what each keeps.',
    '    - `context` is advisory: it says what the segment is or where it sits. Never translate it.',
    '    - `keep`: the strings rule 3 keeps byte for byte in this segment.',
    `    - \`revise\`: for a locale, an earlier version of the segment's source and that version's translation, or with a \`reason\` the segment's current translation. ${REVISE_SENTENCE} ${FORCED_REVISE_SENTENCE}`,
    '    - `corrections`: for a locale, what was wrong with an earlier translation of this segment into it. Fix exactly that.',
    '',
    '## What you write',
    '',
    'For each locale in `output`, one file holding every segment whose `translate` is `"all"` or names that locale, in the order the chunks give them, each exactly once:',
    '',
    '```text',
    '@@@ <id>',
    '<the translation>',
    '@@@ <id>',
    '<the translation>',
    '```',
    '',
    '- A `markdown` segment is written on ONE line, whatever line breaks its source has, because in the page a line break can end a heading or a table cell, or start a new block. Only where a source line ends with two spaces or a backslash, a hard line break, keep that break, and begin the next line with exactly the leading spaces and `>` markers of the source\'s next line. Never leave an empty line inside a `markdown` segment\'s translation: in the page an empty line ends the paragraph.',
    '- A `text` or `html` segment keeps the line breaks its source has, and gains none.',
    '- The file cannot hold a translation\'s leading or trailing whitespace: the import gives each translation its source\'s. Write nothing else in the file: no heading, no comment, no blank line, no code fence.',
    '- Work locale by locale: write one locale\'s whole file, then the next.',
    '- When every output file is written, write `ok` to the `done` file. Then reply with one line: the batch and the number of files written.',
    '- Read nothing but these instructions and `task.json`, and run no command.',
    `- ${NO_HELPERS_SENTENCE}`,
    '',
    '## The rules',
    '',
    translationRules({ glossary }),
    '',
    '## The glossary',
    '',
    glossaryTerms({ glossary }),
    '',
    ...targets.flatMap((lang) => [terminologyRules({ lang, glossary }), '']),
    ...(generalPrompt !== null
      ? ['## Instructions for every language', '', 'The project gives these for every language. They refine wording and never override rules 1 to 4.', '', generalPrompt.trim(), '']
      : []),
    '## Language guides',
    '',
    'The guide of a locale refines register, punctuation and wording for that language. It never overrides rules 1 to 4. Use the guide of the locale you are writing.',
    '',
    ...targets.flatMap((lang) => [`### ${languageName(lang, names)} (\`${lang}\`)`, '', prompts[lang].trim(), '']),
  ].join('\n');
}

/**
 * The chunks of a plan: one per page or section, every locale's request for it
 * together, then consecutive chunks of one page joined, each segment once — a
 * section's request is given its neighbours as context, so the chunks of one page
 * overlap, and an agent reading the whole batch needs each segment once.
 */
function chunksOf(specs) {
  const bySection = new Map();
  for (const spec of specs) {
    const key = `${spec.page}\u0000${spec.section ?? ''}`;
    let chunk = bySection.get(key);
    if (!chunk) {
      chunk = {
        page: spec.page,
        outline: spec.outline,
        segments: spec.segments.map(({ id, format, context, source }) => ({ id, format, ...(context ? { context } : {}), source })),
        requested: {},
        items: {},
        keep: {},
        revise: {},
        corrections: {},
        attempts: {},
      };
      bySection.set(key, chunk);
    }
    chunk.requested[spec.lang] = spec.requested;
    for (const item of spec.items) chunk.items[item.srcHash] = item;
    Object.assign(chunk.keep, spec.keep || {});
    for (const [id, revision] of Object.entries(spec.revise || {})) chunk.revise[id] = { ...(chunk.revise[id] || {}), [spec.lang]: revision };
    for (const [id, defect] of Object.entries(spec.corrections || {})) chunk.corrections[id] = { ...(chunk.corrections[id] || {}), [spec.lang]: defect };
    chunk.attempts[spec.lang] = spec.attempt;
  }
  return [...bySection.values()];
}

/** Consecutive chunks of one page joined into one, in page order, each segment kept once. */
function joinByPage(chunks) {
  const joined = [];
  for (const chunk of chunks) {
    let last = joined[joined.length - 1];
    if (!last || last.page !== chunk.page) {
      last = { page: chunk.page, outline: chunk.outline, segments: [], seen: new Set(), requested: {}, items: {}, keep: {}, revise: {}, corrections: {}, attempts: {} };
      joined.push(last);
    }
    for (const segment of chunk.segments) {
      if (last.seen.has(segment.id)) continue;
      last.seen.add(segment.id);
      last.segments.push(segment);
    }
    for (const [lang, ids] of Object.entries(chunk.requested)) {
      last.requested[lang] = [...(last.requested[lang] || []), ...ids];
      last.attempts[lang] = { ...(last.attempts[lang] || {}), ...Object.fromEntries(ids.map((id) => [id, chunk.attempts[lang]])) };
    }
    Object.assign(last.items, chunk.items);
    Object.assign(last.keep, chunk.keep);
    for (const [id, byLang] of Object.entries(chunk.revise)) last.revise[id] = { ...(last.revise[id] || {}), ...byLang };
    for (const [id, byLang] of Object.entries(chunk.corrections)) last.corrections[id] = { ...(last.corrections[id] || {}), ...byLang };
  }
  return joined;
}

/** A task's text: one segment per line, so it reads compactly and is still one JSON document. */
function taskText(task) {
  const { chunks, ...head } = task;
  const headText = JSON.stringify(head, null, 2).slice(0, -2);
  const chunkTexts = chunks.map((chunk) => {
    const { segments, ...meta } = chunk;
    const metaText = Object.entries(meta).map(([k, v]) => `${JSON.stringify(k)}: ${JSON.stringify(v)}, `).join('');
    return `    { ${metaText}"segments": [\n${segments.map((s) => `      ${JSON.stringify(s)}`).join(',\n')}\n    ] }`;
  });
  return `${headText},\n  "chunks": [\n${chunkTexts.join(',\n')}\n  ]\n}\n`;
}

/**
 * What keeps a batch to the one agent the session started for it: a session that
 * runs one agent at a time does so to stay within its limits, and an agent that
 * starts others to share the work breaks that.
 */
export const NO_HELPERS_SENTENCE = 'Do all the work yourself: do not start other agents or subagents.';

/** The prompt that starts an agent on a batch. */
export function agentPrompt({ instructions, task }) {
  return `Translate the batch in ${task}. First read ${instructions} and follow it exactly; then read ${task}, write every output file it names, and last its done file. Only read and write files, and run no command. ${NO_HELPERS_SENTENCE} Reply with one line.`;
}

/**
 * Writes the next batches of the missing segments.
 *
 * @param {Object} args
 * @param {ReturnType<import('./engine.mjs').createEngine>} args.engine
 * @param {Object} args.adapter
 * @param {string} args.sourceLang
 * @param {string[]} [args.allTargets] every target locale of the configuration; unused, kept for callers that pass it.
 * @param {string[]} args.targets      the locales to plan.
 * @param {import('./config.mjs').TranslationSettings} args.settings  `sectionTokens` and `attempts`.
 * @param {Object} [args.glossary]
 * @param {Object.<string,string>} args.prompts  locale → its language guide, for every locale of `targets`.
 * @param {string|null} [args.generalPrompt]
 * @param {string} args.work           the work directory, absolute.
 * @param {number} [args.words]        the source words a batch asks to translate, at most, beyond a single chunk.
 * @param {number} [args.batches]      how many batches to write.
 * @param {() => string} [args.now]
 * @param {(...a:any[])=>void} [args.log]
 * @returns {Promise<{code:number, written:string[]}>}
 */
export async function sessionExport({
  engine,
  adapter,
  sourceLang,
  targets,
  settings,
  glossary = {},
  prompts,
  generalPrompt = null,
  work,
  words = DEFAULT_BATCH_WORDS,
  batches = 1,
  now = () => new Date().toISOString(),
  log = (...a) => console.log(...a),
}) {
  const paths = sessionPaths(work);

  const { unitCount } = await engine.extract();
  const store = engine.store;
  // What is missing, and the pairs marked for re-translation beside it, each planned as a revision of itself.
  const marked = markedFromStore(store, targets);
  const worklist = withMarked(engine.gate({ targets }), marked, targets);
  if (worklist.status !== 'work') {
    log(`session export: ${unitCount} source units; nothing to translate into ${targets.join(', ')}.`);
    return { code: 0, written: [] };
  }
  if (marked.count > 0) log(`session export: ${marked.count} pair(s) marked for re-translation are planned beside what is missing.`);
  // A pair a batch of this session not yet imported holds, or a recorded Message Batch, is planned by neither again.
  const inSession = withoutHeld(worklist, openPairs(paths));
  const inBatches = withoutHeld(inSession.worklist, batchHeldPairs(store.readPending()));
  if (inSession.skipped > 0) {
    log(`session export: ${inSession.skipped} segment-locale pair(s) are in batches of this session not yet imported and are not planned again.`);
  }
  if (inBatches.skipped > 0) {
    log(`session export: ${inBatches.skipped} segment-locale pair(s) are held by a recorded Message Batch (${store.paths.pending}) and are left to \`l10n collect\`.`);
  }
  const items = inBatches.worklist.items;
  if (items.length === 0) {
    log(
      inSession.skipped > 0 && inBatches.skipped === 0
        ? 'session export: every missing segment is in a batch not yet imported.'
        : 'session export: every missing segment is in a batch not yet imported or a recorded Message Batch.'
    );
    return { code: 0, written: [] };
  }

  const tmByLang = store.readAllTM(targets);
  const queue = readSessionQueue(work);
  const pending = { ...worklist, items };
  const plan = planRequests({
    pages: await adapter.pages(),
    worklist: pending,
    tmByLang,
    targets,
    sectionTokens: settings.sectionTokens,
    attemptLimit: settings.attempts,
    queue,
    // A marked pair is a revision of itself, kept out of the search for changed segments' earlier versions.
    revisions: withMarkedRevisions(
      findRevisions({ worklist: withoutHeld(pending, marked.pairs).worklist, tmByLang, sources: store.readRecordedSources(), targets }),
      marked
    ),
  });

  // Batches of whole chunks in page order, each at most `words` words to translate unless one chunk alone is more.
  const chunkWords = (chunk) => Object.values(chunk.items).reduce((n, item) => n + wordsOf(item.source), 0);
  const groups = [];
  let current = null;
  for (const chunk of chunksOf(plan.specs)) {
    const w = chunkWords(chunk);
    if (current && current.words + w > words) {
      groups.push(current);
      current = null;
      if (groups.length === batches) break;
    }
    if (!current) current = { chunks: [], words: 0 };
    current.chunks.push(chunk);
    current.words += w;
  }
  if (current && groups.length < batches) groups.push(current);

  const existing = listBatches(paths).map((b) => Number(b.id));
  let next = existing.length ? Math.max(...existing) + 1 : 1;
  const written = [];
  for (const group of groups) {
    const id = String(next++).padStart(4, '0');
    const dir = paths.batch(id);
    const chunks = joinByPage(group.chunks);
    const requested = {};
    const attempts = {};
    const revisions = {};
    const planItems = {};
    for (const chunk of chunks) {
      for (const [lang, ids] of Object.entries(chunk.requested)) {
        requested[lang] = [...(requested[lang] || []), ...ids];
        attempts[lang] = { ...(attempts[lang] || {}), ...chunk.attempts[lang] };
      }
      for (const [itemId, byLang] of Object.entries(chunk.revise)) {
        for (const [lang, r] of Object.entries(byLang)) revisions[lang] = { ...(revisions[lang] || {}), [itemId]: recordedRevision(r) };
      }
      for (const [itemId, item] of Object.entries(chunk.items)) {
        planItems[itemId] = {
          source: item.source,
          format: item.format,
          ...(item.context !== undefined ? { context: item.context } : {}),
          ...(item.protected !== undefined ? { protected: item.protected } : {}),
        };
      }
    }
    const locales = targets.filter((lang) => requested[lang] && requested[lang].length > 0);
    // The instructions of exactly the batch's locales, one file per set, rewritten only when their text changes.
    const instructionsFile = path.join(paths.root, instructionsName(locales));
    const instructions = sessionInstructions({ sourceLang, targets: locales, glossary, generalPrompt, prompts });
    if (!fs.existsSync(instructionsFile) || fs.readFileSync(instructionsFile, 'utf8') !== instructions) writeWhole(instructionsFile, instructions);
    const task = {
      batch: id,
      instructions: instructionsFile,
      locales,
      output: Object.fromEntries(locales.map((lang) => [lang, path.join(dir, `${lang}.txt`)])),
      done: path.join(dir, 'done'),
      chunks: chunks.map((chunk) => ({
        page: chunk.page,
        ...(chunk.outline ? { outline: chunk.outline } : {}),
        segments: chunk.segments.map((segment) => {
          const langs = locales.filter((lang) => (chunk.requested[lang] || []).includes(segment.id));
          if (langs.length === 0) return segment;
          const revise = chunk.revise[segment.id]
            ? Object.fromEntries(
                Object.entries(chunk.revise[segment.id]).map(([lang, r]) => [
                  lang,
                  { source: r.source, translation: r.translation, ...(r.reviewed ? { reviewed: true } : {}), ...(r.forced ? { reason: r.reason } : {}) },
                ])
              )
            : null;
          return {
            ...segment,
            translate: langs.length === locales.length ? 'all' : langs,
            ...(chunk.keep[segment.id] ? { keep: chunk.keep[segment.id] } : {}),
            ...(revise ? { revise } : {}),
            ...(chunk.corrections[segment.id] ? { corrections: chunk.corrections[segment.id] } : {}),
          };
        }),
      })),
    };
    writeJson(path.join(dir, 'plan.json'), { batch: id, createdAt: now(), words: group.words, requested, attempts, revisions, items: planItems });
    writeWhole(path.join(dir, 'task.json'), taskText(task));
    written.push(id);
    const pageCount = new Set(chunks.map((c) => c.page)).size;
    log(`session export: batch ${id}: ${group.words} words on ${pageCount} page${pageCount === 1 ? '' : 's'}, into ${locales.join(', ')}.`);
    log(`  agent prompt: ${agentPrompt({ instructions: instructionsFile, task: path.join(dir, 'task.json') })}`);
  }
  for (const [lang, ids] of Object.entries(plan.exhausted)) {
    if (ids.length) log(`session export: ${lang}: ${ids.length} segment(s) rejected ${settings.attempts} times are left out; \`l10n session status\` lists them.`);
  }
  return { code: 0, written };
}

/**
 * The entries of an output file: each `@@@ <id>` line and the lines up to the
 * next, its text without the lines' trailing line break.
 *
 * @param {string} text
 * @returns {Array<{id:string, text:string}>}
 */
export function parseSessionOutput(text) {
  const entries = [];
  let current = null;
  for (const line of String(text).replace(/\r\n/g, '\n').split('\n')) {
    const header = HEADER_RE.exec(line);
    if (header) {
      current = { id: header[1], lines: [] };
      entries.push(current);
    } else if (current) current.lines.push(line);
  }
  return entries.map((e) => ({ id: e.id, text: e.lines.join('\n').replace(/^\n+|\n+$/g, '') }));
}

/** A translation given its source's leading and trailing whitespace, which the output format cannot carry. */
function withSourceEdges(source, text) {
  return source.match(/^\s*/)[0] + text.trim() + source.match(/\s*$/)[0];
}

/**
 * Applies the finished batches.
 *
 * @param {Object} args
 * @param {ReturnType<import('./store.mjs').createStore>} args.store
 * @param {Object} [args.glossary]
 * @param {number} args.attemptLimit    `backend.attempts`: a segment rejected this many times is left out.
 * @param {string} args.work            the work directory, absolute.
 * @param {string[]|null} [args.batchIds]  the batches to apply whether or not their `done` file exists.
 * @param {string|null} [args.model]   the model the agents ran on, recorded in the job log.
 * @param {() => string} [args.now]
 * @param {(...a:any[])=>void} [args.log]
 * @param {(...a:any[])=>void} [args.errlog]
 * @returns {{code:number, imported:string[], applied:number}}
 */
export function sessionImport({
  store,
  glossary = {},
  attemptLimit,
  work,
  batchIds = null,
  model = null,
  now = () => new Date().toISOString(),
  log = (...a) => console.log(...a),
  errlog = (...a) => console.error(...a),
}) {
  const paths = sessionPaths(work);
  const { entries: doNotTranslate, caseSensitive } = doNotTranslateOf(glossary);
  const batches = listBatches(paths);
  for (const id of batchIds || []) {
    if (!batches.some((b) => b.id === id)) {
      errlog(`session import: there is no batch ${id} in ${paths.batches}.`);
      return { code: 2, imported: [], applied: 0 };
    }
  }
  const queue = readSessionQueue(work);
  const imported = [];
  let applied = 0;

  for (const batch of batches) {
    const named = batchIds && batchIds.includes(batch.id);
    if (batch.imported) {
      if (named) log(`session import: batch ${batch.id} is already imported.`);
      continue;
    }
    if (batchIds ? !named : !batch.done) continue;
    const plan = readJson(path.join(batch.dir, 'plan.json'), null);
    if (!plan) {
      errlog(`session import: batch ${batch.id} has no plan.json; it was not written by \`session export\`.`);
      return { code: 2, imported, applied };
    }

    const at = now();
    const job = `session-${batch.id}-${at.replace(/[^0-9]/g, '').slice(0, 14)}`;
    const items = [];
    const failures = [];
    const internal = [];
    const dropped = [];
    const missingFiles = [];
    const accepted = {};
    const rejected = {};
    const unjudged = {};

    for (const [lang, ids] of Object.entries(plan.requested)) {
      const file = path.join(batch.dir, `${lang}.txt`);
      if (!fs.existsSync(file)) {
        missingFiles.push(lang);
        continue;
      }
      const units = ids.map((id) => ({ srcHash: id, ...plan.items[id] }));
      const replies = parseSessionOutput(fs.readFileSync(file, 'utf8')).map((e) =>
        plan.items[e.id] ? { id: e.id, text: withSourceEdges(plan.items[e.id].source, e.text) } : e
      );
      const validation = validateTranslations({ items: units, entries: replies, doNotTranslate, caseSensitive });
      for (const id of validation.dropped) dropped.push({ id, lang, page: batch.id, section: null });

      const entries = {};
      const sources = {};
      for (const unit of units) {
        const text = validation.accepted[unit.srcHash];
        if (typeof text !== 'string') continue;
        const revision = plan.revisions && plan.revisions[lang] && plan.revisions[lang][unit.srcHash];
        entries[unit.srcHash] = machineEntry({ srcHash: unit.srcHash, text, job, at, revision });
        sources[unit.srcHash] = unit.source;
        const attempt = (plan.attempts && plan.attempts[lang] && plan.attempts[lang][unit.srcHash]) || 1;
        items.push({
          srcHash: unit.srcHash,
          lang,
          source: unit.source,
          text,
          status: STATUS.MACHINE,
          attempt,
          ...(model ? { model } : {}),
          ...(revision && revision.forced ? { forced: true, reason: revision.reason } : {}),
        });
      }
      if (Object.keys(entries).length > 0) {
        store.writeLayerEntries(LAYER.MACHINE, lang, entries);
        store.mergeSourceMap(sources);
        store.mergeMachineSources(sources);
        clearQueued(queue, lang, Object.keys(entries));
        settleAccepted({ store, lang, ids: Object.keys(entries), revisions: (plan.revisions && plan.revisions[lang]) || {} });
      }
      // What the agent wrote for each segment, recorded beside a rejection (`recordedText`).
      const returned = returnedTexts(replies);
      for (const [id, defect] of Object.entries(validation.rejected)) {
        const attempt = (plan.attempts && plan.attempts[lang] && plan.attempts[lang][id]) || 1;
        queueDefect(queue, { lang, ids: [id], attempt, defect: { [id]: defect } });
        failures.push({ srcHash: id, lang, error: defect, attempt, ...recordedText(returned.get(id)) });
      }
      // A segment a check could not judge is neither written nor queued: it returns to the pool, its attempt not counted.
      for (const [id, error] of Object.entries(validation.internal || {})) {
        const attempt = (plan.attempts && plan.attempts[lang] && plan.attempts[lang][id]) || 1;
        internal.push({ srcHash: id, lang, error, attempt, ...recordedText(returned.get(id)) });
      }
      accepted[lang] = Object.keys(entries).length;
      if (Object.keys(validation.rejected).length) rejected[lang] = Object.keys(validation.rejected).length;
      if (validation.internal) unjudged[lang] = Object.keys(validation.internal).length;
    }

    writeSessionQueue(work, queue);
    const exhausted = failures
      .filter((f) => queue[f.lang] && queue[f.lang][f.srcHash] && queue[f.lang][f.srcHash].attempts >= attemptLimit)
      .map(({ srcHash, lang, error }) => ({ srcHash, lang, error }));
    const result =
      failures.length === 0 && internal.length === 0 && missingFiles.length === 0 ? RESULT.OK : items.length === 0 ? RESULT.FAILED : RESULT.PARTIAL;
    const jobFile = store.appendJobLog({
      id: job,
      at,
      trigger: 'session',
      items,
      failures,
      exhausted,
      ...(internal.length ? { internal } : {}),
      ...(dropped.length ? { dropped } : {}),
      result,
    });
    writeJson(path.join(batch.dir, 'result.json'), {
      importedAt: at,
      job,
      accepted,
      rejected,
      ...(internal.length ? { internal: unjudged } : {}),
      missingFiles,
      ...(dropped.length ? { dropped } : {}),
    });
    imported.push(batch.id);
    applied += items.length;

    log(
      `session import: batch ${batch.id}: ${items.length} translation(s) written to the machine layer, ${failures.length - exhausted.length} rejected and queued, ` +
        `${exhausted.length} at the attempt limit` +
        (internal.length ? `, ${internal.length} returned to the pool after an internal error` : '') +
        (missingFiles.length ? `; no output for ${missingFiles.join(', ')}, which returns to the pool` : '') +
        `; job=${jobFile}`
    );
    for (const f of failures.slice(0, 5)) log(`  ${f.lang} ${f.srcHash}: ${f.error}`);
    if (failures.length > 5) log(`  … and ${failures.length - 5} more, each stated to its next batch.`);
    for (const f of internal) log(`  internal error, not a defect of the translation and not counted as an attempt: ${f.lang} ${f.srcHash}: ${f.error}`);
    for (const d of dropped) log(`  dropped an identifier the batch did not ask for: ${d.lang} ${JSON.stringify(d.id)}`);
  }
  if (imported.length === 0) log('session import: no finished batch to import.');
  return { code: 0, imported, applied };
}

/**
 * Prints the session's state: per locale what is missing as of the last
 * extract, the batches by state, the rejections, and the translations awaiting
 * a person's review. Reads files only.
 *
 * @param {Object} args
 * @param {ReturnType<import('./engine.mjs').createEngine>} args.engine
 * @param {string[]} args.targets
 * @param {number} args.attemptLimit
 * @param {string} args.work
 * @param {(...a:any[])=>void} [args.log]
 * @returns {{code:number}}
 */
export function sessionStatus({ engine, targets, attemptLimit, work, log = (...a) => console.log(...a) }) {
  const paths = sessionPaths(work);
  const worklist = engine.gate({ targets });
  const missing = Object.fromEntries(targets.map((lang) => [lang, { segments: 0, words: 0 }]));
  for (const item of worklist.status === 'work' ? worklist.items : []) {
    for (const lang of item.missing) {
      if (!missing[lang]) continue;
      missing[lang].segments += 1;
      missing[lang].words += wordsOf(item.source);
    }
  }
  log('session status: missing, as of the last extract:');
  for (const lang of targets) log(`  ${lang}: ${missing[lang].segments} segment(s), ${missing[lang].words} words`);
  const batches = listBatches(paths);
  const open = batches.filter((b) => !b.imported);
  const waiting = open.filter((b) => b.done).map((b) => b.id);
  const running = open.filter((b) => !b.done).map((b) => b.id);
  log(
    `session status: ${batches.length - open.length} batch(es) imported, ${waiting.length} finished and waiting for import` +
      `${waiting.length ? ` (${waiting.join(', ')})` : ''}, ${running.length} open${running.length ? ` (${running.join(', ')})` : ''}.`
  );
  const queue = readSessionQueue(work);
  for (const lang of Object.keys(queue).sort()) {
    const rows = Object.entries(queue[lang]);
    const atLimit = rows.filter(([, e]) => e.attempts >= attemptLimit);
    log(`session status: ${lang}: ${rows.length - atLimit.length} rejected segment(s) queued for a later batch, ${atLimit.length} at the attempt limit.`);
    for (const [id, e] of atLimit) log(`  left out after ${e.attempts} attempts: ${id}: ${e.defect}`);
  }
  if (Object.values(queue).some((rows) => Object.values(rows).some((e) => e.attempts >= attemptLimit))) {
    log('session status: `l10n requeue --session` gives the segments left out their attempts again, their defect kept as a correction.');
  }
  for (const line of markLines(markedFromStore(engine.store, targets), { queue, attemptLimit, prefix: 'session status' })) log(line);
  const review = engine.review({ targets });
  const toReview = Object.values(review).reduce((n, rows) => n + rows.length, 0);
  if (toReview) log(`session status: ${toReview} machine translation(s) revise a reviewed translation; \`l10n review\` lists them.`);
  return { code: 0 };
}

export default {
  DEFAULT_BATCH_WORDS,
  NO_HELPERS_SENTENCE,
  sessionPaths,
  sessionHeldPairs,
  instructionsName,
  sessionInstructions,
  agentPrompt,
  sessionExport,
  parseSessionOutput,
  sessionImport,
  sessionStatus,
};
