/**
 * requeue.mjs — `l10n requeue`: gives the segments left out after
 * `backend.attempts` rejections their attempts again, so that once the prompts,
 * the glossary or the package are fixed, exactly those segments are translated
 * again.
 *
 *   l10n requeue [--targets a,b] [--keys k1,k2] [--api] [--session] [--work <dir>] [--dry-run]
 *
 * READS and WRITES the two resubmission queues: the pending file's
 * (`<memory.dir>/pending.json`, through the store, for `submit` and `collect`) and
 * a translating session's (`<work>/queue.json`, for `session export` and
 * `session import`). With neither `--api` nor `--session` both are read; with one,
 * that one alone. `--dry-run` writes nothing. It makes no network call, touches no
 * memory layer and leaves the pending file's recorded batches as they are.
 *
 * A LEFT-OUT SEGMENT is a queue entry whose `attempts` reached the limit, in a
 * locale `--targets` names (default: every configured target) and, when `--keys`
 * is given, under a key it names. Its `attempts` is set to 0, and everything else
 * the entry holds is kept: its defect, which the next request or batch states as
 * the correction to make, and the fallback model's state. So the next `submit`,
 * or the next `session export`, requests it as a first attempt, and it may be
 * rejected `backend.attempts` times again before it is left out again.
 *
 * A left-out pair that a recorded batch still requests is not reset: `collect`
 * will set its attempts from that batch, so resetting it now would change nothing.
 * It is named, to be requeued after `collect`.
 *
 * Run it between two batches, never while `collect`, `submit`, `session export`
 * or `session import` is running: each rewrites the queue it reads.
 */

import { batchHeldPairs } from './pending.mjs';
import { readSessionQueue, sessionPaths, writeSessionQueue } from './session.mjs';
import fs from 'node:fs';

/**
 * Resets the left-out segments of one queue, in place, and returns what it reset.
 *
 * @param {import('./types.mjs').Queue} queue  updated in place unless `dryRun`.
 * @param {Object} args
 * @param {number} args.attemptLimit
 * @param {string[]} args.targets
 * @param {Set<string>|null} args.keys     the keys to reset, or null for every left-out one.
 * @param {Map<string, Set<string>>} [args.held]  pairs a recorded batch requests, which are left as they are.
 * @param {boolean} [args.dryRun]
 * @returns {{reset: Array<{lang:string, id:string, attempts:number, defect:string}>, held: Array<{lang:string, id:string}>}}
 */
export function requeueLeftOut(queue, { attemptLimit, targets, keys, held = new Map(), dryRun = false }) {
  const reset = [];
  const kept = [];
  for (const lang of Object.keys(queue).sort()) {
    if (!targets.includes(lang)) continue;
    for (const id of Object.keys(queue[lang]).sort()) {
      const entry = queue[lang][id];
      if (!entry || !(entry.attempts >= attemptLimit)) continue;
      if (keys && !keys.has(id)) continue;
      if (held.has(lang) && held.get(lang).has(id)) {
        kept.push({ lang, id });
        continue;
      }
      reset.push({ lang, id, attempts: entry.attempts, defect: entry.defect });
      if (!dryRun) entry.attempts = 0;
    }
  }
  return { reset, held: kept };
}

/** One summary line per locale: how many segments were reset in it. */
function perLocale(reset) {
  const counts = new Map();
  for (const r of reset) counts.set(r.lang, (counts.get(r.lang) || 0) + 1);
  return [...counts].map(([lang, n]) => `${lang}: ${n}`).join(', ');
}

/**
 * Runs `l10n requeue`.
 *
 * @param {Object} args
 * @param {ReturnType<import('./store.mjs').createStore>} args.store
 * @param {string} args.work             the session's work directory, absolute.
 * @param {number} args.attemptLimit     `backend.attempts`.
 * @param {string[]} args.targets
 * @param {string[]|null} [args.keys]
 * @param {boolean} [args.api]           read the pending file's queue.
 * @param {boolean} [args.session]       read the session's queue.
 * @param {boolean} [args.dryRun]
 * @param {(...a:any[])=>void} [args.log]
 * @returns {{code:number, reset:number}}
 */
export function runRequeue({ store, work, attemptLimit, targets, keys = null, api = true, session = true, dryRun = false, log = (...a) => console.log(...a) }) {
  const wanted = keys && keys.length ? new Set(keys) : null;
  const verb = dryRun ? 'would give' : 'gave';
  let total = 0;

  if (api) {
    const pending = store.readPending();
    const { reset, held } = requeueLeftOut(pending.queue, { attemptLimit, targets, keys: wanted, held: batchHeldPairs(pending), dryRun });
    if (reset.length && !dryRun) store.writePending(pending);
    log(`requeue: ${store.paths.pending}: ${reset.length ? `${verb} ${reset.length} left-out segment(s) their attempts again (${perLocale(reset)})` : 'no left-out segment matches'}.`);
    for (const r of reset) log(`  ${r.lang} ${r.id}, rejected ${r.attempts} times: ${r.defect}`);
    for (const h of held) log(`  ${h.lang} ${h.id}: a recorded batch still requests it, so it is left as it is; requeue it after \`l10n collect\`.`);
    total += reset.length;
  }
  if (session) {
    const file = sessionPaths(work).queue;
    if (!fs.existsSync(file)) {
      log(`requeue: ${file}: there is no session queue.`);
    } else {
      const queue = readSessionQueue(work);
      const { reset } = requeueLeftOut(queue, { attemptLimit, targets, keys: wanted, dryRun });
      if (reset.length && !dryRun) writeSessionQueue(work, queue);
      log(`requeue: ${file}: ${reset.length ? `${verb} ${reset.length} left-out segment(s) their attempts again (${perLocale(reset)})` : 'no left-out segment matches'}.`);
      for (const r of reset) log(`  ${r.lang} ${r.id}, rejected ${r.attempts} times: ${r.defect}`);
      total += reset.length;
    }
  }
  if (total > 0) {
    log(
      dryRun
        ? 'requeue --dry-run: nothing was written.'
        : 'requeue: the next `l10n submit` or `l10n session export` requests them as a first attempt, each with its last defect as the correction to make.'
    );
  }
  return { code: 0, reset: total };
}

export default { requeueLeftOut, runRequeue };
