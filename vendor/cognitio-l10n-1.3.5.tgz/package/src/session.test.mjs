import '../test/no-network.mjs';
import { describe, it, expect, beforeEach, afterEach } from 'vitest';
import fs from 'node:fs';
import path from 'node:path';

import { runCli } from './cli.mjs';
import { instructionsName, NO_HELPERS_SENTENCE, parseSessionOutput } from './session.mjs';
import { REVISE_SENTENCE, translationRules } from './translator-prompt.mjs';
import { keyOf } from './normalize.mjs';
import { capture, copyMarkdownFixture } from '../test/helpers.mjs';

let project;
beforeEach(() => {
  project = copyMarkdownFixture('l10n-session-');
});
afterEach(() => {
  fs.rmSync(project, { recursive: true, force: true });
});

const work = (...p) => path.join(project, 'memory', 'session', ...p);
const memory = (...p) => path.join(project, 'memory', ...p);
const readJson = (file) => JSON.parse(fs.readFileSync(file, 'utf8'));

async function run(argv) {
  const io = capture();
  const code = await runCli(argv, { cwd: project, env: {}, log: io.log, errlog: io.errlog });
  return { code, out: io.text(), err: io.errors() };
}

/**
 * Stands in for an agent: writes every output file a batch names, each requested
 * segment answered by `answer(source, lang, id)` — by default its source tagged
 * with the locale, which keeps every protected span, term and line — then, unless
 * `done` is false, the done file. `skip` names locales whose file is not written.
 */
function agent(batch, { answer = (source, lang) => `${source} ⟨${lang}⟩`, skip = [], done = true } = {}) {
  const task = readJson(work('batches', batch, 'task.json'));
  for (const lang of task.locales) {
    if (skip.includes(lang)) continue;
    const lines = [];
    for (const chunk of task.chunks) {
      for (const segment of chunk.segments) {
        if (!segment.translate || (segment.translate !== 'all' && !segment.translate.includes(lang))) continue;
        lines.push(`@@@ ${segment.id}`, answer(segment.source, lang, segment.id));
      }
    }
    fs.writeFileSync(task.output[lang], lines.join('\n') + '\n');
  }
  if (done) fs.writeFileSync(task.done, 'ok\n');
  return task;
}

/** Every batch the export printed, by number. */
const batchesIn = (out) => [...out.matchAll(/^session export: batch (\d{4}):/gm)].map((m) => m[1]);

describe('l10n session export: batches every locale of a segment together, with the instructions an agent reads', () => {
  it('writes the instructions, and each batch’s task and plan, and prints the prompt that starts its agent', async () => {
    const r = await run(['session', 'export', '--batches', '50']);
    expect(r.code).toBe(0);
    const batches = batchesIn(r.out);
    expect(batches.length).toBeGreaterThan(0);
    expect(r.out).toContain(`agent prompt: Translate the batch in ${work('batches', '0001', 'task.json')}. First read ${work('INSTRUCTIONS.it+de.md')}`);
    // One agent per batch: the prompt keeps it from starting others.
    expect(r.out).toContain(NO_HELPERS_SENTENCE);

    const instructions = fs.readFileSync(work('INSTRUCTIONS.it+de.md'), 'utf8');
    expect(instructions).toContain(translationRules({ glossary: {} }));
    expect(instructions).toContain(REVISE_SENTENCE);
    expect(instructions).toContain(NO_HELPERS_SENTENCE);
    expect(instructions).toContain('### Italian (`it`)');
    expect(instructions).toContain('Use an impersonal, professional register.');
    expect(instructions).toContain('@@@ <id>');
    // The instructions every locale shared before are no longer written.
    expect(fs.existsSync(work('INSTRUCTIONS.md'))).toBe(false);

    const task = readJson(work('batches', '0001', 'task.json'));
    expect(task.instructions).toBe(work('INSTRUCTIONS.it+de.md'));
    expect(task.locales).toEqual(['it', 'de']);
    expect(task.output).toEqual({ it: work('batches', '0001', 'it.txt'), de: work('batches', '0001', 'de.txt') });
    const plan = readJson(work('batches', '0001', 'plan.json'));
    const requested = task.chunks.flatMap((c) => c.segments).filter((s) => s.translate).map((s) => s.id);
    expect([...plan.requested.it].sort()).toEqual([...new Set(requested)].sort());
    // A Markdown segment's protected strings reach the agent as `keep`.
    const withCode = task.chunks.flatMap((c) => c.segments).find((s) => s.source.includes('`planted_inline_code`'));
    expect(withCode.keep).toContain('`planted_inline_code`');
  });

  it('writes the guides of a batch’s own locales alone, one instructions file per set of locales', async () => {
    const r = await run(['session', 'export', '--targets', 'de']);
    expect(r.code).toBe(0);
    const [batch] = batchesIn(r.out);
    const task = readJson(work('batches', batch, 'task.json'));
    expect(task.locales).toEqual(['de']);
    expect(task.instructions).toBe(work('INSTRUCTIONS.de.md'));
    const instructions = fs.readFileSync(work('INSTRUCTIONS.de.md'), 'utf8');
    expect(instructions).toContain('### German (`de`)');
    expect(instructions).not.toContain('### Italian (`it`)');
    expect(instructions).toContain('Terminology for German (rule 2):');
    expect(instructions).not.toContain('Terminology for Italian (rule 2):');
    expect(r.out).toContain(`First read ${work('INSTRUCTIONS.de.md')}`);
  });

  it('names a long set of locales by a digest, so the file name stays short', () => {
    const many = Array.from({ length: 37 }, (_, i) => `l${String(i).padStart(2, '0')}-XX`);
    expect(instructionsName(['it', 'de'])).toBe('INSTRUCTIONS.it+de.md');
    expect(instructionsName(many)).toMatch(/^INSTRUCTIONS\.[0-9a-f]{12}\.md$/);
    expect(instructionsName(many)).toBe(instructionsName([...many]));
  });

  it('never plans again a segment that a batch not yet imported holds', async () => {
    const first = await run(['session', 'export', '--words', '40']);
    const second = await run(['session', 'export', '--words', '40']);
    const ids = (batch) => readJson(work('batches', batch, 'plan.json')).requested.it;
    const [a] = batchesIn(first.out);
    const [b] = batchesIn(second.out);
    expect(b).not.toBe(a);
    expect(ids(b).filter((id) => ids(a).includes(id))).toEqual([]);
  });

  it('refuses a malformed --words, and a subcommand it does not know, writing nothing', async () => {
    expect((await run(['session', 'export', '--words', '0'])).code).toBe(2);
    const unknown = await run(['session', 'translate']);
    expect(unknown.code).toBe(2);
    expect(unknown.err).toContain('`l10n session export`, `l10n session import`, `l10n session status`');
    expect(fs.existsSync(work())).toBe(false);
  });
});

describe('l10n session import: validates what the agents wrote and writes the machine layer', () => {
  it('imports finished batches until nothing is missing, and generate writes the translated pages', async () => {
    for (let round = 0; round < 10; round++) {
      const r = await run(['session', 'export', '--batches', '50']);
      const batches = batchesIn(r.out);
      if (batches.length === 0) break;
      for (const batch of batches) agent(batch);
      const imported = await run(['session', 'import', '--model', 'test-agent']);
      expect(imported.code).toBe(0);
      expect(imported.out).not.toMatch(/[1-9]\d* rejected and queued/);
    }
    expect((await run(['gate', '--check'])).code).toBe(0);
    const machine = readJson(memory('machine', 'it.json'));
    const key = keyOf('Text with a footnote[^note].');
    expect(machine[key]).toMatchObject({ text: 'Text with a footnote[^note]. ⟨it⟩', status: 'machine' });
    expect(readJson(memory('machine', '_source.json'))[key]).toBe('Text with a footnote[^note].');
    const job = fs.readdirSync(memory('jobs')).map((f) => readJson(memory('jobs', f))).find((j) => j.trigger === 'session');
    expect(job.items[0].model).toBe('test-agent');

    expect((await run(['generate'])).code).toBe(0);
    expect(fs.readFileSync(path.join(project, 'out', 'it', 'README.md'), 'utf8')).toContain('Text with a footnote[^note]. ⟨it⟩');
  });

  it('rejects a translation that loses a protected string, queues its defect, and states it to the next batch', async () => {
    const [batch] = batchesIn((await run(['session', 'export', '--batches', '50'])).out);
    const lossy = (source, lang) => (lang === 'it' ? source.replace('`planted_inline_code`', 'planted inline code') : `${source} ⟨${lang}⟩`);
    agent(batch, { answer: lossy });
    const r = await run(['session', 'import']);
    expect(r.code).toBe(0);
    expect(r.out).toMatch(/1 rejected and queued/);
    const queue = readJson(work('queue.json'));
    const [id] = Object.keys(queue.it);
    expect(queue.it[id]).toMatchObject({ attempts: 1 });
    expect(queue.it[id].defect).toContain('`planted_inline_code`');

    // Only the rejected Italian segment is left, so the next batch is an Italian one.
    const next = batchesIn((await run(['session', 'export', '--batches', '50'])).out);
    expect(next).toHaveLength(1);
    const task = readJson(work('batches', next[0], 'task.json'));
    expect(task.locales).toEqual(['it']);
    const segment = task.chunks.flatMap((c) => c.segments).find((s) => s.id === id);
    expect(segment.translate).toBe('all');
    expect(segment.corrections.it).toContain('`planted_inline_code`');
    expect(readJson(work('batches', next[0], 'plan.json')).attempts.it[id]).toBe(2);
  });

  it('returns a locale with no output file to the pool, unqueued, and imports an unfinished batch only when named', async () => {
    const [batch] = batchesIn((await run(['session', 'export'])).out);
    agent(batch, { skip: ['de'], done: false });
    expect((await run(['session', 'import'])).out).toContain('session import: no finished batch to import.');
    const r = await run(['session', 'import', '--batch', batch]);
    expect(r.out).toContain('no output for de, which returns to the pool');
    expect(fs.existsSync(work('queue.json')) ? readJson(work('queue.json')).de : undefined).toBeUndefined();
    const ids = readJson(work('batches', batch, 'plan.json')).requested.de;
    const again = batchesIn((await run(['session', 'export'])).out);
    expect(readJson(work('batches', again[0], 'plan.json')).requested.de).toEqual(expect.arrayContaining(ids.slice(0, 1)));
    expect((await run(['session', 'import', '--batch', batch])).out).toContain(`batch ${batch} is already imported`);
  });

  it('rejects a Markdown translation that breaks a one-line source, so the page keeps its structure', async () => {
    const [batch] = batchesIn((await run(['session', 'export', '--batches', '50'])).out);
    const heading = keyOf('Lists');
    agent(batch, { answer: (source, lang, id) => (id === heading && lang === 'de' ? 'Listen\nund mehr' : `${source} ⟨${lang}⟩`) });
    await run(['session', 'import']);
    expect(readJson(work('queue.json')).de[heading].defect).toContain('write the translation on one line');
  });

  it('status reports what is missing, the batches by state and the rejections', async () => {
    const [batch] = batchesIn((await run(['session', 'export'])).out);
    const r = await run(['session', 'status']);
    expect(r.code).toBe(0);
    expect(r.out).toMatch(/^ {2}it: \d+ segment\(s\), \d+ words$/m);
    expect(r.out).toContain(`0 batch(es) imported, 0 finished and waiting for import, 1 open (${batch}).`);
  });
});

describe('a changed segment reaches its agent with the earlier translation to revise', () => {
  it('carries "revise" per locale, and the imported entry records where it came from', async () => {
    for (let round = 0; round < 10; round++) {
      const batches = batchesIn((await run(['session', 'export', '--batches', '50'])).out);
      if (batches.length === 0) break;
      for (const batch of batches) agent(batch);
      await run(['session', 'import']);
    }
    const page = path.join(project, 'docs', 'README.md');
    fs.writeFileSync(page, fs.readFileSync(page, 'utf8').replace('Text with a footnote[^note].', 'Text with a footnote[^note], now edited.'));

    const [batch] = batchesIn((await run(['session', 'export'])).out);
    const segment = readJson(work('batches', batch, 'task.json')).chunks.flatMap((c) => c.segments).find((s) => s.translate);
    expect(segment.source).toBe('Text with a footnote[^note], now edited.');
    expect(segment.revise).toEqual({
      it: { source: 'Text with a footnote[^note].', translation: 'Text with a footnote[^note]. ⟨it⟩' },
      de: { source: 'Text with a footnote[^note].', translation: 'Text with a footnote[^note]. ⟨de⟩' },
    });
    agent(batch);
    await run(['session', 'import']);
    expect(readJson(memory('machine', 'it.json'))[keyOf('Text with a footnote[^note], now edited.')].revision).toEqual({
      from: keyOf('Text with a footnote[^note].'),
      reviewed: false,
    });
  });
});

describe('parseSessionOutput', () => {
  it('reads each segment to the next header, a translation spanning lines included, and accepts CRLF', () => {
    expect(parseSessionOutput('@@@ aaaa\nOne line\n@@@ bbbb\nFirst  \nsecond\n\n')).toEqual([
      { id: 'aaaa', text: 'One line' },
      { id: 'bbbb', text: 'First  \nsecond' },
    ]);
    expect(parseSessionOutput('@@@ aaaa\r\nUna riga\r\n')).toEqual([{ id: 'aaaa', text: 'Una riga' }]);
    expect(parseSessionOutput('stray text before a header\n@@@ aaaa\nx')).toEqual([{ id: 'aaaa', text: 'x' }]);
  });
});
