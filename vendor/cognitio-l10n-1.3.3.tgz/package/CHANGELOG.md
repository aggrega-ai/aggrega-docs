# Changelog

Each version of `@cognitio/l10n` is a git tag of its repository, `l10n-vX.Y.Z`,
whose release publishes the archive a consuming project vendors from
`https://tooling.cognitio.it/l10n/archives/l10n-X.Y.Z.tgz`;
`https://tooling.cognitio.it/l10n/index.json` lists every published version
with its archive's sha256. 1.0.0 holds every feature the package has at its
first release; a feature added after it is recorded under the next version,
above this one.

## 1.3.3

### Re-translating chosen segments

- `l10n retranslate` marks (key, locale) pairs for a new translation though their
  source is unchanged — a form of address or a variety decided later, a glossary
  term added since, a translation found wrong in review — with no hand edit to the
  machine layer. Pairs are chosen with `--keys`, `--keys-file` (`{ "<locale>":
  [keys] }`), `--match` (on the translation now served), `--context` (a prefix of
  the unit's context) and `--file` (a glob over the files a unit is used in),
  every selector given applying; `--reason` says what must change; `--dry-run`
  prints exactly the pairs it would mark.
- The marks are `<memory.dir>/retranslate.json`, committed with the memory. Every
  transport — `session export`, `submit`, `local`, `translate`, `pipeline` —
  requests a marked pair as a revision of itself: `revise` carries its current
  translation and the mark's `reason`, and the instructions say the source is
  unchanged, so only what the reason asks for changes.
- The current translation serves until a new one is accepted; accepting it
  replaces it, records the machine entry's revision and the job log's item as
  `forced` with the reason, and clears the mark. A rejected re-translation follows
  the attempts and `l10n requeue`; the current translation stays, and `status` and
  `session status` name it.
- A pair a person translated is skipped and named, unless `--include-human`: the
  re-translation then starts from the person's text, and their entry moves to the
  human layer's archive once the new one is accepted.
- `gate`, `status` and `session status` report the marked pairs; they never fail
  `gate --check` or `prepush`. Marking is supported in the local mode and in a
  session; under the CI mode `retranslate` stops with exit 2.

### API

- New exports: `runRetranslate`, `selectPairs`, `markedWork`, `markedFromStore`,
  `withMarked`, `withMarkedRevisions`, `settleAccepted`, `recordedRevision`,
  `markLines`, `DEFAULT_REASON` and `FORCED_REVISE_SENTENCE`. The store reads and
  writes the marks (`readRetranslate`, `writeRetranslate`) and archives one
  layer's keys (`archiveLayerKeys`); `planBatch` takes `marked`; `status` takes
  `targets`; `decidePipeline` takes `marked`; a `revise` entry may carry `reason`.

### Examples

- The Markdown example translates the documentation of an invented product,
  Flowline, and the JSON-content configurations name generic paths and keys; a
  project that copied an example keeps its own copy as it is.

### What a consumer does

1. Install 1.3.3 as 1.3.2 was. Nothing changes for a project that never marks a
   pair, and every file 1.3.2 wrote is read as it is.
2. To re-translate pairs: `l10n retranslate … --dry-run`, then without
   `--dry-run`; commit `<memory.dir>/retranslate.json` with the memory; translate
   as usual (`session export` and `session import`, or `l10n local`).

## 1.3.2

Fixes found translating a large documentation corpus on 1.3.1. No key,
catalogue entry or stored protected span changes, and every file 1.3.0 and 1.3.1
wrote is read as it is.

### Validation

- Two protected strings a translation sets side by side, where its source has
  text between them, are compared each on its own. A link whose text is inline
  code and a word, reordered so the code ends it — `` [`import` tool](x) ``
  becoming `` [narzędzie `import`](x) `` — was rejected as missing both strings
  and adding their join; it is accepted, while a changed code span or
  destination is still rejected. The converse too: the catalogue stores
  touching spans as one string, and the check and the `keep` list a request
  carries cut it where the source's own spans meet.
- A literal link is what the GitHub-flavoured Markdown tokenizer links, read as
  if a space stood before it, and `www.` needs a domain after its dot. In 1.3.1
  `WWW.` ending a sentence — Polish "serwer WWW." for a web server — counted as
  an added link, and the tokenizer's own link of `www` before `. ` counted as one
  too; neither is a link now. A web address after `„` or `—` is still protected.
- Inline code a translation adds holding nothing but a placeholder its source's
  inline code holds is accepted with the straight quotes the source writes
  around it, `` `"<provider-name>"` `` as well as `` `<provider-name>` ``. Any
  other added inline code is still rejected.

### Recording

- The job log records every rejected translation's text beside its defect, as
  `text` on its `failures` entry, and on an `internal` one: up to 8,000
  characters, a longer text cut with its whole length as `textLength`. A
  translation averages about 0.4 KB in a large documentation run, so a thousand
  rejections add about 0.4 MB. The queues keep the defect alone.

### Instructions

- Each segment a request asks for carries `"translate": true` where it stands
  among the context's segments, and the general rules say that only such a
  segment is translated and returned; a reply returning a context segment was
  paid for and discarded.
- The general rules say that the project's instructions, like the language
  guide, never override rules 1 to 4, and rule 3 that a string the `keep` list
  names keeps its backticks whatever another instruction says about writing
  other text plain, and that text written beside them is plain prose, never new
  inline code, but for a placeholder copied out of inline code. A session's
  instructions say the same of the project's instructions.

### A harder try for a hard segment

- `backend.retryModel`, an id or `{ "id", "thinking"?, "effort"?,
  "fromAttempt"? }`, runs a request on that model from its `fromAttempt`-th
  attempt on — every resubmission by default, the last alone with
  `backend.attempts` — with its own `thinking` and `effort`, and the largest
  `max_tokens` when it can reason. A refused request still goes to
  `model.fallbackId`. Unset, nothing changes. The README states what it costs.

### API

- New exports: `protectedPieces`, `recordedText`, `returnedTexts`,
  `RECORDED_TEXT_LIMIT` and `DEFAULT_RETRY_FROM_ATTEMPT`. `segmentMarkdown`
  takes `joinTouching`; `standaloneProtectedSpans` keeps touching spans apart;
  `translationSettings` gives `model.retry`; `buildUserMessage` marks the
  requested segments.

### What a consumer does

1. Between two batches, install 1.3.2 as 1.3.1 was. No configuration change is
   needed.
2. `l10n requeue --dry-run`, then `l10n requeue`, to retry the segments left out
   by the defects above.
3. Optionally, set `backend.retryModel`.

## 1.3.1

Fixes found translating a large documentation corpus in a session and through
the Message Batches API side by side. No key, catalogue entry or protected span
changes, and every file 1.3.0 wrote is read as it is: a batch 1.3.0 exported
imports, and a batch 1.3.0 submitted collects.

### Validation

- A Markdown translation holding a bare web address or e-mail address right
  after punctuation the Markdown tokenizer does not accept before a link — `„`,
  `—` — is judged as any other. In 1.3.0 GitHub-flavoured Markdown's tree
  transform gave the link nodes no position, the comparison read one, and the
  `TypeError` it raised was reported as a defect of the translation ("does not
  parse as the source's does: Cannot read properties of undefined"), counted as
  an attempt and stated to the model. The link is found by the same rules
  without the transform, and still protected whole.
- A check that fails itself is the package's failure, never the translation's:
  the segment is neither written nor queued, so no attempt is counted for it. It
  is named in the output as an internal error and recorded in the job log's
  `internal`, and the next submission or batch requests it as before.
- In a Markdown segment, text inside inline code is no longer counted as HTML:
  Markdown does not read it as HTML, and the inline code itself is still kept
  byte for byte. A placeholder such as `<name>` that the source holds inside
  inline code may be copied into inline code of its own — the translation of an
  English message given as code, in parentheses after it — and is accepted
  there. Written outside inline code, where the page reads it as a tag and drops
  it, it is still rejected, and the correction now says so: `"<identity>" comes
  from inline code in the source, and outside inline code the page reads it as
  an HTML tag: keep it inside inline code`.
- A do-not-translate entry can name the other forms of its term:
  `{ "term": "Release", "forms": ["Releases"] }`. The term and its forms are one
  term: wherever the source has any of them, the translation keeps whichever its
  grammar calls for, so a language without plural forms may write `Release` for
  `Releases`, while a translated term is still rejected. A form is a
  do-not-translate term of its own, and a term the list also names apart takes
  the forms of every entry naming it, so a glossary listing `Release` and
  `Releases` apart needs only the one entry added.

### Instructions

- Rule 3 says that a placeholder copied out of inline code stays inside inline
  code, and that a Markdown translation holds no empty line.
- The request format says that a segment the request does not list in
  `translate` is context, read and never returned; a reply entry for one is
  discarded.
- A session's instructions are written per set of locales, as
  `INSTRUCTIONS.<a>+<b>.md` (a digest when the name would be long), holding the
  terminology and language guide of those locales alone, and each batch's
  `task.json` names its file under `instructions`. `INSTRUCTIONS.md`, which held
  every configured locale's, is no longer written and is left as it is, so a
  batch exported before reads it still.
- The agent prompt `session export` prints, and the instructions, say: "Do all
  the work yourself: do not start other agents or subagents."

### Retrying left-out segments

- `l10n requeue` gives the segments left out after `backend.attempts`
  rejections their attempts again, in the pending file's queue and the
  session's, with `--targets`, `--keys`, `--api`, `--session` and `--dry-run`.
  Each keeps its last defect, which its next request or batch states as the
  correction to make. A pair a recorded batch still requests is left until
  `collect`. `status` and `session status` name the command when segments are
  left out.

### Two transports side by side

- `submit` leaves out the (segment, locale) pairs a session batch not yet
  imported holds, and `session export` those a recorded Message Batch holds;
  each says how many it left out and why. `submit` reads the session's work
  directory, `<memory.dir>/session/` or the one `--work` names.

### Spend

- `collect` records in each batch's job log the usage every reply reports —
  input, output, cache read and cache write tokens — per request and summed,
  with its price in US dollars where the package's rate table holds the model.
- `status` prints what the collected batches were billed: per batch, beside the
  estimate `submit` recorded for it, per locale and in total. A batch collected
  before 1.3.1 recorded no usage and counts in none of these.
- `submit` records its estimate with the batch, says after it that both
  estimates are upper bounds — the input at one token per byte, the output at
  each request's `max_tokens`, which reserves the reasoning allowance — and,
  once batches with a recorded estimate have been collected, what share of their
  estimates they were billed.

### API

- New exports: `runRequeue`, `requeueLeftOut`, the usage functions
  (`readUsage`, `sumUsage`, `usageCost`, `requestsCost`, `usageLine`,
  `usageRecord`, `spendSummary`), `withoutHeld`, `batchHeldPairs`,
  `sessionHeldPairs`, `readSessionQueue`, `writeSessionQueue`,
  `instructionsName`, `NO_HELPERS_SENTENCE`, `PLACEHOLDER_SENTENCE`,
  `InternalCheckError`, `standaloneProtectedSpans` and `literalAutolinks`.
  `validateTranslations` returns `internal` when a check failed itself;
  `submit` takes `sessionWork`; `BATCH_RATES` holds the input and cache-read
  rates; `sessionExport` no longer reads `allTargets`.

### What a consumer does

1. Vendor 1.3.1, or install its archive with `npm install --no-save`. No
   configuration changes; a run in progress continues with the next `collect`,
   `submit`, `session export` or `session import`.
2. To retry the segments left out before, run `l10n requeue --dry-run`, then
   `l10n requeue` between two batches.
3. To accept the singular of a plural do-not-translate term, give its entry
   `forms` in the glossary.

## 1.3.0

### A changed segment starts from its earlier translation

- A missing segment is paired with an orphan of the memory whose recorded source
  is similar to its own, one to one and the most similar pairs first, at a
  similarity of 0.5 or above (the Dice coefficient of the two sources' words).
  The request gives the translator that earlier source and its translation under
  `revise`, and the general rules ask for the translation changed only where the
  change in the source requires: an edited paragraph keeps the wording the edit
  did not touch.
- An earlier translation in the human layer is marked `reviewed`, and the
  translator is asked to keep that person's wording wherever the new source
  allows. The machine entry written for a revised segment records
  `revision: { from, reviewed }`.
- `l10n review` lists the machine translations that revise a reviewed one and
  have no human entry yet, with the files their segment is used in; `gate` and
  `session status` print how many there are.
- Every writer of the machine layer records the source of each key it writes in
  `<memory.dir>/machine/_source.json`, beside the layer, so the source of an
  orphan is known wherever its translation is: on the CI branch, after an
  overlay, after a sync. A memory written before 1.3.0 has no such record, and
  its orphans have a recorded source only where `messages/_source.json` keeps
  one.

### Translating in a session

- `l10n session export`, `l10n session import` and `l10n session status`
  translate a project from inside an AI coding session, by the agents the
  session runs, with no API key and no model command. `export` writes batches of
  the missing segments, every locale of a segment in the same batch, with the
  instructions every agent reads, and prints the prompt that starts each agent;
  `import` validates what the agents wrote with the one validation and writes
  the machine layer; rejected segments return in later batches with their defect
  stated, up to `backend.attempts`. The work directory is
  `<memory.dir>/session/`, or the one `--work` names.

### Validation

- A Markdown translation is rejected when a line break in it would change its
  page: a line break where its source is on one line, an empty line, or a line
  opening a new block (a heading, a list item, a blockquote, a code fence, an
  HTML block, a thematic break, a setext underline, a table's delimiter row),
  each line read past the leading spaces and `>` markers of its source's
  continuation lines. Before, such a translation was accepted, and the page it
  was spliced into gained or lost a block.

### API

- New exports: `findRevisions`, `similarity`, `REVISION_SIMILARITY`,
  `machineEntry`, `reviewList`, the session functions (`sessionExport`,
  `sessionImport`, `sessionStatus`, `sessionInstructions`, `sessionPaths`,
  `agentPrompt`, `parseSessionOutput`, `DEFAULT_BATCH_WORDS`), and the parts of
  the instructions every transport shares (`translationRules`, `glossaryTerms`,
  `terminologyRules`, `languageName`, `REVISE_SENTENCE`, `reviseForTranslator`).
  `planRequests` takes `revisions`, and `planBatch` takes `sources`.

### What a consumer does

1. Vendor 1.3.0 with `sh install.sh upgrade`. No configuration changes.
2. Add `<memory.dir>/session/` to `.gitignore` before translating in a session.
3. In the CI mode, the CI branch now also holds `<memory.dir>/machine/_source.json`;
   a project that commits the machine layer elsewhere commits that file with it.

## 1.2.1

- Under the Claude Code backend, the job log's `model` is the model the
  request asked for. It was the first key of the CLI result's `modelUsage`,
  which can be a call the CLI makes on its own on a small model (a Haiku)
  besides the translation, so a request run on `claude-opus-5` could be
  recorded as `claude-haiku-4-5-20251001`.
- The model recorded is the `modelUsage` key equal to the model passed with
  `--model`, or one that extends it with a date or version suffix
  (`claude-opus-5` → `claude-opus-5-20260901`): the exact key first, then the
  one with the most output tokens, then the first in code-point order. When no
  key is the requested model — an alias such as `opus`, or a result that names
  none — the requested model is recorded as it was passed to `--model`. The
  backend always passes `--model`, so the requested model is always known; a
  choice among the reported models by their usage could still name the wrong
  one, and is not needed. The same rule applies to a refusal and to a defect.
- Job logs already written are not rewritten; their `model` stays as recorded.
- The README describes vendoring the package with the `cognitio-modules`
  command (`sh install.sh add @cognitio/l10n`, then `sh install.sh upgrade`),
  as its published archive under `vendor/`; the `site-modules` repository no
  longer has `scripts/vendor.sh`. Documentation only.

### What a consumer does

Vendor 1.2.1 with `sh install.sh upgrade`. No configuration changes.

## 1.2.0

The package's name and host change; its code, its commands and its
configuration do not.

- The package is `@cognitio/l10n`, formerly `@aggrega-ai/l10n`, licensed under
  the Apache License 2.0 as before; no package is published under the former
  name from this version on.
- Its archives are served from `https://tooling.cognitio.it/l10n/archives/`,
  and `https://tooling.cognitio.it/l10n/index.json` lists every published
  version with its archive's sha256. The `site-modules` repository's
  `scripts/vendor.sh` downloads from `tooling.cognitio.it`.

### What a consumer does

1. Add the tooling credential to `~/.netrc` for the new host
   (`machine tooling.cognitio.it login <username> password <password>`).
2. Vendor 1.2.0 (`scripts/vendor.sh l10n 1.2.0 <dir>`) into the directory the
   project installs the package from.
3. Rename the dependency, and any `import` of the package, from
   `@aggrega-ai/l10n` to `@cognitio/l10n`; a project with a `package.json`
   then runs `npm install`, so its lockfile names the new package.

## 1.1.2

- `doctor` accepts a translation workflow or a collector that runs by hand
  alone, with manual dispatch its one trigger, so no push and no schedule starts
  a paid run; for such a translation workflow it reads the working branch from
  the checkout's `ref`. The workflows with their automatic triggers are checked
  as before.

## 1.1.1

- The documentation example's prompt files name the product's stance
  with `content-neutral` and `agnostic to`, with a rendering for each in every
  language, in place of the words they replaced, as the documentation itself
  does. Nothing else changes; a site that copied the example's prompts copies
  them again.

## 1.1.0

Every 1.0.0 configuration means what it meant: each new key is optional, and its
default is the 1.0.0 behaviour. Two changes are stricter, and are listed under
[What a consumer does](#what-a-consumer-does).

### The JSON-content adapter

Configuration now fits a site whose content is not, or not only, block pages,
and one whose target pages were written by hand, with no adapter of its own:

- `adapter.document.walk` — `blocks` (the default), `whole`, or `auto`: a file
  holding a `blocks` array is a page, any other file is walked whole, its leaf
  paths relative to the file; `adapter.document.contextKey` names a whole
  document's context.
- `adapter.fields.denylistKeyPatterns` — key patterns (`_*`) excluded at any
  depth; `adapter.fields.identifierStrings` — keys whose strings are identifiers
  while their objects are content, as the key's own value, in its list, or
  both; `adapter.fields.skipInParent` — a key skipped only inside a parent the
  rule describes by the key it sits under, the keys it holds or the only keys it
  may hold.
- `adapter.output` — `path` (`prefixed` or `neutral`), `langField`, `keyOrder`
  (`sorted` or `source`), `pairs` (`all` or `langMap`: only pages the language
  map pairs are generated, materialized, compared and seeded), `fileName`
  (`source` or `path`: a target file named after its target path) and
  `materialize` (`replace` or `safe`).
- `materialize` under `output.materialize: "safe"` writes a file only when none
  of its leaves falls back to the source text and none of the leaves it would
  replace or remove is hand-edited; it names every file it leaves, with the
  reason. Under either policy it writes only paired pages, under their planned
  names, and never touches a target file no source page generates.
- `adapter.ui.nested` — a nested UI dictionary, every string at any depth an
  entry keyed by its path, the generated dictionaries keeping its shape.
- A page with no `path` gets none in its targets (1.0.0 stopped on it), and
  `seed` pairs it with the target file of its planned name.
- `seed` now applies the language map's pairs, which 1.0.0 read and did not
  pass to the alignment, so a page whose target path the map names is seeded
  from that page.
- Two source pages planned under one target file name stop `generate`, naming
  both.

### The Claude Code backend

- `"backend": { "kind": "claude-code" }` translates each request through Claude
  Code run headless on a Claude subscription, one `claude -p` process per
  request with the same system prompt, context and output schema as an API
  request, the user message on standard input, in an empty temporary directory,
  with `--safe-mode`. A request above `backend.maxPromptBytes` is split by its
  requested segments. Its keys: `model`, `tokenEnv`, `login`, `command`,
  `safeMode`, `maxPromptBytes`, `timeoutSeconds`, `concurrency`, `attempts`,
  `sectionTokens`.
- The token is read from `backend.tokenEnv` (default `CLAUDE_CODE_OAUTH_TOKEN`)
  in the environment alone and handed to the process in its environment; the
  CLI's own login is used only when `backend.login` is `"allowed"` or the run
  sets `L10N_CLAUDE_CODE_LOGIN=1`. The process receives no `ANTHROPIC_*`
  variable.
- `translate`, `pipeline` and `local` run on it; `submit`, `collect` and `ci`
  refuse it, and so does a configuration with a `ci` key. `l10n local`
  translates through it synchronously, with no API key and no batch.
- `I18N_BACKEND` now names the backend of one run, `anthropic` or
  `claude-code`, the other kind built from the configuration's `model`,
  `attempts` and `sectionTokens`.
- `doctor` checks the token's variable name for this backend; `prepush`
  estimates tokens without a price for it.

### Do-not-translate terms

- An entry `{ "term": "PIETRA", "case": "sensitive" }` of `do_not_translate`
  matches its term only as written, in a list that otherwise matches in any
  casing (and `"case": "insensitive"` the converse): the glossary part marks
  the term `(exact case)`, rule 1 states the mark, and the validation applies
  it. A list of plain terms gives the same instructions as in 1.0.0.

### Name and licence

- The package is `@aggrega-ai/l10n`, formerly `@cognitio/l10n`, and is
  licensed under the Apache License 2.0. The archive's URL is unchanged in shape.
- The package lives in `packages/l10n/` of the `site-modules` repository, and a
  version's tag is `l10n-vX.Y.Z`.

### Vendoring

- A project vendors the package into its own repository with the
  `site-modules` repository's `scripts/vendor.sh`, the one step that needs a
  credential for the tooling host, and installs it from there: through a
  `file:` dependency, or in a workflow alone with
  `npm install --no-save --install-links`. Its workflows read no secret to
  install it, and the example templates and the README say so.

### Locale codes

- Every locale code is validated as a BCP 47 language tag of letters, digits
  and hyphens — `fr`, `de`, `es`, `pt`, `pt-BR`, `zh-Hans`, `zh-Hant` — and a
  target listed twice, or equal to the source, is refused; the package's tests
  run every command for `pt`, `es`, `fr`, `de`, `zh-Hans` and `zh-Hant`.

### What a consumer does

1. Vendor 1.1.0 (`scripts/vendor.sh l10n 1.1.0 <dir>`), and install it from
   that directory instead of the archive's URL; remove the `.npmrc` line and the
   `L10N_AUTH` secret the install used. Rename the dependency, and any
   `import` of the package, from `@cognitio/l10n` to `@aggrega-ai/l10n`.
2. Check the locale declaration: a code that is no BCP 47 tag of letters,
   digits and hyphens (`en_US`), a duplicate target, or the source among the
   targets, now stops every command with exit 2, naming it.
3. Check `do_not_translate`: an entry that is an object must now be
   `{ "term": string, "case"?: "sensitive" | "insensitive" }`.
4. To drop a site-specific adapter or backend wrapper, state its rules in the
   configuration (`document`, `output`, `fields`, `ui.nested`,
   `backend.kind: "claude-code"`), run `l10n extract` and compare the catalogue
   with the committed one, then call `l10n` directly.
5. A site whose target files were written by hand sets
   `output.materialize: "safe"` (with `output.pairs` and `output.fileName` as its
   files are named) before it runs `materialize`.

## 1.0.0

The first version a project installs from its published archive.

### Commands

One command line, `l10n`, every command reading the project's
`l10n.config.json` and validating it before anything else:

- `extract` — builds the source catalogue from the source locale.
- `gate` — compares the catalogue with the translation memory; `--check` exits
  1 while a source string lacks a translation, without translating anything or
  calling a model.
- `translate` — translates the missing strings one page per request, through
  the Anthropic Messages API.
- `generate` — writes every target locale from the source and the memory, into
  a staging area for JSON content and into the output directory for Markdown.
- `materialize` — writes the JSON-content target locales to their real
  destinations.
- `pipeline` — extracts, gates, and translates then generates when work
  remains.
- `submit`, `collect`, `status` — the unattended path, through the Message
  Batches API: submit what fits the per-submission token budgets, apply what
  has ended, and print what is pending, with no network call for `status`.
  `submit --dry-run` prints the estimate and creates nothing.
- `ci` — the one command a CI-mode project's two workflows run: collects,
  submits, and pushes the CI branch, which holds the machine translations and
  nothing else, switches the collector workflow on while a batch is recorded
  and off otherwise, then, when translations arrived, dispatches the workflow
  the configuration names.
- `overlay` — copies the CI branch's machine translations over the checkout's
  for a deploy build.
- `sync` and `watch` — bring the CI branch's machine translations, with the
  files regenerated from them, into the working branch as one commit; `watch`
  runs `sync` whenever the CI branch moves.
- `local` — the local mode's translation: submits through the Message Batches
  API, waits on the batch on the developer's machine, collects and resubmits
  until nothing is missing, runs the derived commands, and prints what to
  commit.
- `prepush` — the local mode's push check, as a pre-push hook or on one commit:
  refuses a push unless every pushed commit is fully translated and its targets
  match their regeneration, judging each commit in a temporary worktree, and
  says what to run, with an offline cost estimate.
- `verify-drift` — fails on a target file edited by hand, and reports one that
  merely lags its source.
- `seed` — imports hand-written target text into the memory's human layer.
- `gc` — reports memory entries nothing uses, and archives them with `--apply`.
- `doctor` — checks a project's wiring, one line per check: the configuration,
  the prompt files, the glossary, the API key's variable, the translation
  workflow, its collector, the CI branch, and the sync's commands and paths; in
  the local mode, the local commands and paths, the pre-push hook, the
  `prepare` script and the check workflow in place of the last four.

### Adapters

- **JSON content**, for a site whose pages are JSON content files composed of
  blocks, with a UI dictionary: which fields are translated is configuration,
  and a slug can be overridden per page.
- **Markdown**, for a documentation corpus: each file is parsed as
  GitHub-flavoured Markdown and only its prose is replaced, so code, links,
  tables and generated sections keep their source bytes, and every heading keeps
  its source anchor. A remark plugin, `remarkHeadingIds`, sets those anchors as
  the headings' ids in a site that renders the translated pages.

### Also

- A two-layer translation memory per locale: what people write, and what
  translation runs write, the first winning where both hold a string.
- One request per page, or per section of a long page given its neighbours and
  the page's outline, a section itself above the size divided at its own
  headings and then into runs of segments, and per-language prompt files beside
  an optional general one.
- One validation of every reply, in both transports, segment by segment: markup,
  protected spans, do-not-translate terms, and UTF-8 text decoded in a
  single-byte code page are each a defect of the one segment; an identifier the
  request did not ask for is dropped and logged, one returned twice is judged
  per segment, and a defect of the whole reply is stated once in the next
  request.
- Do-not-translate terms matched case-insensitively, or only as written with the
  glossary's `do_not_translate_case: "sensitive"`, a term bounded within its own
  script.
- Only the system prompt marked for caching; an output ceiling of at least 1,024
  tokens, with a reasoning allowance only on a request that can reason; and a
  refusal's resubmission on `model.fallbackId` with the configured effort and no
  thinking setting.
- A configuration reference, generated from the configuration's schema, in the
  README, with the install and wiring guide.
- Two modes, set by `mode`: `ci`, translating in CI, and `local`, translating
  on the developer's machine with the push refused until it is done.
- Two runnable examples, a JSON-content site and a Markdown corpus, each with
  its translation workflow and its collector; the JSON-content site also in the
  local mode, with its hook, `prepare` script and check workflow.
