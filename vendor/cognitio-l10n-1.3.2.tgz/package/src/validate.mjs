/**
 * validate.mjs — The one validation of a translation reply, applied by both
 * transports before anything reaches the memory.
 *
 * READS nothing and WRITES nothing: a pure function over a request's requested
 * units and the reply's entries.
 *
 * A reply is checked against the request that produced it:
 *   - THE IDENTIFIER SET. An identifier the request did not ask for is dropped
 *     and returned as `dropped`, for the caller to log; it rejects nothing, and
 *     each requested segment is still checked on its own. An identifier returned
 *     more than once with the same text each time — a page that holds one text
 *     twice lists it twice in the context — is checked once like any other; one
 *     returned with different texts rejects that segment alone. An omitted
 *     identifier rejects that segment.
 *   - THE WHOLE REPLY is rejected only when it carries no entries at all; that
 *     defect is returned as `replyDefect`, so the caller states it once.
 *   - PER SEGMENT, against the unit's own source:
 *       - an empty translation of a non-empty source;
 *       - UTF-8 text decoded in a single-byte code page (`doubleEncodedSequences`)
 *         that the source does not hold;
 *       - HTML tags and comments — generated-section markers among them — that
 *         differ from the source's, as a multiset; and, for an `html` unit whose
 *         source is balanced, a translation that is not. In a `markdown` unit the
 *         text inside inline code is not HTML, since Markdown does not read it as
 *         HTML, so it is left out of this count on both sides; the inline code
 *         itself is kept byte for byte by the check below. A placeholder such as
 *         `<name>` that the source holds inside inline code, and the translation
 *         writes outside it, is named as such, since the page reads it as a tag;
 *       - for a `markdown` unit, a protected span the unit stores (inline code,
 *         a link or image destination, inline HTML, a reference, a character
 *         reference) that the translation no longer contains, and any protected
 *         span the translation adds or alters, comparing the source slice and
 *         the translation each parsed on its own. Each protected string is
 *         compared on its own: two that only touch — inline code ending a link's
 *         text, and the destination after it — are two strings on either side,
 *         so a translation may set apart what its source joins, or join what its
 *         source sets apart (`protectedPieces`). The one addition it accepts is
 *         inline code holding nothing but a placeholder the source holds inside
 *         its own inline code, bare or in straight quotes as the source writes
 *         it (`<name>`, `"<name>"`, `'<name>'`) — copied out of an English
 *         message into its translation, it stays code, which is where the page
 *         needs it;
 *       - for a `markdown` unit, a line break the page cannot take: one in a
 *         translation whose source is on one line, an empty line, or a line
 *         that opens a new block (`lineBreakDefect`);
 *       - a do-not-translate term the source contains, in the casing it
 *         occurs with, that the translation drops. A term is found in the
 *         source in any casing by default, and only as written when the
 *         caller passes `caseSensitive`, which it reads from the glossary
 *         through `doNotTranslateOf` (`translator-prompt.mjs`), the reading
 *         rule 1 of the instructions states; an entry `{ term, caseSensitive }`
 *         (`doNotTranslateOf(glossary).entries`) is matched in its own mode.
 *         In either mode a term written
 *         in Latin letters matches where no Latin letter or digit stands
 *         directly before or after it, a letter of another script included
 *         (`Aggrega의`), and any other term where no letter or digit does. An
 *         entry with `forms` — the other forms of one term, such as a plural —
 *         is kept where the translation holds the occurrence or any of its forms,
 *         each matched in the entry's mode.
 * A rejected segment is never written; its defect is the text stated to the
 * model in the segment's next request.
 *
 * A CHECK THAT FAILS ITSELF — a segment the package cannot judge, never a defect
 * of the translation — leaves the segment in `internal` with the error, apart
 * from `accepted` and `rejected`: the caller writes nothing for it, states nothing
 * to the model, and counts no attempt for it.
 */

import { isBalancedHtml } from './translator-prompt.mjs';
import { protectedPieces, standaloneProtectedSpans } from './adapters/markdown/segment.mjs';
import { MarkdownSourceError } from './adapters/markdown/source-error.mjs';

/**
 * The most characters of a rejected translation a job log records with its
 * failure (`recordedText`): above every accepted translation of a large
 * documentation corpus but a few dozen, so a longer one is cut rather than left
 * to swell the log.
 */
export const RECORDED_TEXT_LIMIT = 8000;

/**
 * A rejected translation as a job log records it with its failure, so a defect
 * can be told from a checker's mistake without the request being paid for again:
 * `{ text }`, the text cut at `RECORDED_TEXT_LIMIT` characters with
 * `textLength`, its whole length, when it is longer; nothing for a segment the
 * reply did not return.
 *
 * @param {string|undefined} text
 * @returns {{text?: string, textLength?: number}}
 */
export function recordedText(text) {
  if (typeof text !== 'string') return {};
  const chars = [...text];
  return chars.length > RECORDED_TEXT_LIMIT ? { text: chars.slice(0, RECORDED_TEXT_LIMIT).join(''), textLength: chars.length } : { text };
}

/**
 * The text a reply returned for each identifier, the first where it returned one
 * more than once: what a job log records beside a rejected segment's defect.
 *
 * @param {Array<{id:string, text:string}>|null|undefined} entries
 * @returns {Map<string, string>}
 */
export function returnedTexts(entries) {
  const texts = new Map();
  for (const entry of entries || []) if (!texts.has(entry.id)) texts.set(entry.id, entry.text);
  return texts;
}

/** The error a check raises when it cannot judge a segment: the package's fault, never the translation's. */
export class InternalCheckError extends Error {
  constructor(message, cause) {
    super(message);
    this.name = 'InternalCheckError';
    if (cause !== undefined) this.cause = cause;
  }
}

/** HTML comments (generated-section markers included) and tags, as written. */
const MARKUP_RE = /<!--[\s\S]*?-->|<\/?[A-Za-z][^<>]*>/g;

const escapeRegExp = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

/** Elements of `expected` absent from `actual`, and of `actual` absent from `expected`, as multisets. */
function multisetDifference(expected, actual) {
  const counts = new Map();
  for (const x of expected) counts.set(x, (counts.get(x) || 0) + 1);
  const extra = [];
  for (const x of actual) {
    const n = counts.get(x) || 0;
    if (n > 0) counts.set(x, n - 1);
    else extra.push(x);
  }
  const missing = [];
  for (const [x, n] of counts) for (let i = 0; i < n; i++) missing.push(x);
  return { missing, extra };
}

/** Non-overlapping occurrences of `needle` in `haystack`. */
function occurrences(haystack, needle) {
  let count = 0;
  for (let at = haystack.indexOf(needle); needle && at !== -1; at = haystack.indexOf(needle, at + needle.length)) count++;
  return count;
}

const quoteAll = (list) => list.map((x) => JSON.stringify(x)).join(', ');

/** A placeholder: words in angle brackets, as an English message marks the part a value fills (`<name>`). */
const PLACEHOLDER_RE = /^<[A-Za-z][^<>`]*>$/;

/**
 * Inline code holding nothing but a placeholder: its backticks, one optional space
 * inside each, and the placeholder, bare or between two straight quotes of one kind
 * (`"<name>"`, `'<name>'`), as an English message may quote it.
 */
const CODE_PLACEHOLDER_RE = /^(`+) ?((["']?)<[A-Za-z][^<>`]*>\3) ?\1$/;

/** The content of an inline code span: what its backticks, and one space inside each when both are there, enclose. */
const codeContent = (span) => {
  const m = /^(`+)([\s\S]*)\1$/.exec(span);
  if (!m) return span;
  const inner = m[2];
  return inner.length > 1 && inner.startsWith(' ') && inner.endsWith(' ') ? inner.slice(1, -1) : inner;
};

/**
 * The Markdown reading of a segment's source or translation, parsed on its own:
 * its protected spans with their kinds, its text with every inline code span
 * blanked (what Markdown can read as HTML), and the contents of its inline code.
 * A translation whose generated-section markers do not pair up is a defect of the
 * translation, returned as `{defect}`; any other failure, and any failure on the
 * source, is the package's (`InternalCheckError`).
 *
 * @param {string} text
 * @param {'source'|'translation'} side
 */
function markdownView(text, side) {
  let spans;
  try {
    spans = standaloneProtectedSpans(text);
  } catch (err) {
    if (side === 'translation' && err instanceof MarkdownSourceError) {
      return { defect: `the translation's Markdown does not parse as the source's does: ${err.message}` };
    }
    throw new InternalCheckError(`reading the ${side} as Markdown failed (${(err && err.message) || err})`, err);
  }
  const code = spans.filter((span) => span.kind === 'inlineCode');
  let outsideCode = '';
  let at = 0;
  for (const span of code) {
    outsideCode += text.slice(at, span.start) + ' '.repeat(span.end - span.start);
    at = span.end;
  }
  outsideCode += text.slice(at);
  return { spans, outsideCode, codeContents: code.map((span) => codeContent(span.text)) };
}

/** Whether a placeholder stands inside the source's inline code. */
const placeholderInSourceCode = (md, placeholder) =>
  PLACEHOLDER_RE.test(placeholder) && md.source.codeContents.some((content) => content.includes(placeholder));

/** The markup defect of a segment, or null; `md` is the Markdown reading of a `markdown` unit, else null. */
function markupDefect(item, text, md) {
  const { missing, extra } = multisetDifference(
    (md ? md.source.outsideCode : item.source).match(MARKUP_RE) || [],
    (md ? md.translation.outsideCode : text).match(MARKUP_RE) || []
  );
  if (missing.length || extra.length) {
    const fromCode = md ? [...new Set(extra.filter((x) => placeholderInSourceCode(md, x)))] : [];
    const added = extra.filter((x) => !fromCode.includes(x));
    const parts = [];
    if (missing.length) parts.push(`missing ${quoteAll(missing)}`);
    if (added.length) parts.push(`added ${quoteAll(added)}`);
    for (const x of fromCode) {
      parts.push(`${JSON.stringify(x)} comes from inline code in the source, and outside inline code the page reads it as an HTML tag: keep it inside inline code, as \`${x}\``);
    }
    return `HTML tags or comments differ from the source: ${parts.join('; ')}`;
  }
  if (item.format === 'html' && isBalancedHtml(item.source) && !isBalancedHtml(text)) {
    return 'the HTML tags are no longer balanced as in the source';
  }
  return null;
}

/** The protected-span defect of a Markdown segment, or null. */
function markdownDefect(item, text, md) {
  // The stored spans, each cut where two of the source's own spans only touch: every string is required on its own.
  const stored = protectedPieces(item.source, item.protected || [], md.source.spans);
  const required = new Map();
  for (const span of stored) required.set(span, (required.get(span) || 0) + 1);
  const missing = [];
  for (const [span, n] of required) if (occurrences(text, span) < n) missing.push(span);
  const standalone = multisetDifference(
    md.source.spans.map((span) => span.text),
    md.translation.spans.map((span) => span.text)
  );
  // Inline code holding only a placeholder the source's inline code holds, quoted as there: where the page needs it.
  const extra = standalone.extra.filter((span) => {
    const m = CODE_PLACEHOLDER_RE.exec(span);
    return !(m && md.source.codeContents.some((content) => content.includes(m[2])));
  });
  const lost = [...new Set([...missing, ...standalone.missing])];
  if (lost.length || extra.length) {
    const parts = [];
    if (lost.length) parts.push(`missing or altered ${quoteAll(lost)}`);
    if (extra.length) parts.push(`added ${quoteAll(extra)}`);
    return `inline code, a link or image destination, HTML or a reference differs from the source: ${parts.join('; ')}`;
  }
  return null;
}

/**
 * The lines that open a Markdown block, or turn a paragraph into a heading,
 * when they follow a line of the paragraph: CommonMark's constructs that can
 * interrupt a paragraph — an ATX heading, a code fence, a blockquote, a bullet
 * list item and an ordered one numbered 1, a thematic break, the HTML blocks of
 * the first six kinds — a setext heading underline, and a GitHub table's
 * delimiter row.
 */
const BLOCK_OPENERS = [
  /^ {0,3}#{1,6}(?:[ \t]|$)/,
  /^ {0,3}(?:`{3,}|~{3,})/,
  /^ {0,3}>/,
  /^ {0,3}[-+*][ \t]+\S/,
  /^ {0,3}1[.)][ \t]+\S/,
  /^ {0,3}(?:(?:\*[ \t]*){3,}|(?:_[ \t]*){3,})$/,
  /^ {0,3}(?:=+|-+)[ \t]*$/,
  /^ {0,3}(?:-[ \t]*){3,}$/,
  /^ {0,3}<(?:script|pre|style|textarea|!--|\?|![A-Za-z]|!\[CDATA\[)/i,
  /^ {0,3}<\/?(?:address|article|aside|base|basefont|blockquote|body|caption|center|col|colgroup|dd|details|dialog|dir|div|dl|dt|fieldset|figcaption|figure|footer|form|frame|frameset|h[1-6]|head|header|hr|html|iframe|legend|li|link|main|menu|menuitem|nav|noframes|ol|optgroup|option|p|param|search|section|summary|table|tbody|td|tfoot|th|thead|title|tr|track|ul)(?:[ \t/>]|$)/i,
  /^ {0,3}\|?[ \t]*:?-+:?[ \t]*(?:\|[ \t]*:?-+:?[ \t]*)+\|?[ \t]*$/,
];

/** The leading spaces and `>` markers every continuation line of a source shares: its container's prefix. */
function continuationPrefix(source) {
  const prefixes = source.split('\n').slice(1).map((line) => line.match(/^[ \t>]*/)[0]);
  if (prefixes.length === 0) return '';
  let prefix = prefixes[0];
  for (const p of prefixes) while (!p.startsWith(prefix)) prefix = prefix.slice(0, -1);
  return prefix;
}

/**
 * The line-break defect of a Markdown segment, or null. A translation is spliced
 * into its page where the source slice stood, so a line break in it is read as
 * Markdown in the page: in a heading or a table cell, which a source writes on
 * one line, it ends the construct; in a paragraph, an empty line ends the
 * paragraph and a line opening a block (`BLOCK_OPENERS`) starts another. So a
 * translation breaks a line only where its source spans lines, and each line
 * after the first — read past the container prefix the source's continuation
 * lines carry, or as a lazy continuation without it — is neither empty nor a
 * block opener.
 */
function lineBreakDefect(item, text) {
  if (!text.includes('\n')) return null;
  if (!item.source.includes('\n')) {
    return 'the translation breaks a line that its source writes on one line, and in the page a line break can end a heading or a table cell or start a new block: write the translation on one line';
  }
  const prefix = continuationPrefix(item.source);
  const lines = text.split('\n');
  for (let i = 1; i < lines.length; i++) {
    const rest = lines[i].startsWith(prefix) ? lines[i].slice(prefix.length) : lines[i];
    if (rest.trim() === '') return `line ${i + 1} of the translation is empty, and an empty line ends the paragraph in the page: remove it`;
    if (BLOCK_OPENERS.some((re) => re.test(rest))) {
      return `line ${i + 1} of the translation begins with ${JSON.stringify(rest.trim().slice(0, 12))}, which starts a new Markdown block in the page: move the line break, or write the translation on one line`;
    }
  }
  return null;
}

/** A term written in Latin letters: at least one Latin letter, and no letter of another script. */
const LATIN_TERM_RE = /^(?=.*\p{Script=Latin})[\p{Script=Latin}\P{L}]*$/su;

/**
 * The characters a do-not-translate term may not continue into, on either side:
 * the boundary applies within the term's own script. A term written in Latin
 * letters is bounded by a Latin letter or a digit, so `Componentize` holds no
 * `Component`, while `Component를`, `Componentを` and `Component的` do, a
 * particle or a word of another script standing directly against it. Any other
 * term is bounded by a letter or a digit of any script. Rule 1 of the general
 * rules (`translator-prompt.mjs`) states the same boundary to the model.
 */
const termEdge = (term) => (LATIN_TERM_RE.test(term) ? '[\\p{Script=Latin}\\p{N}]' : '[\\p{L}\\p{N}]');

/**
 * The byte each character of a single-byte code page stands for, for the bytes
 * 0x80 to 0xFF, merged over the code pages UTF-8 text is most often mis-decoded
 * through: Windows-1252, Windows-1250 and ISO-8859-1 (the last read by code
 * point, since the platform decoder reads `iso-8859-1` as Windows-1252). A
 * character two code pages give different bytes keeps each code page's own map.
 */
const CODE_PAGE_MAPS = (() => {
  const maps = [];
  for (const label of ['windows-1252', 'windows-1250']) {
    const decoder = new TextDecoder(label);
    const map = new Map();
    for (let byte = 0x80; byte <= 0xff; byte++) map.set(decoder.decode(Uint8Array.of(byte)), byte);
    maps.push(map);
  }
  const latin1 = new Map();
  for (let byte = 0x80; byte <= 0xff; byte++) latin1.set(String.fromCharCode(byte), byte);
  maps.push(latin1);
  return maps;
})();

const UTF8 = new TextDecoder('utf-8', { fatal: true });

/**
 * Whether the bytes form one UTF-8 character of the kinds double encoding
 * produces in translated prose: a Latin letter or sign from U+0080 to U+017F
 * (two bytes, lead 0xC2 to 0xC5), general punctuation, a currency or letterlike
 * sign from U+2000 to U+21BF (three bytes, lead 0xE2), or a CJK, kana or Hangul
 * character from U+3000 to U+9FFF (three bytes, lead 0xE3 to 0xE9). A sequence
 * holding 0xA0, the no-break space, is never one: an accented capital or a
 * letter followed by a no-break space and a guillemet, as French typography
 * writes « CAFÉ », reads as such bytes in a single-byte code page.
 */
function isDoubleEncoded(bytes) {
  if (bytes.slice(1).some((b) => b < 0x80 || b > 0xbf || b === 0xa0)) return false;
  const [lead, second] = bytes;
  if (bytes.length === 2 && !(lead >= 0xc2 && lead <= 0xc5)) return false;
  if (bytes.length === 3 && !((lead === 0xe2 && second <= 0x86) || (lead >= 0xe3 && lead <= 0xe9))) return false;
  try {
    return [...UTF8.decode(Uint8Array.from(bytes))].length === 1;
  } catch {
    return false;
  }
}

/**
 * The double-encoded UTF-8 sequences a text holds: each run of two or three
 * characters that, read back as the bytes of one single-byte code page
 * (`CODE_PAGE_MAPS`), is one UTF-8 character (`isDoubleEncoded`) — `Ã©` for `é`,
 * `â€”` for `—`, `Ă¤` for `ä`. Distinct, in order of first occurrence.
 *
 * @param {string} text
 * @returns {string[]}
 */
export function doubleEncodedSequences(text) {
  const found = [];
  const chars = [...(typeof text === 'string' ? text : '')];
  for (const map of CODE_PAGE_MAPS) {
    for (let i = 0; i < chars.length; i++) {
      for (const length of [3, 2]) {
        const run = chars.slice(i, i + length);
        if (run.length !== length || !run.every((c) => map.has(c))) continue;
        if (!isDoubleEncoded(run.map((c) => map.get(c)))) continue;
        const sequence = run.join('');
        if (!found.includes(sequence)) found.push(sequence);
        i += length - 1;
        break;
      }
    }
  }
  return found;
}

/** The double-encoding defect of a segment: sequences its translation holds and its source does not; or null. */
function doubleEncodingDefect(item, text) {
  const added = doubleEncodedSequences(text).filter((sequence) => !item.source.includes(sequence));
  return added.length
    ? `the translation holds UTF-8 text decoded in a single-byte code page (${quoteAll(added)}); write each character as itself`
    : null;
}

/** A term matched where no letter or digit of its script stands against it (`termEdge`), in the given flags. */
const boundedTerm = (s, flags) => {
  const edge = termEdge(s);
  return new RegExp(`(?<!${edge})${escapeRegExp(s)}(?!${edge})`, flags);
};

/** The do-not-translate defect of a segment, or null. */
function doNotTranslateDefect(item, text, terms, caseSensitive) {
  const dropped = [];
  for (const entry of terms) {
    // An entry is a term, matched in the list's mode, or `{ term, caseSensitive, forms? }` (`doNotTranslateOf(glossary).entries`).
    const term = typeof entry === 'string' ? entry : entry && entry.term;
    const sensitive = typeof entry === 'string' ? caseSensitive : Boolean(entry && entry.caseSensitive);
    const forms = (entry && typeof entry === 'object' && Array.isArray(entry.forms) ? entry.forms : []).filter((f) => typeof f === 'string' && f);
    if (typeof term !== 'string' || !term) continue;
    for (const occurrence of new Set(item.source.match(boundedTerm(term, sensitive ? 'gu' : 'giu')) || [])) {
      if (boundedTerm(occurrence, 'u').test(text)) continue;
      if (forms.some((form) => boundedTerm(form, sensitive ? 'u' : 'iu').test(text))) continue;
      dropped.push(forms.length ? `${JSON.stringify(occurrence)} (or ${forms.map((f) => JSON.stringify(f)).join(', or ')})` : JSON.stringify(occurrence));
    }
  }
  return dropped.length ? `the do-not-translate term ${dropped.join(', ')} is missing; keep it verbatim` : null;
}

/**
 * The defect of one translated segment against its unit, or null when it passes.
 *
 * @param {{source:string, format?:string, protected?:Array<[number,number]>}} item
 * @param {string} text
 * @param {Array<string|{term:string, caseSensitive:boolean, forms?:string[]}>} [doNotTranslate]  terms, or entries with their own mode.
 * @param {{caseSensitive?: boolean}} [options]  `caseSensitive`: find each plain term in the source only as written.
 * @returns {string|null}
 * @throws {InternalCheckError} when the segment cannot be judged: the package's failure, never a defect of the translation.
 */
export function segmentDefect(item, text, doNotTranslate = [], { caseSensitive = false } = {}) {
  if (typeof text !== 'string' || (text.trim() === '' && item.source.trim() !== '')) return 'the translation is empty';
  const encoding = doubleEncodingDefect(item, text);
  if (encoding) return encoding;
  let md = null;
  if (item.format === 'markdown') {
    const translation = markdownView(text, 'translation');
    if (translation.defect) return markupDefect(item, text, null) || translation.defect;
    md = { source: markdownView(item.source, 'source'), translation };
  }
  return (
    markupDefect(item, text, md) ||
    (md ? markdownDefect(item, text, md) || lineBreakDefect(item, text) : null) ||
    doNotTranslateDefect(item, text, doNotTranslate, caseSensitive)
  );
}

/**
 * Validates a reply against the request that produced it.
 *
 * @param {Object} args
 * @param {Array<{srcHash:string, source:string, format?:string, protected?:Array<[number,number]>}>} args.items
 *        the requested units, in request order.
 * @param {Array<{id:string, text:string}>|null} args.entries  the reply's entries, or null when it had none.
 * @param {string} [args.replyDefect]       why the reply had no entries.
 * @param {Array<string|{term:string, caseSensitive:boolean}>} [args.doNotTranslate]  the glossary's do-not-translate
 *        terms (`doNotTranslateOf(glossary).terms`), or its entries with their own modes (`.entries`).
 * @param {boolean} [args.caseSensitive]    whether they match only as written (`doNotTranslateOf(glossary).caseSensitive`).
 * @returns {{accepted: Object.<string,string>, rejected: Object.<string,string>, dropped: string[], internal?: Object.<string,string>, replyDefect?: string}}
 *          identifier → translation, identifier → defect and, only when a check failed itself, identifier → the
 *          error that stopped it (`internal`), every requested identifier in exactly one;
 *          the identifiers the reply returned that the request did not ask for, each once, in reply order;
 *          and, only when every segment was rejected for one defect of the whole reply, that defect.
 */
export function validateTranslations({ items, entries, replyDefect, doNotTranslate = [], caseSensitive = false }) {
  const accepted = {};
  const rejected = {};
  const internal = {};
  const dropped = [];
  const rejectAll = (defect) => {
    for (const item of items) rejected[item.srcHash] = defect;
    return { accepted: {}, rejected, dropped, replyDefect: defect };
  };
  if (!Array.isArray(entries)) return rejectAll(replyDefect || 'the reply carried no translations');

  const requested = new Set(items.map((item) => item.srcHash));
  const texts = new Map();
  for (const entry of entries) {
    if (!requested.has(entry.id)) {
      if (!dropped.includes(entry.id)) dropped.push(entry.id);
    } else if (texts.has(entry.id)) texts.get(entry.id).push(entry.text);
    else texts.set(entry.id, [entry.text]);
  }
  for (const item of items) {
    if (!texts.has(item.srcHash)) {
      rejected[item.srcHash] = 'no translation was returned for this identifier';
      continue;
    }
    const returned = texts.get(item.srcHash);
    if (new Set(returned).size > 1) {
      rejected[item.srcHash] = `this identifier was returned ${returned.length} times with different texts; return it exactly once`;
      continue;
    }
    const text = returned[0];
    let defect;
    try {
      defect = segmentDefect(item, text, doNotTranslate, { caseSensitive });
    } catch (err) {
      // A check that fails is the package's fault: the segment is neither accepted nor rejected.
      internal[item.srcHash] = err instanceof InternalCheckError ? err.message : `a check failed (${(err && err.message) || err})`;
      continue;
    }
    if (defect) rejected[item.srcHash] = defect;
    else accepted[item.srcHash] = text;
  }
  return { accepted, rejected, dropped, ...(Object.keys(internal).length ? { internal } : {}) };
}

export default { validateTranslations, segmentDefect, doubleEncodedSequences, InternalCheckError, recordedText, returnedTexts, RECORDED_TEXT_LIMIT };
