import '../test/no-network.mjs';
import { describe, it, expect } from 'vitest';

import { validateTranslations } from './validate.mjs';
import { doNotTranslateOf, glossaryTerms, translationRules } from './translator-prompt.mjs';

/** Judges one translation against one source, under a glossary, as every transport does. */
function judge(glossary, source, text) {
  const { entries, caseSensitive } = doNotTranslateOf(glossary);
  return validateTranslations({ items: [{ srcHash: 's', source, format: 'text' }], entries: [{ id: 's', text }], doNotTranslate: entries, caseSensitive });
}

const SENSITIVE = { do_not_translate_case: 'sensitive' };

describe('a do-not-translate term in several forms', () => {
  const family = { ...SENSITIVE, do_not_translate: [{ term: 'Release', forms: ['Releases'] }, 'Recipe'] };

  it('keeps a plural where the translation writes the singular, as a language without plural forms does', () => {
    expect(judge(family, 'Two Releases share it.', '两个 Release 共享它。').accepted).toEqual({ s: '两个 Release 共享它。' });
    expect(judge(family, 'One Release.', '두 Releases.').accepted).toEqual({ s: '두 Releases.' });
  });

  it('still refuses a translated term, naming its forms', () => {
    expect(judge(family, 'Two Releases share it.', '两个版本共享它。').rejected.s).toBe(
      'the do-not-translate term "Releases" (or "Release") is missing; keep it verbatim'
    );
  });

  it('leaves a term without forms as it was: its plural is another word', () => {
    expect(judge(family, 'A Recipe.', 'Una Recipes.').rejected.s).toBe('the do-not-translate term "Recipe" is missing; keep it verbatim');
  });

  it('gives a term the list also names on its own the forms of the entry naming it', () => {
    // The two forms already listed apart, as a glossary written before forms existed lists them, and one entry joining them.
    const both = { ...SENSITIVE, do_not_translate: ['Release', 'Releases', { term: 'Release', forms: ['Releases'] }] };
    expect(judge(both, 'Two Releases.', '두 Release.').accepted).toEqual({ s: '두 Release.' });
  });

  it('matches a form in the entry’s mode', () => {
    expect(judge(family, 'Two Releases.', '두 release.').rejected.s).toBe('the do-not-translate term "Releases" (or "Release") is missing; keep it verbatim');
    const insensitive = { do_not_translate: [{ term: 'Release', forms: ['Releases'] }] };
    expect(judge(insensitive, 'Two Releases.', '두 release.').accepted).toEqual({ s: '두 release.' });
  });
});

describe('doNotTranslateOf — the forms of a term', () => {
  it('reads every member of a family as a term, each with the others as its forms', () => {
    const { terms, entries } = doNotTranslateOf({ ...SENSITIVE, do_not_translate: [{ term: 'Feature', forms: ['Features'] }, 'Plugin'] });
    expect(terms).toEqual(['Feature', 'Plugin']);
    expect(entries).toEqual([
      { term: 'Feature', caseSensitive: true, own: false, forms: ['Features'] },
      { term: 'Plugin', caseSensitive: true, own: false },
      { term: 'Features', caseSensitive: true, own: false, forms: ['Feature'], listed: false },
    ]);
  });

  it('refuses forms that are not a list of other non-empty terms, naming the entry', () => {
    for (const forms of [[], ['Feature'], [''], [1], 'Features']) {
      expect(() => doNotTranslateOf({ do_not_translate: [{ term: 'Feature', forms }] })).toThrow(/"do_not_translate" entry 0/);
    }
  });

  it('leaves a glossary without forms read exactly as before', () => {
    const glossary = { do_not_translate: ['Acme', { term: 'LASTRA', case: 'sensitive' }] };
    expect(doNotTranslateOf(glossary).entries).toEqual([
      { term: 'Acme', caseSensitive: false, own: false },
      { term: 'LASTRA', caseSensitive: true, own: true },
    ]);
    expect(translationRules({ glossary })).not.toContain('(or …)');
  });
});

describe('the instructions state a term’s forms', () => {
  const glossary = { ...SENSITIVE, do_not_translate: [{ term: 'Release', forms: ['Releases'] }] };

  it('lists the term with its forms, and the forms no entry lists apart once, beside it', () => {
    expect(glossaryTerms({ glossary })).toContain('  - "Release" (or "Releases")');
    expect(glossaryTerms({ glossary })).not.toContain('  - "Releases"');
  });

  it('says in rule 1 that any form keeps the term, and never a translation', () => {
    expect(translationRules({ glossary })).toContain('one term in several forms');
    expect(translationRules({ glossary })).toContain('never a translation');
  });
});
